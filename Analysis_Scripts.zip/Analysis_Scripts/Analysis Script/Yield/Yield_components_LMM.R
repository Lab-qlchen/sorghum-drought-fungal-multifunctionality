rm(list = ls())
options(stringsAsFactors = FALSE, contrasts = c("contr.sum", "contr.poly"))
required_packages <- c("lme4", "lmerTest", "emmeans", "multcomp", "multcompView", "dplyr", "tibble", "ggplot2")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/产量相关")
input_file <- "Yield_components_splitplot_data.csv"
output_dir <- "Yield_components_LMM_pooled_95CI_outputs"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
genotype_levels <- c("Jinza 22", "Liangnuo 01")
write_csv_out <- function (x, filename) {
  utils::write.csv(x, file.path(output_dir, filename), row.names = FALSE)
}
dat_y <- utils::read.csv(input_file, check.names = FALSE, fileEncoding = "UTF-8-BOM")
required_cols <- c("PlotID", "Block", "Genotype", "Treatment", "Grain_yield_t_ha", "Panicle_density_m2", "Grain_weight_per_panicle_g")
missing_cols <- setdiff(required_cols, names(dat_y))
if (length(missing_cols) > 0L) {
  stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
}
numeric_cols <- c("Grain_yield_t_ha", "Panicle_density_m2", "Grain_weight_per_panicle_g")
dat_y[numeric_cols] <- lapply(dat_y[numeric_cols], as.numeric)
tol <- 1e-7
dat_y$Yield_from_components <- with(dat_y, Panicle_density_m2 * Grain_weight_per_panicle_g * 0.01)
max_identity_difference <- max(abs(dat_y$Grain_yield_t_ha - dat_y$Yield_from_components), na.rm = TRUE)
if (!is.finite(max_identity_difference) || max_identity_difference > tol) {
  stop("The three yield variables do not match. Maximum yield difference = ", signif(max_identity_difference, 6))
}
dat_y <- dat_y |> dplyr::mutate(PlotID = factor(PlotID, levels = unique(PlotID)), Block = factor(Block, levels = 1:4), Genotype = factor(Genotype, levels = c("Jinza",
  "Liangnuo"), labels = genotype_levels), Drought = factor(Treatment, levels = drought_levels))
dat_y$MainPlotID <- interaction(dat_y$Block, dat_y$Drought, drop = TRUE, sep = "_")
if (nrow(dat_y) != 32L || dplyr::n_distinct(dat_y$MainPlotID) != 16L || anyNA(dat_y[, c("PlotID", "Block", "Genotype", "Drought", "MainPlotID", numeric_cols)])) {
  stop("Expected 32 complete subplot observations and 16 Block x Drought main plots.")
}
design_check <- dat_y |> dplyr::count(Block, Drought, Genotype, name = "n")
if (nrow(design_check) != 32L || any(design_check$n != 1L)) {
  stop("Each Block x Drought x Genotype cell must contain exactly one observation.")
}
mainplot_check <- dat_y |> dplyr::count(MainPlotID, name = "n")
if (nrow(mainplot_check) != 16L || any(mainplot_check$n != 2L)) {
  stop("Expected 16 main plots with exactly two genotype subplots per main plot.")
}
write_csv_out(design_check, "00_design_check.csv")
write_csv_out(mainplot_check, "00_mainplot_check.csv")
write_csv_out(data.frame(Check = "Grain yield versus component product", Maximum_absolute_difference = max_identity_difference), "00_rowwise_formula_checks.csv")
lmm_control <- lme4::lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))
anova_lmm <- function (model) {
  kr <- tryCatch(stats::anova(model, type = 3, ddf = "Kenward-Roger"), error = function (e) NULL)
  if (!is.null(kr)) {
    return(list(table = kr, method = "Kenward-Roger"))
  }
  list(table = stats::anova(model, type = 3, ddf = "Satterthwaite"), method = "Satterthwaite")
}
tidy_lmm_anova <- function (result, trait_title) {
  out <- as.data.frame(result$table)
  out$Effect <- rownames(out)
  rownames(out) <- NULL
  out |> dplyr::relocate(Effect) |> dplyr::mutate(Trait = trait_title, DDF_method = result$method, partial_eta2 = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF)) |>
    dplyr::relocate(Trait, .before = Effect)
}
convergence_message <- function (model) {
  msg <- model@optinfo$conv$lme4$messages
  if (is.null(msg)) "None" else paste(msg, collapse = "; ")
}
fmt_p <- function (p) {
  if (is.na(p) || !is.finite(p)) return("NA")
  if (p < 0.001) "< 0.001" else paste0("= ", sprintf("%.3f", p))
}
anova_line <- function (tab, effect, label) {
  z <- tab |> dplyr::filter(Effect == effect)
  if (nrow(z) != 1L) {
    return(paste0(label, ": unavailable"))
  }
  paste0(label, ": F(", sprintf("%.0f", z$NumDF), ", ", sprintf("%.1f", z$DenDF), ") = ", sprintf("%.2f", z$`F value`), ", P ", fmt_p(z$`Pr(>F)`), ", partial eta2 = ",
    sprintf("%.3f", z$partial_eta2))
}
get_y_label <- function (trait_col) {
  switch (trait_col, Panicle_density_m2 = expression(Panicle ~ density ~ (panicles ~ m ^ { - 2})), Grain_weight_per_panicle_g = expression(Grain ~ weight ~ per ~ panicle
    ~ (g ~ panicle ^ { - 1})), Grain_yield_t_ha = expression(Grain ~ yield ~ (t ~ ha ^ { - 1})), trait_col)
}
safe_range <- function (x) {
  z <- diff(range(x, na.rm = TRUE))
  if (!is.finite(z) || z <= 0) {
    z <- max(abs(x), na.rm = TRUE) * 0.10
  }
  if (!is.finite(z) || z <= 0) {
    z <- 1
  }
  z
}
analyze_lmm_trait <- function (data, trait_col, trait_title, prefix) {
  data$TraitValue <- as.numeric(data[[trait_col]])
  if (anyNA(data$TraitValue) || any(!is.finite(data$TraitValue))) {
    stop(trait_col, " contains missing, non-numeric, or non-finite values.")
  }
  fit <- lmerTest::lmer(TraitValue ~ Block + Drought * Genotype + (1 | MainPlotID), data = data, REML = TRUE, control = lmm_control)
  fit_singular <- lme4::isSingular(fit, tol = 1e-5)
  fit_anova_result <- anova_lmm(fit)
  fit_anova <- tidy_lmm_anova(fit_anova_result, trait_title)
  write_csv_out(fit_anova, paste0(prefix, "_LMM_Type3_ANOVA.csv"))
  capture.output(summary(fit), file = file.path(output_dir, paste0(prefix, "_LMM_summary.txt")))
  write_csv_out(as.data.frame(lme4::VarCorr(fit)), paste0(prefix, "_LMM_random_variance.csv"))
  model_check <- tibble::tibble(Trait = trait_title, Singular_fit = fit_singular, Convergence_message = convergence_message(fit), DDF_method = fit_anova_result$method)
  write_csv_out(model_check, paste0(prefix, "_LMM_model_check.csv"))
  raw_summary <- data |> dplyr::group_by(Drought, Genotype) |> dplyr::summarise(n = dplyr::n(), mean = mean(TraitValue), sd = stats::sd(TraitValue), sem = sd / sqrt(n),
    .groups = "drop")
  write_csv_out(raw_summary, paste0(prefix, "_Drought_Genotype_raw_Mean_SEM.csv"))
  raw_values <- data |> dplyr::select(PlotID, Block, MainPlotID, Drought, Genotype, TraitValue)
  write_csv_out(raw_values, paste0(prefix, "_raw_subplot_values.csv"))
  emm_drought <- emmeans::emmeans(fit, ~ Drought, weights = "equal")
  emm_drought_df <- as.data.frame(emm_drought)
  drought_tukey_df <- as.data.frame(emmeans::contrast(emm_drought, method = "pairwise", adjust = "tukey"))
  drought_letters_df <- multcomp::cld(emm_drought, adjust = "tukey", Letters = letters, sort = FALSE) |> as.data.frame() |> dplyr::mutate(.group = trimws(.group), Drought
    = factor(Drought, levels = drought_levels)) |> dplyr::select(Drought, emmean, SE, df, lower.CL, upper.CL, .group)
  write_csv_out(emm_drought_df, paste0(prefix, "_Drought_adjusted_means.csv"))
  write_csv_out(drought_tukey_df, paste0(prefix, "_Drought_Tukey.csv"))
  write_csv_out(drought_letters_df, paste0(prefix, "_Drought_letters.csv"))
  emm_drought_by_genotype <- emmeans::emmeans(fit, ~ Drought | Genotype, weights = "equal")
  drought_by_genotype_tukey <- as.data.frame(emmeans::contrast(emm_drought_by_genotype, method = "pairwise", adjust = "tukey"))
  drought_by_genotype_letters <- multcomp::cld(emm_drought_by_genotype, adjust = "tukey", Letters = letters, sort = FALSE) |> as.data.frame() |> dplyr::mutate(.group =
    trimws(.group), Drought = factor(Drought, levels = drought_levels), Genotype = factor(Genotype, levels = genotype_levels))
  write_csv_out(as.data.frame(emm_drought_by_genotype), paste0(prefix, "_EMMeans_Drought_within_Genotype.csv"))
  write_csv_out(drought_by_genotype_tukey, paste0(prefix, "_Tukey_Drought_within_Genotype.csv"))
  write_csv_out(drought_by_genotype_letters, paste0(prefix, "_Letters_Drought_within_Genotype.csv"))
  emm_genotype_by_drought <- emmeans::emmeans(fit, ~ Genotype | Drought, weights = "equal")
  genotype_by_drought_tukey <- as.data.frame(emmeans::contrast(emm_genotype_by_drought, method = "pairwise", adjust = "tukey"))
  write_csv_out(as.data.frame(emm_genotype_by_drought), paste0(prefix, "_EMMeans_Genotype_within_Drought.csv"))
  write_csv_out(genotype_by_drought_tukey, paste0(prefix, "_Tukey_Genotype_within_Drought.csv"))
  residual_values <- stats::residuals(fit)
  fitted_values <- stats::fitted(fit)
  capture.output(cat("Trait: ", trait_title, "\n", sep = ""), cat("Primary model:\n"), cat("TraitValue ~ Block + Drought * Genotype + (1 | MainPlotID)\n\n"), cat(
    "Singular fit: ", fit_singular, "\n", sep = ""), cat("Convergence message: ", convergence_message(fit), "\n\n", sep = ""), cat("Residual Shapiro-Wilk test\n"), print(
    stats::shapiro.test(residual_values)), file = file.path(output_dir, paste0(prefix, "_LMM_diagnostics.txt")))
  grDevices::pdf(file.path(output_dir, paste0(prefix, "_LMM_diagnostics.pdf")), width = 8, height = 7)
  graphics::par(mfrow = c(2, 2))
  graphics::plot(fitted_values, residual_values, xlab = "Fitted values", ylab = "Residuals", main = "Residuals vs fitted")
  graphics::abline(h = 0, lty = 2)
  stats::qqnorm(residual_values, main = "Normal Q-Q")
  stats::qqline(residual_values, col = "red")
  graphics::hist(residual_values, main = "Residual distribution", xlab = "Residual")
  graphics::boxplot(residual_values ~ interaction(data$Drought, data$Genotype), xlab = "Drought x genotype", ylab = "Residual", main = "Residuals by cell", las = 2)
  grDevices::dev.off()
  plot_df <- drought_letters_df |> dplyr::mutate(Drought = factor(Drought, levels = drought_levels))
  data <- data |> dplyr::mutate(Drought = factor(Drought, levels = drought_levels))
  trait_range <- safe_range(c(data$TraitValue, plot_df$emmean))
  plot_df <- plot_df |> dplyr::mutate(letter_y = pmax(upper.CL, emmean + SE) + 0.05 * trait_range)
  y_top <- max(plot_df$letter_y, na.rm = TRUE)
  label_text <- paste("Split-plot LMM", anova_line(fit_anova, "Drought", "Drought"), anova_line(fit_anova, "Genotype", "Genotype"), anova_line(fit_anova,
    "Drought:Genotype", "Drought x Genotype"), sep = "\n")
  annotation_df <- data.frame(Drought = factor("Control", levels = drought_levels), y = y_top + 0.34 * trait_range, label = label_text)
  p_trait <- ggplot2::ggplot(plot_df, ggplot2::aes(x = Drought, y = emmean, fill = Drought)) + ggplot2::geom_col(width = 0.65, color = "black", alpha = 0.86) + ggplot2::
    geom_errorbar(ggplot2::aes(ymin = lower.CL, ymax = upper.CL), width = 0.20, linewidth = 0.45) + ggplot2::geom_text(ggplot2::aes(y = letter_y, label = .group), size =
    5, show.legend = FALSE) + ggplot2::geom_text(data = annotation_df, ggplot2::aes(x = Drought, y = y, label = label), hjust = 0, vjust = 1, size = 3.1, lineheight =
    1.02, inherit.aes = FALSE) + ggplot2::scale_fill_manual(values = c(Control = "#E76F61", Drought_L = "#7BAE29", Drought_M = "#20AEB7", Drought_H = "#9B7BB5")) +
    ggplot2::scale_x_discrete(labels = c(Control = "Control", Drought_L = "Light drought", Drought_M = "Moderate drought", Drought_H = "Heavy drought")) + ggplot2::
    coord_cartesian(ylim = c(NA, y_top + 0.42 * trait_range), clip = "off") + ggplot2::labs(title = trait_title, x = NULL, y = get_y_label(trait_col), subtitle =
    "Bars = LMM-adjusted marginal means; error bars = 95% CI") + ggplot2::theme_bw(base_size = 11) + ggplot2::theme(legend.position = "none", plot.title = ggplot2::
    element_text(hjust = 0.5, face = "bold", size = 11), axis.text.x = ggplot2::element_text(angle = 25, hjust = 1), panel.grid.minor = ggplot2::element_blank(),
    plot.margin = ggplot2::margin(10, 20, 10, 10))
  ggplot2::ggsave(file.path(output_dir, paste0(prefix, "_Drought_pooled_LMM_95CI.pdf")), plot = p_trait, width = 7.2, height = 5.0)
  ggplot2::ggsave(file.path(output_dir, paste0(prefix, "_Drought_pooled_LMM_95CI.png")), plot = p_trait, width = 7.2, height = 5.0, dpi = 600)
  list(trait_col = trait_col, prefix = prefix, anova = fit_anova, model_check = model_check, plot = p_trait, fit = fit)
}
analysis_list <- list(analyze_lmm_trait(dat_y, "Panicle_density_m2", "Panicle density", "Panicle_density"), analyze_lmm_trait(dat_y, "Grain_weight_per_panicle_g",
  "Grain weight per panicle", "Grain_weight_per_panicle"), analyze_lmm_trait(dat_y, "Grain_yield_t_ha", "Grain yield", "Grain_yield"))
combined_anova <- dplyr::bind_rows(lapply(analysis_list, `[[`, "anova"))
write_csv_out(combined_anova, "All_traits_LMM_Type3_ANOVA.csv")
combined_model_check <- dplyr::bind_rows(lapply(analysis_list, `[[`, "model_check"))
write_csv_out(combined_model_check, "All_traits_LMM_model_check.csv")
final_plot_list <- list(analysis_list[[3]]$plot, analysis_list[[1]]$plot, analysis_list[[2]]$plot)
draw_three_panels <- function (device_fun, filename, ...) {
  device_fun(filename, ...)
  grid::grid.newpage()
  grid::pushViewport(grid::viewport(layout = grid::grid.layout(nrow = 1, ncol = 3)))
  for (i in seq_along(final_plot_list)) {
    print(final_plot_list[[i]], vp = grid::viewport(layout.pos.row = 1, layout.pos.col = i))
  }
  grDevices::dev.off()
}
draw_three_panels(grDevices::pdf, file.path(output_dir, "Yield_components_three_panel_pooled_LMM_95CI.pdf"), width = 18, height = 5.2)
draw_three_panels(grDevices::png, file.path(output_dir, "Yield_components_three_panel_pooled_LMM_95CI.png"), width = 5400, height = 1560, res = 300)
print(combined_anova)
if (interactive()) {
  utils::View(combined_anova)
}
grid::grid.newpage()
grid::pushViewport(grid::viewport(layout = grid::grid.layout(nrow = 1, ncol = 3)))
for (i in seq_along(final_plot_list)) {
  print(final_plot_list[[i]], vp = grid::viewport(layout.pos.row = 1, layout.pos.col = i))
}
capture.output(utils::sessionInfo(), file = file.path(output_dir, "sessionInfo.txt"))
cat("\nAnalysis completed.\n")
cat("Primary model for every trait:\n")
cat("TraitValue ~ Block + Drought * Genotype + (1 | MainPlotID)\n")
cat("Input subplot observations:", nrow(dat_y), "\n")
cat("Main plots:", dplyr::n_distinct(dat_y$MainPlotID), "\n")
cat("Raw subplot points are not displayed in the main figure.\n")
cat("Bars represent LMM-adjusted marginal means averaged over genotype.\n")
cat("Error bars represent 95% confidence intervals from the same LMM.\n")
cat("Maximum row-wise yield identity difference:", sprintf("%.12g", max_identity_difference), "\n")
cat("Results folder:", normalizePath(output_dir), "\n")
