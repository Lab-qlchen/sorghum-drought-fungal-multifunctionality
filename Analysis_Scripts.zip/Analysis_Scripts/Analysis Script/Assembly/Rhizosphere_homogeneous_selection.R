rm(list = ls())
grDevices::graphics.off()
options(stringsAsFactors = FALSE)
set.seed(1234)
required_packages <- c("tidyverse", "ggplot2", "scales")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(tidyverse)
  library(ggplot2)
  library(scales)
})
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/群落组装")
process_file <- "根际pairwise_betaNTI_RCbray_process.csv"
output_dir <- "Rhizosphere_homogeneous_selection_randomization"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
n_permutations <- 999L
period_levels <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
drought_labels <- c(Control = "Control", Drought_L = "Light", Drought_M = "Moderate", Drought_H = "Heavy")
drought_colors <- c(Control = "#8C8C8C", Drought_L = "#4E79A7", Drought_M = "#59A14F", Drought_H = "#E15759")
parse_stage <- function (group) {
  dplyr::case_when(stringr::str_detect(group, "^JS_") ~ "Jointing stage", stringr::str_detect(group, "^HS_") ~ "Heading stage", stringr::str_detect(group, "^FS_") ~
    "Filling stage", stringr::str_detect(group, "^MS_") ~ "Maturity stage", TRUE ~ NA_character_)
}
parse_drought <- function (group) {
  dplyr::case_when(stringr::str_detect(group, "_Control$") ~ "Control", stringr::str_detect(group, "_Drought_L$") ~ "Drought_L", stringr::str_detect(group, "_Drought_M$")
    ~ "Drought_M", stringr::str_detect(group, "_Drought_H$") ~ "Drought_H", TRUE ~ NA_character_)
}
parse_genotype <- function (sample) {
  dplyr::case_when(stringr::str_detect(sample, "^Z") ~ "Jinza 22", stringr::str_detect(sample, "^N") ~ "Liangnuo 01", TRUE ~ NA_character_)
}
parse_block <- function (sample) {
  stringr::str_match(sample, "_([1-4])$")[, 2]
}
p_stars <- function (p) {
  dplyr::case_when(is.na(p) ~ "", p < 0.001 ~ "***", p < 0.01 ~ "**", p < 0.05 ~ "*", TRUE ~ "ns")
}
fit_logit_trend <- function (pair_df, drought1_col, drought2_col) {
  d1 <- pair_df[[drought1_col]]
  d2 <- pair_df[[drought2_col]]
  same_idx <- !is.na(d1) & !is.na(d2) & d1 == d2
  dat <- pair_df[same_idx,, drop = FALSE]
  if (nrow(dat) == 0L) {
    return(list(slope = NA_real_, OR = NA_real_, OR_lower = NA_real_, OR_upper = NA_real_, counts = tibble::tibble()))
  }
  dat$Drought_current <- factor(dat[[drought1_col]], levels = drought_levels)
  counts <- dat %>% dplyr::group_by(Drought_current) %>% dplyr::summarise(Total_pairs = dplyr::n(), Homo_pairs = sum(Homo), Other_pairs = Total_pairs - Homo_pairs,
    Homo_proportion = Homo_pairs / Total_pairs, .groups = "drop") %>% tidyr::complete(Drought_current = factor(drought_levels, levels = drought_levels), fill = list(
    Total_pairs = 0L, Homo_pairs = 0L, Other_pairs = 0L, Homo_proportion = NA_real_)) %>% dplyr::mutate(Drought_num = match(as.character(Drought_current), drought_levels)
    - 1)
  fit_dat <- counts %>% dplyr::filter(Total_pairs > 0)
  if (nrow(fit_dat) != 4L) {
    return(list(slope = NA_real_, OR = NA_real_, OR_lower = NA_real_, OR_upper = NA_real_, counts = counts))
  }
  fit <- suppressWarnings(stats::glm(cbind(Homo_pairs, Other_pairs) ~ Drought_num, data = fit_dat, family = stats::binomial()))
  slope <- unname(stats::coef(fit)["Drought_num"])
  if (!is.finite(slope)) {
    slope <- NA_real_
  }
  slope_se <- tryCatch(sqrt(stats::vcov(fit)["Drought_num", "Drought_num"]), error = function (e) NA_real_)
  or_lower <- if (is.finite(slope) && is.finite(slope_se)) {
    exp(slope - 1.96 * slope_se)
  } else {
    NA_real_
  }
  or_upper <- if (is.finite(slope) && is.finite(slope_se)) {
    exp(slope + 1.96 * slope_se)
  } else {
    NA_real_
  }
  list(slope = slope, OR = ifelse(is.finite(slope), exp(slope), NA_real_), OR_lower = or_lower, OR_upper = or_upper, counts = counts)
}
make_permuted_drought_map <- function (stage_meta) {
  mainplots <- stage_meta %>% dplyr::distinct(Block, MainPlotID, Drought) %>% dplyr::arrange(Block, MainPlotID)
  if (nrow(mainplots) != 16L || dplyr::n_distinct(mainplots$MainPlotID) != 16L) {
    stop("Each stage must contain 16 Block x Drought main plots.")
  }
  permuted <- mainplots %>% dplyr::group_by(Block) %>% dplyr::mutate(Drought_perm = sample(as.character(Drought), size = dplyr::n(), replace = FALSE)) %>% dplyr::ungroup(
    )
  stats::setNames(permuted$Drought_perm, permuted$MainPlotID)
}
process_tab <- read.csv(process_file, stringsAsFactors = FALSE, check.names = FALSE, fileEncoding = "UTF-8-BOM")
need_cols <- c("Sample1", "Sample2", "Group1", "Group2", "Process")
missing_cols <- setdiff(need_cols, names(process_tab))
if (length(missing_cols) > 0L) {
  stop("Process table is missing columns: ", paste(missing_cols, collapse = ", "))
}
pair_all <- process_tab %>% dplyr::transmute(Sample1 = as.character(Sample1), Sample2 = as.character(Sample2), Group1 = as.character(Group1), Group2 = as.character(Group2
  ), Process = as.character(Process), Stage1 = parse_stage(Group1), Stage2 = parse_stage(Group2), Drought1 = parse_drought(Group1), Drought2 = parse_drought(Group2),
  Genotype1 = parse_genotype(Sample1), Genotype2 = parse_genotype(Sample2), Block1 = parse_block(Sample1), Block2 = parse_block(Sample2), Homo = as.integer(Process ==
  "Homogeneous_selection")) %>% dplyr::filter(!is.na(Stage1), !is.na(Stage2), !is.na(Drought1), !is.na(Drought2), !is.na(Genotype1), !is.na(Genotype2), !is.na(Block1), !
  is.na(Block2)) %>% dplyr::mutate(MainPlotID1 = interaction(Block1, Drought1, drop = TRUE, sep = "_"), MainPlotID2 = interaction(Block2, Drought2, drop = TRUE, sep = "_"
  ))
meta1 <- pair_all %>% dplyr::transmute(Sample = Sample1, Stage = Stage1, Drought = Drought1, Genotype = Genotype1, Block = Block1, MainPlotID = as.character(MainPlotID1))
meta2 <- pair_all %>% dplyr::transmute(Sample = Sample2, Stage = Stage2, Drought = Drought2, Genotype = Genotype2, Block = Block2, MainPlotID = as.character(MainPlotID2))
sample_meta <- dplyr::bind_rows(meta1, meta2) %>% dplyr::distinct()
consistency_check <- sample_meta %>% dplyr::count(Sample, name = "n")
if (any(consistency_check$n != 1L)) {
  stop("At least one sample has inconsistent Stage/Drought/Genotype/Block metadata.")
}
sample_meta <- sample_meta %>% dplyr::mutate(Stage = factor(Stage, levels = period_levels), Drought = factor(Drought, levels = drought_levels), Genotype = factor(Genotype
  , levels = c("Jinza 22", "Liangnuo 01")), Block = factor(Block, levels = as.character(1:4)))
stage_result_list <- list()
stage_count_list <- list()
perm_result_list <- list()
for (stage_name in period_levels) {
  message("Running stage: ", stage_name)
  stage_pairs <- pair_all %>% dplyr::filter(Stage1 == stage_name, Stage2 == stage_name)
  stage_meta <- sample_meta %>% dplyr::filter(Stage == stage_name) %>% droplevels()
  if (nrow(stage_meta) != 32L) {
    stop(stage_name, ": expected 32 rhizosphere samples, found ", nrow(stage_meta), ".")
  }
  if (dplyr::n_distinct(stage_meta$MainPlotID) != 16L || dplyr::n_distinct(stage_meta$Genotype) != 2L) {
    stop(stage_name, ": split-plot metadata do not match 16 main plots x 2 genotypes.")
  }
  observed <- fit_logit_trend(stage_pairs, "Drought1", "Drought2")
  stage_count_list[[stage_name]] <- observed$counts %>% dplyr::mutate(Stage = stage_name, .before = 1)
  perm_slopes <- rep(NA_real_, n_permutations)
  for (b in seq_len(n_permutations)) {
    drought_map <- make_permuted_drought_map(stage_meta)
    perm_pairs <- stage_pairs %>% dplyr::mutate(Drought1_perm = unname(drought_map[as.character(MainPlotID1)]), Drought2_perm = unname(drought_map[as.character(
      MainPlotID2)]))
    perm_fit <- fit_logit_trend(perm_pairs, "Drought1_perm", "Drought2_perm")
    perm_slopes[b] <- perm_fit$slope
  }
  valid_perm <- perm_slopes[is.finite(perm_slopes)]
  if (!is.finite(observed$slope) || length(valid_perm) == 0L) {
    perm_p <- NA_real_
  } else {
    perm_p <- (1 + sum(abs(valid_perm) >= abs(observed$slope))) / (1 + length(valid_perm))
  }
  stage_result_list[[stage_name]] <- tibble::tibble(Stage = stage_name, Log_odds_slope = observed$slope, OR_per_drought_step = observed$OR, OR_lower_95 = observed$
    OR_lower, OR_upper_95 = observed$OR_upper, Permutation_P = perm_p, N_permutations_valid = length(valid_perm))
  perm_result_list[[stage_name]] <- tibble::tibble(Stage = stage_name, Permutation = seq_along(perm_slopes), Permuted_log_odds_slope = perm_slopes)
}
stage_results <- dplyr::bind_rows(stage_result_list) %>% dplyr::mutate(Stage = factor(Stage, levels = period_levels), Significance = p_stars(Permutation_P))
observed_counts <- dplyr::bind_rows(stage_count_list) %>% dplyr::mutate(Stage = factor(Stage, levels = period_levels), Drought_current = factor(Drought_current, levels =
  drought_levels))
permutation_distribution <- dplyr::bind_rows(perm_result_list)
write.csv(stage_results, file.path(output_dir, "01_Homogeneous_selection_drought_randomization_results.csv"), row.names = FALSE)
write.csv(observed_counts, file.path(output_dir, "02_Homogeneous_selection_observed_proportions.csv"), row.names = FALSE)
write.csv(permutation_distribution, file.path(output_dir, "03_Homogeneous_selection_permutation_distribution.csv"), row.names = FALSE)
print(stage_results)
print(observed_counts)
plot_or <- stage_results %>% dplyr::mutate(Stage_plot = factor(Stage, levels = rev(period_levels)), Label = paste0("OR = ", sprintf("%.2f", OR_per_drought_step), " ",
  Significance))
finite_or <- plot_or$OR_per_drought_step[is.finite(plot_or$OR_per_drought_step) & plot_or$OR_per_drought_step > 0]
if (length(finite_or) == 0L) {
  stop("No finite positive OR values are available for plotting.")
}
or_min <- min(c(1, finite_or))
or_max <- max(c(1, finite_or))
finite_lower <- plot_or$OR_lower_95[is.finite(plot_or$OR_lower_95) & plot_or$OR_lower_95 > 0]
finite_upper <- plot_or$OR_upper_95[is.finite(plot_or$OR_upper_95) & plot_or$OR_upper_95 > 0]
if (length(finite_lower) > 0L) {
  or_min <- min(or_min, finite_lower)
}
if (length(finite_upper) > 0L) {
  or_max <- max(or_max, finite_upper)
}
label_x <- or_max * 1.16
p_or <- ggplot2::ggplot(plot_or, ggplot2::aes(x = OR_per_drought_step, y = Stage_plot)) + ggplot2::geom_vline(xintercept = 1, linetype = "dashed", linewidth = 0.5, colour
  = "grey50") + ggplot2::geom_segment(ggplot2::aes(x = 1, xend = OR_per_drought_step, yend = Stage_plot), linewidth = 0.8, colour = "grey60") + ggplot2::geom_errorbar(
  ggplot2::aes(xmin = OR_lower_95, xmax = OR_upper_95), orientation = "y", width = 0.16, linewidth = 0.55, colour = "grey45", na.rm = TRUE) + ggplot2::geom_point(shape =
  21, size = 3.8, fill = "#2AA7A1", colour = "#2AA7A1", stroke = 0.4) + ggplot2::geom_text(ggplot2::aes(label = Label), x = label_x, hjust = 0, size = 3.5, colour =
  "black") + ggplot2::scale_x_log10(limits = c(or_min * 0.72, label_x * 2.10), breaks = c(0.3, 1, 3, 10, 30)) + ggplot2::labs(x = "Homogeneous selection odds ratio", y =
  NULL, tag = "B") + ggplot2::theme_classic(base_size = 10.5) + ggplot2::theme(panel.border = ggplot2::element_rect(colour = "black", fill = NA, linewidth = 0.5),
  axis.text = ggplot2::element_text(colour = "black"), plot.tag = ggplot2::element_text(face = "bold", size = 14), plot.tag.position = c(0.02, 0.98), plot.margin =
  ggplot2::margin(10, 12, 8, 10)) + ggplot2::coord_cartesian(clip = "off")
print(p_or)
ggplot2::ggsave(file.path(output_dir, "Figure_homogeneous_selection_drought_OR_randomization.pdf"), p_or, width = 5.8, height = 4.2)
ggplot2::ggsave(file.path(output_dir, "Figure_homogeneous_selection_drought_OR_randomization.png"), p_or, width = 5.8, height = 4.2, dpi = 600)
p_prop <- ggplot2::ggplot(observed_counts, ggplot2::aes(x = Drought_current, y = Homo_proportion, group = 1)) + ggplot2::geom_line(linewidth = 0.8, colour = "grey55") +
  ggplot2::geom_point(ggplot2::aes(fill = Drought_current), shape = 21, size = 3.6, colour = "black", stroke = 0.45) + ggplot2::facet_wrap(~ Stage, nrow = 1) + ggplot2::
  scale_fill_manual(values = drought_colors, labels = drought_labels, drop = FALSE) + ggplot2::scale_x_discrete(labels = drought_labels) + ggplot2::scale_y_continuous(
  limits = c(0, 1), expand = ggplot2::expansion(mult = c(0, 0.03))) + ggplot2::labs(x = "Drought treatment", y = "Homogeneous selection proportion", fill = NULL) +
  ggplot2::theme_bw(base_size = 12) + ggplot2::theme(panel.grid = ggplot2::element_blank(), strip.background = ggplot2::element_rect(fill = "grey90", colour = "black"),
  strip.text = ggplot2::element_text(face = "bold"), axis.text.x = ggplot2::element_text(angle = 35, hjust = 1, colour = "black"), axis.text.y = ggplot2::element_text(
  colour = "black"), legend.position = "none")
print(p_prop)
ggplot2::ggsave(file.path(output_dir, "Figure_homogeneous_selection_observed_proportion.pdf"), p_prop, width = 10.5, height = 4.2)
ggplot2::ggsave(file.path(output_dir, "Figure_homogeneous_selection_observed_proportion.png"), p_prop, width = 10.5, height = 4.2, dpi = 600)
capture.output(sessionInfo(), file = file.path(output_dir, "sessionInfo.txt"))
message("Homogeneous-selection randomization analysis completed: ", output_dir)
