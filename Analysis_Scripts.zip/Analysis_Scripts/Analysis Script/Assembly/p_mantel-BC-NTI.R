rm(list = ls())
options(stringsAsFactors = FALSE)
set.seed(1234)
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/26.8.28 fungi SMF/群落组装")
pkg_needed <- c("tidyverse", "vegan", "ggplot2", "patchwork", "emmeans")
pkg_new <- pkg_needed[!pkg_needed %in% rownames(installed.packages())]
if (length(pkg_new) > 0) {
  install.packages(pkg_new, repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
}
suppressPackageStartupMessages({
  library(tidyverse)
  library(vegan)
  library(ggplot2)
  library(patchwork)
  library(emmeans)
})
file_info <- list(Phyllosphere = list(asv = "叶际F_ASV.csv", pair = "叶际pairwise_betaNTI_RCbray_process.csv", group = "叶际分组.csv", color = "#84B300"), Endosphere = list(asv =
  "根内F_ASV.csv", pair = "根内pairwise_betaNTI_RCbray_process.csv", group = "根内分组.csv", color = "#F07167"), Rhizosphere = list(asv = "根际F_ASV.csv", pair =
  "根际pairwise_betaNTI_RCbray_process.csv", group = "根际分组.csv", color = "#2DB7B5"))
period_levels <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
mantel_permutations <- 999
read_asv_comm <- function (asv_file) {
  asv <- read.csv(asv_file, check.names = FALSE)
  asv_id <- asv[[9]]
  otu <- asv[, 10:ncol(asv), drop = FALSE]
  rownames(otu) <- asv_id
  otu <- as.matrix(otu)
  mode(otu) <- "numeric"
  comm <- t(otu)
  comm <- comm[, colSums(comm) > 0, drop = FALSE]
  comm
}
dist_to_table <- function (dist_obj, value_name = "BrayCurtis") {
  mat <- as.matrix(dist_obj)
  s <- rownames(mat)
  idx <- which(upper.tri(mat), arr.ind = TRUE)
  out <- data.frame(Sample1 = s[idx[, 1]], Sample2 = s[idx[, 2]], value = mat[idx], stringsAsFactors = FALSE)
  colnames(out)[3] <- value_name
  out
}
normalize_pair_order <- function (df, s1 = "Sample1", s2 = "Sample2") {
  x1 <- df[[s1]]
  x2 <- df[[s2]]
  df[[s1]] <- ifelse(x1 <= x2, x1, x2)
  df[[s2]] <- ifelse(x1 <= x2, x2, x1)
  df
}
read_group_info <- function (group_file) {
  grp <- read.csv(group_file, check.names = FALSE)
  colnames(grp)[1:2] <- c("Sample", "Group")
  grp <- grp %>% mutate(Period = case_when(grepl("^JS_", Group) ~ "Jointing stage", grepl("^HS_", Group) ~ "Heading stage", grepl("^FS_", Group) ~ "Filling stage", grepl(
    "^MS_", Group) ~ "Maturity stage", TRUE ~ NA_character_), Drought = case_when(grepl("_Control$", Group) ~ "Control", grepl("_Drought_L$", Group) ~ "Drought_L", grepl(
    "_Drought_M$", Group) ~ "Drought_M", grepl("_Drought_H$", Group) ~ "Drought_H", TRUE ~ NA_character_))
  grp$Period <- factor(grp$Period, levels = period_levels)
  grp$Drought <- factor(grp$Drought, levels = drought_levels)
  grp
}
pair_to_symmetric_matrix <- function (df, samples, value_col) {
  mat <- matrix(NA_real_, nrow = length(samples), ncol = length(samples), dimnames = list(samples, samples))
  diag(mat) <- 0
  for (i in seq_len(nrow(df))) {
    s1 <- df$Sample1[i]
    s2 <- df$Sample2[i]
    val <- df[[value_col]][i]
    if (s1 %in% samples && s2 %in% samples) {
      mat[s1, s2] <- val
      mat[s2, s1] <- val
    }
  }
  mat
}
format_p <- function (p) {
  if (is.na(p)) {
    return("NA")
  }
  if (p < 0.001) {
    return("< 0.001")
  }
  sprintf("%.3f", p)
}
process_stage_specific <- function (habitat_name, info, permutations = 999) {
  cat("\n============================================================\n")
  cat("Drought-adjusted analysis:", habitat_name, "\n")
  cat("============================================================\n")
  comm <- read_asv_comm(info$asv)
  bc_dist <- vegan::vegdist(comm, method = "bray")
  bc_df <- dist_to_table(bc_dist, value_name = "BrayCurtis")
  bc_df <- normalize_pair_order(bc_df)
  pair_df <- read.csv(info$pair, check.names = FALSE)
  pair_df <- normalize_pair_order(pair_df)
  grp <- read_group_info(info$group)
  grp_simple <- grp %>% transmute(Sample = as.character(Sample), Group = as.character(Group), Period = as.character(Period), Drought = as.character(Drought))
  meta1 <- grp_simple %>% transmute(Sample1 = Sample, Period1 = Period, Drought1 = Drought)
  meta2 <- grp_simple %>% transmute(Sample2 = Sample, Period2 = Period, Drought2 = Drought)
  pair_all <- pair_df %>% left_join(bc_df, by = c("Sample1", "Sample2")) %>% left_join(meta1, by = "Sample1") %>% left_join(meta2, by = "Sample2") %>% filter(!is.na(
    betaNTI), !is.na(BrayCurtis), !is.na(Period1), !is.na(Period2), !is.na(Drought1), !is.na(Drought2)) %>% filter(Period1 == Period2) %>% mutate(Period = Period1,
    Habitat = habitat_name)
  stage_data_list <- list()
  stage_stat_list <- list()
  stage_prediction_list <- list()
  for (st in period_levels) {
    cat("\n", habitat_name, " - ", st, "\n", sep = "")
    stage_pairs <- pair_all %>% filter(Period == st)
    if (nrow(stage_pairs) < 3) {
      warning(paste(habitat_name, st, ": too few pairwise comparisons."))
      next
    }
    stage_pairs <- stage_pairs %>% mutate(D1 = match(Drought1, drought_levels), D2 = match(Drought2, drought_levels), DroughtPair = factor(paste(pmin(D1, D2), pmax(D1, D2
      ), sep = "_")))
    lm_reduced <- lm(BrayCurtis ~ DroughtPair, data = stage_pairs)
    lm_full <- lm(BrayCurtis ~ DroughtPair + betaNTI, data = stage_pairs)
    adjusted_slope <- unname(coef(lm_full)["betaNTI"])
    sse_reduced <- deviance(lm_reduced)
    sse_full <- deviance(lm_full)
    partial_R2 <- (sse_reduced - sse_full) / sse_reduced
    partial_R2 <- max(0, min(1, partial_R2))
    beta_grid <- seq(min(stage_pairs$betaNTI, na.rm = TRUE), max(stage_pairs$betaNTI, na.rm = TRUE), length.out = 100)
    pred_emm <- emmeans::emmeans(lm_full, ~ betaNTI, at = list(betaNTI = beta_grid), weights = "equal")
    pred_df <- as.data.frame(pred_emm) %>% mutate(Habitat = habitat_name, Period = factor(st, levels = period_levels))
    stage_samples <- grp_simple %>% filter(Period == st) %>% pull(Sample) %>% unique()
    pair_samples <- unique(c(pair_df$Sample1, pair_df$Sample2))
    stage_samples <- Reduce(intersect, list(stage_samples, rownames(comm), pair_samples))
    bc_stage_df <- bc_df %>% filter(Sample1 %in% stage_samples, Sample2 %in% stage_samples)
    bc_mat <- pair_to_symmetric_matrix(df = bc_stage_df, samples = stage_samples, value_col = "BrayCurtis")
    bnti_stage_df <- pair_df %>% filter(Sample1 %in% stage_samples, Sample2 %in% stage_samples)
    bnti_mat <- pair_to_symmetric_matrix(df = bnti_stage_df, samples = stage_samples, value_col = "betaNTI")
    keep_samples <- stage_samples[rowSums(is.na(bc_mat)) == 0 & rowSums(is.na(bnti_mat)) == 0]
    if (length(keep_samples) >= 3) {
      bc_mat2 <- bc_mat[keep_samples, keep_samples, drop = FALSE]
      bnti_mat2 <- bnti_mat[keep_samples, keep_samples, drop = FALSE]
      stage_meta <- grp_simple %>% filter(Period == st, Sample %in% keep_samples) %>% mutate(Drought = factor(Drought, levels = drought_levels))
      stage_meta <- stage_meta[match(keep_samples, stage_meta$Sample),, drop = FALSE]
      if (any(stage_meta$Sample != keep_samples)) {
        stop(paste(habitat_name, st, ": metadata/sample order mismatch."))
      }
      drought_design <- model.matrix(~ Drought - 1, data = stage_meta)
      rownames(drought_design) <- stage_meta$Sample
      drought_dist <- dist(drought_design, method = "euclidean")
      mantel_res <- vegan::mantel.partial(xdis = as.dist(bc_mat2), ydis = as.dist(bnti_mat2), zdis = drought_dist, method = "pearson", permutations = permutations)
      partial_mantel_r <- unname(mantel_res$statistic)
      mantel_p <- mantel_res$signif
    } else {
      partial_mantel_r <- NA_real_
      mantel_p <- NA_real_
    }
    stage_stat <- tibble(Habitat = habitat_name, Period = st, Adjusted_slope = adjusted_slope, Partial_R2 = partial_R2, Partial_Mantel_r = partial_mantel_r, P = mantel_p,
      N_samples = length(keep_samples), N_pairs = nrow(stage_pairs))
    print(stage_stat)
    stage_pairs$Period <- factor(stage_pairs$Period, levels = period_levels)
    stage_data_list[[st]] <- stage_pairs
    stage_stat_list[[st]] <- stage_stat
    stage_prediction_list[[st]] <- pred_df
  }
  stage_data <- bind_rows(stage_data_list)
  stage_stat <- bind_rows(stage_stat_list) %>% mutate(Period = factor(Period, levels = period_levels))
  stage_predictions <- bind_rows(stage_prediction_list)
  return(list(data = stage_data, stat = stage_stat, predictions = stage_predictions))
}
stage_res_list <- list()
for (nm in names(file_info)) {
  stage_res_list[[nm]] <- process_stage_specific(habitat_name = nm, info = file_info[[nm]], permutations = mantel_permutations)
}
all_stage_data <- bind_rows(lapply(stage_res_list, function (x) x$data))
all_stage_stat <- bind_rows(lapply(stage_res_list, function (x) x$stat))
all_stage_predictions <- bind_rows(lapply(stage_res_list, function (x) x$predictions))
write.csv(all_stage_data, "Three_habitats_four_stages_betaNTI_BrayCurtis_pairwise_data_drought_adjusted.csv", row.names = FALSE)
write.csv(all_stage_stat, "Three_habitats_four_stages_betaNTI_BrayCurtis_drought_adjusted_stats.csv", row.names = FALSE)
write.csv(all_stage_predictions, "Three_habitats_four_stages_betaNTI_BrayCurtis_adjusted_predictions.csv", row.names = FALSE)
make_stage_plot <- function (df, stat_df, prediction_df, habitat_name, point_color) {
  label_pos <- df %>% group_by(Period) %>% summarise(x_pos = quantile(betaNTI, 0.05, na.rm = TRUE), y_pos = quantile(BrayCurtis, 0.97, na.rm = TRUE), .groups = "drop")
  label_df <- stat_df %>% left_join(label_pos, by = "Period") %>% mutate(P_text = vapply(P, format_p, character(1)), label = paste0("Adj. slope = ", sprintf("%.3f",
    Adjusted_slope), "\nPartial R² = ", sprintf("%.3f", Partial_R2), "\nPartial Mantel r = ", sprintf("%.3f", Partial_Mantel_r), "\nP = ", P_text))
  p <- ggplot(df, aes(x = betaNTI, y = BrayCurtis)) + geom_point(color = point_color, size = 1.8, alpha = 0.30) + geom_ribbon(data = prediction_df, aes(x = betaNTI, ymin
    = lower.CL, ymax = upper.CL), inherit.aes = FALSE, fill = point_color, alpha = 0.18) + geom_line(data = prediction_df, aes(x = betaNTI, y = emmean), inherit.aes =
    FALSE, color = point_color, linewidth = 1) + geom_text(data = label_df, aes(x = x_pos, y = y_pos, label = label), inherit.aes = FALSE, hjust = 0, vjust = 1, size =
    3.2) + facet_wrap(~ Period, nrow = 1, scales = "free") + theme_bw() + labs(title = habitat_name, x = expression(beta * "NTI"), y = "Bray-Curtis dissimilarity") +
    theme(panel.grid = element_blank(), strip.background = element_rect(fill = "grey95", color = "black"), strip.text = element_text(face = "bold", size = 10), plot.title
    = element_text(face = "bold", hjust = 0.5, size = 13), axis.title = element_text(size = 11), axis.text = element_text(size = 9, color = "black"))
  return(p)
}
stage_plot_list <- list()
for (nm in names(file_info)) {
  stage_plot_list[[nm]] <- make_stage_plot(df = stage_res_list[[nm]]$data, stat_df = stage_res_list[[nm]]$stat, prediction_df = stage_res_list[[nm]]$predictions,
    habitat_name = nm, point_color = file_info[[nm]]$color)
  print(stage_plot_list[[nm]])
  ggsave(filename = paste0(nm, "_betaNTI_vs_BrayCurtis_four_stages_drought_adjusted.pdf"), plot = stage_plot_list[[nm]], width = 13, height = 4)
  ggsave(filename = paste0(nm, "_betaNTI_vs_BrayCurtis_four_stages_drought_adjusted.png"), plot = stage_plot_list[[nm]], width = 13, height = 4, dpi = 300)
}
p_stage_combined <- stage_plot_list$Phyllosphere / stage_plot_list$Endosphere / stage_plot_list$Rhizosphere + plot_layout(ncol = 1)
print(p_stage_combined)
ggsave(filename = "Three_habitats_betaNTI_BrayCurtis_four_stages_drought_adjusted.pdf", plot = p_stage_combined, width = 13, height = 12)
ggsave(filename = "Three_habitats_betaNTI_BrayCurtis_four_stages_drought_adjusted.png", plot = p_stage_combined, width = 13, height = 12, dpi = 300)
rhizo_stage_stat <- all_stage_stat %>% filter(Habitat == "Rhizosphere") %>% mutate(Period = factor(Period, levels = c("Maturity stage", "Filling stage", "Heading stage",
  "Jointing stage")), sig = case_when(is.na(P) ~ "", P < 0.001 ~ "***", P < 0.01 ~ "**", P < 0.05 ~ "*", TRUE ~ "ns"), label = paste0(sprintf("%.3f", Partial_Mantel_r),
  " ", sig))
print(rhizo_stage_stat %>% select(Period, Adjusted_slope, Partial_R2, Partial_Mantel_r, P, sig))
x_min <- min(0, rhizo_stage_stat$Partial_Mantel_r, na.rm = TRUE)
x_max <- max(0, rhizo_stage_stat$Partial_Mantel_r, na.rm = TRUE)
x_range <- x_max - x_min
if (!is.finite(x_range) || x_range == 0) {
  x_range <- 0.1
}
x_left <- x_min - 0.08 * x_range
x_right <- x_max + 0.30 * x_range
p_Fig4C <- ggplot(rhizo_stage_stat, aes(x = Partial_Mantel_r, y = Period)) + geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.5, color = "grey50") +
  geom_segment(aes(x = 0, xend = Partial_Mantel_r, y = Period, yend = Period), linewidth = 0.7, color = "grey55") + geom_point(size = 4, shape = 21, fill = "#2DB7B5",
  color = "#2DB7B5", stroke = 0.5) + geom_text(aes(x = Partial_Mantel_r + 0.025 * x_range, label = label), hjust = 0, size = 4) + scale_x_continuous(limits = c(x_left,
  x_right), expand = expansion(mult = c(0.01, 0.02))) + labs(x = "Drought-adjusted partial Mantel r", y = NULL, title = expression(beta * "NTI–Bray-Curtis relationship")) +
  theme_bw(base_size = 12) + theme(panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(), panel.grid.major.x = element_line(color = "grey90", linewidth
  = 0.4), axis.text = element_text(color = "black", size = 11), axis.title.x = element_text(size = 12, color = "black"), plot.title = element_text(size = 13, face =
  "bold", hjust = 0.5, color = "black"), plot.margin = margin(t = 8, r = 18, b = 8, l = 8))
print(p_Fig4C)
ggsave("Figure4C_Rhizosphere_betaNTI_Bray_drought_adjusted.pdf", p_Fig4C, width = 6, height = 4.2)
ggsave("Figure4C_Rhizosphere_betaNTI_Bray_drought_adjusted.png", p_Fig4C, width = 6, height = 4.2, dpi = 600)
cat("\n============================================================\n")
cat("Drought-adjusted betaNTI-Bray-Curtis analysis completed.\n")
cat("Partial Mantel permutations:", mantel_permutations, "\n")
cat("\nFormal inference:\n")
cat("Bray-Curtis ~ betaNTI | Drought\n")
cat("\nDescriptive adjusted model:\n")
cat("Bray-Curtis ~ DroughtPair + betaNTI\n")
cat("\nOutput files:\n")
cat("1. Three_habitats_four_stages_betaNTI_BrayCurtis_drought_adjusted_stats.csv\n")
cat("2. Three_habitats_four_stages_betaNTI_BrayCurtis_pairwise_data_drought_adjusted.csv\n")
cat("3. Three_habitats_four_stages_betaNTI_BrayCurtis_adjusted_predictions.csv\n")
cat("4. Three habitat-specific four-stage PDF/PNG figures\n")
cat("5. Combined three-habitat PDF/PNG figure\n")
cat("6. Figure4C_Rhizosphere_betaNTI_Bray_drought_adjusted.pdf/png\n")
cat("============================================================\n")
