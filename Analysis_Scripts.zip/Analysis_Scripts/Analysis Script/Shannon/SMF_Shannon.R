rm(list = ls())
options(stringsAsFactors = FALSE)
options(contrasts = c("contr.sum", "contr.poly"))
pkgs <- c("lme4", "lmerTest", "emmeans", "multcomp", "multcompView", "dplyr", "tidyr", "purrr", "stringr", "ggplot2")
missing_pkgs <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_pkgs) > 0L) {
  stop("Install packages first: ", paste(missing_pkgs, collapse = ", "))
}
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/SMF-SHANNON")
input_file <- "SMF_Shannon_splitplot_data.csv"
output_dir <- "SMF_Shannon_FINAL_results"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
period_levels <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
genotype_levels <- c("Jinza 22", "Liangnuo 01")
func_cols <- c("NH4+-N", "NO3--N", "AP", "DOC", "MBC", "TC", "ALP", "AG", "BG", "CBH", "NAG", "LAP")
required_cols <- c("Sample", "PlotID", "Block", "MainPlotID", "Genotype", "Period", "Drought", "Fungi_Shannon", func_cols)
dat <- utils::read.csv(input_file, check.names = FALSE, fileEncoding = "UTF-8-BOM")
missing_cols <- setdiff(required_cols, names(dat))
if (length(missing_cols) > 0L) {
  stop("Missing columns: ", paste(missing_cols, collapse = ", "))
}
dat <- dat |> dplyr::mutate(Sample = as.character(Sample), PlotID = factor(as.character(PlotID)), MainPlotID = factor(as.character(MainPlotID)), Block = factor(
  as.character(Block), levels = as.character(1:4)), Genotype = factor(as.character(Genotype), levels = genotype_levels), Period = factor(as.character(Period), levels =
  period_levels), Drought = factor(as.character(Drought), levels = drought_levels), Fungi_Shannon = as.numeric(Fungi_Shannon))
dat[func_cols] <- lapply(dat[func_cols], as.numeric)
if (nrow(dat) != 128L) {
  stop("Expected 128 rows.")
}
if (anyNA(dat[, required_cols])) {
  stop("Required columns contain missing or unrecognized values.")
}
if (any(vapply(dat[func_cols], stats::sd, numeric(1)) == 0)) {
  stop("At least one SMF function has zero variance.")
}
function_z <- scale(as.matrix(dat[, func_cols]))
dat$SMF_meanZ <- rowMeans(function_z)
utils::write.csv(dat, file.path(output_dir, "01_data_with_SMF.csv"), row.names = FALSE)
lmm_control <- lme4::lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))
get_anova <- function (model) {
  ans <- tryCatch(stats::anova(model, type = 3, ddf = "Kenward-Roger"), error = function (e) NULL)
  method <- "Kenward-Roger"
  if (is.null(ans)) {
    ans <- stats::anova(model, type = 3, ddf = "Satterthwaite")
    method <- "Satterthwaite"
  }
  out <- as.data.frame(ans)
  out$Effect <- rownames(out)
  rownames(out) <- NULL
  out |> dplyr::relocate(Effect) |> dplyr::mutate(DDF_method = method, partial_eta2 = (`F value` * NumDF) / (`F value` * NumDF + DenDF))
}
fmt_p <- function (p) {
  if (is.na(p)) return("NA")
  if (p < 0.001) return("< 0.001")
  paste0("= ", sprintf("%.3f", p))
}
anova_label <- function (tab, effect, label) {
  z <- tab |> dplyr::filter(Effect == effect)
  if (nrow(z) != 1L) {
    return(paste0(label, ": unavailable"))
  }
  paste0(label, ": F(", sprintf("%.0f", z$NumDF), ", ", sprintf("%.1f", z$DenDF), ") = ", sprintf("%.2f", z$`F value`), ", P ", fmt_p(z$`Pr(>F)`))
}
fit_smf <- lmerTest::lmer(SMF_meanZ ~ Block + Drought * Period + Genotype + (1 | MainPlotID) + (1 | PlotID), data = dat, REML = TRUE, control = lmm_control)
smf_anova <- get_anova(fit_smf)
utils::write.csv(smf_anova, file.path(output_dir, "02_SMF_LMM_ANOVA.csv"), row.names = FALSE)
smf_emm <- emmeans::emmeans(fit_smf, ~ Drought | Period, weights = "equal")
smf_emm_df <- as.data.frame(smf_emm)
smf_tukey <- as.data.frame(emmeans::contrast(smf_emm, method = "pairwise", adjust = "tukey"))
smf_letters <- multcomp::cld(smf_emm, adjust = "tukey", Letters = letters, sort = FALSE) |> as.data.frame() |> dplyr::transmute(Period = factor(Period, levels =
  period_levels), Drought = factor(Drought, levels = drought_levels), .group = stringr::str_trim(.group))
utils::write.csv(smf_emm_df, file.path(output_dir, "03_SMF_adjusted_means.csv"), row.names = FALSE)
utils::write.csv(smf_tukey, file.path(output_dir, "04_SMF_Tukey.csv"), row.names = FALSE)
smf_plot_df <- smf_emm_df |> dplyr::mutate(Period = factor(Period, levels = period_levels), Drought = factor(Drought, levels = drought_levels)) |> dplyr::left_join(
  smf_letters, by = c("Period", "Drought"))
yr <- diff(range(c(smf_plot_df$lower.CL, smf_plot_df$upper.CL), na.rm = TRUE))
if (!is.finite(yr) || yr == 0) {
  yr <- 1
}
smf_subtitle <- paste(anova_label(smf_anova, "Genotype", "Genotype"), anova_label(smf_anova, "Drought", "Drought"), anova_label(smf_anova, "Period", "Stage"), anova_label
  (smf_anova, "Drought:Period", "Drought x stage"), sep = "    ")
p_smf <- ggplot2::ggplot(smf_plot_df, ggplot2::aes(x = Drought, y = emmean, fill = Drought)) + ggplot2::geom_col(width = 0.75) + ggplot2::geom_errorbar(ggplot2::aes(ymin
  = lower.CL, ymax = upper.CL), width = 0.20) + ggplot2::geom_text(ggplot2::aes(y = upper.CL + 0.05 * yr, label = .group), size = 4, vjust = 0) + ggplot2::facet_wrap(~
  Period, nrow = 1, scales = "free_y") + ggplot2::scale_fill_manual(values = c(Control = "#E76F61", Drought_L = "#7BAE29", Drought_M = "#20AEB7", Drought_H = "#9B7BB5")) +
  ggplot2::labs(x = "Drought treatment", y = "Soil multifunctionality (mean Z)", subtitle = smf_subtitle) + ggplot2::theme_bw() + ggplot2::theme(panel.grid = ggplot2::
  element_blank(), axis.text.x = ggplot2::element_text(angle = 45, hjust = 1), strip.text = ggplot2::element_text(face = "bold"), legend.position = "none", plot.subtitle
  = ggplot2::element_text(size = 9))
print(p_smf)
ggplot2::ggsave(file.path(output_dir, "Fig1_SMF_by_stage.pdf"), p_smf, width = 12, height = 4.3)
ggplot2::ggsave(file.path(output_dir, "Fig1_SMF_by_stage.png"), p_smf, width = 12, height = 4.3, dpi = 600)
fit_one_stage <- function (stage_name) {
  d <- dat |> dplyr::filter(Period == stage_name)
  shannon_mean <- mean(d$Fungi_Shannon)
  shannon_sd <- stats::sd(d$Fungi_Shannon)
  smf_mean <- mean(d$SMF_meanZ)
  smf_sd <- stats::sd(d$SMF_meanZ)
  d <- d |> dplyr::mutate(Shannon_z = (Fungi_Shannon - shannon_mean) / shannon_sd, SMF_z = (SMF_meanZ - smf_mean) / smf_sd)
  model <- lmerTest::lmer(SMF_z ~ Block + Genotype + Shannon_z + (1 | MainPlotID), data = d, REML = TRUE, control = lmm_control)
  tab <- get_anova(model)
  z <- tab |> dplyr::filter(Effect == "Shannon_z")
  beta <- unname(lme4::fixef(model)["Shannon_z"])
  partial_r <- sign(beta) * sqrt((z$`F value` * z$NumDF) / (z$`F value` * z$NumDF + z$DenDF))
  x_raw <- seq(min(d$Fungi_Shannon), max(d$Fungi_Shannon), length.out = 100)
  x_z <- (x_raw - shannon_mean) / shannon_sd
  pred <- as.data.frame(emmeans::emmeans(model, ~ Shannon_z, at = list(Shannon_z = x_z), weights = "equal")) |> dplyr::transmute(Period = factor(stage_name, levels =
    period_levels), Fungi_Shannon = Shannon_z * shannon_sd + shannon_mean, predicted_SMF = emmean * smf_sd + smf_mean, lower = lower.CL * smf_sd + smf_mean, upper =
    upper.CL * smf_sd + smf_mean)
  result <- data.frame(Period = stage_name, N = stats::nobs(model), Estimate_std = beta, Partial_r = partial_r, Partial_R2 = partial_r ^ 2, F_value = z$`F value`, NumDF =
    z$NumDF, DenDF = z$DenDF, P_value = z$`Pr(>F)`, Singular_fit = lme4::isSingular(model, tol = 1e-5))
  list(result = result, data = d, prediction = pred)
}
stage_fit <- lapply(period_levels, fit_one_stage)
assoc_results <- dplyr::bind_rows(lapply(stage_fit, function (x) x$result)) |> dplyr::mutate(Period = factor(Period, levels = period_levels), P_FDR = stats::p.adjust(
  P_value, method = "BH"))
utils::write.csv(assoc_results, file.path(output_dir, "05_Shannon_SMF_partial_correlations.csv"), row.names = FALSE)
scatter_data <- dplyr::bind_rows(lapply(stage_fit, function (x) x$data))
prediction_df <- dplyr::bind_rows(lapply(stage_fit, function (x) x$prediction))
annotation_df <- scatter_data |> dplyr::group_by(Period) |> dplyr::summarise(x = min(Fungi_Shannon), y = max(SMF_meanZ), .groups = "drop") |> dplyr::left_join(
  assoc_results |> dplyr::select(Period, Partial_r, P_value, P_FDR), by = "Period") |> dplyr::mutate(label = paste0("Partial r = ", sprintf("%.2f", Partial_r), "\nP ",
  vapply(P_value, fmt_p, character(1)), "\nFDR P ", vapply(P_FDR, fmt_p, character(1))))
p_assoc <- ggplot2::ggplot(scatter_data, ggplot2::aes(x = Fungi_Shannon, y = SMF_meanZ)) + ggplot2::geom_point(size = 3, color = "#2485bc", alpha = 0.75) + ggplot2::
  geom_ribbon(data = prediction_df, ggplot2::aes(x = Fungi_Shannon, ymin = lower, ymax = upper), inherit.aes = FALSE, fill = "#b0c4de", alpha = 0.55) + ggplot2::geom_line(
  data = prediction_df, ggplot2::aes(x = Fungi_Shannon, y = predicted_SMF), inherit.aes = FALSE, color = "#1b4f72", linewidth = 0.9) + ggplot2::geom_text(data =
  annotation_df, ggplot2::aes(x = x, y = y, label = label), inherit.aes = FALSE, hjust = 0, vjust = 1, size = 3.5) + ggplot2::facet_wrap(~ Period, nrow = 1, scales =
  "free") + ggplot2::labs(x = "Fungal Shannon diversity", y = "Soil multifunctionality (mean Z)") + ggplot2::theme_bw() + ggplot2::theme(panel.grid = ggplot2::
  element_blank(), strip.text = ggplot2::element_text(face = "bold"))
print(p_assoc)
ggplot2::ggsave(file.path(output_dir, "Fig2_Shannon_SMF_correlation.pdf"), p_assoc, width = 12, height = 4.3)
ggplot2::ggsave(file.path(output_dir, "Fig2_Shannon_SMF_correlation.png"), p_assoc, width = 12, height = 4.3, dpi = 600)
minmax01 <- function (x) {
  (x - min(x)) / (max(x) - min(x))
}
function_01 <- as.data.frame(lapply(dat[func_cols], minmax01))
thresholds <- 1:99
threshold_count <- vapply(thresholds / 100, function (thr) {
  rowSums(function_01 >= thr)
}, numeric(nrow(dat)))
colnames(threshold_count) <- paste0("T", thresholds)
fit_one_threshold <- function (stage_name, threshold_value) {
  idx <- dat$Period == stage_name
  d <- dat[idx,, drop = FALSE]
  d$SMF_count <- threshold_count[idx, paste0("T", threshold_value)]
  if (stats::sd(d$SMF_count) == 0) {
    return(data.frame(Period = stage_name, Threshold = threshold_value, Slope = NA_real_, SE = NA_real_, lower.CL = NA_real_, upper.CL = NA_real_))
  }
  d$Shannon_z <- as.numeric(scale(d$Fungi_Shannon))
  model <- tryCatch(lmerTest::lmer(SMF_count ~ Block + Genotype + Shannon_z + (1 | MainPlotID), data = d, REML = TRUE, control = lmm_control), error = function (e) NULL)
  if (is.null(model)) {
    return(data.frame(Period = stage_name, Threshold = threshold_value, Slope = NA_real_, SE = NA_real_, lower.CL = NA_real_, upper.CL = NA_real_))
  }
  tab <- get_anova(model)
  z <- tab |> dplyr::filter(Effect == "Shannon_z")
  if (nrow(z) != 1L) {
    return(data.frame(Period = stage_name, Threshold = threshold_value, Slope = NA_real_, SE = NA_real_, lower.CL = NA_real_, upper.CL = NA_real_))
  }
  slope <- unname(lme4::fixef(model)["Shannon_z"])
  slope_se <- sqrt(stats::vcov(model)["Shannon_z", "Shannon_z"])
  tcrit <- stats::qt(0.975, df = z$DenDF)
  data.frame(Period = stage_name, Threshold = threshold_value, Slope = slope, SE = slope_se, lower.CL = slope - tcrit * slope_se, upper.CL = slope + tcrit * slope_se)
}
threshold_grid <- tidyr::expand_grid(Period = period_levels, Threshold = thresholds)
threshold_results <- purrr::pmap_dfr(threshold_grid, function (Period, Threshold) {
  fit_one_threshold(stage_name = Period, threshold_value = Threshold)
}) |> dplyr::mutate(Period = factor(Period, levels = period_levels))
utils::write.csv(threshold_results, file.path(output_dir, "06_multithreshold_slopes.csv"), row.names = FALSE)
get_peak_range <- function (d) {
  d <- d |> dplyr::filter(is.finite(Slope)) |> dplyr::arrange(Threshold)
  if (nrow(d) == 0L) {
    return(data.frame(Peak_threshold = NA_real_, Peak_slope = NA_real_, Peak_range_min = NA_real_, Peak_range_max = NA_real_))
  }
  peak_i <- which.max(abs(d$Slope))
  peak_threshold <- d$Threshold[peak_i]
  peak_slope <- d$Slope[peak_i]
  cutoff <- 0.95 * abs(peak_slope)
  high <- abs(d$Slope) >= cutoff
  left <- peak_i
  while (left > 1L && isTRUE(high[left - 1L])) {
    left <- left - 1L
  }
  right <- peak_i
  while (right < nrow(d) && isTRUE(high[right + 1L])) {
    right <- right + 1L
  }
  data.frame(Peak_threshold = peak_threshold, Peak_slope = peak_slope, Peak_range_min = d$Threshold[left], Peak_range_max = d$Threshold[right])
}
peak_summary <- threshold_results |> dplyr::group_by(Period) |> dplyr::group_modify(~ get_peak_range(.x)) |> dplyr::ungroup()
utils::write.csv(peak_summary, file.path(output_dir, "07_multithreshold_peak_range.csv"), row.names = FALSE)
threshold_plot_df <- threshold_results |> dplyr::filter(is.finite(Slope), is.finite(lower.CL), is.finite(upper.CL))
p_threshold <- ggplot2::ggplot(threshold_plot_df, ggplot2::aes(x = Threshold, y = Slope)) + ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "grey40",
  linewidth = 0.6) + ggplot2::geom_ribbon(ggplot2::aes(ymin = lower.CL, ymax = upper.CL), fill = "#B0C4DE", alpha = 0.60) + ggplot2::geom_line(color = "#1B4F72",
  linewidth = 1) + ggplot2::facet_wrap(~ Period, nrow = 1, scales = "free_y") + ggplot2::labs(x = "SMF threshold (%)", y =
  "Shannon slope\n(number of functions per 1 SD Shannon)") + ggplot2::theme_bw() + ggplot2::theme(panel.grid = ggplot2::element_blank(), axis.title = ggplot2::
  element_text(size = 12), axis.text = ggplot2::element_text(size = 10), strip.text = ggplot2::element_text(size = 11, face = "bold"))
print(p_threshold)
ggplot2::ggsave(file.path(output_dir, "Fig3_multithreshold_Shannon_SMF.pdf"), p_threshold, width = 12, height = 4.3)
ggplot2::ggsave(file.path(output_dir, "Fig3_multithreshold_Shannon_SMF.png"), p_threshold, width = 12, height = 4.3, dpi = 600)
cat("\n========== SMF differences ==========\n")
print(smf_anova |> dplyr::filter(Effect %in% c("Genotype", "Drought", "Period", "Drought:Period")))
cat("\n========== MAIN: Shannon-SMF correlations ==========\n")
print(assoc_results |> dplyr::select(Period, N, Estimate_std, Partial_r, Partial_R2, F_value, P_value, P_FDR, Singular_fit))
cat("\n========== SUPPLEMENT: multithreshold peak range ==========\n")
print(peak_summary)
message("\nFinished. Results saved in: ", normalizePath(output_dir))
