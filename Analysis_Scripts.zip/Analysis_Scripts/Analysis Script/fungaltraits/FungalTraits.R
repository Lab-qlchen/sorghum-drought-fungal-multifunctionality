setwd("D:/IUE/山西数据/真菌/抽平/fungtraits功能注释/2026.1.26 fungtraits 注释分析")
library(tidyverse)
trophic_db <- read.csv("FungalTraits 1.2_ver_16Dec_2020.csv", stringsAsFactors = FALSE) %>% transmute(Genus.join = GENUS, primary = primary_lifestyle, secondary =
  Secondary_lifestyle)
annotate_traits <- function (otu_file, taxa_file, out_file) {
  message("Processing: ", otu_file)
  otu <- read.csv(otu_file, row.names = 1, check.names = FALSE)
  otu <- otu[, colSums(!is.na(otu)) > 0, drop = FALSE]
  tax <- read.csv(taxa_file, row.names = 1, check.names = FALSE) %>% select(taxonomy) %>% separate(taxonomy, into = c("Domain", "Phylum", "Class", "Order", "Family",
    "Genus", "Species"), sep = ";\\s*", extra = "drop", fill = "right")
  tax[is.na(tax)] <- "Unclassified"
  tax <- tax[rownames(otu),]
  res <- data.frame(ASV = rownames(tax), tax, Genus.join = ifelse(tax$Genus %in% c("Unclassified", "g__"), NA, sub("^g__", "", tax$Genus)), stringsAsFactors = FALSE) %>%
    left_join(trophic_db, by = "Genus.join") %>% cbind(otu[.$ASV,, drop = FALSE])
  write.csv(res, out_file, row.names = FALSE)
  message("Annotation success rate: ", round(mean(!is.na(res$primary)) * 100, 2), "%\n")
  invisible(res)
}
annotate_traits("根际_asv.csv", "根际_taxa.csv", "根际_ASV_FungalTraits_with_abundance.csv")
annotate_traits("根内_asv.csv", "根内_taxa.csv", "根内_ASV_FungalTraits_with_abundance.csv")
annotate_traits("叶际_asv.csv", "叶际_taxa.csv", "叶际_ASV_FungalTraits_with_abundance.csv")
setwd("D:/IUE/山西数据/真菌/抽平/fungtraits功能注释/2026.1.26 fungtraits 注释分析")
library(tidyverse)
final_fun_levels <- c("NA", "Others_function", "soil_saprotroph", "litter_saprotroph", "wood_saprotroph", "plant_pathogen", "arbuscular_mycorrhizal", "ectomycorrhizal",
  "animal_parasite", "mycoparasite")
final_fun_colors <- c("NA" = "#BDBDBD", "Others_function" = "#E0E0E0", "soil_saprotroph" = "#D95F02", "litter_saprotroph" = "#7570B3", "wood_saprotroph" = "#1B9E77",
  "plant_pathogen" = "#E7298A", "arbuscular_mycorrhizal" = "#66A61E", "ectomycorrhizal" = "#A6761D", "animal_parasite" = "#E6AB02", "mycoparasite" = "#666666")
group_long <- read.csv("分组.csv", check.names = FALSE) %>% transmute(R_sample = `#R_sample`, R_group = R_G1234_ABCD, T_sample = `#T_sample`, T_group = T_G1234_ABCD,
  L_sample = `#L_sample`, L_group = L_G1234_ABCD) %>% pivot_longer(everything(), names_to = c("Type", ".value"), names_sep = "_") %>% filter(!is.na(sample), sample != "") %>%
  mutate(Compartment = recode(Type, R = "Rhizosphere", T = "Root_endosphere", L = "Phyllosphere"), Period = case_when(grepl("^JS_", group) ~ "Jointing stage", grepl(
  "^HS_", group) ~ "Heading stage", grepl("^FS_", group) ~ "Filling stage", grepl("^MS_", group) ~ "Maturity stage"), Drought = case_when(grepl("_Control$", group) ~
  "Control", grepl("_Drought_L$", group) ~ "Drought_L", grepl("_Drought_M$", group) ~ "Drought_M", grepl("_Drought_H$", group) ~ "Drought_H")) %>% filter(!is.na(Period),
  !is.na(Drought)) %>% mutate(Period = factor(Period, levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")), Drought = factor(Drought, levels
  = c("Control", "Drought_L", "Drought_M", "Drought_H")))
plot_fungal_function <- function (infile, compartment, prefix) {
  message("Processing: ", compartment)
  prop_fun <- read.csv(infile, check.names = FALSE) %>% pivot_longer(cols = - (ASV:secondary), names_to = "Sample", values_to = "Abundance") %>% left_join(group_long %>%
    filter(Compartment == compartment), by = c("Sample" = "sample")) %>% mutate(Function = case_when(is.na(primary) ~ "NA", primary %in% final_fun_levels ~ primary, TRUE
    ~ "Others_function")) %>% filter(Abundance > 0) %>% group_by(Period, Drought, Function) %>% summarise(Total = sum(Abundance), .groups = "drop") %>% group_by(Period,
    Drought) %>% mutate(Proportion = Total / sum(Total)) %>% ungroup() %>% mutate(Function = factor(Function, levels = final_fun_levels))
  write.csv(prop_fun, paste0(prefix, "_proportion.csv"), row.names = FALSE)
  p <- ggplot(prop_fun, aes(Drought, Proportion, fill = Function)) + geom_bar(stat = "identity", width = 0.8, color = "black") + facet_grid(. ~ Period, scales = "free_x",
    space = "free_x") + scale_fill_manual(values = final_fun_colors, drop = FALSE) + theme_bw() + theme(axis.text.x = element_text(angle = 45, hjust = 1), panel.spacing.x
    = unit(1, "lines"), strip.background = element_rect(fill = "grey90"), strip.text = element_text(face = "bold")) + labs(x = "Drought gradient", y =
    "Proportion of fungal functional guilds", fill = "Fungal function", title = paste0("Fungal functional composition (", compartment, ")"))
  print(p)
  ggsave(filename = paste0(prefix, "_stacked_bar.pdf"), plot = p, width = 16, height = 6)
}
