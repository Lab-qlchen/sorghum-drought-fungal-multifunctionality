rm(list = ls())
grDevices::graphics.off()
options(stringsAsFactors = FALSE)
options(contrasts = c("contr.sum", "contr.poly"))
set.seed(123)
required_packages <- c("tidyverse", "vegan", "permute", "lme4", "lmerTest", "emmeans", "patchwork")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(tidyverse)
  library(vegan)
  library(permute)
  library(lme4)
  library(lmerTest)
  library(emmeans)
  library(patchwork)
})
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/26.8.28 fungi SMF/群落组成")
output_dir <- "Fungal_PERMANOVA_Shannon_results"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
n_permutations <- 999L
transform_asv_to_relative_abundance <- TRUE
period_levels <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
compartment_levels <- c("Phyllosphere", "Endosphere", "Rhizosphere")
compartment_colors <- c(Phyllosphere = "#4E79A7", Endosphere = "#59A14F", Rhizosphere = "#E15759")
compartment_shapes <- c(Phyllosphere = 16, Endosphere = 17, Rhizosphere = 15)
p_stars <- function (p) {
  dplyr::case_when(is.na(p) ~ "", p < 0.001 ~ "***", p < 0.01 ~ "**", p < 0.05 ~ "*", TRUE ~ "")
}
z_score <- function (x) {
  x_sd <- stats::sd(x, na.rm = TRUE)
  if (!is.finite(x_sd) || x_sd == 0) {
    stop("A zero-variance Shannon group cannot be standardized.")
  }
  as.numeric((x - mean(x, na.rm = TRUE)) / x_sd)
}
save_pdf <- function (filename, plot, width, height) {
  if (capabilities("cairo")) {
    ggsave(filename = filename, plot = plot, width = width, height = height, device = grDevices::cairo_pdf)
  } else {
    ggsave(filename = filename, plot = plot, width = width, height = height)
  }
}
theme_publication <- theme_classic(base_size = 11) + theme(axis.title = element_text(size = 11, colour = "black"), axis.text = element_text(size = 10, colour = "black"),
  axis.line = element_line(linewidth = 0.6, colour = "black"), axis.ticks = element_line(linewidth = 0.5, colour = "black"), strip.background = element_rect(fill =
  "#EEEEEE", colour = "black", linewidth = 0.5), strip.text = element_text(size = 10.5, face = "bold", colour = "black"), legend.title = element_blank(), legend.text =
  element_text(size = 9.5, colour = "black"), plot.tag = element_text(size = 15, face = "bold", colour = "black"))
build_design_metadata <- function (sample, group_label) {
  out <- tibble(Sample = as.character(sample), Group = as.character(group_label), Period = case_when(str_detect(Group, "^JS_") ~ "Jointing stage", str_detect(Group,
    "^HS_") ~ "Heading stage", str_detect(Group, "^FS_") ~ "Filling stage", str_detect(Group, "^MS_") ~ "Maturity stage", TRUE ~ NA_character_), Drought = case_when(
    str_detect(Group, "_Control$") ~ "Control", str_detect(Group, "_Drought_L$") ~ "Drought_L", str_detect(Group, "_Drought_M$") ~ "Drought_M", str_detect(Group,
    "_Drought_H$") ~ "Drought_H", TRUE ~ NA_character_), Genotype = case_when(str_detect(Sample, "^Z") ~ "Jinza 22", str_detect(Sample, "^N") ~ "Liangnuo 01", TRUE ~
    NA_character_), Block = str_match(Sample, "_([1-4])$")[, 2])
  if (anyNA(out)) {
    bad_samples <- out$Sample[!complete.cases(out)]
    stop("Could not derive Period, Drought, Genotype or Block for: ", paste(bad_samples, collapse = ", "))
  }
  out %>% mutate(Block = factor(Block, levels = as.character(1:4)), Period = factor(Period, levels = period_levels), Drought = factor(Drought, levels = drought_levels),
    Genotype = factor(Genotype, levels = c("Jinza 22", "Liangnuo 01")), MainPlotID = interaction(Block, Drought, drop = TRUE, sep = "_"), PlotID = interaction(Block,
    Drought, Genotype, drop = TRUE, sep = "_"))
}
check_splitplot_structure <- function (meta, expected_rows, context) {
  if (nrow(meta) != expected_rows) {
    stop(context, ": expected ", expected_rows, " observations, found ", nrow(meta), ".")
  }
  if (n_distinct(meta$MainPlotID) != 16L) {
    stop(context, ": expected 16 Block x Drought main plots.")
  }
  if (n_distinct(meta$PlotID) != 32L) {
    stop(context, ": expected 32 genotype subplots.")
  }
  cell_check <- meta %>% count(Block, Drought, Genotype, Period, name = "n")
  if (nrow(cell_check) != 128L || any(cell_check$n != 1L)) {
    print(cell_check)
    stop(context, ": each Block x Drought x Genotype x Period cell must occur once.")
  }
}
wholeplot_permutation <- function (meta, nperm = n_permutations) {
  permute::how(within = permute::Within(type = "none"), plots = permute::Plots(strata = meta$MainPlotID, type = "free"), blocks = meta$Block, nperm = nperm, complete =
    FALSE)
}
extract_adonis_effect <- function (table, effect = "Drought") {
  table_df <- as.data.frame(table)
  table_df$Effect <- rownames(table_df)
  rownames(table_df) <- NULL
  out <- table_df %>% filter(Effect == effect)
  if (nrow(out) != 1L) {
    stop("PERMANOVA effect was not found exactly once: ", effect)
  }
  tibble(R2 = as.numeric(out$R2), F_value = as.numeric(out$F), P_value = as.numeric(out$`Pr(>F)`))
}
read_community <- function (asv_file, group_file, compartment) {
  asv_raw <- read.csv(asv_file, check.names = FALSE, fileEncoding = "UTF-8-BOM")
  group_raw <- read.csv(group_file, check.names = FALSE, fileEncoding = "UTF-8-BOM")
  if (ncol(group_raw) < 2L) {
    stop(group_file, " must contain sample and group columns.")
  }
  names(group_raw)[1:2] <- c("Sample", "Group")
  if (anyDuplicated(group_raw$Sample)) {
    stop(group_file, " contains duplicated sample IDs.")
  }
  sample_columns <- match(group_raw$Sample, names(asv_raw))
  if (anyNA(sample_columns)) {
    missing_samples <- group_raw$Sample[is.na(sample_columns)]
    stop(asv_file, " is missing samples listed in ", group_file, ": ", paste(missing_samples, collapse = ", "))
  }
  asv <- t(as.matrix(asv_raw[, sample_columns, drop = FALSE]))
  storage.mode(asv) <- "numeric"
  rownames(asv) <- names(asv_raw)[sample_columns]
  if (any(!is.finite(asv)) || any(asv < 0)) {
    stop(asv_file, " contains non-finite or negative abundance values.")
  }
  keep_samples <- rowSums(asv) > 0
  if (!all(keep_samples)) {
    warning(compartment, ": zero-sum samples were removed.")
    asv <- asv[keep_samples,, drop = FALSE]
  }
  keep_taxa <- colSums(asv) > 0
  asv <- asv[, keep_taxa, drop = FALSE]
  meta <- build_design_metadata(group_raw$Sample, group_raw$Group)
  meta <- meta[match(rownames(asv), meta$Sample),, drop = FALSE]
  if (!identical(rownames(asv), meta$Sample)) {
    stop(compartment, ": ASV rows and metadata are not aligned.")
  }
  check_splitplot_structure(meta, 128L, compartment)
  if (transform_asv_to_relative_abundance) {
    asv <- vegan::decostand(asv, method = "total")
  }
  list(asv = asv, meta = meta, compartment = compartment)
}
community_L <- read_community("叶际F_ASV.csv", "叶际分组.csv", "Phyllosphere")
community_T <- read_community("根内F_ASV.csv", "根内分组.csv", "Endosphere")
community_R <- read_community("根际F_ASV.csv", "根际分组.csv", "Rhizosphere")
run_permanova <- function (community) {
  asv <- community$asv
  meta <- community$meta
  compartment <- community$compartment
  overall_permutation <- wholeplot_permutation(meta)
  overall_fit <- vegan::adonis2(asv ~ Block + Period + Genotype + Drought, data = meta, method = "bray", permutations = overall_permutation, by = "margin")
  overall_result <- extract_adonis_effect(overall_fit, "Drought") %>% mutate(Compartment = compartment, Period = "Overall", N = nrow(meta), Formula =
    "Block + Period + Genotype + Drought", .before = 1)
  overall_distance <- vegan::vegdist(asv, method = "bray")
  overall_dispersion <- vegan::betadisper(overall_distance, meta$Drought)
  overall_dispersion_test <- permutest(overall_dispersion, permutations = overall_permutation)
  overall_dispersion_row <- tibble(Compartment = compartment, Period = "Overall", F_value = as.numeric(overall_dispersion_test$tab[1, "F"]), P_value = as.numeric(
    overall_dispersion_test$tab[1, "Pr(>F)"]))
  stage_results <- list()
  stage_dispersion_results <- list()
  for (stage in period_levels) {
    index <- meta$Period == stage
    stage_asv <- asv[index,, drop = FALSE]
    stage_meta <- droplevels(meta[index,, drop = FALSE])
    stage_permutation <- wholeplot_permutation(stage_meta)
    stage_fit <- vegan::adonis2(stage_asv ~ Block + Genotype + Drought, data = stage_meta, method = "bray", permutations = stage_permutation, by = "margin")
    stage_results[[stage]] <- extract_adonis_effect(stage_fit, "Drought") %>% mutate(Compartment = compartment, Period = stage, N = nrow(stage_meta), Formula =
      "Block + Genotype + Drought", .before = 1)
    stage_distance <- vegan::vegdist(stage_asv, method = "bray")
    stage_dispersion <- vegan::betadisper(stage_distance, stage_meta$Drought)
    stage_dispersion_test <- permutest(stage_dispersion, permutations = stage_permutation)
    stage_dispersion_results[[stage]] <- tibble(Compartment = compartment, Period = stage, F_value = as.numeric(stage_dispersion_test$tab[1, "F"]), P_value = as.numeric(
      stage_dispersion_test$tab[1, "Pr(>F)"]))
  }
  list(permanova = bind_rows(overall_result, bind_rows(stage_results)), dispersion = bind_rows(overall_dispersion_row, bind_rows(stage_dispersion_results)))
}
permanova_results <- list(run_permanova(community_L), run_permanova(community_T), run_permanova(community_R))
permanova_table <- bind_rows(lapply(permanova_results, `[[`, "permanova")) %>% mutate(Compartment = factor(Compartment, levels = compartment_levels), Period = factor(
  Period, levels = c("Overall", period_levels)), Significance = p_stars(P_value), Label = ifelse(Significance == "", sprintf("%.3f", R2), paste0(sprintf("%.3f", R2), "\n"
  , Significance)))
dispersion_table <- bind_rows(lapply(permanova_results, `[[`, "dispersion")) %>% mutate(Compartment = factor(Compartment, levels = compartment_levels), Period = factor(
  Period, levels = c("Overall", period_levels)))
write.csv(permanova_table, file.path(output_dir, "01_PERMANOVA_drought_R2.csv"), row.names = FALSE)
write.csv(dispersion_table, file.path(output_dir, "02_PERMANOVA_dispersion_checks.csv"), row.names = FALSE)
position_A <- position_dodge(width = 0.78)
max_A <- max(permanova_table$R2, na.rm = TRUE)
figure_A <- ggplot(permanova_table, aes(x = Period, y = R2, fill = Compartment)) + geom_col(position = position_A, width = 0.68, colour = "black", linewidth = 0.35) +
  geom_text(aes(label = Label), position = position_A, vjust = - 0.25, size = 3.25, lineheight = 0.85, colour = "black") + geom_vline(xintercept = 1.5, linetype =
  "dashed", linewidth = 0.45, colour = "grey55") + scale_fill_manual(values = compartment_colors, drop = FALSE) + scale_x_discrete(labels = c(Overall = "Overall",
  `Jointing stage` = "Jointing", `Heading stage` = "Heading", `Filling stage` = "Filling", `Maturity stage` = "Maturity")) + scale_y_continuous(limits = c(0, max_A * 1.24
  ), expand = expansion(mult = c(0, 0))) + labs(x = NULL, y = expression("Drought effect size (PERMANOVA " * R ^ 2 * ")"), fill = NULL) + theme_publication + theme(
  legend.position = "top", legend.key.width = grid::unit(1.2, "cm"), plot.margin = ggplot2::margin(5, 12, 5, 5))
print(figure_A)
save_pdf(file.path(output_dir, "Figure_A_PERMANOVA_drought_R2.pdf"), figure_A, width = 9.5, height = 4.2)
ggsave(file.path(output_dir, "Figure_A_PERMANOVA_drought_R2.png"), figure_A, width = 9.5, height = 4.2, dpi = 600)
clean_label <- function (x) {
  stringr::str_squish(as.character(x))
}
period_from_column <- function (x) {
  raw <- clean_label(x)
  key <- stringr::str_to_lower(stringr::str_replace_all(raw, "[[:space:]_-]+", ""))
  dplyr::case_when(key %in% c("jointing", "jointingstage", "js", "stage1", "1") | stringr::str_detect(key, "^jointing") | stringr::str_detect(raw, "拔节") ~
    "Jointing stage", key %in% c("heading", "headingstage", "hs", "stage2", "2") | stringr::str_detect(key, "^heading") | stringr::str_detect(raw, "抽穗") ~ "Heading stage"
    , key %in% c("filling", "fillingstage", "grainfilling", "grainfillingstage", "fs", "stage3", "3") | stringr::str_detect(key, "^(grain)?filling") | stringr::str_detect
    (raw, "灌浆") ~ "Filling stage", key %in% c("maturity", "maturitystage", "mature", "ms", "stage4", "4") | stringr::str_detect(key, "^matur") | stringr::str_detect(raw,
    "成熟") ~ "Maturity stage", TRUE ~ NA_character_)
}
period_from_sample <- function (sample) {
  stage_code <- stringr::str_match(stringr::str_to_upper(clean_label(sample)), "^[ZN]([1-4])")[, 2]
  dplyr::recode(stage_code, `1` = "Jointing stage", `2` = "Heading stage", `3` = "Filling stage", `4` = "Maturity stage", .default = NA_character_)
}
drought_from_column <- function (x) {
  raw <- clean_label(x)
  key <- stringr::str_to_lower(stringr::str_replace_all(raw, "[[:space:]_()%-]+", ""))
  dplyr::case_when(key %in% c("control", "ck", "a", "normal", "control80fc", "80fc") | stringr::str_detect(key, "control|80fc") | stringr::str_detect(raw, "对照|正常") ~
    "Control", key %in% c("droughtl", "light", "lightdrought", "b", "60fc") | stringr::str_detect(key, "light|droughtl|60fc") | stringr::str_detect(raw, "轻") ~
    "Drought_L", key %in% c("droughtm", "moderate", "moderatedrought", "c", "50fc") | stringr::str_detect(key, "moderate|droughtm|50fc") | stringr::str_detect(raw, "中") ~
    "Drought_M", key %in% c("droughth", "heavy", "heavydrought", "severe", "severedrought", "d", "40fc") | stringr::str_detect(key, "heavy|severe|droughth|40fc") |
    stringr::str_detect(raw, "重") ~ "Drought_H", TRUE ~ NA_character_)
}
drought_from_sample <- function (sample) {
  drought_code <- stringr::str_match(stringr::str_to_upper(clean_label(sample)), "([A-D])_[1-4]$")[, 2]
  dplyr::recode(drought_code, A = "Control", B = "Drought_L", C = "Drought_M", D = "Drought_H", .default = NA_character_)
}
block_from_column <- function (x) {
  raw <- stringr::str_to_upper(clean_label(x))
  numeric_code <- stringr::str_match(raw, "([1-4])$")[, 2]
  letter_code <- dplyr::recode(raw, A = "1", B = "2", C = "3", D = "4", .default = NA_character_)
  dplyr::coalesce(numeric_code, letter_code)
}
block_from_sample <- function (sample) {
  stringr::str_match(clean_label(sample), "_([1-4])$")[, 2]
}
genotype_from_column <- function (x) {
  raw <- clean_label(x)
  key <- stringr::str_to_lower(stringr::str_replace_all(raw, "[[:space:]_-]+", ""))
  dplyr::case_when(key %in% c("variety1", "genotype1", "jinza", "jinza22", "jz", "z", "1") | stringr::str_detect(key, "jinza") | stringr::str_detect(raw, "晋杂|杂") ~
    "Jinza 22", key %in% c("variety2", "genotype2", "liangnuo", "liangnuo01", "ln", "n", "2") | stringr::str_detect(key, "liangnuo") | stringr::str_detect(raw, "良糯|糯") ~
    "Liangnuo 01", TRUE ~ NA_character_)
}
genotype_from_sample <- function (sample) {
  genotype_code <- stringr::str_sub(stringr::str_to_upper(clean_label(sample)), 1, 1)
  dplyr::recode(genotype_code, Z = "Jinza 22", N = "Liangnuo 01", .default = NA_character_)
}
append_problem <- function (problem, condition, label) {
  condition[is.na(condition)] <- TRUE
  ifelse(condition, ifelse(problem == "", label, paste(problem, label, sep = "; ")), problem)
}
read_shannon <- function (filename, compartment) {
  x <- read.csv(filename, check.names = FALSE, fileEncoding = "UTF-8-BOM")
  required_columns <- c("Sample", "Shannon", "Block", "Period", "Drought", "Variety")
  if (!all(required_columns %in% names(x))) {
    stop(filename, " is missing columns: ", paste(setdiff(required_columns, names(x)), collapse = ", "))
  }
  sample_value <- clean_label(x$Sample)
  shannon_text <- clean_label(x$Shannon)
  shannon_value <- suppressWarnings(as.numeric(stringr::str_replace(shannon_text, ",", ".")))
  period_column <- period_from_column(x$Period)
  period_sample <- period_from_sample(sample_value)
  period_value <- dplyr::coalesce(period_sample, period_column)
  drought_column <- drought_from_column(x$Drought)
  drought_sample <- drought_from_sample(sample_value)
  drought_value <- dplyr::coalesce(drought_sample, drought_column)
  block_column <- block_from_column(x$Block)
  block_sample <- block_from_sample(sample_value)
  block_value <- dplyr::coalesce(block_sample, block_column)
  genotype_column <- genotype_from_column(x$Variety)
  genotype_sample <- genotype_from_sample(sample_value)
  genotype_value <- dplyr::coalesce(genotype_sample, genotype_column)
  problem <- rep("", nrow(x))
  problem <- append_problem(problem, is.na(sample_value) | sample_value == "", "missing Sample")
  problem <- append_problem(problem, is.na(shannon_value) | !is.finite(shannon_value), "missing/non-numeric Shannon")
  problem <- append_problem(problem, is.na(block_value), "unrecognized Block")
  problem <- append_problem(problem, is.na(period_value), "unrecognized Period")
  problem <- append_problem(problem, is.na(drought_value), "unrecognized Drought")
  problem <- append_problem(problem, is.na(genotype_value), "unrecognized Variety")
  problem <- append_problem(problem, !is.na(block_sample) & !is.na(block_column) & block_sample != block_column, "Sample/Block conflict")
  problem <- append_problem(problem, !is.na(period_sample) & !is.na(period_column) & period_sample != period_column, "Sample/Period conflict")
  problem <- append_problem(problem, !is.na(drought_sample) & !is.na(drought_column) & drought_sample != drought_column, "Sample/Drought conflict")
  problem <- append_problem(problem, !is.na(genotype_sample) & !is.na(genotype_column) & genotype_sample != genotype_column, "Sample/Variety conflict")
  parsed <- tibble(Source_file = filename, Source_row = seq_len(nrow(x)) + 1L, Sample = sample_value, Shannon_raw = as.character(x$Shannon), Block_raw = as.character(x$
    Block), Period_raw = as.character(x$Period), Drought_raw = as.character(x$Drought), Variety_raw = as.character(x$Variety), Shannon = shannon_value, Block =
    block_value, Period = period_value, Drought = drought_value, Genotype = genotype_value, Problem = problem)
  bad <- parsed %>% filter(Problem != "")
  if (nrow(bad) > 0L) {
    diagnostic_file <- file.path(output_dir, paste0("ERROR_", compartment, "_Shannon_import.csv"))
    write.csv(bad, diagnostic_file, row.names = FALSE, fileEncoding = "UTF-8")
    print(bad)
    stop(filename, " contains ", nrow(bad), " unrecognized or conflicting row(s). See: ", diagnostic_file)
  }
  parsed %>% transmute(Sample, Shannon, Block = factor(Block, levels = as.character(1:4)), Period = factor(Period, levels = period_levels), Drought = factor(Drought,
    levels = drought_levels), Genotype = factor(Genotype, levels = c("Jinza 22", "Liangnuo 01")), Compartment = factor(compartment, levels = compartment_levels))
}
shannon_data <- bind_rows(read_shannon("叶际_Shannon_perSample.csv", "Phyllosphere"), read_shannon("根内_Shannon_perSample.csv", "Endosphere"), read_shannon(
  "根际_Shannon_perSample.csv", "Rhizosphere"))
if (anyNA(shannon_data)) {
  stop("Unexpected NA remained after the validated Shannon import.")
}
write.csv(shannon_data, file.path(output_dir, "00_Shannon_normalized_input.csv"), row.names = FALSE, fileEncoding = "UTF-8")
if (nrow(shannon_data) != 384L) {
  stop("Expected 384 Shannon observations: 128 per compartment.")
}
if (nlevels(shannon_data$Genotype) != 2L) {
  stop("Expected exactly two genotype levels in the Variety column.")
}
shannon_cell_check <- shannon_data %>% count(Block, Drought, Genotype, Period, Compartment, name = "n")
if (nrow(shannon_cell_check) != 384L || any(shannon_cell_check$n != 1L)) {
  print(shannon_cell_check)
  stop("Each Block x Drought x Genotype x Period x Compartment cell must occur once.")
}
shannon_data <- shannon_data %>% dplyr::mutate(MainPlotID = interaction(Block, Drought, drop = TRUE, sep = "_"), PlotID = interaction(Block, Drought, Genotype, drop =
  TRUE, sep = "_"), Compartment = factor(Compartment, levels = compartment_levels)) %>% dplyr::group_by(Compartment) %>% dplyr::mutate(Shannon_z = z_score(Shannon)) %>%
  dplyr::ungroup()
if (dplyr::n_distinct(shannon_data$MainPlotID) != 16L || dplyr::n_distinct(shannon_data$PlotID) != 32L) {
  stop("Shannon split-plot identifiers are inconsistent with the design.")
}
fit_shannon_compartment <- function (compartment_name) {
  dat_comp <- shannon_data %>% dplyr::filter(Compartment == compartment_name) %>% droplevels()
  if (nrow(dat_comp) != 128L) {
    stop(compartment_name, ": expected 128 Shannon observations, found ", nrow(dat_comp), ".")
  }
  model <- lmerTest::lmer(Shannon_z ~ Block + Drought * Period + Genotype + (1 | MainPlotID) + (1 | PlotID), data = dat_comp, REML = TRUE, control = lme4::lmerControl(
    optimizer = "bobyqa", optCtrl = list(maxfun = 200000)))
  anova_result <- tryCatch(list(table = stats::anova(model, type = 3, ddf = "Kenward-Roger"), method = "Kenward-Roger"), error = function (e) {
    list(table = stats::anova(model, type = 3, ddf = "Satterthwaite"), method = "Satterthwaite")
  })
  anova_df <- as.data.frame(anova_result$table)
  anova_df$Effect <- rownames(anova_df)
  rownames(anova_df) <- NULL
  anova_df <- anova_df %>% dplyr::mutate(Compartment = compartment_name, DDF_method = anova_result$method, .before = 1)
  emm <- tryCatch(emmeans::emmeans(model, ~ Drought | Period, weights = "equal", lmer.df = "kenward-roger"), error = function (e) {
    emmeans::emmeans(model, ~ Drought | Period, weights = "equal", lmer.df = "satterthwaite")
  })
  pairwise_obj <- emmeans::contrast(emm, method = "pairwise", adjust = "tukey")
  pairwise_df <- as.data.frame(summary(pairwise_obj, infer = c(TRUE, TRUE), adjust = "tukey")) %>% dplyr::mutate(Compartment = compartment_name, .before = 1)
  control_df <- pairwise_df %>% dplyr::filter(stringr::str_detect(contrast, "^Control - Drought_(L|M|H)$")) %>% dplyr::mutate(Drought = dplyr::case_when(stringr::
    str_detect(contrast, "Drought_L$") ~ "Drought_L", stringr::str_detect(contrast, "Drought_M$") ~ "Drought_M", stringr::str_detect(contrast, "Drought_H$") ~ "Drought_H"
    , TRUE ~ NA_character_), original_lower = lower.CL, original_upper = upper.CL, estimate = - estimate, lower.CL = - original_upper, upper.CL = - original_lower,
    P_value_Tukey = p.value, Significance = p_stars(P_value_Tukey), Drought = factor(Drought, levels = c("Drought_L", "Drought_M", "Drought_H")), Period = factor(Period,
    levels = period_levels), Compartment = factor(Compartment, levels = compartment_levels)) %>% dplyr::select(- original_lower, - original_upper)
  if (nrow(control_df) != length(period_levels) * 3L) {
    stop(compartment_name, ": expected 12 Tukey-adjusted drought-vs-Control contrasts.")
  }
  variance_df <- as.data.frame(lme4::VarCorr(model))
  variance_value <- function (group_name) {
    out <- variance_df %>% dplyr::filter(grp == group_name) %>% dplyr::pull(vcov)
    if (length(out) == 0L) {
      return(NA_real_)
    }
    as.numeric(out[[1]])
  }
  model_check <- tibble::tibble(Compartment = compartment_name, N = stats::nobs(model), Singular_fit = lme4::isSingular(model, tol = 1e-5), MainPlot_variance =
    variance_value("MainPlotID"), Plot_variance = variance_value("PlotID"), Residual_variance = variance_value("Residual"))
  list(model = model, anova = anova_df, emmeans = as.data.frame(emm), pairwise = pairwise_df, control = control_df, check = model_check)
}
shannon_results <- stats::setNames(lapply(compartment_levels, fit_shannon_compartment), compartment_levels)
shannon_anova <- dplyr::bind_rows(lapply(shannon_results, `[[`, "anova"))
shannon_pairwise <- dplyr::bind_rows(lapply(shannon_results, `[[`, "pairwise"))
shannon_contrasts <- dplyr::bind_rows(lapply(shannon_results, `[[`, "control"))
shannon_model_check <- dplyr::bind_rows(lapply(shannon_results, `[[`, "check"))
write.csv(shannon_anova, file.path(output_dir, "03_Shannon_LMM_TypeIII_ANOVA.csv"), row.names = FALSE)
write.csv(shannon_pairwise, file.path(output_dir, "04_Shannon_all_pairwise_Tukey.csv"), row.names = FALSE)
write.csv(shannon_contrasts, file.path(output_dir, "05_Shannon_drought_vs_Control.csv"), row.names = FALSE)
write.csv(shannon_model_check, file.path(output_dir, "06_Shannon_model_check.csv"), row.names = FALSE)
capture.output({
  for (compartment_name in compartment_levels) {
    cat("\n\n================ ", compartment_name, " ================\n", sep = "")
    print(summary(shannon_results[[compartment_name]]$model))
  }
}, file = file.path(output_dir, "04_Shannon_LMM_summary.txt"))
range_B <- range(c(shannon_contrasts$lower.CL, shannon_contrasts$upper.CL), na.rm = TRUE)
offset_B <- diff(range_B) * 0.045
if (!is.finite(offset_B) || offset_B <= 0) offset_B <- 0.08
shannon_plot_data <- shannon_contrasts %>% mutate(Label_y = ifelse(estimate >= 0, upper.CL + offset_B, lower.CL - offset_B), Label_vjust = ifelse(estimate >= 0, 0, 1))
position_B <- position_dodge(width = 0.64)
figure_B <- ggplot(shannon_plot_data, aes(x = Drought, y = estimate, colour = Compartment, shape = Compartment, group = Compartment)) + geom_hline(yintercept = 0,
  linetype = "dashed", linewidth = 0.45, colour = "grey55") + geom_errorbar(aes(ymin = lower.CL, ymax = upper.CL), position = position_B, width = 0, linewidth = 0.7) +
  geom_point(position = position_B, size = 2.7) + geom_text(aes(y = Label_y, label = Significance, vjust = Label_vjust), position = position_B, colour = "black", size =
  3.2, show.legend = FALSE) + facet_wrap(~ Period, nrow = 1) + scale_colour_manual(values = compartment_colors, drop = FALSE) + scale_shape_manual(values =
  compartment_shapes, drop = FALSE) + scale_x_discrete(labels = c(Drought_L = "Light", Drought_M = "Moderate", Drought_H = "Heavy")) + labs(x = "Drought treatment", y =
  "Change in standardized Shannon diversity\nrelative to Control", colour = NULL, shape = NULL) + theme_publication + theme(legend.position = "top", panel.spacing.x =
  grid::unit(0.13, "cm"), plot.margin = ggplot2::margin(5, 12, 5, 5)) + coord_cartesian(clip = "off")
print(figure_B)
save_pdf(file.path(output_dir, "Figure_B_Shannon_drought_vs_Control.pdf"), figure_B, width = 10.5, height = 4.4)
ggsave(file.path(output_dir, "Figure_B_Shannon_drought_vs_Control.png"), figure_B, width = 10.5, height = 4.4, dpi = 600)
figure_AB <- (figure_A / figure_B) + plot_layout(heights = c(0.88, 1.00)) + plot_annotation(tag_levels = "A")
print(figure_AB)
save_pdf(file.path(output_dir, "Figure_AB_PERMANOVA_Shannon_final.pdf"), figure_AB, width = 11.2, height = 8.2)
ggsave(file.path(output_dir, "Figure_AB_PERMANOVA_Shannon_final.tiff"), figure_AB, width = 11.2, height = 8.2, units = "in", dpi = 600, compression = "lzw")
ggsave(file.path(output_dir, "Figure_AB_PERMANOVA_Shannon_final.png"), figure_AB, width = 11.2, height = 8.2, dpi = 600)
capture.output(sessionInfo(), file = file.path(output_dir, "07_sessionInfo.txt"))
message("Analysis completed. Results saved in: ", output_dir)
