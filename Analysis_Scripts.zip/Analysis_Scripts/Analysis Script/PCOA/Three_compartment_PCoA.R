rm(list = ls())
grDevices::graphics.off()
options(stringsAsFactors = FALSE)
options(contrasts = c("contr.sum", "contr.poly"))
set.seed(123)
required_packages <- c("tidyverse", "vegan", "permute", "patchwork")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(tidyverse)
  library(vegan)
  library(permute)
  library(patchwork)
})
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/群落组成")
output_dir <- "Three_compartment_PCoA_results"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
n_permutations <- 999L
transform_to_relative_abundance <- TRUE
period_levels <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
genotype_levels <- c("Jinza 22", "Liangnuo 01")
compartment_levels <- c("Phyllosphere", "Endosphere", "Rhizosphere")
drought_colors <- c(Control = "#F8766D", Drought_L = "#7CAE00", Drought_M = "#00BFC4", Drought_H = "#C77CFF")
drought_labels <- c(Control = "Control", Drought_L = "Light drought", Drought_M = "Moderate drought", Drought_H = "Heavy drought")
period_shapes <- c(`Jointing stage` = 21, `Heading stage` = 24, `Filling stage` = 22, `Maturity stage` = 23)
period_labels <- c(`Jointing stage` = "Jointing", `Heading stage` = "Heading", `Filling stage` = "Filling", `Maturity stage` = "Maturity")
clean_label <- function (x) {
  stringr::str_squish(as.character(x))
}
fmt_p <- function (p) {
  if (!is.finite(p)) {
    return("NA")
  }
  if (p < 0.001) {
    return("< 0.001")
  }
  paste0("= ", sprintf("%.3f", p))
}
p_stars <- function (p) {
  dplyr::case_when(is.na(p) ~ "", p < 0.001 ~ "***", p < 0.01 ~ "**", p < 0.05 ~ "*", TRUE ~ "")
}
save_pdf <- function (filename, plot, width, height) {
  if (capabilities("cairo")) {
    ggsave(filename = filename, plot = plot, width = width, height = height, device = grDevices::cairo_pdf)
  } else {
    ggsave(filename = filename, plot = plot, width = width, height = height)
  }
}
theme_pcoa <- theme_classic(base_size = 10.5) + theme(axis.title = element_text(size = 10.5, colour = "black"), axis.text = element_text(size = 9.5, colour = "black"),
  axis.line = element_line(linewidth = 0.55, colour = "black"), axis.ticks = element_line(linewidth = 0.45, colour = "black"), plot.title = element_text(hjust = 0.5, face
  = "bold", size = 11.5, colour = "black"), plot.tag = element_text(face = "bold", size = 14, colour = "black"), legend.title = element_text(size = 10, face = "bold"),
  legend.text = element_text(size = 9.5), plot.margin = ggplot2::margin(8, 8, 8, 8))
build_design_metadata <- function (sample, group_label, source_file) {
  sample_value <- clean_label(sample)
  group_value <- clean_label(group_label)
  sample_upper <- stringr::str_to_upper(sample_value)
  group_upper <- stringr::str_to_upper(group_value)
  period_group <- dplyr::case_when(stringr::str_detect(group_upper, "^JS_") ~ "Jointing stage", stringr::str_detect(group_upper, "^HS_") ~ "Heading stage", stringr::
    str_detect(group_upper, "^FS_") ~ "Filling stage", stringr::str_detect(group_upper, "^MS_") ~ "Maturity stage", TRUE ~ NA_character_)
  drought_group <- dplyr::case_when(stringr::str_detect(group_upper, "_CONTROL$") ~ "Control", stringr::str_detect(group_upper, "_DROUGHT_L$") ~ "Drought_L", stringr::
    str_detect(group_upper, "_DROUGHT_M$") ~ "Drought_M", stringr::str_detect(group_upper, "_DROUGHT_H$") ~ "Drought_H", TRUE ~ NA_character_)
  period_code <- stringr::str_match(sample_upper, "^[ZN]([1-4])")[, 2]
  period_sample <- dplyr::recode(period_code, `1` = "Jointing stage", `2` = "Heading stage", `3` = "Filling stage", `4` = "Maturity stage", .default = NA_character_)
  drought_code <- stringr::str_match(sample_upper, "([A-D])_[1-4]$")[, 2]
  drought_sample <- dplyr::recode(drought_code, A = "Control", B = "Drought_L", C = "Drought_M", D = "Drought_H", .default = NA_character_)
  genotype_code <- stringr::str_sub(sample_upper, 1, 1)
  genotype_value <- dplyr::recode(genotype_code, Z = "Jinza 22", N = "Liangnuo 01", .default = NA_character_)
  block_value <- stringr::str_match(sample_value, "_([1-4])$")[, 2]
  period_value <- dplyr::coalesce(period_group, period_sample)
  drought_value <- dplyr::coalesce(drought_group, drought_sample)
  problem <- rep("", length(sample_value))
  append_problem <- function (problem_vector, condition, label) {
    condition[is.na(condition)] <- TRUE
    ifelse(condition, ifelse(problem_vector == "", label, paste(problem_vector, label, sep = "; ")), problem_vector)
  }
  problem <- append_problem(problem, is.na(sample_value) | sample_value == "", "missing Sample")
  problem <- append_problem(problem, is.na(group_value) | group_value == "", "missing Group")
  problem <- append_problem(problem, is.na(period_value), "unrecognized Period")
  problem <- append_problem(problem, is.na(drought_value), "unrecognized Drought")
  problem <- append_problem(problem, is.na(genotype_value), "unrecognized Genotype")
  problem <- append_problem(problem, is.na(block_value), "unrecognized Block")
  problem <- append_problem(problem, !is.na(period_group) & !is.na(period_sample) & period_group != period_sample, "Sample/Group Period conflict")
  problem <- append_problem(problem, !is.na(drought_group) & !is.na(drought_sample) & drought_group != drought_sample, "Sample/Group Drought conflict")
  diagnostic <- tibble::tibble(Source_file = source_file, Source_row = seq_along(sample_value) + 1L, Sample = sample_value, Group = group_value, Period_from_group =
    period_group, Period_from_sample = period_sample, Period = period_value, Drought_from_group = drought_group, Drought_from_sample = drought_sample, Drought =
    drought_value, Genotype = genotype_value, Block = block_value, Problem = problem)
  bad <- diagnostic %>% dplyr::filter(Problem != "")
  if (nrow(bad) > 0L) {
    diagnostic_path <- file.path(output_dir, paste0("ERROR_", tools::file_path_sans_ext(basename(source_file)), ".csv"))
    write.csv(bad, diagnostic_path, row.names = FALSE, fileEncoding = "UTF-8")
    print(bad)
    stop(source_file, " contains ", nrow(bad), " unrecognized or conflicting row(s). See: ", diagnostic_path)
  }
  diagnostic %>% dplyr::transmute(Sample, Group, Block = factor(Block, levels = as.character(1:4)), Drought = factor(Drought, levels = drought_levels), Genotype = factor(
    Genotype, levels = genotype_levels), Period = factor(Period, levels = period_levels), MainPlotID = interaction(Block, Drought, drop = TRUE, sep = "_"), PlotID =
    interaction(Block, Drought, Genotype, drop = TRUE, sep = "_"))
}
check_splitplot_structure <- function (meta, compartment) {
  if (nrow(meta) != 128L) {
    stop(compartment, ": expected 128 samples, found ", nrow(meta), ".")
  }
  if (dplyr::n_distinct(meta$MainPlotID) != 16L) {
    stop(compartment, ": expected 16 Block x Drought main plots.")
  }
  if (dplyr::n_distinct(meta$PlotID) != 32L) {
    stop(compartment, ": expected 32 genotype subplots.")
  }
  design_cells <- meta %>% dplyr::count(Block, Drought, Genotype, Period, name = "n")
  if (nrow(design_cells) != 128L || any(design_cells$n != 1L)) {
    print(design_cells)
    stop(compartment, ": each Block x Drought x Genotype x Period cell must occur once.")
  }
}
mainplot_permutation <- function (meta) {
  permute::how(within = permute::Within(type = "none"), plots = permute::Plots(strata = meta$MainPlotID, type = "free"), blocks = meta$Block, nperm = n_permutations,
    complete = FALSE)
}
period_permutation <- function (meta) {
  permute::how(within = permute::Within(type = "free"), blocks = meta$PlotID, nperm = n_permutations, complete = FALSE)
}
extract_adonis_effect <- function (table, effect) {
  table_df <- as.data.frame(table)
  table_df$Effect <- rownames(table_df)
  rownames(table_df) <- NULL
  out <- table_df %>% dplyr::filter(Effect == effect)
  if (nrow(out) != 1L) {
    stop("PERMANOVA effect was not found exactly once: ", effect)
  }
  tibble::tibble(R2 = as.numeric(out$R2), F_value = as.numeric(out$F), P_value = as.numeric(out$`Pr(>F)`))
}
extract_dispersion <- function (test, effect) {
  tibble::tibble(Effect = effect, F_value = as.numeric(test$tab[1, "F"]), P_value = as.numeric(test$tab[1, "Pr(>F)"]))
}
effect_line <- function (statistics, effect, label) {
  row <- statistics %>% dplyr::filter(Effect == effect)
  if (nrow(row) != 1L) {
    return(paste0(label, ": unavailable"))
  }
  paste0(label, ": ", "R² = ", sprintf("%.3f", row$R2[[1]]), ", P ", fmt_p(row$P_value[[1]]))
}
read_community <- function (asv_file, group_file, compartment) {
  asv_raw <- read.csv(asv_file, check.names = FALSE, fileEncoding = "UTF-8-BOM")
  group_raw <- read.csv(group_file, check.names = FALSE, fileEncoding = "UTF-8-BOM")
  if (ncol(group_raw) < 2L) {
    stop(group_file, " must contain Sample and Group columns.")
  }
  names(group_raw)[1:2] <- c("Sample", "Group")
  group_raw$Sample <- clean_label(group_raw$Sample)
  group_raw$Group <- clean_label(group_raw$Group)
  if (anyDuplicated(group_raw$Sample)) {
    stop(group_file, " contains duplicated Sample values.")
  }
  sample_columns <- match(group_raw$Sample, names(asv_raw))
  if (anyNA(sample_columns)) {
    missing_samples <- group_raw$Sample[is.na(sample_columns)]
    stop(asv_file, " is missing samples listed in ", group_file, ": ", paste(missing_samples, collapse = ", "))
  }
  abundance_df <- asv_raw[, sample_columns, drop = FALSE]
  abundance_df <- as.data.frame(lapply(abundance_df, function (x) suppressWarnings(as.numeric(as.character(x)))), check.names = FALSE)
  abundance_matrix <- as.matrix(abundance_df)
  if (any(!is.finite(abundance_matrix))) {
    stop(asv_file, " contains missing or non-numeric abundance values.")
  }
  if (any(abundance_matrix < 0)) {
    stop(asv_file, " contains negative abundance values.")
  }
  asv <- t(abundance_matrix)
  rownames(asv) <- names(asv_raw)[sample_columns]
  zero_samples <- rownames(asv)[rowSums(asv) <= 0]
  if (length(zero_samples) > 0L) {
    stop(compartment, " contains zero-sum samples: ", paste(zero_samples, collapse = ", "))
  }
  keep_taxa <- colSums(asv) > 0
  if (!any(keep_taxa)) {
    stop(compartment, ": no non-zero ASVs remain.")
  }
  asv <- asv[, keep_taxa, drop = FALSE]
  meta <- build_design_metadata(group_raw$Sample, group_raw$Group, group_file)
  meta <- meta[match(rownames(asv), meta$Sample),, drop = FALSE]
  if (!identical(rownames(asv), as.character(meta$Sample))) {
    stop(compartment, ": ASV rows and metadata are not aligned.")
  }
  check_splitplot_structure(meta, compartment)
  if (transform_to_relative_abundance) {
    asv <- vegan::decostand(asv, method = "total")
  }
  list(asv = asv, meta = meta, compartment = compartment, asv_file = asv_file, group_file = group_file)
}
communities <- list(read_community("叶际F_ASV.csv", "叶际分组.csv", "Phyllosphere"), read_community("根内F_ASV.csv", "根内分组.csv", "Endosphere"), read_community("根际F_ASV.csv",
  "根际分组.csv", "Rhizosphere"))
run_compartment <- function (community) {
  asv <- community$asv
  meta <- community$meta
  compartment <- community$compartment
  bray <- vegan::vegdist(asv, method = "bray")
  ordination <- stats::cmdscale(bray, k = 2, eig = TRUE)
  if (is.null(ordination$points) || ncol(ordination$points) < 2L) {
    stop(compartment, ": fewer than two PCoA axes were returned.")
  }
  positive_eigenvalues <- ordination$eig[ordination$eig > 0]
  if (length(positive_eigenvalues) < 2L) {
    stop(compartment, ": fewer than two positive PCoA eigenvalues.")
  }
  axis_1_percent <- 100 * positive_eigenvalues[1] / sum(positive_eigenvalues)
  axis_2_percent <- 100 * positive_eigenvalues[2] / sum(positive_eigenvalues)
  score_df <- as.data.frame(ordination$points[, 1:2, drop = FALSE])
  names(score_df) <- c("PCoA1", "PCoA2")
  score_df <- dplyr::bind_cols(tibble::tibble(Compartment = factor(compartment, levels = compartment_levels)), tibble::as_tibble(score_df), meta)
  model_formula_text <- "Block + Period + Genotype + Drought"
  drought_fit <- vegan::adonis2(asv ~ Block + Period + Genotype + Drought, data = meta, method = "bray", permutations = mainplot_permutation(meta), by = "margin")
  period_fit <- vegan::adonis2(asv ~ Block + Period + Genotype + Drought, data = meta, method = "bray", permutations = period_permutation(meta), by = "margin")
  permanova_statistics <- dplyr::bind_rows(extract_adonis_effect(period_fit, "Period") %>% dplyr::mutate(Effect = "Stage", Model_term = "Period", Formula =
    model_formula_text, Permutation_unit = "Period within PlotID"), extract_adonis_effect(drought_fit, "Drought") %>% dplyr::mutate(Effect = "Drought", Model_term =
    "Drought", Formula = model_formula_text, Permutation_unit = "MainPlotID within Block")) %>% dplyr::mutate(Compartment = compartment, N = nrow(meta), Significance =
    p_stars(P_value), .before = 1) %>% dplyr::select(Compartment, Effect, Model_term, R2, F_value, P_value, Significance, N, Formula, Permutation_unit)
  drought_dispersion <- vegan::betadisper(bray, meta$Drought)
  drought_dispersion_test <- vegan::permutest(drought_dispersion, permutations = mainplot_permutation(meta))
  period_dispersion <- vegan::betadisper(bray, meta$Period)
  period_dispersion_test <- vegan::permutest(period_dispersion, permutations = period_permutation(meta))
  dispersion_statistics <- dplyr::bind_rows(extract_dispersion(drought_dispersion_test, "Drought"), extract_dispersion(period_dispersion_test, "Stage")) %>% dplyr::mutate(
    Compartment = compartment, N = nrow(meta), .before = 1)
  axis_statistics <- tibble::tibble(Compartment = compartment, Axis = c("PCoA1", "PCoA2"), Explained_percent = c(axis_1_percent, axis_2_percent), Correction =
    "None (original cmdscale calculation)")
  annotation_text <- paste("PERMANOVA", effect_line(permanova_statistics, "Stage", "Stage"), effect_line(permanova_statistics, "Drought", "Drought"), sep = "\n")
  compartment_plot <- ggplot(score_df, aes(x = PCoA1, y = PCoA2, colour = Drought, shape = Period)) + geom_point(aes(fill = Drought), size = 2.7, stroke = 0.65) +
    annotate("text", x = min(score_df$PCoA1, na.rm = TRUE), y = max(score_df$PCoA2, na.rm = TRUE), label = annotation_text, hjust = 0, vjust = 1, size = 4, colour =
    "black") + scale_colour_manual(values = drought_colors, breaks = drought_levels, labels = drought_labels, drop = FALSE) + scale_fill_manual(values = drought_colors,
    breaks = drought_levels, labels = drought_labels, drop = FALSE, guide = "none") + scale_shape_manual(values = period_shapes, breaks = period_levels, labels =
    period_labels, drop = FALSE) + labs(title = compartment, x = paste0("PCoA1 (", sprintf("%.1f", axis_1_percent), "%)"), y = paste0("PCoA2 (", sprintf("%.1f",
    axis_2_percent), "%)"), colour = "Drought", shape = "Stage") + theme_bw() + theme(panel.grid = element_blank(), plot.title = element_text(hjust = 0.5))
  list(plot = compartment_plot, scores = score_df, axes = axis_statistics, permanova = permanova_statistics, dispersion = dispersion_statistics)
}
results <- lapply(communities, run_compartment)
names(results) <- compartment_levels
pcoa_scores <- dplyr::bind_rows(lapply(results, `[[`, "scores")) %>% dplyr::mutate(Compartment = factor(Compartment, levels = compartment_levels))
pcoa_axes <- dplyr::bind_rows(lapply(results, `[[`, "axes")) %>% dplyr::mutate(Compartment = factor(Compartment, levels = compartment_levels))
permanova_results <- dplyr::bind_rows(lapply(results, `[[`, "permanova")) %>% dplyr::mutate(Compartment = factor(Compartment, levels = compartment_levels))
dispersion_results <- dplyr::bind_rows(lapply(results, `[[`, "dispersion")) %>% dplyr::mutate(Compartment = factor(Compartment, levels = compartment_levels))
write.csv(pcoa_scores, file.path(output_dir, "01_three_compartment_PCoA_scores.csv"), row.names = FALSE)
write.csv(pcoa_axes, file.path(output_dir, "02_three_compartment_PCoA_axis_variance.csv"), row.names = FALSE)
write.csv(permanova_results, file.path(output_dir, "03_three_compartment_PERMANOVA.csv"), row.names = FALSE)
write.csv(dispersion_results, file.path(output_dir, "04_PERMANOVA_dispersion_checks.csv"), row.names = FALSE)
plot_list <- lapply(results, `[[`, "plot")
figure_1 <- wrap_plots(plot_list, nrow = 1, guides = "collect") + plot_annotation(tag_levels = "A") & theme(legend.position = "bottom", legend.box = "horizontal")
print(figure_1)
save_pdf(file.path(output_dir, "Figure_1_three_compartment_PCoA.pdf"), figure_1, width = 12.6, height = 4.8)
ggsave(file.path(output_dir, "Figure_1_three_compartment_PCoA.png"), figure_1, width = 12.6, height = 4.8, dpi = 600)
ggsave(file.path(output_dir, "Figure_1_three_compartment_PCoA.tiff"), figure_1, width = 12.6, height = 4.8, units = "in", dpi = 600, compression = "lzw")
capture.output(sessionInfo(), file = file.path(output_dir, "05_sessionInfo.txt"))
message("Analysis completed. Results saved in: ", output_dir)
