rm(list = ls())
grDevices::graphics.off()
options(stringsAsFactors = FALSE)
options(contrasts = c("contr.sum", "contr.poly"))
required_packages <- c("tidyverse", "lme4", "lmerTest", "emmeans", "multcompView", "patchwork")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(tidyverse)
  library(lme4)
  library(lmerTest)
  library(emmeans)
  library(multcompView)
  library(patchwork)
})
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/补充分析")
output_dir <- "Three_compartment_raw_Shannon_results"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
period_levels <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
genotype_levels <- c("Jinza 22", "Liangnuo 01")
compartment_levels <- c("Phyllosphere", "Endosphere", "Rhizosphere")
drought_colours <- c(Control = "#F8766D", Drought_L = "#7CAE00", Drought_M = "#00BFC4", Drought_H = "#C77CFF")
drought_labels <- c(Control = "Control", Drought_L = "Light drought", Drought_M = "Moderate drought", Drought_H = "Heavy drought")
lmm_control <- lme4::lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 200000))
clean_label <- function (x) {
  stringr::str_squish(as.character(x))
}
get_optional_column <- function (x, candidates) {
  hit <- candidates[candidates %in% names(x)]
  if (length(hit) == 0L) {
    return(rep(NA_character_, nrow(x)))
  }
  clean_label(x[[hit[[1]]]])
}
period_from_column <- function (x) {
  raw <- clean_label(x)
  key <- stringr::str_to_lower(stringr::str_replace_all(raw, "[[:space:]_-]+", ""))
  dplyr::case_when(key %in% c("jointing", "jointingstage", "js", "stage1", "1") | stringr::str_detect(key, "^jointing") | stringr::str_detect(raw, "拔节") ~
    "Jointing stage", key %in% c("heading", "headingstage", "hs", "stage2", "2") | stringr::str_detect(key, "^heading") | stringr::str_detect(raw, "抽穗") ~ "Heading stage"
    , key %in% c("filling", "fillingstage", "grainfilling", "grainfillingstage", "fs", "stage3", "3") | stringr::str_detect(key, "^(grain)?filling") | stringr::str_detect
    (raw, "灌浆") ~ "Filling stage", key %in% c("maturity", "maturitystage", "mature", "ms", "stage4", "4") | stringr::str_detect(key, "^matur") | stringr::str_detect(raw,
    "成熟") ~ "Maturity stage", TRUE ~ NA_character_)
}
period_from_sample <- function (sample) {
  code <- stringr::str_match(stringr::str_to_upper(clean_label(sample)), "^[ZN]([1-4])")[, 2]
  dplyr::recode(code, `1` = "Jointing stage", `2` = "Heading stage", `3` = "Filling stage", `4` = "Maturity stage", .default = NA_character_)
}
drought_from_column <- function (x) {
  raw <- clean_label(x)
  key <- stringr::str_to_lower(stringr::str_replace_all(raw, "[[:space:]_()%-]+", ""))
  dplyr::case_when(key %in% c("control", "ck", "a", "normal", "control80fc", "80fc") | stringr::str_detect(key, "control|80fc") | stringr::str_detect(raw, "对照|正常") ~
    "Control", key %in% c("droughtl", "light", "lightdrought", "b", "60fc") | stringr::str_detect(key, "light|droughtl|60fc") | stringr::str_detect(raw, "轻") ~
    "Drought_L", key %in% c("droughtm", "moderate", "moderatedrought", "c", "50fc") | stringr::str_detect(key, "moderate|droughtm|50fc") | stringr::str_detect(raw, "中") ~
    "Drought_M", key %in% c("droughth", "heavy", "heavydrought", "severe", "severedrought", "d", "40fc") | stringr::str_detect(key, "heavy|severe|droughth|40fc") |
    stringr::str_detect(raw, "重") ~ "Drought_H", TRUE ~ NA_character_)
}
drought_from_sample <- function (sample) {
  code <- stringr::str_match(stringr::str_to_upper(clean_label(sample)), "([A-D])_[1-4]$")[, 2]
  dplyr::recode(code, A = "Control", B = "Drought_L", C = "Drought_M", D = "Drought_H", .default = NA_character_)
}
block_from_column <- function (x) {
  raw <- stringr::str_to_upper(clean_label(x))
  numeric_code <- stringr::str_match(raw, "([1-4])$")[, 2]
  letter_code <- dplyr::recode(raw, A = "1", B = "2", C = "3", D = "4", .default = NA_character_)
  dplyr::coalesce(numeric_code, letter_code)
}
block_from_sample <- function (sample) {
  stringr::str_match(clean_label(sample), "_([1-4])$")[, 2]
}
genotype_from_column <- function (x) {
  raw <- clean_label(x)
  key <- stringr::str_to_lower(stringr::str_replace_all(raw, "[[:space:]_-]+", ""))
  dplyr::case_when(key %in% c("variety1", "genotype1", "jinza", "jinza22", "jz", "z", "1") | stringr::str_detect(key, "jinza") | stringr::str_detect(raw, "晋杂|杂") ~
    "Jinza 22", key %in% c("variety2", "genotype2", "liangnuo", "liangnuo01", "ln", "n", "2") | stringr::str_detect(key, "liangnuo") | stringr::str_detect(raw, "良糯|糯") ~
    "Liangnuo 01", TRUE ~ NA_character_)
}
genotype_from_sample <- function (sample) {
  code <- stringr::str_sub(stringr::str_to_upper(clean_label(sample)), 1, 1)
  dplyr::recode(code, Z = "Jinza 22", N = "Liangnuo 01", .default = NA_character_)
}
fmt_p <- function (p) {
  if (!is.finite(p)) return("NA")
  if (p < 0.001) return("< 0.001")
  paste0("= ", sprintf("%.3f", p))
}
extract_variance <- function (variance_df, group_name) {
  value <- variance_df$vcov[variance_df$grp == group_name]
  if (length(value) == 0L) return(NA_real_)
  as.numeric(value[[1]])
}
save_pdf <- function (filename, plot, width, height) {
  if (capabilities("cairo")) {
    ggplot2::ggsave(filename, plot, width = width, height = height, device = grDevices::cairo_pdf)
  } else {
    ggplot2::ggsave(filename, plot, width = width, height = height)
  }
}
read_shannon_table <- function (filename, compartment) {
  if (!file.exists(filename)) {
    stop("Input file was not found: ", filename, "\nCurrent working directory: ", getwd())
  }
  x <- read.csv(filename, check.names = FALSE, fileEncoding = "UTF-8-BOM")
  if (!all(c("Sample", "Shannon") %in% names(x))) {
    stop(filename, " must contain columns named Sample and Shannon.")
  }
  sample_value <- clean_label(x$Sample)
  shannon_value <- suppressWarnings(as.numeric(stringr::str_replace(clean_label(x$Shannon), ",", ".")))
  period_sample <- period_from_sample(sample_value)
  period_column <- period_from_column(get_optional_column(x, c("Period", "Stage", "period", "stage")))
  drought_sample <- drought_from_sample(sample_value)
  drought_column <- drought_from_column(get_optional_column(x, c("Drought", "Treatment", "drought", "treatment")))
  block_sample <- block_from_sample(sample_value)
  block_column <- block_from_column(get_optional_column(x, c("Block", "block", "Replicate", "replicate")))
  genotype_sample <- genotype_from_sample(sample_value)
  genotype_column <- genotype_from_column(get_optional_column(x, c("Genotype", "Variety", "genotype", "variety", "Cultivar")))
  period_value <- dplyr::coalesce(period_sample, period_column)
  drought_value <- dplyr::coalesce(drought_sample, drought_column)
  block_value <- dplyr::coalesce(block_sample, block_column)
  genotype_value <- dplyr::coalesce(genotype_sample, genotype_column)
  bad <- tibble::tibble(Row = seq_len(nrow(x)) + 1L, Sample = sample_value, Shannon = shannon_value, Period = period_value, Drought = drought_value, Block = block_value,
    Genotype = genotype_value) %>% dplyr::filter(Sample == "" | !is.finite(Shannon) | is.na(Period) | is.na(Drought) | is.na(Block) | is.na(Genotype))
  if (nrow(bad) > 0L) {
    diagnostic_file <- file.path(output_dir, paste0("ERROR_", compartment, "_input_rows.csv"))
    write.csv(bad, diagnostic_file, row.names = FALSE)
    print(bad)
    stop(filename, " contains ", nrow(bad), " row(s) that cannot be recognized. See: ", diagnostic_file)
  }
  out <- tibble::tibble(Compartment = factor(compartment, levels = compartment_levels), Sample = sample_value, Shannon = shannon_value, Block = factor(block_value, levels
    = as.character(1:4)), Drought = factor(drought_value, levels = drought_levels), Genotype = factor(genotype_value, levels = genotype_levels), Period = factor(
    period_value, levels = period_levels)) %>% dplyr::mutate(MainPlotID = interaction(Block, Drought, drop = TRUE, sep = "_"), PlotID = interaction(Block, Drought,
    Genotype, drop = TRUE, sep = "_"), Drought_order = as.numeric(Drought) - 1)
  if (anyDuplicated(out$Sample)) {
    stop(filename, " contains duplicated Sample values.")
  }
  if (nrow(out) != 128L) {
    stop(compartment, ": expected 128 samples, found ", nrow(out), ".")
  }
  cell_check <- out %>% dplyr::count(Block, Drought, Genotype, Period, name = "n")
  if (nrow(cell_check) != 128L || any(cell_check$n != 1L) || dplyr::n_distinct(out$MainPlotID) != 16L || dplyr::n_distinct(out$PlotID) != 32L) {
    print(cell_check)
    stop(compartment, ": data do not match the split-plot structure.")
  }
  out
}
shannon_data <- dplyr::bind_rows(read_shannon_table("叶际_Shannon_perSample.csv", "Phyllosphere"), read_shannon_table("根内_Shannon_perSample.csv", "Endosphere"),
  read_shannon_table("根际_Shannon_perSample.csv", "Rhizosphere"))
write.csv(shannon_data, file.path(output_dir, "01_raw_Shannon_clean_input.csv"), row.names = FALSE)
fit_one_compartment <- function (compartment_name) {
  dat <- shannon_data %>% dplyr::filter(Compartment == compartment_name) %>% droplevels()
  model <- lmerTest::lmer(Shannon ~ Block + Drought * Period + Genotype + (1 | MainPlotID) + (1 | PlotID), data = dat, REML = TRUE, control = lmm_control)
  trend_model <- lmerTest::lmer(Shannon ~ Block + Drought_order * Period + Genotype + (1 | MainPlotID) + (1 | PlotID), data = dat, REML = TRUE, control = lmm_control)
  anova_result <- tryCatch(list(table = stats::anova(model, type = 3, ddf = "Kenward-Roger"), method = "Kenward-Roger"), error = function (e) {
    list(table = stats::anova(model, type = 3, ddf = "Satterthwaite"), method = "Satterthwaite")
  })
  anova_df <- as.data.frame(anova_result$table)
  anova_df$Effect <- rownames(anova_df)
  rownames(anova_df) <- NULL
  anova_df <- anova_df %>% dplyr::transmute(Compartment = compartment_name, Effect, Sum_Sq = as.numeric(`Sum Sq`), Mean_Sq = as.numeric(`Mean Sq`), NumDF = as.numeric(
    NumDF), DenDF = as.numeric(DenDF), F_value = as.numeric(`F value`), P_value = as.numeric(`Pr(>F)`), DDF_method = anova_result$method)
  emm <- tryCatch(emmeans::emmeans(model, ~ Drought | Period, weights = "equal", lmer.df = "kenward-roger"), error = function (e) {
    emmeans::emmeans(model, ~ Drought | Period, weights = "equal", lmer.df = "satterthwaite")
  })
  emm_df <- as.data.frame(emm) %>% dplyr::mutate(Compartment = factor(compartment_name, levels = compartment_levels), .before = 1)
  pairwise_df <- as.data.frame(emmeans::contrast(emm, method = "pairwise", adjust = "tukey")) %>% dplyr::mutate(Compartment = compartment_name, .before = 1)
  letters_df <- pairwise_df %>% dplyr::group_by(Period) %>% dplyr::group_modify(~ {
    p_values <- .x$p.value
    names(p_values) <- gsub(" - ", "-", .x$contrast, fixed = TRUE)
    if (any(!is.finite(p_values))) {
      stop(compartment_name, ": non-finite Tukey P values were returned for ", as.character(.y$Period))
    }
    letter_vector <- multcompView::multcompLetters(p_values, Letters = letters)$Letters
    tibble::tibble(Drought = factor(names(letter_vector), levels = drought_levels), Letter = unname(letter_vector))
  }) %>% dplyr::ungroup() %>% dplyr::mutate(Compartment = factor(compartment_name, levels = compartment_levels), .before = 1)
  trend_emtrends <- tryCatch(emmeans::emtrends(trend_model, ~ Period, var = "Drought_order", lmer.df = "kenward-roger"), error = function (e) {
    emmeans::emtrends(trend_model, ~ Period, var = "Drought_order", lmer.df = "satterthwaite")
  })
  trend_df_raw <- as.data.frame(summary(trend_emtrends, infer = c(TRUE, TRUE)))
  slope_column <- grep("\\.trend$", names(trend_df_raw), value = TRUE)
  if (length(slope_column) != 1L) {
    stop(compartment_name, ": ordered-trend slope column was not found.")
  }
  trend_df <- trend_df_raw %>% dplyr::transmute(Compartment = factor(compartment_name, levels = compartment_levels), Period, Slope = as.numeric(.data[[slope_column]]), SE
    = as.numeric(SE), df = as.numeric(df), lower.CL = as.numeric(lower.CL), upper.CL = as.numeric(upper.CL), t_ratio = as.numeric(t.ratio), P_value = as.numeric(p.value),
    Significance = dplyr::case_when(P_value < 0.001 ~ "***", P_value < 0.01 ~ "**", P_value < 0.05 ~ "*", TRUE ~ "ns"))
  trend_intercept <- tryCatch(emmeans::emmeans(trend_model, ~ Period, at = list(Drought_order = 0), weights = "equal", lmer.df = "kenward-roger"), error = function (e) {
    emmeans::emmeans(trend_model, ~ Period, at = list(Drought_order = 0), weights = "equal", lmer.df = "satterthwaite")
  }) %>% as.data.frame() %>% dplyr::transmute(Period, Intercept = emmean)
  trend_line_df <- tidyr::crossing(Period = factor(period_levels, levels = period_levels), Drought_order = seq(0, 3, length.out = 100)) %>% dplyr::left_join(
    trend_intercept, by = "Period") %>% dplyr::left_join(trend_df %>% dplyr::select(Period, Slope), by = "Period") %>% dplyr::mutate(Compartment = factor(compartment_name
    , levels = compartment_levels), Predicted_Shannon = Intercept + Slope * Drought_order, .before = 1)
  variance_df <- as.data.frame(lme4::VarCorr(model))
  model_check <- tibble::tibble(Compartment = compartment_name, N = stats::nobs(model), Singular_fit = lme4::isSingular(model, tol = 1e-5), Trend_model_singular = lme4::
    isSingular(trend_model, tol = 1e-5), MainPlot_variance = extract_variance(variance_df, "MainPlotID"), Plot_variance = extract_variance(variance_df, "PlotID"),
    Residual_variance = extract_variance(variance_df, "Residual"))
  list(model = model, trend_model = trend_model, anova = anova_df, emmeans = emm_df, pairwise = pairwise_df, letters = letters_df, trend = trend_df, trend_line =
    trend_line_df, model_check = model_check)
}
results <- setNames(lapply(compartment_levels, fit_one_compartment), compartment_levels)
anova_results <- dplyr::bind_rows(lapply(results, `[[`, "anova"))
emmeans_results <- dplyr::bind_rows(lapply(results, `[[`, "emmeans"))
pairwise_results <- dplyr::bind_rows(lapply(results, `[[`, "pairwise"))
letters_results <- dplyr::bind_rows(lapply(results, `[[`, "letters"))
trend_results <- dplyr::bind_rows(lapply(results, `[[`, "trend"))
trend_line_results <- dplyr::bind_rows(lapply(results, `[[`, "trend_line"))
model_checks <- dplyr::bind_rows(lapply(results, `[[`, "model_check"))
write.csv(anova_results, file.path(output_dir, "02_raw_Shannon_LMM_TypeIII_ANOVA.csv"), row.names = FALSE)
write.csv(emmeans_results, file.path(output_dir, "03_raw_Shannon_adjusted_means.csv"), row.names = FALSE)
write.csv(pairwise_results, file.path(output_dir, "04_raw_Shannon_Tukey_pairwise.csv"), row.names = FALSE)
write.csv(letters_results, file.path(output_dir, "05_raw_Shannon_Tukey_letters.csv"), row.names = FALSE)
write.csv(trend_results, file.path(output_dir, "06_raw_Shannon_ordered_trends.csv"), row.names = FALSE)
write.csv(model_checks, file.path(output_dir, "07_raw_Shannon_model_checks.csv"), row.names = FALSE)
for (compartment_name in compartment_levels) {
  safe_name <- gsub("[^A-Za-z0-9]+", "_", compartment_name)
  capture.output(summary(results[[compartment_name]]$model), file = file.path(output_dir, paste0("08_", safe_name, "_raw_Shannon_LMM_summary.txt")))
  capture.output(summary(results[[compartment_name]]$trend_model), file = file.path(output_dir, paste0("09_", safe_name, "_ordered_trend_LMM_summary.txt")))
}
compartment_ranges <- shannon_data %>% dplyr::group_by(Compartment) %>% dplyr::summarise(y_min = min(Shannon, na.rm = TRUE), y_max = max(Shannon, na.rm = TRUE), y_range =
  y_max - y_min, .groups = "drop") %>% dplyr::mutate(y_range = dplyr::if_else(y_range > 0, y_range, 1))
raw_max <- shannon_data %>% dplyr::group_by(Compartment, Period, Drought) %>% dplyr::summarise(raw_max = max(Shannon, na.rm = TRUE), .groups = "drop")
letters_plot <- letters_results %>% dplyr::left_join(raw_max, by = c("Compartment", "Period", "Drought")) %>% dplyr::left_join(compartment_ranges, by = "Compartment") %>%
  dplyr::mutate(Drought_order = as.numeric(Drought) - 1, letter_y = raw_max + 0.055 * y_range)
trend_labels <- trend_results %>% dplyr::left_join(compartment_ranges, by = "Compartment") %>% dplyr::mutate(Drought_order = 1.5, label_y = y_min - 0.075 * y_range)
figure_raw_shannon <- ggplot2::ggplot(shannon_data, ggplot2::aes(x = Drought_order, y = Shannon, group = Drought)) + ggplot2::geom_boxplot(ggplot2::aes(fill = Drought),
  width = 0.55, outlier.shape = NA, linewidth = 0.65, colour = "black") + ggplot2::geom_jitter(width = 0.12, height = 0, size = 1.8, shape = 21, fill = "white", colour =
  "black", stroke = 0.2) + ggplot2::geom_line(data = trend_line_results, ggplot2::aes(x = Drought_order, y = Predicted_Shannon, group = Period), inherit.aes = FALSE,
  colour = "#6A8EC9", linewidth = 1.15) + ggplot2::geom_text(data = letters_plot, ggplot2::aes(x = Drought_order, y = letter_y, label = Letter), inherit.aes = FALSE, size
  = 3.3, colour = "black") + ggplot2::geom_text(data = trend_labels, ggplot2::aes(x = Drought_order, y = label_y, label = Significance), inherit.aes = FALSE, size = 4.2,
  colour = "black") + ggplot2::facet_grid(rows = ggplot2::vars(Compartment), cols = ggplot2::vars(Period), scales = "free_y") + ggplot2::scale_fill_manual(values =
  drought_colours, breaks = drought_levels, labels = drought_labels, drop = FALSE) + ggplot2::scale_x_continuous(breaks = 0:3, labels = drought_labels[drought_levels]) +
  ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0.04, 0.16))) + ggplot2::coord_cartesian(clip = "off") + ggplot2::labs(x = NULL, y =
  "Shannon diversity index", fill = "Drought treatment") + ggplot2::theme_classic(base_size = 11) + ggplot2::theme(panel.border = ggplot2::element_rect(colour = "black",
  fill = NA, linewidth = 0.6), panel.spacing = grid::unit(0.10, "cm"), axis.text.x = ggplot2::element_blank(), axis.ticks.x = ggplot2::element_blank(), axis.title.x =
  ggplot2::element_blank(), strip.background = ggplot2::element_rect(fill = "grey85", colour = "black", linewidth = 0.6), strip.text = ggplot2::element_text(face = "bold"
  , size = 10), strip.text.y.right = ggplot2::element_text(angle = 90), legend.position = "top", legend.title = ggplot2::element_text(size = 10), legend.text = ggplot2::
  element_text(size = 9), plot.margin = ggplot2::margin(8, 12, 8, 8))
print(figure_raw_shannon)
save_pdf(file.path(output_dir, "Figure_raw_Shannon_three_compartments_boxplots.pdf"), figure_raw_shannon, width = 12, height = 8.6)
ggplot2::ggsave(file.path(output_dir, "Figure_raw_Shannon_three_compartments_boxplots.png"), figure_raw_shannon, width = 12, height = 8.6, dpi = 600)
capture.output(sessionInfo(), file = file.path(output_dir, "10_sessionInfo.txt"))
message("Analysis completed. Results saved in: ", output_dir)
