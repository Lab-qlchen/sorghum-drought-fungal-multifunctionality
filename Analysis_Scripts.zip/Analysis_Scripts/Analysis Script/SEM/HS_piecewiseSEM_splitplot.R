work_dir <- "D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/SEM"
if (!dir.exists(work_dir)) {
  stop("Working directory was not found: ", work_dir)
}
setwd(work_dir)
input_csv <- "HS_SEM.csv"
out_dir <- file.path(work_dir, "HS_piecewiseSEM_results")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
required_packages <- c("dplyr", "tidyr", "tibble", "readr", "ggplot2", "lme4", "lmerTest", "piecewiseSEM", "igraph", "patchwork", "scales", "purrr")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Please install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(tibble)
  library(readr)
  library(ggplot2)
  library(lme4)
  library(lmerTest)
  library(piecewiseSEM)
  library(igraph)
  library(patchwork)
  library(purrr)
})
options(contrasts = c("contr.sum", "contr.poly"))
set.seed(20260902)
if (!file.exists(input_csv)) {
  stop("Input file was not found: ", input_csv, "\nSave the supplied SEM table as HS_SEM.csv or edit input_csv.")
}
dat_raw <- readr::read_csv(input_csv, show_col_types = FALSE)
required_columns <- c("Sample", "PlotID", "Block", "MainPlotID", "Genotype", "Period", "Drought", "RWC", "PGI_meanZ", "Grain_yield_t_ha", "SMF_meanZ", "Fungi_Shannon",
  "average_degree", "robustness", "Negative_Cohesion", "HS_indicator_score")
missing_columns <- setdiff(required_columns, names(dat_raw))
if (length(missing_columns) > 0L) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "))
}
if (anyDuplicated(dat_raw$Sample)) {
  stop("Sample contains duplicated identifiers.")
}
numeric_columns <- c("RWC", "PGI_meanZ", "Grain_yield_t_ha", "SMF_meanZ", "Fungi_Shannon", "average_degree", "robustness", "Negative_Cohesion", "HS_indicator_score")
dat_raw <- dat_raw %>% dplyr::mutate(dplyr::across(dplyr::all_of(numeric_columns), ~ suppressWarnings(as.numeric(.x))), Sample = as.character(Sample), PlotID = factor(
  PlotID), Block = factor(Block), MainPlotID = factor(MainPlotID), Genotype = factor(Genotype), Period = factor(Period), Drought = factor(Drought))
if (anyNA(dat_raw[, required_columns])) {
  bad <- names(which(colSums(is.na(dat_raw[, required_columns])) > 0L))
  stop("Missing or non-numeric values detected in: ", paste(bad, collapse = ", "))
}
period_values <- unique(toupper(gsub("[[:space:]_-]+", " ", trimws(as.character(dat_raw$Period)))))
allowed_hs_names <- c("HS", "HEADING", "HEADING STAGE")
if (length(period_values) != 1L || !period_values %in% allowed_hs_names) {
  stop("This script analyses heading-stage samples only. Period currently contains: ", paste(period_values, collapse = ", "),
    ". Accepted names are HS, Heading, or Heading stage.")
}
dat_raw$Period <- factor(rep("HS", nrow(dat_raw)), levels = "HS")
if (nrow(dat_raw) != 32L) {
  warning("Expected 32 HS samples, but found ", nrow(dat_raw), ".")
}
if (nlevels(dat_raw$MainPlotID) != 16L) {
  warning("Expected 16 MainPlotID levels in the split-plot HS data, but found ", nlevels(dat_raw$MainPlotID), ".")
}
design_check <- dat_raw %>% dplyr::count(Block, Drought, Genotype, name = "n") %>% dplyr::arrange(Block, Drought, Genotype)
mainplot_check <- dat_raw %>% dplyr::count(MainPlotID, name = "n_subplots") %>% dplyr::arrange(MainPlotID)
readr::write_csv(design_check, file.path(out_dir, "00_design_balance.csv"))
readr::write_csv(mainplot_check, file.path(out_dir, "00_mainplot_replication.csv"))
z_numeric <- function (x) {
  s <- stats::sd(x, na.rm = TRUE)
  if (!is.finite(s) || s == 0) stop("A variable has zero or invalid variance.")
  as.numeric(scale(x))
}
sem_dat <- dat_raw %>% dplyr::transmute(Sample, PlotID, Block, MainPlotID, Genotype, Period, Drought, RWC, Water_deficit = - z_numeric(RWC), Shannon = z_numeric(
  Fungi_Shannon), Mean_degree = z_numeric(average_degree), HS_indicator = z_numeric(HS_indicator_score), SMF = z_numeric(SMF_meanZ), PGI = z_numeric(PGI_meanZ), Yield =
  z_numeric(Grain_yield_t_ha), Robustness = z_numeric(robustness), Negative_cohesion = z_numeric(Negative_Cohesion))
readr::write_csv(sem_dat, file.path(out_dir, "01_HS_SEM_standardized_data.csv"))
sem_model_data <- as.data.frame(sem_dat)
candidate_variables <- c("Water_deficit", "Shannon", "Mean_degree", "HS_indicator", "SMF", "PGI", "Yield", "Robustness", "Negative_cohesion")
cor_matrix <- stats::cor(sem_dat[, candidate_variables], use = "pairwise.complete.obs", method = "pearson")
cor_long <- as.data.frame(as.table(cor_matrix), stringsAsFactors = FALSE) %>% dplyr::rename(Variable_1 = Var1, Variable_2 = Var2, Pearson_r = Freq)
readr::write_csv(cor_long, file.path(out_dir, "02_candidate_variable_correlations.csv"))
calculate_vif <- function (data, variables) {
  purrr::map_dfr(variables, function (response) {
    predictors <- setdiff(variables, response)
    fit <- stats::lm(stats::reformulate(predictors, response = response), data = data)
    r2 <- summary(fit)$r.squared
    tibble::tibble(Variable = response, VIF = 1 / (1 - r2))
  })
}
primary_smf_predictors <- c("Water_deficit", "Shannon", "Mean_degree", "HS_indicator")
vif_table <- calculate_vif(sem_dat, primary_smf_predictors)
readr::write_csv(vif_table, file.path(out_dir, "03_primary_SMF_predictor_VIF.csv"))
if (any(vif_table$VIF >= 5)) {
  warning("At least one primary SMF predictor has VIF >= 5. Check file 03.")
}
network_cor <- cor_matrix[c("Mean_degree", "Robustness", "Negative_cohesion"), c("Mean_degree", "Robustness", "Negative_cohesion"), drop = FALSE]
readr::write_csv(as.data.frame(network_cor) %>% tibble::rownames_to_column("Variable"), file.path(out_dir, "03_network_metric_correlations.csv"))
lmer_control <- lme4::lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 2e5), check.conv.singular = "ignore")
m_shannon <- lmerTest::lmer(Shannon ~ Water_deficit + Block + Genotype + (1 | MainPlotID), data = sem_model_data, REML = FALSE, control = lmer_control, na.action =
  na.fail)
m_degree <- lmerTest::lmer(Mean_degree ~ Water_deficit + Block + Genotype + (1 | MainPlotID), data = sem_model_data, REML = FALSE, control = lmer_control, na.action =
  na.fail)
m_indicator <- lmerTest::lmer(HS_indicator ~ Water_deficit + Block + Genotype + (1 | MainPlotID), data = sem_model_data, REML = FALSE, control = lmer_control, na.action =
  na.fail)
m_smf <- lmerTest::lmer(SMF ~ Water_deficit + Shannon + Mean_degree + HS_indicator + Block + Genotype + (1 | MainPlotID), data = sem_model_data, REML = FALSE, control =
  lmer_control, na.action = na.fail)
m_pgi <- lmerTest::lmer(PGI ~ Water_deficit + SMF + Block + Genotype + (1 | MainPlotID), data = sem_model_data, REML = FALSE, control = lmer_control, na.action = na.fail)
m_yield <- lmerTest::lmer(Yield ~ Water_deficit + PGI + Block + Genotype + (1 | MainPlotID), data = sem_model_data, REML = FALSE, control = lmer_control, na.action =
  na.fail)
model_list <- list(Shannon = m_shannon, Mean_degree = m_degree, HS_indicator = m_indicator, SMF = m_smf, PGI = m_pgi, Yield = m_yield)
singular_table <- purrr::imap_dfr(model_list, function (model, response) {
  convergence_messages <- model@optinfo$conv$lme4$messages
  if (is.null(convergence_messages)) convergence_messages <- ""
  tibble::tibble(Response = response, Singular = lme4::isSingular(model, tol = 1e-5), Convergence_message = paste(convergence_messages, collapse = "; "))
})
readr::write_csv(singular_table, file.path(out_dir, "04_model_singularity.csv"))
if (any(singular_table$Singular)) {
  warning("One or more component models have a near-zero MainPlotID variance. ", "The random effect has been retained to preserve the split-plot design; ",
    "see 04_model_singularity.csv.")
}
sem_fit <- piecewiseSEM::psem(m_shannon, m_degree, m_indicator, m_smf, m_pgi, m_yield, data = sem_model_data)
saveRDS(sem_fit, file.path(out_dir, "05_piecewiseSEM_model.rds"))
basis_set <- piecewiseSEM::basisSet(sem_fit)
clean_claim_name <- function (x) {
  x <- gsub("`", "", as.character(x), fixed = TRUE)
  trimws(x)
}
fit_dsep_claim <- function (claim, claim_id) {
  claim <- clean_claim_name(claim)
  if (length(claim) < 2L) stop("Invalid basis-set claim number ", claim_id, ".")
  tested <- claim[1]
  response <- claim[2]
  conditioning <- if (length(claim) > 2L) claim[- c(1, 2)] else character(0)
  if (response %in% c("Block", "Genotype")) {
    old_response <- response
    response <- tested
    tested <- old_response
  }
  if (!response %in% names(sem_model_data)) {
    stop("Unknown response in basis-set claim: ", response)
  }
  if (!is.numeric(sem_model_data[[response]])) {
    stop("The response of basis-set claim ", claim_id, " is not numeric: ", response)
  }
  predictors <- unique(c(tested, conditioning, "Block", "Genotype"))
  predictors <- setdiff(predictors, c(response, "MainPlotID", "1", ""))
  unknown <- setdiff(predictors, names(sem_model_data))
  if (length(unknown) > 0L) {
    stop("Unknown variable(s) in basis-set claim: ", paste(unknown, collapse = ", "))
  }
  claim_formula <- stats::as.formula(paste(response, "~", paste(predictors, collapse = " + "), "+ (1 | MainPlotID)"))
  claim_model <- lmerTest::lmer(claim_formula, data = sem_model_data, REML = FALSE, control = lmer_control, na.action = na.fail)
  test_table <- as.data.frame(stats::anova(claim_model, type = 2, ddf = "Satterthwaite")) %>% tibble::rownames_to_column("Term")
  row_index <- which(test_table$Term == tested)
  if (length(row_index) != 1L) {
    stop("Cannot identify the tested term '", tested, "' in basis-set claim ", claim_id, ".")
  }
  p_column <- grep("^Pr\\(>F\\)$", names(test_table), value = TRUE)
  f_column <- grep("^F value$", names(test_table), value = TRUE)
  if (length(p_column) != 1L || length(f_column) != 1L) {
    stop("Unexpected lmerTest ANOVA columns in basis-set claim ", claim_id, ".")
  }
  test_row <- test_table[row_index,, drop = FALSE]
  tibble::tibble(Claim_ID = claim_id, Independence_claim = paste0(response, " ~ ", tested, if (length(conditioning)) paste0(" + ", paste(conditioning, collapse = " + "))
    else ""), Response = response, Tested_predictor = tested, Conditioning_variables = paste(conditioning, collapse = "; "), NumDF = test_row[["NumDF"]], DenDF = test_row
    [["DenDF"]], F_value = test_row[[f_column]], P_value = test_row[[p_column]], Singular = lme4::isSingular(claim_model, tol = 1e-5))
}
dsep_table <- if (length(basis_set) == 0L) {
  tibble::tibble(Claim_ID = integer(), Independence_claim = character(), Response = character(), Tested_predictor = character(), Conditioning_variables = character(),
    NumDF = numeric(), DenDF = numeric(), F_value = numeric(), P_value = numeric(), Singular = logical())
} else {
  purrr::imap_dfr(basis_set, fit_dsep_claim)
}
if (nrow(dsep_table) == 0L) {
  fisher_table <- tibble::tibble(Fisher_C = 0, df = 0, P_value = NA_real_, n_claims = 0L)
} else {
  fisher_c <- - 2 * sum(log(pmax(dsep_table$P_value, .Machine$double.xmin)))
  fisher_df <- 2L * nrow(dsep_table)
  fisher_table <- tibble::tibble(Fisher_C = fisher_c, df = fisher_df, P_value = stats::pchisq(fisher_c, df = fisher_df, lower.tail = FALSE), n_claims = nrow(dsep_table))
}
component_aic <- purrr::imap_dfr(model_list, function (model, response) {
  ll <- stats::logLik(model)
  tibble::tibble(Response = response, logLik = as.numeric(ll), K = attr(ll, "df"), n = stats::nobs(model), AIC = stats::AIC(model))
})
global_k <- sum(component_aic$K)
global_n <- nrow(sem_model_data)
global_aic <- - 2 * sum(component_aic$logLik) + 2 * global_k
aic_table <- tibble::tibble(AIC = global_aic, AICc = if (global_n > global_k + 1) {
  global_aic + (2 * global_k * (global_k + 1)) / (global_n - global_k - 1)
} else {
  NA_real_
}, K = global_k, n = global_n)
nakagawa_r2 <- function (model, response) {
  fixed_fitted <- stats::predict(model, re.form = NA)
  fixed_variance <- stats::var(fixed_fitted)
  variance_components <- as.data.frame(lme4::VarCorr(model))
  random_variance <- sum(variance_components$vcov[variance_components$grp != "Residual"])
  residual_variance <- stats::sigma(model) ^ 2
  total_variance <- fixed_variance + random_variance + residual_variance
  tibble::tibble(Response = response, Marginal = fixed_variance / total_variance, Conditional = (fixed_variance + random_variance) / total_variance, Fixed_variance =
    fixed_variance, Random_variance = random_variance, Residual_variance = residual_variance)
}
r2_table <- purrr::imap_dfr(model_list, nakagawa_r2)
readr::write_csv(fisher_table, file.path(out_dir, "06_global_Fisher_C.csv"))
readr::write_csv(aic_table, file.path(out_dir, "06_global_AIC.csv"))
readr::write_csv(component_aic, file.path(out_dir, "06_component_AIC.csv"))
readr::write_csv(dsep_table, file.path(out_dir, "06_directed_separation_tests.csv"))
readr::write_csv(r2_table, file.path(out_dir, "06_component_R2.csv"))
capture.output({
  cat("HS rhizosphere piecewise SEM\n")
  cat("Component models: lmerTest::lmer, method = ML\n")
  cat("Fixed design controls: Block + Genotype\n")
  cat("Random intercept: MainPlotID\n\n")
  cat("Directed-separation tests\n")
  print(dsep_table)
  cat("\nFisher's C\n")
  print(fisher_table)
  cat("\nAIC\n")
  print(aic_table)
  cat("\nComponent R-squared\n")
  print(r2_table)
}, file = file.path(out_dir, "05_piecewiseSEM_summary.txt"))
extract_mixed_coefficients <- function (model, response) {
  ct <- as.data.frame(summary(model)$coefficients)
  ct %>% tibble::rownames_to_column("Term") %>% tibble::as_tibble() %>% dplyr::transmute(Response = response, Term, Estimate = .data[["Estimate"]], Std_Error = .data[[
    "Std. Error"]], DF = .data[["df"]], Statistic = .data[["t value"]], P_value = .data[["Pr(>|t|)"]])
}
all_coefficients <- purrr::imap_dfr(model_list, ~ extract_mixed_coefficients(.x, .y))
all_coefficients <- all_coefficients %>% dplyr::mutate(Role = dplyr::case_when(Term == "(Intercept)" ~ "Intercept", grepl("^Block|^Genotype", Term) ~ "Design control",
  TRUE ~ "Focal path"), Significance = dplyr::case_when(P_value < 0.001 ~ "***", P_value < 0.01 ~ "**", P_value < 0.05 ~ "*", P_value < 0.10 ~ ".", TRUE ~ "ns"))
readr::write_csv(all_coefficients, file.path(out_dir, "07_all_component_coefficients.csv"))
focal_definition <- tibble::tribble(~ Response, ~ Term, ~ From, ~ To, "Shannon", "Water_deficit", "Water deficit", "Shannon", "Mean_degree", "Water_deficit",
  "Water deficit", "Mean degree", "HS_indicator", "Water_deficit", "Water deficit", "HS z- indicators", "SMF", "Water_deficit", "Water deficit", "SMF", "SMF", "Shannon",
  "Shannon", "SMF", "SMF", "Mean_degree", "Mean degree", "SMF", "SMF", "HS_indicator", "HS z- indicators", "SMF", "PGI", "Water_deficit", "Water deficit", "PGI", "PGI",
  "SMF", "SMF", "PGI", "Yield", "Water_deficit", "Water deficit", "Yield", "Yield", "PGI", "PGI", "Yield")
focal_paths <- focal_definition %>% dplyr::left_join(all_coefficients %>% dplyr::select(Response, Term, Estimate, Std_Error, DF, Statistic, P_value, Significance), by = c
  ("Response", "Term")) %>% dplyr::mutate(Lower_95CI = Estimate - 1.96 * Std_Error, Upper_95CI = Estimate + 1.96 * Std_Error, Path_label = paste0(sprintf("%.2f", Estimate
  ), ifelse(Significance == "ns", "", Significance)))
if (anyNA(focal_paths$Estimate)) {
  stop("At least one focal path could not be extracted from the component models.")
}
readr::write_csv(focal_paths, file.path(out_dir, "08_focal_standardized_paths.csv"))
edge_effects <- focal_paths %>% dplyr::select(From, To, Estimate)
path_graph <- igraph::graph_from_data_frame(edge_effects, directed = TRUE)
target_nodes <- c("SMF", "PGI", "Yield")
enumerate_effects <- function (target) {
  possible_sources <- setdiff(igraph::V(path_graph)$name, target)
  purrr::map_dfr(possible_sources, function (source) {
    paths <- igraph::all_simple_paths(path_graph, from = source, to = target, mode = "out")
    if (length(paths) == 0L) return(tibble::tibble())
    purrr::map_dfr(paths, function (path_object) {
      nodes <- igraph::as_ids(path_object)
      links <- tibble::tibble(From = head(nodes, - 1), To = tail(nodes, - 1)) %>% dplyr::left_join(edge_effects, by = c("From", "To"))
      tibble::tibble(Source = source, Target = target, Path = paste(nodes, collapse = " -> "), Number_of_edges = nrow(links), Path_effect = prod(links$Estimate))
    })
  })
}
all_effect_paths <- purrr::map_dfr(target_nodes, enumerate_effects)
effect_summary <- all_effect_paths %>% group_by(Source, Target) %>% dplyr::summarise(Direct = sum(Path_effect[Number_of_edges == 1L], na.rm = TRUE), Indirect = sum(
  Path_effect[Number_of_edges >= 2L], na.rm = TRUE), Total = Direct + Indirect, .groups = "drop")
readr::write_csv(all_effect_paths, file.path(out_dir, "09_all_effect_paths.csv"))
readr::write_csv(effect_summary, file.path(out_dir, "09_direct_indirect_total_effects.csv"))
grDevices::pdf(file.path(out_dir, "10_component_model_diagnostics.pdf"), width = 9, height = 4.5, onefile = TRUE)
for (response in names(model_list)) {
  model <- model_list[[response]]
  old_par <- par(mfrow = c(1, 2), mar = c(4.2, 4.2, 2.5, 1.2))
  plot(fitted(model), resid(model), pch = 21, bg = "#5B9BD5", col = "black", xlab = "Fitted values", ylab = "Residuals", main = paste(response, "residuals"))
  abline(h = 0, lty = 2, col = "grey45")
  stats::qqnorm(resid(model), pch = 21, bg = "#5B9BD5", col = "black", main = paste(response, "normal Q-Q"))
  stats::qqline(resid(model), col = "#C23B3B", lwd = 1.2)
  par(old_par)
}
grDevices::dev.off()
get_r2_lookup <- function (r2_data) {
  empty_r2 <- tibble::tibble(Response = character(), R2 = double())
  if (nrow(r2_data) == 0L || "Error" %in% names(r2_data)) return(empty_r2)
  response_col <- intersect(c("Response", "response"), names(r2_data))[1]
  conditional_col <- grep("Conditional", names(r2_data), value = TRUE, ignore.case = TRUE)[1]
  marginal_col <- grep("Marginal", names(r2_data), value = TRUE, ignore.case = TRUE)[1]
  if (is.na(response_col)) return(empty_r2)
  selected_r2 <- if (!is.na(conditional_col)) conditional_col else marginal_col
  if (is.na(selected_r2)) return(empty_r2)
  r2_data %>% dplyr::transmute(Response = as.character(.data[[response_col]]), R2 = as.numeric(.data[[selected_r2]]))
}
r2_lookup <- get_r2_lookup(r2_table)
node_table <- tibble::tribble(~ Node, ~ Response, ~ x, ~ y, "Water deficit", NA_character_, 0.0, 3.35, "Shannon", "Shannon", - 2.0, 2.35, "Mean degree", "Mean_degree",
  0.0, 2.35, "HS z- indicators", "HS_indicator", 2.0, 2.35, "SMF", "SMF", 0.0, 1.25, "PGI", "PGI", 0.0, 0.25, "Yield", "Yield", 0.0, - 0.75) %>% dplyr::left_join(
  r2_lookup, by = "Response") %>% dplyr::mutate(Node_label = ifelse(is.na(R2), Node, paste0(Node, "\n", "R² = ", sprintf("%.2f", R2))))
edge_plot <- focal_paths %>% dplyr::left_join(node_table %>% dplyr::select(Node, x, y), by = c("From" = "Node")) %>% dplyr::rename(x_from = x, y_from = y) %>% dplyr::
  left_join(node_table %>% dplyr::select(Node, x, y), by = c("To" = "Node")) %>% dplyr::rename(x_to = x, y_to = y) %>% dplyr::mutate(Edge_colour = dplyr::case_when(
  P_value < 0.10 & Estimate > 0 ~ "#C23B3B", P_value < 0.10 & Estimate < 0 ~ "#2878A8", TRUE ~ "#B6B6B6"), Edge_linetype = ifelse(P_value < 0.05, "solid", "dashed"),
  Edge_width = 0.65 + 1.8 * abs(Estimate), Curvature = dplyr::case_when(From == "Water deficit" & To == "Shannon" ~ - 0.10, From == "Water deficit" & To ==
  "HS z- indicators" ~ 0.10, From == "Water deficit" & To == "SMF" ~ - 0.26, From == "Water deficit" & To == "PGI" ~ 0.34, From == "Water deficit" & To == "Yield" ~ -
  0.43, TRUE ~ 0), label_x = (x_from + x_to) / 2, label_y = (y_from + y_to) / 2)
label_offsets <- tibble::tribble(~ From, ~ To, ~ dx, ~ dy, "Water deficit", "Shannon", - 0.12, 0.05, "Water deficit", "Mean degree", 0.18, 0.00, "Water deficit",
  "HS z- indicators", 0.12, 0.05, "Water deficit", "SMF", - 0.80, 0.02, "Shannon", "SMF", - 0.12, 0.03, "Mean degree", "SMF", 0.18, 0.00, "HS z- indicators", "SMF", 0.12,
  0.03, "Water deficit", "PGI", 0.88, 0.04, "SMF", "PGI", 0.17, 0.00, "Water deficit", "Yield", - 1.10, - 0.02, "PGI", "Yield", 0.17, 0.00)
edge_plot <- edge_plot %>% dplyr::left_join(label_offsets, by = c("From", "To")) %>% dplyr::mutate(dx = dplyr::coalesce(dx, 0), dy = dplyr::coalesce(dy, 0), label_x =
  label_x + dx, label_y = label_y + dy)
extract_named_number <- function (data, patterns) {
  if (nrow(data) == 0L || "Error" %in% names(data)) return(NA_real_)
  hit_mask <- Reduce(function (a, b) a | b, lapply(patterns, function (p) grepl(p, names(data), ignore.case = TRUE)))
  column_name <- names(data)[hit_mask][1]
  if (is.na(column_name)) return(NA_real_)
  suppressWarnings(as.numeric(data[[column_name]][1]))
}
fisher_c_value <- extract_named_number(fisher_table, c("Fisher.C", "Fisher_C", "Cstat"))
fisher_p_value <- extract_named_number(fisher_table, c("P.Value", "P_value", "Pvalue"))
fit_caption <- if (is.finite(fisher_c_value) && is.finite(fisher_p_value)) {
  paste0("Fisher's C = ", sprintf("%.2f", fisher_c_value), ", P = ", format.pval(fisher_p_value, digits = 3, eps = 0.001))
} else {
  "Global fit: see 06_global_Fisher_C.csv"
}
p_sem <- ggplot() + coord_cartesian(xlim = c(- 3.4, 3.4), ylim = c(- 1.25, 3.8), clip = "off")
for (i in seq_len(nrow(edge_plot))) {
  e <- edge_plot[i,]
  p_sem <- p_sem + geom_curve(data = e, aes(x = x_from, y = y_from, xend = x_to, yend = y_to), curvature = e$Curvature, colour = e$Edge_colour, linetype = e$Edge_linetype
    , linewidth = e$Edge_width, alpha = ifelse(e$P_value < 0.10, 0.95, 0.70), arrow = grid::arrow(length = grid::unit(0.18, "cm"), type = "closed"), lineend = "round")
}
p_sem <- p_sem + geom_label(data = edge_plot, aes(x = label_x, y = label_y, label = Path_label), size = 3.2, label.size = 0, label.padding = grid::unit(0.06, "lines"),
  fill = scales::alpha("white", 0.82), colour = edge_plot$Edge_colour, fontface = "bold") + geom_label(data = node_table, aes(x = x, y = y, label = Node_label), size =
  3.6, fontface = "bold", fill = "#F7F7F7", colour = "black", label.size = 0.45, label.padding = grid::unit(0.28, "lines")) + annotate("text", x = - 3.25, y = - 1.08,
  label = fit_caption, hjust = 0, size = 3.3) + annotate("text", x = 3.25, y = - 1.08, label = "Controls: Block + Genotype; random intercept: MainPlotID", hjust = 1, size
  = 3.0, colour = "grey30") + annotate("segment", x = - 3.25, xend = - 2.65, y = 3.68, yend = 3.68, colour = "#C23B3B", linewidth = 1.2, arrow = grid::arrow(length = grid
  ::unit(0.14, "cm"), type = "closed")) + annotate("text", x = - 2.55, y = 3.68, label = "Positive", hjust = 0, size = 3.1) + annotate("segment", x = - 1.55, xend = -
  0.95, y = 3.68, yend = 3.68, colour = "#2878A8", linewidth = 1.2, arrow = grid::arrow(length = grid::unit(0.14, "cm"), type = "closed")) + annotate("text", x = - 0.85,
  y = 3.68, label = "Negative", hjust = 0, size = 3.1) + annotate("segment", x = 0.25, xend = 0.85, y = 3.68, yend = 3.68, colour = "#B6B6B6", linewidth = 1.0, linetype =
  "dashed", arrow = grid::arrow(length = grid::unit(0.14, "cm"), type = "closed")) + annotate("text", x = 0.95, y = 3.68, label = "P >= 0.05", hjust = 0, size = 3.1) +
  theme_void(base_size = 11) + theme(plot.margin = margin(12, 12, 12, 12))
effect_colours <- c(Direct = "#E57A6F", Indirect = "#2BB3B1")
make_effect_plot <- function (target) {
  plot_data <- effect_summary %>% dplyr::filter(Target == target) %>% dplyr::select(Source, Direct, Indirect) %>% tidyr::pivot_longer(cols = c(Direct, Indirect), names_to
    = "Effect_type", values_to = "Effect") %>% dplyr::mutate(Source = reorder(Source, Effect, FUN = function (x) sum(abs(x))))
  ggplot(plot_data, aes(x = Effect, y = Source, fill = Effect_type)) + geom_col(position = position_dodge(width = 0.72), width = 0.62) + geom_vline(xintercept = 0,
    linewidth = 0.45, colour = "black") + scale_fill_manual(values = effect_colours, name = NULL) + labs(title = paste("Effects on", target), x = "Standardized effect", y
    = NULL) + theme_classic(base_size = 10) + theme(plot.title = element_text(size = 11, face = "bold"), axis.text = element_text(colour = "black"), legend.position = if
    (target == "SMF") "top" else "none", legend.justification = "left", plot.margin = margin(3, 5, 3, 5))
}
p_effects <- (make_effect_plot("SMF") / make_effect_plot("PGI") / make_effect_plot("Yield")) + patchwork::plot_layout(heights = c(1, 1, 1))
p_complete <- (p_sem | p_effects) + patchwork::plot_layout(widths = c(1.75, 1.0)) + patchwork::plot_annotation(tag_levels = "A")
ggsave(file.path(out_dir, "Figure_HS_piecewiseSEM_complete.pdf"), p_complete, width = 14, height = 8.2, units = "in", device = cairo_pdf)
ggsave(file.path(out_dir, "Figure_HS_piecewiseSEM_complete.png"), p_complete, width = 14, height = 8.2, units = "in", dpi = 600, bg = "white")
ggsave(file.path(out_dir, "Figure_HS_piecewiseSEM_path_only.pdf"), p_sem, width = 9.5, height = 7.2, units = "in", device = cairo_pdf)
cat("\nHS piecewise SEM completed.\n")
cat("Input samples:", nrow(sem_dat), "\n")
cat("Results directory:", out_dir, "\n")
cat("\nPrimary interpretation files:\n")
cat("  05_piecewiseSEM_summary.txt\n")
cat("  06_global_Fisher_C.csv\n")
cat("  06_component_R2.csv\n")
cat("  08_focal_standardized_paths.csv\n")
cat("  09_direct_indirect_total_effects.csv\n")
cat("  Figure_HS_piecewiseSEM_complete.pdf/png\n")
if (nrow(fisher_table) > 0L && is.finite(fisher_p_value) && fisher_p_value < 0.05) {
  cat("\nWARNING: Fisher's C is significant. The proposed causal structure does ", "not fit adequately; inspect 06_directed_separation_tests.csv.\n", sep = "")
}
