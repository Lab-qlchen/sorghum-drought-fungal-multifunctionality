rm(list = ls())
grDevices::graphics.off()
options(stringsAsFactors = FALSE)
options(contrasts = c("contr.sum", "contr.poly"))
required_packages <- c("tidyverse", "lme4", "lmerTest", "emmeans", "multcomp", "multcompView", "patchwork", "performance")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(tidyverse)
  library(lme4)
  library(lmerTest)
  library(emmeans)
  library(multcomp)
  library(multcompView)
  library(patchwork)
  library(performance)
})
get_project_dir <- function () {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg) > 0L) {
    script_path <- sub("^--file=", "", file_arg[[1]])
    return(dirname(normalizePath(script_path, winslash = "/")))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    script_path <- rstudioapi::getActiveDocumentContext()$path
    if (nzchar(script_path)) {
      return(dirname(normalizePath(script_path, winslash = "/")))
    }
  }
  normalizePath(getwd(), winslash = "/")
}
project_dir <- "D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/酶计量学"
setwd(project_dir)
input_file <- file.path(project_dir, "Ecoenzyme_raw_splitplot_data.csv")
output_dir <- file.path(project_dir, "Ecoenzyme_stoichiometry_LMM_results")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
dat <- read.csv(input_file, check.names = FALSE, fileEncoding = "UTF-8-BOM")
required_cols <- c("Sample", "PlotID", "Block", "MainPlotID", "Genotype", "Period", "Drought", "ALP", "AG", "BG", "CBH", "NAG", "LAP")
if (!all(required_cols %in% names(dat))) {
  stop("Missing required columns: ", paste(setdiff(required_cols, names(dat)), collapse = ", "))
}
dat <- dat %>% mutate(Sample = factor(Sample), PlotID = factor(PlotID), MainPlotID = factor(MainPlotID), Block = factor(Block, levels = 1:4), Genotype = factor(Genotype,
  levels = c("Jinza 22", "Liangnuo 01")), Period = factor(Period, levels = c("Jointing", "Heading", "Filling", "Maturity")), Drought = factor(Drought, levels = c(
  "Control", "Drought_L", "Drought_M", "Drought_H")))
enzyme_cols <- c("ALP", "AG", "BG", "CBH", "NAG", "LAP")
for (variable in enzyme_cols) {
  original <- dat[[variable]]
  nonempty <- !is.na(original) & trimws(as.character(original)) != ""
  converted <- suppressWarnings(as.numeric(original))
  if (any(nonempty & is.na(converted))) {
    stop("Non-numeric values were found in: ", variable)
  }
  dat[[variable]] <- converted
}
design_cols <- c("Sample", "PlotID", "Block", "MainPlotID", "Genotype", "Period", "Drought")
if (anyNA(dat[, design_cols])) {
  stop("Design columns contain missing or unrecognized values.")
}
if (anyNA(dat[, enzyme_cols])) {
  stop("Enzyme activity columns contain missing values.")
}
if (any(dat$ALP <= 0 | dat$BG <= 0 | dat$NAG < 0 | dat$LAP < 0)) {
  stop("ALP and BG must be positive; NAG and LAP must be non-negative.")
}
if (nrow(dat) != 128L || nlevels(dat$Sample) != 128L || nlevels(dat$MainPlotID) != 16L || nlevels(dat$PlotID) != 32L) {
  stop("Expected 128 samples, 16 MainPlotIDs and 32 PlotIDs. ", "Inspect the supplied data table.")
}
cell_check <- dat %>% count(Block, Drought, Genotype, Period, name = "n")
if (nrow(cell_check) != 128L || any(cell_check$n != 1L)) {
  print(cell_check)
  stop("Each Block x Drought x Genotype x Period cell must occur once.")
}
mainplot_check <- dat %>% distinct(MainPlotID, Block, Drought)
if (nrow(mainplot_check) != 16L || any(count(mainplot_check, MainPlotID)$n != 1L) || any(count(mainplot_check, Block, Drought)$n != 1L)) {
  stop("MainPlotID must uniquely represent Block x Drought.")
}
subplot_check <- dat %>% distinct(PlotID, MainPlotID, Genotype)
if (nrow(subplot_check) != 32L || any(count(subplot_check, PlotID)$n != 1L) || any(count(subplot_check, MainPlotID, Genotype)$n != 1L)) {
  stop("PlotID must uniquely represent MainPlotID x Genotype.")
}
if (!all(table(dat$MainPlotID) == 8L)) {
  stop("Every MainPlotID must have two genotypes x four periods.")
}
if (!all(table(dat$PlotID) == 4L)) {
  stop("Every PlotID must be observed at four periods.")
}
design_summary <- tibble(Design_level = c("Block", "Main plot", "Genotype subplot", "Sample"), ID = c("Block", "MainPlotID", "PlotID", "Sample"), Expected_number = c(4L,
  16L, 32L, 128L), Observed_number = c(n_distinct(dat$Block), n_distinct(dat$MainPlotID), n_distinct(dat$PlotID), n_distinct(dat$Sample)))
write.csv(design_summary, file.path(output_dir, "00_design_check.csv"), row.names = FALSE)
dat <- dat %>% mutate(C_acquiring_BG = BG, N_acquiring_NAG_LAP = NAG + LAP, P_acquiring_ALP = ALP, C_vs_P_prop = C_acquiring_BG / (C_acquiring_BG + P_acquiring_ALP),
  C_vs_N_prop = C_acquiring_BG / (C_acquiring_BG + N_acquiring_NAG_LAP), Vector_length = sqrt(C_vs_P_prop ^ 2 + C_vs_N_prop ^ 2), Vector_angle_deg = atan2(C_vs_N_prop,
  C_vs_P_prop) * 180 / pi, N_to_P_ratio = N_acquiring_NAG_LAP / P_acquiring_ALP, C_to_N_ratio = C_acquiring_BG / N_acquiring_NAG_LAP, Angle_based_limitation = case_when(
  Vector_angle_deg > 45 ~ "P limitation", Vector_angle_deg < 45 ~ "N limitation", TRUE ~ "N-P balance"), Quadrant_limitation = case_when(N_to_P_ratio < 1 & C_to_N_ratio >
  1 ~ "C & P limitation", N_to_P_ratio > 1 & C_to_N_ratio > 1 ~ "C & N limitation", N_to_P_ratio < 1 & C_to_N_ratio < 1 ~ "P limitation", N_to_P_ratio > 1 & C_to_N_ratio
  < 1 ~ "N limitation", TRUE ~ "Boundary"))
write.csv(dat, file.path(output_dir, "01_analysis_data_recalculated.csv"), row.names = FALSE)
limitation_counts <- dat %>% count(Period, Drought, Angle_based_limitation, name = "n") %>% group_by(Period, Drought) %>% mutate(Proportion = n / sum(n)) %>% ungroup()
write.csv(limitation_counts, file.path(output_dir, "02_angle_limitation_counts.csv"), row.names = FALSE)
fmt_p <- function (p) {
  if (length(p) == 0L || is.na(p)) {
    "NA"
  } else if (p < 0.001) {
    "< 0.001"
  } else {
    paste0("= ", sprintf("%.3f", p))
  }
}
extract_metric <- function (object, metric) {
  if (is.null(object)) return(NA_real_)
  if (is.data.frame(object) && metric %in% names(object)) {
    value <- object[[metric]]
    return(if (length(value) == 0L) NA_real_ else as.numeric(value[[1]]))
  }
  if (is.list(object) && !is.null(object[[metric]])) {
    value <- object[[metric]]
    return(if (length(value) == 0L) NA_real_ else as.numeric(value[[1]]))
  }
  if (is.atomic(object) && !is.null(names(object)) && metric %in% names(object)) {
    return(as.numeric(object[[metric]]))
  }
  NA_real_
}
safe_model_quality <- function (model) {
  variance_table <- as.data.frame(VarCorr(model))
  get_variance <- function (group) {
    value <- variance_table$vcov[variance_table$grp == group]
    if (length(value) == 0L) NA_real_ else as.numeric(value[[1]])
  }
  r2_result <- tryCatch(suppressWarnings(performance::r2_nakagawa(model, tolerance = 1e-8)), error = function (e) NULL)
  convergence_messages <- model@optinfo$conv$lme4$messages
  convergence_text <- if (is.null(convergence_messages)) {
    "None"
  } else {
    paste(convergence_messages, collapse = "; ")
  }
  data.frame(N = nobs(model), R2_marginal = extract_metric(r2_result, "R2_marginal"), R2_conditional = extract_metric(r2_result, "R2_conditional"), MainPlot_variance =
    get_variance("MainPlotID"), Plot_variance = get_variance("PlotID"), Residual_variance = get_variance("Residual"), Singular_fit = isSingular(model, tol = 1e-5),
    Convergence_warning = convergence_text, stringsAsFactors = FALSE)
}
fit_type3_anova <- function (model) {
  kr_result <- tryCatch(stats::anova(model, type = 3, ddf = "Kenward-Roger"), error = function (e) NULL)
  if (!is.null(kr_result)) {
    return(list(table = kr_result, method = "Kenward-Roger"))
  }
  list(table = stats::anova(model, type = 3, ddf = "Satterthwaite"), method = "Satterthwaite")
}
tidy_type3 <- function (anova_result, metric) {
  out <- as.data.frame(anova_result$table)
  out$Effect <- rownames(out)
  rownames(out) <- NULL
  out %>% mutate(Metric = metric, partial_eta2_F = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF), DDF_method = anova_result$method, .before = 1) %>% relocate(Metric
    , Effect)
}
get_effect_row <- function (anova_df, effect) {
  row <- anova_df %>% filter(Effect == effect)
  if (nrow(row) == 0L && grepl(":", effect, fixed = TRUE)) {
    reversed <- paste(rev(strsplit(effect, ":", fixed = TRUE)[[1]]), collapse = ":")
    row <- anova_df %>% filter(Effect == reversed)
  }
  row
}
effect_label <- function (anova_df, effect, label) {
  row <- get_effect_row(anova_df, effect)
  if (nrow(row) != 1L) return(paste0(label, ": unavailable"))
  paste0(label, ": F(", sprintf("%.0f", row$NumDF), ", ", sprintf("%.1f", row$DenDF), ") = ", sprintf("%.2f", row$`F value`), ", P ", fmt_p(row$`Pr(>F)`))
}
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
period_levels <- c("Jointing", "Heading", "Filling", "Maturity")
drought_colors <- c(Control = "#E67E73", Drought_L = "#8FB847", Drought_M = "#45B4B8", Drought_H = "#A487B5")
metric_labels <- c(Vector_length = "Vector length", Vector_angle_deg = "Vector angle (degree)")
emmeans::emm_options(lmer.df = if (requireNamespace("pbkrtest", quietly = TRUE)) {
  "kenward-roger"
} else {
  "satterthwaite"
})
fit_one_metric <- function (metric) {
  cat("Running:", metric, "\n")
  model_formula <- as.formula(paste0(metric, " ~ Block + Drought * Period + Genotype + ", "(1 | MainPlotID) + (1 | PlotID)"))
  model <- lmerTest::lmer(model_formula, data = dat, REML = TRUE, control = lme4::lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 200000)))
  anova_result <- fit_type3_anova(model)
  anova_df <- tidy_type3(anova_result, metric)
  quality_df <- safe_model_quality(model) %>% mutate(Metric = metric, Formula = paste(deparse(model_formula), collapse = " "), DDF_method = anova_result$method, .before =
    1)
  emm_stage <- emmeans::emmeans(model, ~ Drought | Period, weights = "equal")
  stage_pairs <- as.data.frame(emmeans::contrast(emm_stage, method = "pairwise", adjust = "tukey")) %>% mutate(Metric = metric, Adjustment = "Tukey within each Period",
    .before = 1)
  stage_emmeans <- multcomp::cld(emm_stage, Letters = letters, adjust = "tukey", sort = FALSE) %>% as.data.frame() %>% mutate(Metric = metric, Period = factor(Period,
    levels = period_levels), Drought = factor(Drought, levels = drought_levels), Letter = trimws(.group), .before = 1) %>% dplyr::select(- .group)
  emm_overall <- emmeans::emmeans(model, ~ Drought, weights = "equal")
  overall_pairs <- as.data.frame(emmeans::contrast(emm_overall, method = "pairwise", adjust = "tukey")) %>% mutate(Metric = metric, Adjustment = "Tukey overall Drought",
    .before = 1)
  mainplot_values <- dat %>% group_by(Block, MainPlotID, Period, Drought) %>% summarise(n_genotypes = n(), MainPlotValue = mean(.data[[metric]]), .groups = "drop") %>%
    mutate(Metric = metric, .before = 1)
  mainplot_summary <- mainplot_values %>% group_by(Metric, Period, Drought) %>% summarise(n_mainplots = n(), mean = mean(MainPlotValue), sd = sd(MainPlotValue), sem = sd
    / sqrt(n_mainplots), .groups = "drop")
  plot_df <- stage_emmeans
  y_min <- min(plot_df$lower.CL, na.rm = TRUE)
  y_max <- max(plot_df$upper.CL, na.rm = TRUE)
  y_range <- y_max - y_min
  if (!is.finite(y_range) || y_range <= 0) y_range <- 1
  plot_df <- plot_df %>% mutate(letter_y = upper.CL + 0.055 * y_range)
  model_label <- paste(effect_label(anova_df, "Drought", "Drought"), effect_label(anova_df, "Period", "Stage"), effect_label(anova_df, "Drought:Period", "Drought x stage"
    ), sep = "\n")
  metric_plot <- ggplot(plot_df, aes(x = Period, y = emmean, group = Drought, colour = Drought)) + geom_line(linewidth = 0.9) + geom_point(size = 2.7) + geom_errorbar(aes
    (ymin = lower.CL, ymax = upper.CL), width = 0.08, linewidth = 0.55) + geom_text(aes(y = letter_y, label = Letter), colour = "black", size = 3.4, show.legend = FALSE) +
    annotate("text", x = 1, y = y_max + 0.36 * y_range, label = model_label, hjust = 0, vjust = 1, size = 2.7, lineheight = 1.05) + coord_cartesian(ylim = c(y_min - 0.08
    * y_range, y_max + 0.58 * y_range), clip = "off") + scale_colour_manual(values = drought_colors, breaks = drought_levels, labels = c("Control", "Light drought",
    "Moderate drought", "Heavy drought")) + labs(x = NULL, y = metric_labels[[metric]], colour = "Drought") + theme_bw(base_size = 11) + theme(panel.grid = element_blank(
    ), axis.text.x = element_text(angle = 20, hjust = 1), plot.margin = ggplot2::margin(12, 18, 8, 8))
  if (metric == "Vector_angle_deg") {
    metric_plot <- metric_plot + geom_hline(yintercept = 45, linetype = "dashed", colour = "grey35", linewidth = 0.6)
  }
  list(model = model, anova = anova_df, quality = quality_df, stage_emmeans = stage_emmeans, stage_pairs = stage_pairs, overall_pairs = overall_pairs, mainplot_values =
    mainplot_values, mainplot_summary = mainplot_summary, plot = metric_plot)
}
metrics <- c("Vector_length", "Vector_angle_deg")
results <- setNames(lapply(metrics, fit_one_metric), metrics)
write.csv(bind_rows(lapply(results, `[[`, "anova")), file.path(output_dir, "03_LMM_TypeIII_vector_metrics.csv"), row.names = FALSE)
write.csv(bind_rows(lapply(results, `[[`, "quality")), file.path(output_dir, "04_random_variance_R2_model_checks.csv"), row.names = FALSE)
write.csv(bind_rows(lapply(results, `[[`, "stage_emmeans")), file.path(output_dir, "05_adjusted_means_95CI_letters_by_stage.csv"), row.names = FALSE)
write.csv(bind_rows(lapply(results, `[[`, "stage_pairs")), file.path(output_dir, "06_Tukey_drought_within_stage.csv"), row.names = FALSE)
write.csv(bind_rows(lapply(results, `[[`, "overall_pairs")), file.path(output_dir, "07_overall_drought_Tukey_supplementary.csv"), row.names = FALSE)
write.csv(bind_rows(lapply(results, `[[`, "mainplot_values")), file.path(output_dir, "08_raw_mainplot_values_descriptive.csv"), row.names = FALSE)
write.csv(bind_rows(lapply(results, `[[`, "mainplot_summary")), file.path(output_dir, "09_raw_mainplot_mean_SEM_descriptive.csv"), row.names = FALSE)
capture.output({
  for (metric in metrics) {
    cat("\n", paste(rep("=", 78), collapse = ""), "\n", sep = "")
    cat(metric, "\n")
    cat(paste(rep("=", 78), collapse = ""), "\n", sep = "")
    print(summary(results[[metric]]$model))
    print(results[[metric]]$anova)
    cat("Singular fit:", isSingular(results[[metric]]$model, tol = 1e-5), "\n")
    print(as.data.frame(VarCorr(results[[metric]]$model)))
  }
}, file = file.path(output_dir, "10_model_summaries.txt"))
pdf(file.path(output_dir, "11_LMM_residual_diagnostics.pdf"), width = 8, height = 7)
for (metric in metrics) {
  model <- results[[metric]]$model
  par(mfrow = c(2, 2))
  plot(fitted(model), residuals(model), xlab = "Fitted", ylab = "Residuals", main = paste(metric, "residuals vs fitted"))
  abline(h = 0, lty = 2)
  qqnorm(residuals(model), main = paste(metric, "normal Q-Q"))
  qqline(residuals(model), col = "red")
  hist(residuals(model), main = paste(metric, "residual histogram"), xlab = "Residual")
  plot(dat$Period, residuals(model), xlab = "Stage", ylab = "Residual", main = paste(metric, "residuals by stage"))
}
dev.off()
genotype_shapes <- c("Jinza 22" = 16, "Liangnuo 01" = 17)
make_boxplot_annotation <- function (metric) {
  letters_df <- results[[metric]]$stage_emmeans |> dplyr::select(Period, Drought, Letter)
  value_range <- diff(range(dat[[metric]], na.rm = TRUE))
  if (!is.finite(value_range) || value_range <= 0) {
    value_range <- 1
  }
  pad <- if (metric == "Vector_angle_deg") {
    max(0.08 * value_range, 0.50)
  } else {
    max(0.08 * value_range, 0.01)
  }
  dat |> dplyr::group_by(Period, Drought) |> dplyr::summarise(y = max(.data[[metric]], na.rm = TRUE) + pad, .groups = "drop") |> dplyr::left_join(letters_df, by = c(
    "Period", "Drought"))
}
anno_length <- make_boxplot_annotation("Vector_length")
anno_angle <- make_boxplot_annotation("Vector_angle_deg")
length_label <- paste(effect_label(results$Vector_length$anova, "Drought", "Drought"), effect_label(results$Vector_length$anova, "Period", "Stage"), effect_label(results$
  Vector_length$anova, "Drought:Period", "Drought x stage"), sep = "   ")
angle_label <- paste(effect_label(results$Vector_angle_deg$anova, "Drought", "Drought"), effect_label(results$Vector_angle_deg$anova, "Period", "Stage"), effect_label(
  results$Vector_angle_deg$anova, "Drought:Period", "Drought x stage"), sep = "   ")
p_length <- ggplot2::ggplot(dat, ggplot2::aes(x = Drought, y = Vector_length, fill = Drought)) + ggplot2::geom_boxplot(width = 0.65, outlier.shape = NA, alpha = 0.75) +
  ggplot2::geom_jitter(ggplot2::aes(colour = Drought, shape = Genotype), width = 0.12, size = 2.2, alpha = 0.80) + ggplot2::geom_text(data = anno_length, ggplot2::aes(x =
  Drought, y = y, label = Letter), inherit.aes = FALSE, size = 5) + ggplot2::facet_wrap(~ Period, nrow = 1) + ggplot2::scale_fill_manual(values = drought_colors, drop =
  FALSE) + ggplot2::scale_colour_manual(values = drought_colors, drop = FALSE) + ggplot2::scale_shape_manual(values = genotype_shapes, drop = FALSE) + ggplot2::
  scale_y_continuous(expand = ggplot2::expansion(mult = c(0.05, 0.16))) + ggplot2::labs(x = NULL, y = "Vector length", subtitle = length_label) + ggplot2::theme_bw(
  base_size = 12) + ggplot2::theme(panel.grid = ggplot2::element_blank(), axis.text = ggplot2::element_text(colour = "black"), axis.title = ggplot2::element_text(colour =
  "black"), strip.text = ggplot2::element_text(face = "bold"), legend.position = "none", plot.subtitle = ggplot2::element_text(hjust = 0, size = 10, colour = "black",
  margin = ggplot2::margin(b = 8)), axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
p_angle <- ggplot2::ggplot(dat, ggplot2::aes(x = Drought, y = Vector_angle_deg, fill = Drought)) + ggplot2::geom_hline(yintercept = 45, linetype = "dashed", linewidth =
  0.6, colour = "grey35") + ggplot2::geom_boxplot(width = 0.65, outlier.shape = NA, alpha = 0.75) + ggplot2::geom_jitter(ggplot2::aes(colour = Drought, shape = Genotype),
  width = 0.12, size = 2.2, alpha = 0.80) + ggplot2::geom_text(data = anno_angle, ggplot2::aes(x = Drought, y = y, label = Letter), inherit.aes = FALSE, size = 5) +
  ggplot2::facet_wrap(~ Period, nrow = 1) + ggplot2::scale_fill_manual(values = drought_colors, drop = FALSE) + ggplot2::scale_colour_manual(values = drought_colors, drop
  = FALSE) + ggplot2::scale_shape_manual(values = genotype_shapes, drop = FALSE) + ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0.05, 0.16))) +
  ggplot2::labs(x = NULL, y = "Vector angle (degree)", subtitle = angle_label) + ggplot2::theme_bw(base_size = 12) + ggplot2::theme(panel.grid = ggplot2::element_blank(),
  axis.text = ggplot2::element_text(colour = "black"), axis.title = ggplot2::element_text(colour = "black"), strip.text = ggplot2::element_text(face = "bold"),
  legend.position = "none", plot.subtitle = ggplot2::element_text(hjust = 0, size = 10, colour = "black", margin = ggplot2::margin(b = 8)), axis.text.x = ggplot2::
  element_text(angle = 45, hjust = 1))
print(p_length)
print(p_angle)
p_effect <- patchwork::wrap_plots(p_length, p_angle, ncol = 1, heights = c(1, 1))
print(p_effect)
ggplot2::ggsave(file.path(output_dir, "Fig1_Ecoenzyme_vector_boxplots.pdf"), p_effect, width = 12, height = 8.2)
ggplot2::ggsave(file.path(output_dir, "Fig1_Ecoenzyme_vector_boxplots.png"), p_effect, width = 12, height = 8.2, dpi = 600)
p_coordinates <- ggplot(dat, aes(x = C_vs_P_prop, y = C_vs_N_prop, colour = Drought, shape = Period)) + geom_abline(slope = 1, intercept = 0, linetype = "dashed", colour
  = "grey35") + geom_point(size = 2.7, alpha = 0.78) + coord_equal() + scale_colour_manual(values = drought_colors, breaks = drought_levels, labels = c("Control",
  "Light drought", "Moderate drought", "Heavy drought")) + labs(x = "BG / (BG + ALP)", y = "BG / (BG + NAG + LAP)", colour = "Drought", shape = "Stage") + theme_bw(
  base_size = 11) + theme(panel.grid = element_blank(), legend.position = "top")
print(p_coordinates)
ggsave(file.path(output_dir, "Fig2_Ecoenzyme_vector_coordinates.pdf"), p_coordinates, width = 7, height = 5.8)
ggsave(file.path(output_dir, "Fig2_Ecoenzyme_vector_coordinates.png"), p_coordinates, width = 7, height = 5.8, dpi = 600)
x_min <- min(dat$N_to_P_ratio, na.rm = TRUE)
x_max <- max(dat$N_to_P_ratio, na.rm = TRUE)
y_min <- min(dat$C_to_N_ratio, na.rm = TRUE)
y_max <- max(dat$C_to_N_ratio, na.rm = TRUE)
p_quadrant <- ggplot(dat, aes(x = N_to_P_ratio, y = C_to_N_ratio, colour = Drought, shape = Period)) + geom_vline(xintercept = 1, linetype = "dashed", colour = "grey35") +
  geom_hline(yintercept = 1, linetype = "dashed", colour = "grey35") + geom_point(size = 2.7, alpha = 0.78) + annotate("text", x = sqrt(x_min), y = sqrt(y_max), label =
  "C & P limitation", hjust = 0.5, vjust = 0) + annotate("text", x = sqrt(x_max), y = sqrt(y_max), label = "C & N limitation", hjust = 0.5, vjust = 0) + annotate("text",
  x = sqrt(x_min), y = sqrt(y_min), label = "P limitation", hjust = 0.5, vjust = 1) + annotate("text", x = sqrt(x_max), y = sqrt(y_min), label = "N limitation", hjust =
  0.5, vjust = 1) + scale_x_log10() + scale_y_log10() + scale_colour_manual(values = drought_colors, breaks = drought_levels, labels = c("Control", "Light drought",
  "Moderate drought", "Heavy drought")) + labs(x = "(NAG + LAP) / ALP", y = "BG / (NAG + LAP)", colour = "Drought", shape = "Stage") + theme_bw(base_size = 11) + theme(
  panel.grid = element_blank(), legend.position = "top")
print(p_quadrant)
ggsave(file.path(output_dir, "Fig3_Ecoenzyme_limitation_quadrant.pdf"), p_quadrant, width = 7.2, height = 5.9)
ggsave(file.path(output_dir, "Fig3_Ecoenzyme_limitation_quadrant.png"), p_quadrant, width = 7.2, height = 5.9, dpi = 600)
capture.output(sessionInfo(), file = file.path(output_dir, "12_sessionInfo.txt"))
message("Analysis completed. Results saved in: ", output_dir)
