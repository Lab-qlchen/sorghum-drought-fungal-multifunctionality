rm(list = ls())
options(stringsAsFactors = FALSE)
options(contrasts = c("contr.sum", "contr.poly"))
required_packages <- c("tidyverse", "lme4", "lmerTest", "emmeans", "multcomp", "multcompView", "patchwork", "pheatmap", "RColorBrewer", "performance")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(tidyverse)
  library(lme4)
  library(lmerTest)
  library(emmeans)
  library(multcomp)
  library(multcompView)
  library(patchwork)
  library(pheatmap)
  library(RColorBrewer)
  library(performance)
})
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/理化和酶活")
input_file <- "Soil_traits_repeated_splitplot_complete.csv"
output_dir <- "Soil_traits_LMM_results"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
dat <- read.csv(input_file, check.names = FALSE, fileEncoding = "UTF-8-BOM")
soil_traits <- c("NH4+-N", "NO3--N", "AP", "DOC", "MBC", "TC", "RWC")
enzyme_traits <- c("ALP", "AG", "BG", "CBH", "NAG", "LAP")
all_traits <- c(soil_traits, enzyme_traits)
required_cols <- c("Sample", "PlotID", "Block", "MainPlotID", "Genotype", "Period", "Drought", all_traits)
if (!all(required_cols %in% names(dat))) {
  stop("Missing required columns: ", paste(setdiff(required_cols, names(dat)), collapse = ", "))
}
dat$Block <- factor(dat$Block, levels = 1:4)
dat$MainPlotID <- factor(dat$MainPlotID)
dat$PlotID <- factor(dat$PlotID)
dat$Sample <- factor(dat$Sample)
dat$Genotype <- factor(dat$Genotype, levels = c("Jinza", "Liangnuo"), labels = c("Jinza 22", "Liangnuo 01"))
dat$Period <- factor(dat$Period, levels = c("Jointing", "Heading", "Filling", "Maturity"))
dat$Drought <- factor(dat$Drought, levels = c("Control", "Drought_L", "Drought_M", "Drought_H"))
for (trait in all_traits) {
  original_value <- dat[[trait]]
  nonempty_original <- !is.na(original_value) & trimws(as.character(original_value)) != ""
  converted_value <- suppressWarnings(as.numeric(original_value))
  if (any(nonempty_original & is.na(converted_value))) {
    stop("Non-numeric values were found in trait: ", trait)
  }
  dat[[trait]] <- converted_value
}
if (anyNA(dat[, c("Sample", "PlotID", "Block", "MainPlotID", "Genotype", "Period", "Drought")])) {
  stop("The experimental-design columns contain missing or unrecognized values.")
}
if (nrow(dat) != 128L || nlevels(dat$MainPlotID) != 16L || nlevels(dat$PlotID) != 32L || nlevels(dat$Sample) != 128L) {
  stop("Expected 128 observations, 16 main plots, 32 genotype subplots, ", "and 128 unique sample IDs.")
}
cell_check <- dat %>% count(Block, Drought, Genotype, Period, name = "n")
if (nrow(cell_check) != 128L || any(cell_check$n != 1L)) {
  print(cell_check)
  stop("Each Block x Drought x Genotype x Period cell must occur once.")
}
mainplot_check <- dat %>% distinct(MainPlotID, Block, Drought)
if (nrow(mainplot_check) != 16L || any(count(mainplot_check, MainPlotID)$n != 1L) || any(count(mainplot_check, Block, Drought)$n != 1L)) {
  stop("MainPlotID must uniquely represent each Block x Drought main plot.")
}
subplot_check <- dat %>% distinct(PlotID, MainPlotID, Genotype)
if (nrow(subplot_check) != 32L || any(count(subplot_check, PlotID)$n != 1L) || any(count(subplot_check, MainPlotID, Genotype)$n != 1L)) {
  stop("PlotID must uniquely represent each MainPlotID x Genotype subplot.")
}
if (!all(table(dat$MainPlotID) == 8L)) {
  stop("Each main plot must contain two genotypes observed at four periods.")
}
if (!all(table(dat$PlotID) == 4L)) {
  stop("Each genotype subplot must be observed once at each of four periods.")
}
design_summary <- bind_rows(tibble(Design_level = "Main plot", ID = "MainPlotID", Number = n_distinct(dat$MainPlotID), Observations_per_ID = 8L), tibble(Design_level =
  "Genotype subplot", ID = "PlotID", Number = n_distinct(dat$PlotID), Observations_per_ID = 4L), tibble(Design_level = "Sample", ID = "Sample", Number = n_distinct(dat$
  Sample), Observations_per_ID = 1L))
write.csv(design_summary, file.path(output_dir, "00_design_check.csv"), row.names = FALSE)
safe_name <- function (x) make.names(x, unique = TRUE)
name_map <- setNames(safe_name(all_traits), all_traits)
for (trait in all_traits) {
  dat[[name_map[[trait]]]] <- dat[[trait]]
}
ddf_method <- if (requireNamespace("pbkrtest", quietly = TRUE)) {
  "Kenward-Roger"
} else {
  "Satterthwaite"
}
emmeans::emm_options(lmer.df = if (ddf_method == "Kenward-Roger") {
  "kenward-roger"
} else {
  "satterthwaite"
})
cat("Denominator-df method:", ddf_method, "\n")
fmt_p <- function (p) {
  if (length(p) == 0L || is.na(p)) {
    "NA"
  } else if (p < 0.001) {
    "< 0.001"
  } else {
    paste0("= ", sprintf("%.3f", p))
  }
}
extract_metric <- function (object, metric) {
  if (is.null(object)) return(NA_real_)
  if (is.data.frame(object) && metric %in% names(object)) {
    value <- object[[metric]]
    return(if (length(value) == 0L) NA_real_ else as.numeric(value[[1]]))
  }
  if (is.list(object) && !is.null(object[[metric]])) {
    value <- object[[metric]]
    return(if (length(value) == 0L) NA_real_ else as.numeric(value[[1]]))
  }
  if (is.atomic(object) && !is.null(names(object)) && metric %in% names(object)) {
    return(as.numeric(object[[metric]]))
  }
  NA_real_
}
safe_model_quality <- function (model) {
  vc <- as.data.frame(VarCorr(model))
  get_variance <- function (group) {
    value <- vc$vcov[vc$grp == group]
    if (length(value) == 0L) NA_real_ else as.numeric(value[[1]])
  }
  r2_result <- tryCatch(suppressWarnings(performance::r2_nakagawa(model, tolerance = 1e-8)), error = function (e) NULL)
  convergence_messages <- model@optinfo$conv$lme4$messages
  convergence_text <- if (is.null(convergence_messages)) {
    "None"
  } else {
    paste(convergence_messages, collapse = "; ")
  }
  data.frame(N = stats::nobs(model), R2_marginal = extract_metric(r2_result, "R2_marginal"), R2_conditional = extract_metric(r2_result, "R2_conditional"),
    MainPlot_variance = get_variance("MainPlotID"), Plot_variance = get_variance("PlotID"), Residual_variance = get_variance("Residual"), Singular_fit = lme4::isSingular(
    model, tol = 1e-5), Convergence_warning = convergence_text, stringsAsFactors = FALSE)
}
fit_type3_anova <- function (model) {
  kr_result <- tryCatch(stats::anova(model, type = 3, ddf = "Kenward-Roger"), error = function (e) NULL)
  if (!is.null(kr_result)) {
    return(list(table = kr_result, method = "Kenward-Roger"))
  }
  list(table = stats::anova(model, type = 3, ddf = "Satterthwaite"), method = "Satterthwaite")
}
tidy_type3_anova <- function (anova_result, trait) {
  out <- as.data.frame(anova_result$table)
  out$Effect <- rownames(out)
  rownames(out) <- NULL
  out %>% mutate(Trait = trait, partial_eta2_F = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF), P_label = vapply(`Pr(>F)`, fmt_p, character(1)), DDF_method =
    anova_result$method, .before = 1) %>% relocate(Trait, Effect)
}
get_effect_row <- function (anova_df, effect) {
  row <- anova_df %>% filter(Effect == effect)
  if (nrow(row) == 0L && grepl(":", effect, fixed = TRUE)) {
    reversed_effect <- paste(rev(strsplit(effect, ":", fixed = TRUE)[[1]]), collapse = ":")
    row <- anova_df %>% filter(Effect == reversed_effect)
  }
  row
}
effect_label <- function (anova_df, effect, display_name) {
  row <- get_effect_row(anova_df, effect)
  if (nrow(row) != 1L) return(paste0(display_name, ": unavailable"))
  paste0(display_name, ": F(", sprintf("%.0f", row$NumDF), ", ", sprintf("%.1f", row$DenDF), ") = ", sprintf("%.2f", row$`F value`), ", P ", fmt_p(row$`Pr(>F)`))
}
drought_colors <- c(Control = "#E67E73", Drought_L = "#8FB847", Drought_M = "#45B4B8", Drought_H = "#A487B5")
period_levels <- c("Jointing", "Heading", "Filling", "Maturity")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
fit_one_trait <- function (orig_trait) {
  safe_trait <- name_map[[orig_trait]]
  cat("Running:", orig_trait, "\n")
  dat_sub <- dat %>% filter(!is.na(.data[[safe_trait]]))
  if (nrow(dat_sub) == 0L) {
    stop(orig_trait, ": all observations are missing.")
  }
  observed_cells <- dat_sub %>% distinct(Block, Drought, Genotype, Period)
  if (nrow(observed_cells) < 128L) {
    warning(orig_trait, ": missing observations produced an unbalanced model; inspect diagnostics.")
  }
  model_formula <- as.formula(paste0(safe_trait, " ~ Block + Drought * Period + Genotype + ", "(1 | MainPlotID) + (1 | PlotID)"))
  model <- lmerTest::lmer(model_formula, data = dat_sub, REML = TRUE, control = lme4::lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 200000)))
  anova_result <- fit_type3_anova(model)
  anova_df <- tidy_type3_anova(anova_result, orig_trait)
  quality_df <- safe_model_quality(model) %>% mutate(Trait = orig_trait, Formula = paste(deparse(model_formula), collapse = " "), DDF_method = anova_result$method,
    .before = 1)
  emm_stage <- emmeans::emmeans(model, ~ Drought | Period, weights = "equal")
  stage_pairs <- as.data.frame(emmeans::contrast(emm_stage, method = "pairwise", adjust = "tukey")) %>% mutate(Trait = orig_trait, Adjustment = "Tukey within each Period"
    , .before = 1)
  stage_emmeans <- multcomp::cld(emm_stage, Letters = letters, adjust = "tukey", sort = FALSE) %>% as.data.frame() %>% mutate(Trait = orig_trait, Period = factor(Period,
    levels = period_levels), Drought = factor(Drought, levels = drought_levels), Letter = trimws(.group), .before = 1) %>% dplyr::select(- .group)
  emm_overall <- emmeans::emmeans(model, ~ Drought, weights = "equal")
  overall_pairs <- as.data.frame(emmeans::contrast(emm_overall, method = "pairwise", adjust = "tukey")) %>% mutate(Trait = orig_trait, Adjustment =
    "Tukey overall Drought", .before = 1)
  mainplot_data <- dat_sub %>% group_by(Block, MainPlotID, Period, Drought) %>% summarise(n_genotypes = n(), MainPlotValue = mean(.data[[safe_trait]]), .groups = "drop")
  if (any(mainplot_data$n_genotypes != 2L)) {
    warning(orig_trait, ": at least one main-plot mean is not based on both genotypes.")
  }
  mainplot_summary <- mainplot_data %>% group_by(Period, Drought) %>% summarise(n_mainplots = n(), mean = mean(MainPlotValue), sd = sd(MainPlotValue), sem = sd / sqrt(
    n_mainplots), .groups = "drop") %>% mutate(Trait = orig_trait, .before = 1)
  p_genotype <- get_effect_row(anova_df, "Genotype")$`Pr(>F)`
  p_drought <- get_effect_row(anova_df, "Drought")$`Pr(>F)`
  p_period <- get_effect_row(anova_df, "Period")$`Pr(>F)`
  p_interaction <- get_effect_row(anova_df, "Drought:Period")$`Pr(>F)`
  flags_df <- data.frame(Trait = orig_trait, Genotype_P = if (length(p_genotype) == 0L) NA_real_ else p_genotype, Drought_P = if (length(p_drought) == 0L) NA_real_ else
    p_drought, Period_P = if (length(p_period) == 0L) NA_real_ else p_period, Drought_Period_P = if (length(p_interaction) == 0L) NA_real_ else p_interaction,
    Singular_fit = lme4::isSingular(model, tol = 1e-5), stringsAsFactors = FALSE)
  plot_df <- stage_emmeans
  y_min <- min(plot_df$lower.CL, na.rm = TRUE)
  y_max <- max(plot_df$upper.CL, na.rm = TRUE)
  y_range <- y_max - y_min
  if (!is.finite(y_range) || y_range <= 0) {
    y_range <- max(abs(c(y_min, y_max)), 1, na.rm = TRUE)
  }
  plot_df <- plot_df %>% mutate(letter_y = upper.CL + 0.05 * y_range)
  model_label <- paste(effect_label(anova_df, "Drought", "Drought"), effect_label(anova_df, "Period", "Stage"), effect_label(anova_df, "Drought:Period", "Drought x stage"
    ), sep = "\n")
  trait_plot <- ggplot(plot_df, aes(x = Period, y = emmean, group = Drought, colour = Drought)) + geom_ribbon(aes(ymin = lower.CL, ymax = upper.CL, fill = Drought), alpha
    = 0.15, colour = NA) + geom_line(linewidth = 0.9) + geom_point(size = 2.8) + geom_text(aes(y = letter_y, label = Letter), colour = "black", size = 3.4, show.legend =
    FALSE) + annotate("text", x = 1.02, y = y_max + 0.32 * y_range, label = model_label, hjust = 0, vjust = 1, size = 2.35, lineheight = 1.05, colour = "black") +
    coord_cartesian(ylim = c(y_min - 0.05 * y_range, y_max + 0.62 * y_range), clip = "off") + scale_colour_manual(values = drought_colors, breaks = drought_levels, labels
    = c("Control", "Light drought", "Moderate drought", "Heavy drought")) + scale_fill_manual(values = drought_colors, breaks = drought_levels, labels = c("Control",
    "Light drought", "Moderate drought", "Heavy drought")) + labs(title = orig_trait, x = NULL, y = NULL, colour = "Drought", fill = "Drought") + theme_bw() + theme(
    panel.grid = element_blank(), plot.title = element_text(hjust = 0.5, face = "bold", size = 11), axis.text.x = element_text(angle = 20, hjust = 1), legend.title =
    element_text(size = 10), legend.text = element_text(size = 9), plot.margin = ggplot2::margin(10, 20, 10, 10))
  list(model = model, anova = anova_df, quality = quality_df, stage_emmeans = stage_emmeans, stage_pairs = stage_pairs, overall_pairs = overall_pairs, mainplot_data =
    mainplot_data %>% mutate(Trait = orig_trait, .before = 1), mainplot_summary = mainplot_summary, flags = flags_df, plot = trait_plot)
}
results <- setNames(lapply(all_traits, fit_one_trait), all_traits)
anova_table <- bind_rows(lapply(results, `[[`, "anova")) %>% group_by(Effect) %>% mutate(P_FDR_BH_across_traits = p.adjust(`Pr(>F)`, method = "BH")) %>% ungroup()
quality_table <- bind_rows(lapply(results, `[[`, "quality"))
stage_emmeans_table <- bind_rows(lapply(results, `[[`, "stage_emmeans"))
stage_pairwise_table <- bind_rows(lapply(results, `[[`, "stage_pairs"))
overall_pairwise_table <- bind_rows(lapply(results, `[[`, "overall_pairs"))
mainplot_data_table <- bind_rows(lapply(results, `[[`, "mainplot_data"))
mainplot_summary_table <- bind_rows(lapply(results, `[[`, "mainplot_summary"))
flags_table <- bind_rows(lapply(results, `[[`, "flags"))
write.csv(anova_table, file.path(output_dir, "01_LMM_TypeIII_all_traits.csv"), row.names = FALSE)
write.csv(quality_table, file.path(output_dir, "02_random_variance_R2_model_checks.csv"), row.names = FALSE)
write.csv(stage_emmeans_table, file.path(output_dir, "03_Drought_within_stage_EMMeans_letters.csv"), row.names = FALSE)
write.csv(stage_pairwise_table, file.path(output_dir, "04_Drought_within_stage_Tukey.csv"), row.names = FALSE)
write.csv(overall_pairwise_table, file.path(output_dir, "05_Overall_Drought_Tukey_supplementary.csv"), row.names = FALSE)
write.csv(mainplot_data_table, file.path(output_dir, "06_raw_mainplot_values_descriptive.csv"), row.names = FALSE)
write.csv(mainplot_summary_table, file.path(output_dir, "07_raw_mainplot_mean_SEM_descriptive.csv"), row.names = FALSE)
write.csv(flags_table, file.path(output_dir, "08_key_effects_and_singularity.csv"), row.names = FALSE)
capture.output({
  for (trait in all_traits) {
    cat("\n============================================================\n")
    cat("Trait:", trait, "\n")
    cat("============================================================\n")
    print(summary(results[[trait]]$model))
    cat("\nType III ANOVA\n")
    print(results[[trait]]$anova)
  }
}, file = file.path(output_dir, "09_LMM_model_summaries.txt"))
pdf(file.path(output_dir, "10_LMM_residual_diagnostics.pdf"), width = 9, height = 4.5)
for (trait in all_traits) {
  diagnostic_model <- results[[trait]]$model
  diagnostic_residuals <- residuals(diagnostic_model)
  diagnostic_fitted <- fitted(diagnostic_model)
  par(mfrow = c(1, 2), mar = c(4, 4, 3, 1))
  plot(diagnostic_fitted, diagnostic_residuals, xlab = "Fitted values", ylab = "Residuals", main = paste(trait, "residuals"))
  abline(h = 0, lty = 2, col = "red")
  qqnorm(diagnostic_residuals, main = paste(trait, "normal Q-Q"))
  qqline(diagnostic_residuals, col = "red")
}
dev.off()
soil_plot_list <- lapply(soil_traits, function (x) results[[x]]$plot)
fig_s1 <- wrap_plots(soil_plot_list, ncol = 3, guides = "collect") & theme(legend.position = "bottom")
print(fig_s1)
ggsave(file.path(output_dir, "Fig_S1_soil_physicochemical_properties.pdf"), fig_s1, width = 14, height = 10)
ggsave(file.path(output_dir, "Fig_S1_soil_physicochemical_properties.png"), fig_s1, width = 14, height = 10, dpi = 600)
enzyme_plot_list <- lapply(enzyme_traits, function (x) results[[x]]$plot)
fig_s2 <- wrap_plots(enzyme_plot_list, ncol = 3, guides = "collect") & theme(legend.position = "bottom")
print(fig_s2)
ggsave(file.path(output_dir, "Fig_S2_soil_enzyme_activities.pdf"), fig_s2, width = 14, height = 8)
ggsave(file.path(output_dir, "Fig_S2_soil_enzyme_activities.png"), fig_s2, width = 14, height = 8, dpi = 600)
heat_df <- dat %>% group_by(Block, MainPlotID, Period, Drought) %>% summarise(across(all_of(all_traits), ~ mean(.x, na.rm = TRUE)), .groups = "drop") %>% group_by(Period,
  Drought) %>% summarise(across(all_of(all_traits), ~ mean(.x, na.rm = TRUE)), .groups = "drop") %>% mutate(Treatment = paste(Period, Drought, sep = "_"))
heat_mat <- heat_df %>% dplyr::select(Treatment, all_of(all_traits)) %>% column_to_rownames("Treatment") %>% t()
heat_sd <- apply(heat_mat, 1, sd, na.rm = TRUE)
valid_heat_rows <- is.finite(heat_sd) & heat_sd > 0
if (!all(valid_heat_rows)) {
  warning("The following zero-variance heatmap rows were omitted: ", paste(rownames(heat_mat)[!valid_heat_rows], collapse = ", "))
}
heat_mat <- heat_mat[valid_heat_rows,, drop = FALSE]
heat_mat <- t(scale(t(heat_mat)))
column_order <- tidyr::expand_grid(Period = period_levels, Drought = drought_levels) %>% mutate(name = paste(Period, Drought, sep = "_")) %>% pull(name)
heat_mat <- heat_mat[, column_order, drop = FALSE]
heat_colors <- colorRampPalette(rev(brewer.pal(11, "RdBu")))(100)
pdf(file.path(output_dir, "Fig_S3_heatmap_mainplot_means.pdf"), width = 10, height = 8)
pheatmap(heat_mat, cluster_rows = TRUE, cluster_cols = FALSE, gaps_col = c(4, 8, 12), border_color = NA, fontsize = 10, color = heat_colors)
dev.off()
png(file.path(output_dir, "Fig_S3_heatmap_mainplot_means.png"), width = 3000, height = 2400, res = 600)
pheatmap(heat_mat, cluster_rows = TRUE, cluster_cols = FALSE, gaps_col = c(4, 8, 12), border_color = NA, fontsize = 10, color = heat_colors)
dev.off()
capture.output(sessionInfo(), file = file.path(output_dir, "11_sessionInfo.txt"))
message("Analysis completed. Results saved in: ", output_dir)
