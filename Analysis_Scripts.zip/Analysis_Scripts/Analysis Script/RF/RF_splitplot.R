rm(list = ls())
grDevices::graphics.off()
options(stringsAsFactors = FALSE)
required_packages <- c("tidyverse", "patchwork")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(tidyverse)
  library(patchwork)
})
work_dir <- paste0("D:/IUE/山西数据/真菌/抽平/测试数据文件/", "splitplot-SMF-Fungi/随机森林")
output_dir <- file.path(work_dir, "SMF_RF_results")
importance_file <- file.path(output_dir, "01_RF_variable_importance_rawP.csv")
performance_file <- file.path(output_dir, "02_RF_model_performance_OOB_groupedCV.csv")
if (!file.exists(importance_file)) {
  stop("Cannot find: ", importance_file)
}
if (!file.exists(performance_file)) {
  stop("Cannot find: ", performance_file)
}
importance_all <- readr::read_csv(importance_file, show_col_types = FALSE)
performance_all <- readr::read_csv(performance_file, show_col_types = FALSE)
required_importance_cols <- c("Model", "Variable", "IncMSE", "Significance")
required_performance_cols <- c("Model", "OOB_R2")
missing_importance <- setdiff(required_importance_cols, names(importance_all))
missing_performance <- setdiff(required_performance_cols, names(performance_all))
if (length(missing_importance) > 0L) {
  stop("Importance table is missing: ", paste(missing_importance, collapse = ", "))
}
if (length(missing_performance) > 0L) {
  stop("Performance table is missing: ", paste(missing_performance, collapse = ", "))
}
model_levels <- c("Overall", "Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
model_short <- c("Overall" = "Overall", "Jointing stage" = "JS", "Heading stage" = "HS", "Filling stage" = "FS", "Maturity stage" = "MS")
variable_labels <- c(Fungi_Shannon = "Fungal Shannon", average_degree = "Mean degree", robustness = "Robustness", Negative_Cohesion = "Negative cohesion",
  HS_indicator_score = "HS z− indicator score")
model_cols <- c("Overall" = "grey45", "Jointing stage" = "#F8766D", "Heading stage" = "#7CAE00", "Filling stage" = "#00BFC4", "Maturity stage" = "#C77CFF")
importance_all <- importance_all %>% dplyr::mutate(Model = factor(Model, levels = model_levels))
performance_all <- performance_all %>% dplyr::mutate(Model = factor(Model, levels = model_levels))
plot_RF_one <- function (model_name) {
  df <- importance_all %>% dplyr::filter(as.character(Model) == model_name) %>% dplyr::arrange(IncMSE)
  if (nrow(df) == 0L) {
    stop("No RF importance result found for model: ", model_name)
  }
  df <- df %>% dplyr::mutate(Variable_label = dplyr::if_else(Variable %in% names(variable_labels), unname(variable_labels[Variable]), Variable))
  df$Variable_label <- factor(df$Variable_label, levels = df$Variable_label)
  x_values <- c(0, df$IncMSE)
  x_span <- diff(range(x_values, na.rm = TRUE))
  if (!is.finite(x_span) || x_span == 0) {
    x_span <- 1
  }
  ggplot2::ggplot(df, ggplot2::aes(x = IncMSE, y = Variable_label)) + ggplot2::geom_vline(xintercept = 0, linetype = 2, linewidth = 0.45, colour = "grey50") + ggplot2::
    geom_col(fill = unname(model_cols[model_name]), width = 0.65, colour = "black", linewidth = 0.30) + ggplot2::geom_text(ggplot2::aes(x = IncMSE + ifelse(IncMSE >= 0,
    0.045 * x_span, - 0.045 * x_span), label = Significance, hjust = ifelse(IncMSE >= 0, 0, 1)), size = 5, fontface = "bold", colour = "black") + ggplot2::labs(title =
    unname(model_short[model_name]), x = "Increase in MSE (%)", y = NULL) + ggplot2::theme_bw(base_size = 12) + ggplot2::theme(plot.title = ggplot2::element_text(face =
    "bold", size = 14, hjust = 0.5, colour = "black"), panel.grid.major.y = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank(), axis.text = ggplot2::
    element_text(colour = "black"), axis.title.x = ggplot2::element_text(colour = "black"), legend.position = "none", aspect.ratio = 1, plot.margin = ggplot2::margin(t =
    5, r = 5, b = 5, l = 5, unit = "pt")) + ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0.14, 0.18)))
}
p_overall <- plot_RF_one("Overall")
p_JS <- plot_RF_one("Jointing stage")
p_HS <- plot_RF_one("Heading stage")
p_FS <- plot_RF_one("Filling stage")
p_MS <- plot_RF_one("Maturity stage")
if (!"Grouped_CV_R2_mean" %in% names(performance_all)) {
  stop("Performance table is missing Grouped_CV_R2_mean. ", "Please use 02_RF_model_performance_OOB_groupedCV.csv from the current RF analysis.")
}
performance_plot_data <- performance_all %>% dplyr::transmute(Model = factor(as.character(Model), levels = model_levels), Model_short = factor(unname(model_short[
  as.character(Model)]), levels = unname(model_short[model_levels])), OOB_R2_percent = 100 * as.numeric(OOB_R2), Grouped_CV_R2_percent = 100 * as.numeric(
  Grouped_CV_R2_mean)) %>% dplyr::mutate(x_base = as.numeric(Model_short), x_OOB = x_base - 0.18, x_CV = x_base + 0.18)
performance_values <- c(performance_plot_data$OOB_R2_percent, performance_plot_data$Grouped_CV_R2_percent)
performance_range <- range(c(0, performance_values), na.rm = TRUE)
performance_span <- diff(performance_range)
if (!is.finite(performance_span) || performance_span == 0) {
  performance_span <- 10
}
label_offset <- 0.045 * performance_span
performance_plot_data <- performance_plot_data %>% dplyr::mutate(OOB_label_y = OOB_R2_percent + ifelse(OOB_R2_percent >= 0, label_offset, - label_offset), CV_label_y =
  Grouped_CV_R2_percent + ifelse(Grouped_CV_R2_percent >= 0, label_offset, - label_offset), OOB_vjust = ifelse(OOB_R2_percent >= 0, 0, 1), CV_vjust = ifelse(
  Grouped_CV_R2_percent >= 0, 0, 1))
p_performance <- ggplot2::ggplot(performance_plot_data) + ggplot2::geom_hline(yintercept = 0, linewidth = 0.45, colour = "grey45") + ggplot2::geom_col(ggplot2::aes(x =
  x_OOB, y = OOB_R2_percent, fill = Model, colour = Model), width = 0.32, linewidth = 0.55, show.legend = FALSE) + ggplot2::geom_col(ggplot2::aes(x = x_CV, y =
  Grouped_CV_R2_percent, colour = Model), fill = "white", width = 0.32, linewidth = 0.95, show.legend = FALSE) + ggplot2::geom_text(ggplot2::aes(x = x_OOB, y =
  OOB_label_y, label = paste0(sprintf("%.1f", OOB_R2_percent), "%")), vjust = performance_plot_data$OOB_vjust, size = 3.6, fontface = "bold", colour = "black") + ggplot2::
  geom_text(ggplot2::aes(x = x_CV, y = CV_label_y, label = paste0(sprintf("%.1f", Grouped_CV_R2_percent), "%")), vjust = performance_plot_data$CV_vjust, size = 3.6,
  fontface = "bold", colour = "black") + ggplot2::scale_fill_manual(values = model_cols, drop = FALSE) + ggplot2::scale_colour_manual(values = model_cols, drop = FALSE) +
  ggplot2::scale_x_continuous(breaks = seq_along(model_levels), labels = unname(model_short[model_levels]), limits = c(0.55, 5.45), expand = ggplot2::expansion(mult = c(
  0.01, 0.01))) + ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0.16, 0.18))) + ggplot2::labs(title = "Model predictive performance", subtitle =
  expression("Filled = OOB " * R ^ 2 * ";   open = grouped CV " * R ^ 2), x = NULL, y = expression("Predictive " * R ^ 2 * " (%)")) + ggplot2::theme_bw(base_size = 12) +
  ggplot2::theme(plot.title = ggplot2::element_text(face = "bold", size = 14, hjust = 0.5, colour = "black"), plot.subtitle = ggplot2::element_text(size = 10, hjust = 0.5
  , colour = "black"), axis.text.x = ggplot2::element_text(face = "bold", colour = "black", size = 10), axis.text.y = ggplot2::element_text(colour = "black"),
  axis.title.y = ggplot2::element_text(colour = "black"), panel.grid.major.x = ggplot2::element_blank(), panel.grid.minor = ggplot2::element_blank(), legend.position =
  "none", plot.margin = ggplot2::margin(t = 5, r = 5, b = 5, l = 5, unit = "pt"))
top_row <- patchwork::wrap_plots(p_overall, p_JS, p_HS, ncol = 3, widths = c(1, 1, 1))
bottom_row <- patchwork::wrap_plots(p_FS, p_MS, p_performance, ncol = 3, widths = c(1, 1, 1.45))
final_RF_plot <- top_row / bottom_row + patchwork::plot_layout(heights = c(1, 1))
print(final_RF_plot)
ggplot2::ggsave(file.path(output_dir, "SMF_RF_OLD_STYLE_2x3_WIDER_PERFORMANCE_FINAL.pdf"), final_RF_plot, width = 12, height = 8, units = "in", device = grDevices::
  cairo_pdf)
ggplot2::ggsave(file.path(output_dir, "SMF_RF_OLD_STYLE_2x3_WIDER_PERFORMANCE_FINAL.png"), final_RF_plot, width = 12, height = 8, dpi = 600, units = "in")
message("RF plotting completed. Figure saved in: ", normalizePath(output_dir, winslash = "/", mustWork = FALSE))
