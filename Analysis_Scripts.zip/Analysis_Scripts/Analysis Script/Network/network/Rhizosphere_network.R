library(tidyverse)
library(igraph)
library(microeco)
library(rstatix)
library(multcompView)
library(scales)
library(ggplotify)
library(cowplot)
work_dir <- "."
setwd(work_dir)
asv <- read.csv("根际网络.csv", check.names = FALSE)
group <- read.csv("根际分组.csv", check.names = FALSE)
colnames(group) <- c("Sample", "Group")
asv <- asv[, !grepl("^Unnamed", colnames(asv))]
tax <- asv[, 1:4]
colnames(tax)[1] <- "Function"
rownames(tax) <- asv[, 4]
otu <- asv[, - (1:4)]
rownames(otu) <- asv[, 4]
common_samples <- intersect(colnames(otu), group$Sample)
otu <- otu[, common_samples, drop = FALSE]
group <- group %>% filter(Sample %in% common_samples)
group <- group %>% mutate(Period = case_when(str_detect(Group, "^JS_") ~ "JS", str_detect(Group, "^HS_") ~ "HS", str_detect(Group, "^FS_") ~ "FS", str_detect(Group,
  "^MS_") ~ "MS", TRUE ~ NA_character_), Period_full = case_when(str_detect(Group, "^JS_") ~ "Jointing stage", str_detect(Group, "^HS_") ~ "Heading stage", str_detect(
  Group, "^FS_") ~ "Filling stage", str_detect(Group, "^MS_") ~ "Maturity stage", TRUE ~ NA_character_), Drought = case_when(str_detect(Group, "_Control$") ~ "Control",
  str_detect(Group, "_Drought_L$") ~ "Drought_L", str_detect(Group, "_Drought_M$") ~ "Drought_M", str_detect(Group, "_Drought_H$") ~ "Drought_H", TRUE ~ NA_character_)) %>%
  filter(!is.na(Period), !is.na(Drought))
group$Period <- factor(group$Period, levels = c("JS", "HS", "FS", "MS"))
group$Period_full <- factor(group$Period_full, levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage"))
group$Drought <- factor(group$Drought, levels = c("Control", "Drought_L", "Drought_M", "Drought_H"))
base_outdir <- "5.19根际_按时期_SpiecEasi_meta_network_final"
dir.create(base_outdir, showWarnings = FALSE, recursive = TRUE)
REL_ABUND_CUTOFF <- 0.0001
FREQ_CUTOFF <- 0.20
SPIEC_METHOD <- "mb"
LAMBDA_MIN_RATIO <- 0.01
NLAMBDA <- 20
SEL_CRITERION <- "bstars"
PULSAR_REP_NUM <- 20
PULSAR_SEED <- 123
PULSAR_NCORES <- 1
ROBUST_REMOVE_SEQ <- seq(0, 0.9, by = 0.1)
N_ROBUST_REP <- 100
safe_mean_distance <- function (g) {
  if (vcount(g) < 2 || ecount(g) < 1) return(NA_real_)
  comps <- components(g)
  giant_id <- which.max(comps$csize)
  g_giant <- induced_subgraph(g, vids = V(g)[comps$membership == giant_id])
  if (vcount(g_giant) < 2 || ecount(g_giant) < 1) return(NA_real_)
  mean_distance(g_giant, directed = FALSE, weights = NA)
}
safe_diameter <- function (g) {
  if (vcount(g) < 2 || ecount(g) < 1) return(NA_real_)
  comps <- components(g)
  giant_id <- which.max(comps$csize)
  g_giant <- induced_subgraph(g, vids = V(g)[comps$membership == giant_id])
  if (vcount(g_giant) < 2 || ecount(g_giant) < 1) return(NA_real_)
  diameter(g_giant, directed = FALSE, weights = NA)
}
safe_modularity <- function (g) {
  if (vcount(g) < 2 || ecount(g) < 1) {
    return(list(modules_num = NA_real_, modularity = NA_real_))
  }
  comm <- tryCatch(cluster_fast_greedy(as.undirected(g)), error = function (e) NULL)
  if (is.null(comm)) {
    return(list(modules_num = NA_real_, modularity = NA_real_))
  } else {
    return(list(modules_num = length(comm), modularity = modularity(comm)))
  }
}
rob_giant_fraction <- function (g) {
  if (vcount(g) == 0) return(0)
  comps <- components(g)
  max(comps$csize) / vcount(g)
}
rob_global_efficiency <- function (g) {
  if (vcount(g) < 2 || ecount(g) < 1) return(0)
  d <- distances(g, weights = NA)
  diag(d) <- NA
  inv_d <- 1 / d
  inv_d[is.infinite(inv_d)] <- 0
  eff <- mean(inv_d[!is.na(inv_d)])
  if (is.nan(eff) || is.na(eff)) eff <- 0
  return(eff)
}
calc_period_robustness_curve <- function (g, period_name, mode = c("random", "degree"), remove_seq = seq(0, 0.9, by = 0.1), nrep = 100, seed = 123) {
  mode <- match.arg(mode)
  set.seed(seed)
  g0 <- as.undirected(g, mode = "collapse")
  g0 <- delete_vertices(g0, which(degree(g0) == 0))
  if (vcount(g0) < 2 || ecount(g0) < 1) {
    return(data.frame(Period = period_name, mode = mode, rep = 1, remove_fraction = remove_seq, giant_fraction = NA_real_, edge_fraction = NA_real_, efficiency = NA_real_
      ))
  }
  n0 <- vcount(g0)
  e0 <- ecount(g0)
  out_list <- list()
  for (rp in seq_len(nrep)) {
    if (mode == "random") {
      remove_order <- sample(V(g0)$name, n0, replace = FALSE)
    }
    if (mode == "degree") {
      deg0 <- degree(g0)
      remove_order <- names(sort(deg0, decreasing = TRUE))
    }
    tmp <- lapply(remove_seq, function (fr) {
      n_remove <- floor(fr * n0)
      if (n_remove == 0) {
        g_sub <- g0
      } else {
        remove_nodes <- remove_order[1:n_remove]
        g_sub <- delete_vertices(g0, remove_nodes)
      }
      data.frame(Period = period_name, mode = mode, rep = rp, remove_fraction = fr, giant_fraction = rob_giant_fraction(g_sub), edge_fraction = ifelse(e0 > 0, ecount(
        g_sub) / e0, NA_real_), efficiency = rob_global_efficiency(g_sub))
    })
    out_list[[rp]] <- bind_rows(tmp)
  }
  bind_rows(out_list)
}
calc_period_robustness_auc <- function (curve_df) {
  curve_df %>% group_by(Period, mode, rep) %>% arrange(remove_fraction) %>% summarise(robustness_giant_auc = sum(diff(remove_fraction) * (head(giant_fraction, - 1) + tail
    (giant_fraction, - 1)) / 2, na.rm = TRUE), robustness_edge_auc = sum(diff(remove_fraction) * (head(edge_fraction, - 1) + tail(edge_fraction, - 1)) / 2, na.rm = TRUE),
    robustness_efficiency_auc = sum(diff(remove_fraction) * (head(efficiency, - 1) + tail(efficiency, - 1)) / 2, na.rm = TRUE), .groups = "drop") %>% group_by(Period,
    mode) %>% summarise(robustness_giant_auc_mean = mean(robustness_giant_auc, na.rm = TRUE), robustness_giant_auc_sd = sd(robustness_giant_auc, na.rm = TRUE),
    robustness_edge_auc_mean = mean(robustness_edge_auc, na.rm = TRUE), robustness_edge_auc_sd = sd(robustness_edge_auc, na.rm = TRUE), robustness_efficiency_auc_mean =
    mean(robustness_efficiency_auc, na.rm = TRUE), robustness_efficiency_auc_sd = sd(robustness_efficiency_auc, na.rm = TRUE), .groups = "drop")
}
prepare_topology_graph <- function (g) {
  if (is.null(g)) return(NULL)
  g2 <- as.undirected(g, mode = "collapse")
  g2 <- simplify(g2, remove.multiple = TRUE, remove.loops = TRUE)
  g2
}
sample_specific_seed <- function (sample_name, base_seed = 123) {
  as.integer((base_seed + sum(utf8ToInt(as.character(sample_name)))) %% .Machine$integer.max)
}
safe_average_clustering_sub <- function (g) {
  g <- prepare_topology_graph(g)
  if (is.null(g) || vcount(g) == 0) return(NA_real_)
  if (vcount(g) < 3 || ecount(g) < 1) return(0)
  x <- tryCatch(transitivity(g, type = "local", isolates = "zero"), error = function (e) NULL)
  if (is.null(x) || length(x) == 0) return(NA_real_)
  out <- mean(x, na.rm = TRUE)
  if (is.nan(out) || is.infinite(out)) return(NA_real_)
  out
}
safe_connectance_sub <- function (g) {
  g <- prepare_topology_graph(g)
  if (is.null(g) || vcount(g) < 2) return(NA_real_)
  ecount(g) / (vcount(g) * (vcount(g) - 1) / 2)
}
safe_average_path_length_sub <- function (g) {
  g <- prepare_topology_graph(g)
  if (is.null(g) || vcount(g) < 2 || ecount(g) < 1) {
    return(NA_real_)
  }
  comps <- components(g)
  giant_id <- which.max(comps$csize)
  g_giant <- induced_subgraph(g, vids = V(g)[comps$membership == giant_id])
  if (vcount(g_giant) < 2 || ecount(g_giant) < 1) {
    return(NA_real_)
  }
  mean_distance(g_giant, directed = FALSE, weights = NA)
}
trapz_auc_sub <- function (x, y) {
  if (length(x) < 2 || length(y) < 2) return(NA_real_)
  sum(diff(x) * (head(y, - 1) + tail(y, - 1)) / 2, na.rm = TRUE)
}
calc_random_robustness_sub <- function (g, remove_seq = seq(0, 0.9, by = 0.1), nrep = 100, seed = 123) {
  g0 <- prepare_topology_graph(g)
  if (is.null(g0) || vcount(g0) < 2 || ecount(g0) < 1) {
    return(0)
  }
  n0 <- vcount(g0)
  node_names <- V(g0)$name
  max_curve <- sapply(remove_seq, function (fr) {
    n_remove <- floor(fr * n0)
    (n0 - n_remove) / n0
  })
  max_auc <- trapz_auc_sub(remove_seq, max_curve)
  if (is.na(max_auc) || max_auc <= 0) {
    return(NA_real_)
  }
  set.seed(seed)
  auc_rep <- numeric(nrep)
  for (rp in seq_len(nrep)) {
    remove_order <- sample(node_names, size = n0, replace = FALSE)
    giant_curve <- sapply(remove_seq, function (fr) {
      n_remove <- floor(fr * n0)
      if (n_remove == 0) {
        g_sub <- g0
      } else {
        remove_nodes <- remove_order[seq_len(n_remove)]
        g_sub <- delete_vertices(g0, remove_nodes)
      }
      if (vcount(g_sub) == 0) {
        return(0)
      }
      comps <- components(g_sub)
      giant_size <- max(comps$csize)
      giant_size / n0
    })
    auc_raw <- trapz_auc_sub(remove_seq, giant_curve)
    auc_rep[rp] <- auc_raw / max_auc
  }
  out <- mean(auc_rep, na.rm = TRUE)
  if (is.nan(out) || is.infinite(out)) {
    return(NA_real_)
  }
  max(0, min(1, out))
}
calc_sample_subgraph_metrics <- function (sample_name, otu_rel, g_meta) {
  present_taxa <- rownames(otu_rel)[otu_rel[, sample_name] > 0]
  present_taxa <- intersect(present_taxa, V(g_meta)$name)
  g_sub <- induced_subgraph(g_meta, vids = present_taxa)
  g_sub <- prepare_topology_graph(g_sub)
  n_nodes <- vcount(g_sub)
  if (n_nodes == 0) {
    return(data.frame(Sample = sample_name, nodes_num = 0, average_degree = NA_real_, average_clustering = NA_real_, connectance = NA_real_, average_path_length =
      NA_real_, robustness = NA_real_))
  }
  nodes_num <- n_nodes
  average_degree <- mean(degree(g_sub))
  average_clustering <- safe_average_clustering_sub(g_sub)
  connectance <- safe_connectance_sub(g_sub)
  seed_i <- sample_specific_seed(sample_name, base_seed = PULSAR_SEED)
  average_path_length <- safe_average_path_length_sub(g_sub)
  robustness <- calc_random_robustness_sub(g_sub, remove_seq = ROBUST_REMOVE_SEQ, nrep = N_ROBUST_REP, seed = seed_i + 10000L)
  data.frame(Sample = sample_name, nodes_num = nodes_num, average_degree = average_degree, average_clustering = average_clustering, connectance = connectance,
    average_path_length = average_path_length, robustness = robustness)
}
global_func_cols <- c("plant_pathogen" = "#69aed5", "soil_saprotroph" = "#84B300", "dung_saprotroph" = "#00BFC4", "unspecified_saprotroph" = "#B07BE3",
  "litter_saprotroph" = "#f8766d", "animal_parasite" = "#84C492", "wood_saprotroph" = "#e6ab02", "Other" = "#8C6D31", "NA" = "grey70")
recode_function_group <- function (x) {
  x <- as.character(x)
  x[is.na(x) | x == ""] <- "NA"
  keep_funcs <- c("plant_pathogen", "soil_saprotroph", "dung_saprotroph", "unspecified_saprotroph", "litter_saprotroph", "animal_parasite", "wood_saprotroph")
  x2 <- ifelse(x %in% keep_funcs, x, "Other")
  x2[x == "NA"] <- "NA"
  x2
}
plot_meta_network_base <- function (g, tax, title_txt, func_cols) {
  g_plot <- delete_vertices(g, which(degree(g) == 0))
  if (vcount(g_plot) == 0) {
    plot.new()
    title(main = paste0(title_txt, "\n(no connected nodes)"))
    return(invisible(NULL))
  }
  V(g_plot)$Function_raw <- tax[V(g_plot)$name, "Function"]
  V(g_plot)$Function <- recode_function_group(V(g_plot)$Function_raw)
  node_func <- as.character(V(g_plot)$Function)
  V(g_plot)$color <- func_cols[node_func]
  V(g_plot)$color[is.na(V(g_plot)$color)] <- "grey70"
  deg_vals <- degree(g_plot)
  if (length(unique(deg_vals)) > 1) {
    V(g_plot)$size <- rescale(deg_vals, to = c(4, 10))
  } else {
    V(g_plot)$size <- 7
  }
  if (!is.null(E(g_plot)$weight)) {
    w_abs <- abs(E(g_plot)$weight)
    if (length(unique(w_abs)) > 1) {
      E(g_plot)$width <- rescale(w_abs, to = c(0.5, 2.2))
    } else {
      E(g_plot)$width <- 1
    }
  } else {
    E(g_plot)$width <- 1
  }
  E(g_plot)$color <- "grey70"
  lay <- layout_with_fr(g_plot)
  plot(g_plot, layout = lay, vertex.label = NA, edge.label = NA, edge.curved = 0.3, main = title_txt, margin = 0.2)
  mtext(side = 1, line = 1, cex = 0.9, text = paste0("Nodes = ", vcount(g_plot), "    Edges = ", ecount(g_plot)))
}
save_single_network_pdf <- function (g, tax, title_txt, func_cols, file) {
  pdf(file, width = 8, height = 8)
  par(mar = c(2.5, 1.5, 3, 1.5))
  plot_meta_network_base(g, tax, title_txt, func_cols)
  dev.off()
}
make_shared_legend <- function (func_cols) {
  legend_df <- data.frame(Function = factor(names(func_cols), levels = names(func_cols)), x = 1, y = seq_along(func_cols))
  p_leg <- ggplot(legend_df, aes(x = x, y = y, color = Function)) + geom_point(size = 4) + scale_color_manual(values = func_cols, drop = FALSE) + theme_void() + theme(
    legend.position = "right", legend.title = element_text(size = 11), legend.text = element_text(size = 9)) + guides(color = guide_legend(title = "Function", ncol = 1))
  cowplot::get_legend(p_leg)
}
periods <- c("JS", "HS", "FS", "MS")
all_period_metrics <- list()
all_period_network_param <- list()
all_period_robustness_curve <- list()
all_period_robustness_auc <- list()
all_period_graphs <- list()
all_period_tax <- list()
for (pd in periods) {
  cat("\n=====================================\n")
  cat("Processing Period:", pd, "\n")
  cat("=====================================\n")
  outdir_pd <- file.path(base_outdir, pd)
  dir.create(outdir_pd, showWarnings = FALSE, recursive = TRUE)
  group_pd <- group %>% filter(Period == pd)
  samples_pd <- group_pd$Sample
  otu_pd <- otu[, samples_pd, drop = FALSE]
  otu_rel_pd <- sweep(otu_pd, 2, colSums(otu_pd), "/")
  otu_rel_pd[is.na(otu_rel_pd)] <- 0
  micro_pd <- as.data.frame(otu_pd)
  tax_pd <- tax[rownames(micro_pd),, drop = FALSE]
  sample_pd <- group_pd %>% as.data.frame()
  rownames(sample_pd) <- sample_pd$Sample
  dataset_pd <- microtable$new(otu_table = micro_pd, sample_table = sample_pd, tax_table = tax_pd)
  dataset_pd$filter_taxa(rel_abund = REL_ABUND_CUTOFF, freq = FREQ_CUTOFF)
  cat("After filtering:", "taxa =", nrow(dataset_pd$otu_table), "samples =", nrow(dataset_pd$sample_table), "\n")
  t1 <- trans_network$new(dataset = dataset_pd, cor_method = NULL, group_column = "Drought")
  pargs2 <- list(rep.num = PULSAR_REP_NUM, seed = PULSAR_SEED, ncores = PULSAR_NCORES)
  t1$cal_network(network_method = "SpiecEasi", SpiecEasi_method = SPIEC_METHOD, lambda.min.ratio = LAMBDA_MIN_RATIO, nlambda = NLAMBDA, sel.criterion = SEL_CRITERION,
    pulsar.select = TRUE, pulsar.params = pargs2)
  g_meta <- t1$res_network
  cat("Meta-network built:", "nodes =", vcount(g_meta), "edges =", ecount(g_meta), "\n")
  cat("Calculating period-level network robustness:", pd, "\n")
  rob_random_pd <- calc_period_robustness_curve(g = g_meta, period_name = pd, mode = "random", remove_seq = seq(0, 0.9, by = 0.1), nrep = 100, seed = PULSAR_SEED)
  rob_degree_pd <- calc_period_robustness_curve(g = g_meta, period_name = pd, mode = "degree", remove_seq = seq(0, 0.9, by = 0.1), nrep = 1, seed = PULSAR_SEED)
  rob_curve_pd <- bind_rows(rob_random_pd, rob_degree_pd)
  write.csv(rob_curve_pd, file.path(outdir_pd, paste0(pd, "_period_network_robustness_curve.csv")), row.names = FALSE)
  rob_auc_pd <- calc_period_robustness_auc(rob_curve_pd)
  write.csv(rob_auc_pd, file.path(outdir_pd, paste0(pd, "_period_network_robustness_AUC.csv")), row.names = FALSE)
  all_period_robustness_curve[[pd]] <- rob_curve_pd
  all_period_robustness_auc[[pd]] <- rob_auc_pd
  saveRDS(g_meta, file.path(outdir_pd, paste0(pd, "_meta_network_SpiecEasi.rds")))
  write_graph(g_meta, file.path(outdir_pd, paste0(pd, "_meta_network_SpiecEasi.graphml")), format = "graphml")
  node_names <- V(g_meta)$name
  tax_use <- dataset_pd$tax_table[node_names,, drop = FALSE]
  for (col_name in colnames(tax_use)) {
    g_meta <- set_vertex_attr(g_meta, name = col_name, value = as.character(tax_use[[col_name]]))
  }
  all_period_graphs[[pd]] <- g_meta
  all_period_tax[[pd]] <- dataset_pd$tax_table
  save_single_network_pdf(g = g_meta, tax = dataset_pd$tax_table, title_txt = paste0("Rhizosphere ", pd, " meta-network (SpiecEasi)"), func_cols = global_func_cols, file
    = file.path(outdir_pd, paste0(pd, "_meta_network.pdf")))
  mod_meta <- safe_modularity(g_meta)
  avg_clust_meta <- tryCatch(mean(transitivity(g_meta, type = "local"), na.rm = TRUE), error = function (e) NA_real_)
  if (is.nan(avg_clust_meta)) avg_clust_meta <- NA_real_
  network_param_meta <- data.frame(Period = pd, Sample_number = ncol(dataset_pd$otu_table), nodes_num = vcount(g_meta), edges_num = ecount(g_meta), average_degree = if (
    vcount(g_meta) > 0) mean(degree(g_meta)) else NA_real_, network_density = if (vcount(g_meta) > 1) edge_density(g_meta) else NA_real_, clustering_coefficient = if (
    vcount(g_meta) > 2) transitivity(g_meta, type = "global") else NA_real_, average_clustering = avg_clust_meta, average_path_length = safe_mean_distance(g_meta),
    network_diameter = safe_diameter(g_meta), modules_num = mod_meta$modules_num, modularity = mod_meta$modularity, complexity = ifelse(vcount(g_meta) > 0, ecount(g_meta)
    / vcount(g_meta), NA_real_))
  write.csv(network_param_meta, file.path(outdir_pd, paste0(pd, "_meta_network_parameter.csv")), row.names = FALSE)
  all_period_network_param[[pd]] <- network_param_meta
  otu_rel_pd2 <- otu_rel_pd[rownames(dataset_pd$otu_table),, drop = FALSE]
  sample_metrics_pd <- map_dfr(colnames(otu_rel_pd2), calc_sample_subgraph_metrics, otu_rel = otu_rel_pd2, g_meta = g_meta)
  sample_metrics_pd <- sample_metrics_pd %>% left_join(group_pd, by = "Sample")
  write.csv(sample_metrics_pd, file.path(outdir_pd, paste0(pd, "_sample_specific_subnetwork_metrics.csv")), row.names = FALSE)
  all_period_metrics[[pd]] <- sample_metrics_pd
}
all_sample_metrics <- bind_rows(all_period_metrics)
all_meta_param <- bind_rows(all_period_network_param)
write.csv(all_sample_metrics, file.path(base_outdir, "Rhizosphere_all_period_sample_specific_subnetwork_metrics.csv"), row.names = FALSE)
write.csv(all_meta_param, file.path(base_outdir, "Rhizosphere_all_period_meta_network_parameters.csv"), row.names = FALSE)
all_robustness_curve <- bind_rows(all_period_robustness_curve)
all_robustness_auc <- bind_rows(all_period_robustness_auc)
write.csv(all_robustness_curve, file.path(base_outdir, "Rhizosphere_all_period_network_robustness_curve.csv"), row.names = FALSE)
write.csv(all_robustness_auc, file.path(base_outdir, "Rhizosphere_all_period_network_robustness_AUC.csv"), row.names = FALSE)
network_plot_list <- list()
for (pd in periods) {
  g_tmp <- all_period_graphs[[pd]]
  tax_tmp <- all_period_tax[[pd]]
  network_plot_list[[pd]] <- ggplotify::as.ggplot(~ {
    par(mar = c(2.5, 1.5, 3, 1.5))
    plot_meta_network_base(g = g_tmp, tax = tax_tmp, title_txt = paste0("Rhizosphere ", pd), func_cols = global_func_cols)
  })
}
legend_grob <- make_shared_legend(global_func_cols)
network_grid <- cowplot::plot_grid(plotlist = network_plot_list, ncol = 2)
network_combined <- cowplot::plot_grid(network_grid, legend_grob, ncol = 2, rel_widths = c(1, 0.28))
print(network_combined)
ggsave(filename = file.path(base_outdir, "Rhizosphere_all_period_meta_network_combined.pdf"), plot = network_combined, width = 14, height = 10)
ggsave(filename = file.path(base_outdir, "Rhizosphere_all_period_meta_network_combined.png"), plot = network_combined, width = 14, height = 10, dpi = 300)
RADAR_METRICS_SAMPLE <- c("nodes_num", "average_degree", "connectance", "average_clustering", "average_path_length")
radar_sample_df <- all_sample_metrics %>% dplyr::select(Sample, Period_full, Drought, all_of(RADAR_METRICS_SAMPLE)) %>% group_by(Period_full, Drought) %>% summarise(
  across(all_of(RADAR_METRICS_SAMPLE), ~ {
  if (all(is.na(.x))) {
    NA_real_
  } else {
    mean(.x, na.rm = TRUE)
  }
}), .groups = "drop") %>% pivot_longer(cols = all_of(RADAR_METRICS_SAMPLE), names_to = "Metric", values_to = "Value")
radar_stat_input <- all_sample_metrics %>% dplyr::select(Period_full, Drought, all_of(RADAR_METRICS_SAMPLE)) %>% pivot_longer(cols = all_of(RADAR_METRICS_SAMPLE),
  names_to = "Metric", values_to = "Value") %>% filter(!is.na(Value), !is.na(Drought), !is.na(Period_full))
safe_kruskal_radar <- function (df) {
  if (length(unique(df$Drought)) < 2) {
    return(data.frame(p = NA_real_))
  }
  if (length(unique(df$Value)) <= 1) {
    return(data.frame(p = NA_real_))
  }
  res <- tryCatch(kruskal.test(Value ~ Drought, data = df), error = function (e) NULL)
  if (is.null(res)) {
    data.frame(p = NA_real_)
  } else {
    data.frame(p = res$p.value)
  }
}
radar_stat_df <- radar_stat_input %>% group_by(Period_full, Metric) %>% group_modify(~ safe_kruskal_radar(.x)) %>% ungroup() %>% group_by(Period_full) %>% mutate(p.adj =
  p.adjust(p, method = "BH")) %>% ungroup() %>% mutate(sig = case_when(is.na(p.adj) ~ "", p.adj < 0.001 ~ "***", p.adj < 0.01 ~ "**", p.adj < 0.05 ~ "*", TRUE ~ ""))
write.csv(radar_stat_df, file.path(base_outdir, "Rhizosphere_network_topology_radar_Kruskal_BH.csv"), row.names = FALSE)
robustness_df <- all_sample_metrics %>% dplyr::select(Sample, Period_full, Drought, robustness) %>% filter(!is.na(robustness), !is.na(Drought), !is.na(Period_full)) %>%
  mutate(Drought = factor(Drought, levels = c("Control", "Drought_L", "Drought_M", "Drought_H"), labels = c("Control", "Drought_L", "Drought_M", "Drought_H")),
  Period_full = factor(Period_full, levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")))
write.csv(robustness_df, file.path(base_outdir, "Rhizosphere_subnetwork_robustness_plot_data.csv"), row.names = FALSE)
robustness_kw <- robustness_df %>% group_by(Period_full) %>% kruskal_test(robustness ~ Drought)
write.csv(robustness_kw, file.path(base_outdir, "Rhizosphere_subnetwork_robustness_Kruskal_test.csv"), row.names = FALSE)
robustness_dunn <- robustness_df %>% group_by(Period_full) %>% dunn_test(robustness ~ Drought, p.adjust.method = "BH")
write.csv(robustness_dunn, file.path(base_outdir, "Rhizosphere_subnetwork_robustness_Dunn_test.csv"), row.names = FALSE)
get_letter_df <- function (df_one_stage) {
  stage_name <- unique(df_one_stage$Period_full)
  group_levels <- levels(df_one_stage$Drought)
  dunn_res <- dunn_test(data = df_one_stage, formula = robustness ~ Drought, p.adjust.method = "BH")
  pmat <- matrix(1, nrow = length(group_levels), ncol = length(group_levels), dimnames = list(group_levels, group_levels))
  if (nrow(dunn_res) > 0) {
    for (i in seq_len(nrow(dunn_res))) {
      g1 <- as.character(dunn_res$group1[i])
      g2 <- as.character(dunn_res$group2[i])
      pval <- dunn_res$p.adj[i]
      pmat[g1, g2] <- pval
      pmat[g2, g1] <- pval
    }
  }
  letter_obj <- multcompView::multcompLetters(x = pmat, threshold = 0.05)
  letter_df <- data.frame(Drought = names(letter_obj$Letters), Letters = letter_obj$Letters, stringsAsFactors = FALSE)
  out <- letter_df
  out$Period_full <- stage_name
  out
}
robustness_letters <- bind_rows(lapply(split(robustness_df, robustness_df$Period_full), get_letter_df))
write.csv(robustness_letters, file.path(base_outdir, "Rhizosphere_subnetwork_robustness_letter_grouping.csv"), row.names = FALSE)
