rm(list = ls())
options(stringsAsFactors = FALSE)
setwd("D:/IUE/山西数据/真菌/抽平/真菌_网络分析/网络参数与SMF_GPI相关性")
library(tidyverse)
smf <- read.csv("SMF_MeanZ_results.csv", check.names = FALSE)
coh <- read.csv("sample_cohesion_Hernandez.csv", check.names = FALSE)
net <- read.csv("Rhizosphere_all_period_sample_specific_subnetwork_metrics.csv", check.names = FALSE)
grp <- read.csv("根际分组.csv", check.names = FALSE)
colnames(grp)[1:2] <- c("Sample", "Group")
grp <- grp %>% mutate(Period = case_when(str_detect(Group, "^JS_") ~ "JS", str_detect(Group, "^HS_") ~ "HS", str_detect(Group, "^FS_") ~ "FS", str_detect(Group, "^MS_") ~
  "MS", TRUE ~ NA_character_), Period_full = case_when(str_detect(Group, "^JS_") ~ "Jointing stage", str_detect(Group, "^HS_") ~ "Heading stage", str_detect(Group, "^FS_"
  ) ~ "Filling stage", str_detect(Group, "^MS_") ~ "Maturity stage", TRUE ~ NA_character_)) %>% filter(!is.na(Period))
network_topology_vars <- c("nodes_num", "average_degree", "connectance", "average_clustering", "average_path_length", "robustness")
cohesion_vars <- intersect(c("Negative_Cohesion", "Positive_Cohesion"), colnames(coh))
if (length(cohesion_vars) == 0) {
  stop("No cohesion variables found.")
}
network_vars <- c(cohesion_vars, network_topology_vars)
missing_vars <- setdiff(network_topology_vars, colnames(net))
if (length(missing_vars) > 0) {
  stop(paste("Missing network columns:", paste(missing_vars, collapse = ", ")))
}
dat <- net %>% select(Sample, all_of(network_topology_vars)) %>% left_join(coh %>% select(Sample, all_of(cohesion_vars)), by = "Sample") %>% left_join(smf %>% select(
  Sample, SMF_meanZ), by = "Sample") %>% left_join(grp %>% select(Sample, Group, Period, Period_full), by = "Sample")
cat("Merged samples:", nrow(dat), "\n")
periods <- c("JS", "HS", "FS", "MS")
res_list <- list()
for (pd in periods) {
  dat_pd <- dat %>% filter(Period == pd)
  for (x in network_vars) {
    tmp_data <- dat_pd %>% select(SMF_meanZ, all_of(x)) %>% drop_na()
    if (nrow(tmp_data) < 3) {
      res_list[[paste(pd, x, sep = "_")]] <- data.frame(Period = pd, Variable = x, n = nrow(tmp_data), Spearman_rho = NA, P_value = NA)
    } else {
      cor_test <- cor.test(tmp_data$SMF_meanZ, tmp_data[[x]], method = "spearman", exact = FALSE)
      res_list[[paste(pd, x, sep = "_")]] <- data.frame(Period = pd, Variable = x, n = nrow(tmp_data), Spearman_rho = unname(cor_test$estimate), P_value = cor_test$
        p.value)
    }
  }
}
res <- bind_rows(res_list)
res <- res %>% mutate(P_BH = p.adjust(P_value, method = "BH"))
res <- res %>% mutate(sig = case_when(is.na(P_BH) ~ "", P_BH < 0.001 ~ "***", P_BH < 0.01 ~ "**", P_BH < 0.05 ~ "*", TRUE ~ ""), neg_log10_PBH = - log10(pmax(P_BH,
  .Machine$double.xmin)))
label_map <- c("Negative_Cohesion" = "Negative cohesion", "Positive_Cohesion" = "Positive cohesion", "nodes_num" = "Nodes", "average_degree" = "Average degree",
  "connectance" = "Connectance", "average_clustering" = "Clustering", "average_path_length" = "Average path length", "robustness" = "Robustness")
variable_order <- c("Negative_Cohesion", "Positive_Cohesion", "nodes_num", "average_degree", "connectance", "average_clustering", "average_path_length", "robustness")
variable_order <- variable_order[variable_order %in% network_vars]
res <- res %>% mutate(Variable_label = recode(Variable, !!!label_map))
res$Period <- factor(res$Period, levels = c("JS", "HS", "FS", "MS"))
res$Variable_label <- factor(res$Variable_label, levels = label_map[variable_order])
p_bubble <- ggplot(res, aes(x = Variable_label, y = Period)) + geom_point(aes(size = neg_log10_PBH, fill = Spearman_rho), shape = 21, color = "grey30", stroke = 0.35) +
  geom_text(aes(label = sig), size = 5, fontface = "bold") + scale_fill_gradient2(low = "#3B4CC0", mid = "white", high = "#B40426", midpoint = 0, limits = c(- 1, 1), name
  = "Spearman rho") + scale_size_continuous(range = c(2, 10), name = "-log10(BH P)") + labs(x = NULL, y = NULL, title =
  "Spearman correlations between SMF and fungal network properties") + theme_bw(base_size = 14) + theme(plot.title = element_text(hjust = 0.5, face = "bold"), axis.text.x
  = element_text(angle = 35, hjust = 1, color = "black"), axis.text.y = element_text(face = "bold", color = "black"), panel.grid.minor = element_blank())
print(p_bubble)
ggsave("SMF_network_cohesion_spearman_bubble_new_network_parameters.pdf", p_bubble, width = 12, height = 5)
ggsave("SMF_network_cohesion_spearman_bubble_new_network_parameters.png", p_bubble, width = 12, height = 5, dpi = 300)
write.csv(res, "SMF_network_cohesion_spearman_results_new_network_parameters.csv", row.names = FALSE)
cat("\nDONE.\n")
