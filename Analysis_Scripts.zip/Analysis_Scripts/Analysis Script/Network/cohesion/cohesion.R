setwd("D:/IUE/山西数据/真菌/抽平/totalASVs 内聚力_宽度_重叠指数")
rm(list = ls())
library(tidyverse)
ITER <- 200
PERS_CUTOFF <- 0.10
asv <- read.csv("根际.csv", check.names = FALSE)
rownames(asv) <- asv[, 1]
otu <- asv[, - 1]
otu_rel <- sweep(otu, 2, colSums(otu), "/")
otu_rel[is.na(otu_rel)] <- 0
rel <- t(otu_rel)
zero <- function (x) sum(x == 0)
pos.mean <- function (x) {
  v <- x[x > 0]
  if (length(v) == 0) 0 else mean(v)
}
neg.mean <- function (x) {
  v <- x[x < 0]
  if (length(v) == 0) 0 else mean(v)
}
cat("OTU 数（筛选前）:", ncol(rel), "\n")
zero.cutoff <- ceiling(PERS_CUTOFF * nrow(rel))
rel <- rel[, apply(rel, 2, zero) < (nrow(rel) - zero.cutoff), drop = FALSE]
cat("OTU 数（persistence ≥10% 后）:", ncol(rel), "\n")
class(rel)
str(rel[1:5, 1:5])
apply(rel, 2, zero)[1:10]
cor.true <- cor(rel, method = "spearman")
diag(cor.true) <- 0
set.seed(123)
med.tax.cors <- matrix(NA, nrow = ncol(rel), ncol = ncol(rel), dimnames = list(colnames(rel), colnames(rel)))
for (taxon in seq_len(ncol(rel))) {
  perm.cors <- matrix(NA, nrow = ncol(rel), ncol = ITER)
  for (i in seq_len(ITER)) {
    perm.rel <- rel
    for (j in seq_len(ncol(rel))) {
      perm.rel[, j] <- sample(rel[, j])
    }
    perm.rel[, taxon] <- rel[, taxon]
    cor.null <- cor(perm.rel, method = "spearman")
    diag(cor.null) <- 0
    perm.cors[, i] <- cor.null[, taxon]
  }
  med.tax.cors[, taxon] <- apply(perm.cors, 1, median, na.rm = TRUE)
}
obs.exp.cors <- cor.true - med.tax.cors
diag(obs.exp.cors) <- 0
conn.pos <- apply(obs.exp.cors, 2, pos.mean)
conn.neg <- apply(obs.exp.cors, 2, neg.mean)
write.csv(data.frame(ASV = colnames(rel), Positive_Connectedness = conn.pos, Negative_Connectedness = conn.neg), "根际taxon_connectedness_Hernandez.csv", row.names = FALSE)
cohesion_df <- data.frame(Sample = rownames(rel), Positive_Cohesion = as.numeric(rel %*% conn.pos), Negative_Cohesion = as.numeric(rel %*% conn.neg))
write.csv(cohesion_df, "根际sample_cohesion_Hernandez.csv", row.names = FALSE)
cat("✔ Hernandez cohesion 计算完成\n")
library(tidyverse)
library(ggpubr)
cohesion_df <- read.csv("根际sample_cohesion_Hernandez.csv")
group <- read.csv("根际分组.csv", stringsAsFactors = FALSE)
colnames(group) <- c("Sample", "Group")
cohesion_df <- cohesion_df %>% left_join(group, by = "Sample") %>% mutate(Period = case_when(grepl("^JS_", Group) ~ "Jointing stage", grepl("^HS_", Group) ~
  "Heading stage", grepl("^FS_", Group) ~ "Filling stage", grepl("^MS_", Group) ~ "Maturity stage"), Drought = case_when(grepl("_Control$", Group) ~ "Control", grepl(
  "_Drought_L$", Group) ~ "Drought_L", grepl("_Drought_M$", Group) ~ "Drought_M", grepl("_Drought_H$", Group) ~ "Drought_H"))
cohesion_df$Drought <- factor(cohesion_df$Drought, levels = c("Control", "Drought_L", "Drought_M", "Drought_H"))
cohesion_df$Period <- factor(cohesion_df$Period, levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage"))
library(rstatix)
stat_pos <- cohesion_df %>% group_by(Period) %>% dunn_test(Positive_Cohesion ~ Drought, p.adjust.method = "BH") %>% filter(p.adj < 0.05) %>% add_xy_position(x = "Drought"
  )
stat_neg <- cohesion_df %>% group_by(Period) %>% dunn_test(Negative_Cohesion ~ Drought, p.adjust.method = "BH") %>% filter(p.adj < 0.05) %>% add_xy_position(x = "Drought"
  )
p_pos <- ggplot(cohesion_df, aes(x = Drought, y = Positive_Cohesion, fill = Drought)) + geom_boxplot(width = 0.6, outlier.shape = NA) + geom_jitter(width = 0.15, size = 1
  , alpha = 0.7) + facet_wrap(~ Period, nrow = 1, scales = "free_y") + theme_bw() + labs(x = "Drought treatment", y = "Positive cohesion") + theme(axis.text.x =
  element_text(angle = 45, hjust = 1), legend.position = "none", strip.text = element_text(size = 12))
if (nrow(stat_pos) > 0) {
  p_pos <- p_pos + stat_pvalue_manual(stat_pos, label = "p.adj.signif", hide.ns = TRUE)
}
p_pos
ggsave("根际Positive_cohesion_boxplot.pdf", p_pos, width = 12, height = 4)
p_neg <- ggplot(cohesion_df, aes(x = Drought, y = Negative_Cohesion, fill = Drought)) + geom_boxplot(width = 0.6, outlier.shape = NA) + geom_jitter(width = 0.15, size = 1
  , alpha = 0.7) + facet_wrap(~ Period, nrow = 1, scales = "free_y") + theme_bw() + labs(x = "Drought treatment", y = "Negative cohesion") + theme(axis.text.x =
  element_text(angle = 45, hjust = 1), legend.position = "none", strip.text = element_text(size = 12))
if (nrow(stat_neg) > 0) {
  p_neg <- p_neg + stat_pvalue_manual(stat_neg, label = "p.adj.signif", hide.ns = TRUE)
}
p_neg
ggsave("根际Negative_cohesion_boxplot.pdf", p_neg, width = 12, height = 4)
