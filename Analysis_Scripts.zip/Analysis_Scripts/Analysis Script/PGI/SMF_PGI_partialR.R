rm(list = ls())
options(stringsAsFactors = FALSE, contrasts = c("contr.sum", "contr.poly"))
required_packages <- c("lme4", "lmerTest", "emmeans", "multcomp", "multcompView", "dplyr", "tibble", "tidyr", "purrr", "stringr", "ggplot2")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/SMF-PGI")
input_file <- "SMF_PGI_splitplot_data.csv"
output_dir <- "SMF_PGI_integrated_results"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
period_levels <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
genotype_levels <- c("Jinza 22", "Liangnuo 01")
func_cols <- c("NH4+-N", "NO3--N", "AP", "DOC", "MBC", "TC", "ALP", "AG", "BG", "CBH", "NAG", "LAP")
required_cols <- c("Sample", "PlotID", "Block", "MainPlotID", "Genotype", "Period", "Drought", "PGI_meanZ", func_cols)
write_csv_out <- function (x, filename) {
  utils::write.csv(x, file.path(output_dir, filename), row.names = FALSE)
}
dat <- utils::read.csv(input_file, check.names = FALSE, fileEncoding = "UTF-8")
missing_cols <- setdiff(required_cols, names(dat))
if (length(missing_cols) > 0L) {
  stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
}
dat <- dat |> dplyr::mutate(Sample = as.character(Sample), PlotID = factor(as.character(PlotID), levels = unique(as.character(PlotID))), MainPlotID = factor(as.character(
  MainPlotID), levels = unique(as.character(MainPlotID))), Block = factor(as.character(Block), levels = as.character(1:4)), Genotype = factor(as.character(Genotype),
  levels = genotype_levels), Period = factor(as.character(Period), levels = period_levels), Drought = factor(as.character(Drought), levels = drought_levels), PGI_meanZ =
  suppressWarnings(as.numeric(PGI_meanZ)))
dat[func_cols] <- lapply(dat[func_cols], function (x) {
  suppressWarnings(as.numeric(x))
})
if (nrow(dat) != 128L || dplyr::n_distinct(dat$Sample) != 128L) {
  stop("Expected 128 rows with 128 unique samples.")
}
if (anyNA(dat[, required_cols])) {
  stop("Required analysis columns contain missing or unrecognized values.")
}
cell_check <- dat |> dplyr::count(Block, Drought, Genotype, Period, name = "n")
if (nrow(cell_check) != 128L || any(cell_check$n != 1L)) {
  stop("Each Block x Drought x Genotype x Period cell must contain one observation.")
}
mainplot_check <- dat |> dplyr::count(MainPlotID, name = "n")
if (nrow(mainplot_check) != 16L || any(mainplot_check$n != 8L)) {
  stop("Expected 16 main plots with eight observations per main plot.")
}
plot_check <- dat |> dplyr::count(PlotID, name = "n")
if (nrow(plot_check) != 32L || any(plot_check$n != 4L)) {
  stop("Expected 32 genotype subplots with four observations per subplot.")
}
plot_mapping_check <- dat |> dplyr::group_by(PlotID) |> dplyr::summarise(n_Block = dplyr::n_distinct(Block), n_MainPlotID = dplyr::n_distinct(MainPlotID), n_Drought =
  dplyr::n_distinct(Drought), n_Genotype = dplyr::n_distinct(Genotype), .groups = "drop")
if (any(as.matrix(plot_mapping_check[, - 1]) != 1L)) {
  stop("At least one PlotID maps to multiple design levels.")
}
stage_check <- dat |> dplyr::count(Period, name = "N") |> dplyr::mutate(Main_plots = vapply(as.character(Period), function (z) {
  dplyr::n_distinct(dat$MainPlotID[as.character(dat$Period) == z])
}, integer(1)), Subplots = vapply(as.character(Period), function (z) {
  dplyr::n_distinct(dat$PlotID[as.character(dat$Period) == z])
}, integer(1)))
if (any(stage_check$N != 32L) || any(stage_check$Main_plots != 16L) || any(stage_check$Subplots != 32L)) {
  stop("Each stage must contain 32 subplot observations from 16 main plots.")
}
write_csv_out(stage_check, "00_design_check_by_stage.csv")
bad_functions <- func_cols[vapply(dat[func_cols], function (x) {
  any(!is.finite(x)) || stats::sd(x) == 0
}, logical(1))]
if (length(bad_functions) > 0L) {
  stop("Invalid or zero-variance SMF component columns: ", paste(bad_functions, collapse = ", "))
}
function_z <- scale(as.matrix(dat[, func_cols]))
dat$SMF_meanZ <- rowMeans(function_z)
write_csv_out(dat |> dplyr::select(Sample, PlotID, Block, MainPlotID, Genotype, Period, Drought, PGI_meanZ, SMF_meanZ, dplyr::all_of(func_cols)),
  "01_analysis_data_with_SMF.csv")
lmm_control <- lme4::lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))
anova_lmm <- function (model) {
  kr <- tryCatch(stats::anova(model, type = 3, ddf = "Kenward-Roger"), error = function (e) NULL)
  if (!is.null(kr)) {
    return(list(table = kr, method = "Kenward-Roger"))
  }
  list(table = stats::anova(model, type = 3, ddf = "Satterthwaite"), method = "Satterthwaite")
}
tidy_lmm_anova <- function (result) {
  out <- as.data.frame(result$table)
  out$Effect <- rownames(out)
  rownames(out) <- NULL
  out |> dplyr::relocate(Effect) |> dplyr::mutate(DDF_method = result$method, partial_eta2 = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF))
}
convergence_message <- function (model) {
  msg <- model@optinfo$conv$lme4$messages
  if (is.null(msg)) {
    "None"
  } else {
    paste(msg, collapse = "; ")
  }
}
fmt_p <- function (p) {
  if (is.na(p) || !is.finite(p)) {
    return("NA")
  }
  if (p < 0.001) {
    "< 0.001"
  } else {
    paste0("= ", sprintf("%.3f", p))
  }
}
anova_line <- function (tab, effect, label) {
  z <- tab |> dplyr::filter(Effect == effect)
  if (nrow(z) != 1L) {
    return(paste0(label, ": unavailable"))
  }
  paste0(label, ": F(", sprintf("%.0f", z$NumDF), ", ", sprintf("%.1f", z$DenDF), ") = ", sprintf("%.2f", z$`F value`), ", P ", fmt_p(z$`Pr(>F)`), ", partial eta2 = ",
    sprintf("%.3f", z$partial_eta2))
}
fit_smf <- lmerTest::lmer(SMF_meanZ ~ Block + Drought * Period + Genotype + (1 | MainPlotID) + (1 | PlotID), data = dat, REML = TRUE, control = lmm_control)
smf_anova_result <- anova_lmm(fit_smf)
smf_anova <- tidy_lmm_anova(smf_anova_result)
write_csv_out(smf_anova, "02_SMF_LMM_type3_ANOVA.csv")
capture.output(summary(fit_smf), file = file.path(output_dir, "02_SMF_LMM_summary.txt"))
write_csv_out(as.data.frame(lme4::VarCorr(fit_smf)), "02_SMF_random_variance.csv")
smf_model_check <- tibble::tibble(Model = "SMF repeated-measures split-plot LMM", Singular_fit = lme4::isSingular(fit_smf, tol = 1e-5), Convergence_message =
  convergence_message(fit_smf), DDF_method = smf_anova_result$method)
write_csv_out(smf_model_check, "02_SMF_model_check.csv")
smf_emm <- emmeans::emmeans(fit_smf, ~ Drought | Period, weights = "equal")
smf_emm_df <- as.data.frame(smf_emm)
smf_pairs_df <- as.data.frame(emmeans::contrast(smf_emm, method = "pairwise", adjust = "tukey"))
smf_letters_df <- multcomp::cld(smf_emm, adjust = "tukey", Letters = letters, sort = FALSE) |> as.data.frame() |> dplyr::transmute(Period = factor(Period, levels =
  period_levels), Drought = factor(Drought, levels = drought_levels), .group = stringr::str_trim(.group))
write_csv_out(smf_emm_df, "03_SMF_adjusted_means.csv")
write_csv_out(smf_pairs_df, "04_SMF_drought_Tukey_within_stage.csv")
write_csv_out(smf_letters_df, "05_SMF_drought_letters.csv")
drought_labels <- c(Control = "Control", Drought_L = "Light drought", Drought_M = "Moderate drought", Drought_H = "Heavy drought")
smf_plot_df <- smf_emm_df |> dplyr::mutate(Period = factor(Period, levels = period_levels), Drought = factor(Drought, levels = drought_levels)) |> dplyr::left_join(
  smf_letters_df, by = c("Period", "Drought"))
smf_subtitle <- paste(anova_line(smf_anova, "Drought", "Drought"), anova_line(smf_anova, "Period", "Stage"), anova_line(smf_anova, "Drought:Period", "Drought x stage"),
  sep = "    ")
smf_y_range <- diff(range(c(smf_plot_df$lower.CL, smf_plot_df$upper.CL), na.rm = TRUE))
if (!is.finite(smf_y_range) || smf_y_range == 0) {
  smf_y_range <- 1
}
p_smf <- ggplot2::ggplot(smf_plot_df, ggplot2::aes(x = Drought, y = emmean, fill = Drought)) + ggplot2::geom_col(width = 0.75) + ggplot2::geom_errorbar(ggplot2::aes(ymin
  = lower.CL, ymax = upper.CL), width = 0.20) + ggplot2::geom_text(ggplot2::aes(y = upper.CL + 0.05 * smf_y_range, label = .group), size = 4, vjust = 0) + ggplot2::
  facet_wrap(~ Period, nrow = 1, scales = "free_y", drop = FALSE) + ggplot2::scale_fill_manual(values = c(Control = "#E76F61", Drought_L = "#7BAE29", Drought_M =
  "#20AEB7", Drought_H = "#9B7BB5")) + ggplot2::scale_x_discrete(labels = drought_labels) + ggplot2::labs(x = "Drought treatment", y = "Soil multifunctionality (mean Z)",
  subtitle = smf_subtitle) + ggplot2::theme_bw() + ggplot2::theme(panel.grid = ggplot2::element_blank(), axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
  strip.text = ggplot2::element_text(face = "bold"), legend.position = "none", plot.subtitle = ggplot2::element_text(size = 9))
print(p_smf)
ggplot2::ggsave(file.path(output_dir, "Fig1D_SMF_drought_by_stage.pdf"), plot = p_smf, width = 12, height = 4.3)
ggplot2::ggsave(file.path(output_dir, "Fig1D_SMF_drought_by_stage.png"), plot = p_smf, width = 12, height = 4.3, dpi = 600)
fit_assoc_stage <- function (stage_name) {
  d <- dat |> dplyr::filter(Period == stage_name) |> dplyr::transmute(Sample, PlotID, Block, MainPlotID, Genotype, Drought, Period, PGI_raw = as.numeric(PGI_meanZ),
    SMF_raw = as.numeric(SMF_meanZ)) |> tidyr::drop_na()
  if (nrow(d) != 32L || stats::sd(d$PGI_raw) == 0 || stats::sd(d$SMF_raw) == 0) {
    stop("Invalid data at ", stage_name, ": expected 32 observations with non-zero PGI and SMF variance.")
  }
  pgi_mean <- mean(d$PGI_raw)
  pgi_sd <- stats::sd(d$PGI_raw)
  smf_mean <- mean(d$SMF_raw)
  smf_sd <- stats::sd(d$SMF_raw)
  d <- d |> dplyr::mutate(PGI_z = (PGI_raw - pgi_mean) / pgi_sd, SMF_z = (SMF_raw - smf_mean) / smf_sd)
  model <- lmerTest::lmer(SMF_z ~ Block + Genotype + PGI_z + (1 | MainPlotID), data = d, REML = TRUE, control = lmm_control)
  assoc_anova_result <- anova_lmm(model)
  assoc_table <- as.data.frame(assoc_anova_result$table)
  if (!"PGI_z" %in% rownames(assoc_table)) {
    stop("Could not extract PGI_z effect at ", stage_name, ".")
  }
  z <- assoc_table["PGI_z",, drop = FALSE]
  num_df <- as.numeric(z$NumDF)
  den_df <- as.numeric(z$DenDF)
  f_value <- as.numeric(z$`F value`)
  p_value <- as.numeric(z$`Pr(>F)`)
  estimate_std <- unname(lme4::fixef(model)["PGI_z"])
  partial_r <- sign(estimate_std) * sqrt((f_value * num_df) / (f_value * num_df + den_df))
  variance_df <- as.data.frame(lme4::VarCorr(model))
  mainplot_variance <- variance_df$vcov[variance_df$grp == "MainPlotID"]
  residual_variance <- variance_df$vcov[variance_df$grp == "Residual"]
  if (length(mainplot_variance) == 0L) {
    mainplot_variance <- NA_real_
  } else {
    mainplot_variance <- mainplot_variance[1]
  }
  if (length(residual_variance) == 0L) {
    residual_variance <- NA_real_
  } else {
    residual_variance <- residual_variance[1]
  }
  pgi_grid_raw <- seq(min(d$PGI_raw), max(d$PGI_raw), length.out = 120)
  pgi_grid_z <- (pgi_grid_raw - pgi_mean) / pgi_sd
  emm_line <- emmeans::emmeans(model, ~ PGI_z, at = list(PGI_z = pgi_grid_z), weights = "equal")
  pred <- as.data.frame(emm_line)
  lower_name <- intersect(c("lower.CL", "asymp.LCL"), names(pred))[1]
  upper_name <- intersect(c("upper.CL", "asymp.UCL"), names(pred))[1]
  if (is.na(lower_name) || is.na(upper_name)) {
    stop("Confidence-limit columns were not returned at ", stage_name, ".")
  }
  pred <- pred |> dplyr::transmute(Period = factor(stage_name, levels = period_levels), PGI_meanZ = PGI_z * pgi_sd + pgi_mean, predicted_SMF = emmean * smf_sd + smf_mean,
    lower = .data[[lower_name]] * smf_sd + smf_mean, upper = .data[[upper_name]] * smf_sd + smf_mean)
  result_row <- tibble::tibble(Period = factor(stage_name, levels = period_levels), N = stats::nobs(model), Estimate_std = estimate_std, Partial_r = partial_r, NumDF =
    num_df, DenDF = den_df, F_value = f_value, P_value = p_value, DDF_method = assoc_anova_result$method, Singular_fit = lme4::isSingular(model, tol = 1e-5),
    MainPlot_variance = mainplot_variance, Residual_variance = residual_variance, Convergence_message = convergence_message(model))
  list(data = d, model = model, result = result_row, prediction = pred)
}
stage_assoc_fits <- lapply(period_levels, fit_assoc_stage)
names(stage_assoc_fits) <- period_levels
assoc_results <- dplyr::bind_rows(lapply(stage_assoc_fits, function (x) {
  x$result
})) |> dplyr::mutate(Period = factor(Period, levels = period_levels), P_FDR = stats::p.adjust(P_value, method = "BH"))
write_csv_out(assoc_results, "06_PGI_SMF_stage_specific_partial_correlations.csv")
for (stage_name in period_levels) {
  fit_object <- stage_assoc_fits[[stage_name]]$model
  safe_stage_name <- gsub(" ", "_", stage_name)
  capture.output(summary(fit_object), file = file.path(output_dir, paste0("07_", safe_stage_name, "_PGI_SMF_LMM_summary.txt")))
}
plot_data <- dplyr::bind_rows(lapply(stage_assoc_fits, function (x) {
  x$data |> dplyr::transmute(Period = factor(Period, levels = period_levels), PGI_meanZ = PGI_raw, SMF_meanZ = SMF_raw, Block, Genotype, Drought, MainPlotID, PlotID)
}))
prediction_df <- dplyr::bind_rows(lapply(stage_assoc_fits, function (x) {
  x$prediction
}))
annotation_df <- plot_data |> dplyr::group_by(Period) |> dplyr::summarise(x = min(PGI_meanZ, na.rm = TRUE), y = max(SMF_meanZ, na.rm = TRUE), .groups = "drop") |> dplyr::
  left_join(assoc_results |> dplyr::select(Period, Partial_r, P_value, P_FDR), by = "Period") |> dplyr::mutate(label = paste0("Partial r = ", sprintf("%.2f", Partial_r),
  "\nP ", vapply(P_value, fmt_p, character(1)), "\nFDR P ", vapply(P_FDR, fmt_p, character(1))))
p_assoc <- ggplot2::ggplot(plot_data, ggplot2::aes(x = PGI_meanZ, y = SMF_meanZ)) + ggplot2::geom_point(size = 3, color = "#2485bc", alpha = 0.75) + ggplot2::geom_ribbon(
  data = prediction_df, ggplot2::aes(x = PGI_meanZ, ymin = lower, ymax = upper), inherit.aes = FALSE, fill = "#b0c4de", alpha = 0.55) + ggplot2::geom_line(data =
  prediction_df, ggplot2::aes(x = PGI_meanZ, y = predicted_SMF), inherit.aes = FALSE, color = "#1b4f72", linewidth = 0.9) + ggplot2::geom_text(data = annotation_df,
  ggplot2::aes(x = x, y = y, label = label), inherit.aes = FALSE, hjust = 0, vjust = 1, size = 3.5, lineheight = 1.05) + ggplot2::facet_wrap(~ Period, nrow = 1, scales =
  "free") + ggplot2::labs(x = "Plant growth index (mean Z)", y = "Soil multifunctionality (mean Z)", subtitle = paste0("Stage-specific split-plot LMM: ",
  "SMF_z ~ Block + Genotype + PGI_z + (1 | MainPlotID); ", "drought not adjusted")) + ggplot2::theme_bw() + ggplot2::theme(panel.grid = ggplot2::element_blank(),
  axis.title = ggplot2::element_text(size = 12), axis.text = ggplot2::element_text(size = 10), strip.text = ggplot2::element_text(size = 11, face = "bold"), plot.subtitle
  = ggplot2::element_text(size = 9))
print(p_assoc)
ggplot2::ggsave(file.path(output_dir, "Fig1E_PGI_SMF_stage_specific_partial_correlation.pdf"), plot = p_assoc, width = 12, height = 4.3)
ggplot2::ggsave(file.path(output_dir, "Fig1E_PGI_SMF_stage_specific_partial_correlation.png"), plot = p_assoc, width = 12, height = 4.3, dpi = 600)
grDevices::pdf(file.path(output_dir, "08_PGI_SMF_stage_specific_diagnostics.pdf"), width = 10, height = 8)
graphics::par(mfrow = c(2, 2))
for (stage_name in period_levels) {
  fit_object <- stage_assoc_fits[[stage_name]]$model
  graphics::plot(stats::fitted(fit_object), stats::residuals(fit_object), xlab = "Fitted values", ylab = "Residuals", main = paste0(stage_name, ": residuals vs fitted"))
  graphics::abline(h = 0, lty = 2)
}
grDevices::dev.off()
cat("\n================ SMF LMM ================\n")
print(smf_anova |> dplyr::filter(Effect %in% c("Genotype", "Drought", "Period", "Drought:Period")))
cat("\n========== Stage-specific PGI-SMF association ==========\n")
print(assoc_results |> dplyr::select(Period, N, Estimate_std, Partial_r, NumDF, DenDF, F_value, P_value, P_FDR, DDF_method, Singular_fit))
capture.output(utils::sessionInfo(), file = file.path(output_dir, "09_sessionInfo.txt"))
message("Analysis completed. Results saved in: ", normalizePath(output_dir))
