rm(list = ls())
options(stringsAsFactors = FALSE)
options(contrasts = c("contr.sum", "contr.poly"))
library(tidyverse)
library(lme4)
library(lmerTest)
library(emmeans)
library(multcomp)
library(multcompView)
library(performance)
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/PGI")
input_file <- "PGI_splitplot_repeated_data.csv"
output_dir <- "PGI_splitplot_LMM_results"
dir.create(output_dir, showWarnings = FALSE)
period_levels <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
genotype_levels <- c("Jinza 22", "Liangnuo 01")
required_cols <- c("Sample", "PlotID", "Block", "MainPlotID", "Genotype", "Period", "Drought", "Plant_height", "Leaf_area")
dat <- read.csv(input_file, check.names = FALSE, fileEncoding = "UTF-8")
missing_cols <- setdiff(required_cols, names(dat))
if (length(missing_cols) > 0L) {
  stop("Missing columns: ", paste(missing_cols, collapse = ", "))
}
dat <- dat %>% mutate(Row_order = seq_len(n()), Sample = factor(Sample, levels = unique(Sample)), PlotID = factor(PlotID, levels = unique(PlotID)), MainPlotID = factor(
  MainPlotID, levels = unique(MainPlotID)), Block = factor(Block, levels = 1:4), Genotype = factor(Genotype, levels = genotype_levels), Period = factor(Period, levels =
  period_levels), Drought = factor(Drought, levels = drought_levels), Plant_height = as.numeric(Plant_height), Leaf_area = as.numeric(Leaf_area))
if (nrow(dat) != 128L || dplyr::n_distinct(dat$Sample) != 128L) {
  stop("Expected 128 unique samples.")
}
if (anyNA(dat[, required_cols])) {
  stop("Required analysis columns contain missing or unmatched values.")
}
cell_check <- dat %>% count(Block, Drought, Genotype, Period, name = "n")
if (nrow(cell_check) != 128L || any(cell_check$n != 1L)) {
  stop("Each Block x Drought x Genotype x Period cell must contain one sample.")
}
mainplot_check <- dat %>% count(MainPlotID, name = "n")
if (nrow(mainplot_check) != 16L || any(mainplot_check$n != 8L)) {
  stop("Expected 16 drought main plots with eight observations per main plot.")
}
plot_check <- dat %>% count(PlotID, name = "n")
if (nrow(plot_check) != 32L || any(plot_check$n != 4L)) {
  stop("Expected 32 genotype subplots with four observations per subplot.")
}
plot_mapping_check <- dat %>% group_by(PlotID) %>% summarise(n_Block = n_distinct(Block), n_MainPlotID = n_distinct(MainPlotID), n_Drought = n_distinct(Drought),
  n_Genotype = n_distinct(Genotype), .groups = "drop")
if (any(as.matrix(plot_mapping_check[, - 1]) != 1L)) {
  stop("At least one PlotID maps to multiple design levels.")
}
design_summary <- bind_rows(tibble(Level = "Drought main plot", Number = n_distinct(dat$MainPlotID), Observations_per_unit = 8L), tibble(Level = "Genotype subplot",
  Number = n_distinct(dat$PlotID), Observations_per_unit = 4L), tibble(Level = "Sample", Number = n_distinct(dat$Sample), Observations_per_unit = 1L))
write.csv(design_summary, file.path(output_dir, "00_design_check.csv"), row.names = FALSE)
trait_cols <- c("Plant_height", "Leaf_area")
bad_traits <- trait_cols[vapply(dat[trait_cols], function (x) any(!is.finite(x)) || stats::sd(x) == 0, logical(1))]
if (length(bad_traits) > 0L) {
  stop("Invalid or zero-variance trait columns: ", paste(bad_traits, collapse = ", "))
}
trait_z <- scale(as.matrix(dat[, trait_cols]))
dat$Plant_height_Z <- trait_z[, "Plant_height"]
dat$Leaf_area_Z <- trait_z[, "Leaf_area"]
dat$PGI_meanZ <- rowMeans(trait_z)
write.csv(dat %>% arrange(Row_order) %>% mutate(across(c(Sample, PlotID, MainPlotID), as.character)) %>% dplyr::select(Sample, PlotID, Block, MainPlotID, Genotype, Period
  , Drought, Plant_height, Leaf_area, Plant_height_Z, Leaf_area_Z, PGI_meanZ), file.path(output_dir, "01_PGI_calculated_values.csv"), row.names = FALSE)
lmm_control <- lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000))
fit_pgi <- lmerTest::lmer(PGI_meanZ ~ Block + Drought * Period + Genotype + (1 | MainPlotID) + (1 | PlotID), data = dat, REML = TRUE, control = lmm_control)
anova_lmm <- function (model) {
  kr <- tryCatch(stats::anova(model, type = 3, ddf = "Kenward-Roger"), error = function (e) NULL)
  if (!is.null(kr)) {
    return(list(table = kr, method = "Kenward-Roger"))
  }
  list(table = stats::anova(model, type = 3, ddf = "Satterthwaite"), method = "Satterthwaite")
}
tidy_lmm_anova <- function (result) {
  out <- as.data.frame(result$table)
  out$Effect <- rownames(out)
  rownames(out) <- NULL
  out %>% dplyr::relocate(Effect) %>% mutate(DDF_method = result$method, partial_eta2 = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF))
}
pgi_anova_result <- anova_lmm(fit_pgi)
pgi_anova <- tidy_lmm_anova(pgi_anova_result)
write.csv(pgi_anova, file.path(output_dir, "02_PGI_LMM_type3_ANOVA.csv"), row.names = FALSE)
capture.output(summary(fit_pgi), file = file.path(output_dir, "03_PGI_LMM_summary.txt"))
write.csv(as.data.frame(VarCorr(fit_pgi)), file.path(output_dir, "04_PGI_random_variance.csv"), row.names = FALSE)
pgi_emm <- emmeans(fit_pgi, ~ Drought | Period, weights = "equal")
pgi_emm_df <- as.data.frame(pgi_emm)
pgi_pairs_df <- as.data.frame(pairs(pgi_emm, adjust = "tukey"))
pgi_letters_df <- multcomp::cld(pgi_emm, adjust = "tukey", Letters = letters, sort = FALSE) %>% as.data.frame() %>% transmute(Period = factor(Period, levels =
  period_levels), Drought = factor(Drought, levels = drought_levels), .group = stringr::str_trim(.group))
write.csv(pgi_emm_df, file.path(output_dir, "05_PGI_adjusted_means.csv"), row.names = FALSE)
write.csv(pgi_pairs_df, file.path(output_dir, "06_PGI_drought_Tukey_within_stage.csv"), row.names = FALSE)
write.csv(pgi_letters_df, file.path(output_dir, "07_PGI_drought_letters.csv"), row.names = FALSE)
convergence_message <- function (model) {
  msg <- model@optinfo$conv$lme4$messages
  if (is.null(msg)) "None" else paste(msg, collapse = "; ")
}
full_singular <- isSingular(fit_pgi, tol = 1e-5)
model_check <- tibble(Model = "Primary full split-plot repeated-measures model", Singular_fit = full_singular, Convergence_message = convergence_message(fit_pgi))
write.csv(model_check, file.path(output_dir, "08_model_check.csv"), row.names = FALSE)
if (full_singular) {
  fit_pgi_reduced <- lmerTest::lmer(PGI_meanZ ~ Block + Drought * Period + Genotype + (1 | PlotID), data = dat, REML = TRUE, control = lmm_control)
  reduced_anova <- tidy_lmm_anova(anova_lmm(fit_pgi_reduced))
  write.csv(reduced_anova, file.path(output_dir, "09_PGI_reduced_model_sensitivity_ANOVA.csv"), row.names = FALSE)
  capture.output(summary(fit_pgi_reduced), file = file.path(output_dir, "09_PGI_reduced_model_summary.txt"))
}
safe_number <- function (x) {
  value <- suppressWarnings(as.numeric(x)[1])
  if (is.null(x) || length(x) == 0L || !is.finite(value)) {
    return(NA_real_)
  }
  value
}
extract_performance_metric <- function (object, candidate_names, allow_unnamed_single = FALSE) {
  if (is.null(object) || length(object) == 0L) {
    return(NA_real_)
  }
  object_names <- names(object)
  if (is.null(object_names) && (is.data.frame(object) || is.matrix(object))) {
    object_names <- colnames(object)
  }
  if (!is.null(object_names)) {
    matched_name <- candidate_names[candidate_names %in% object_names][1]
    if (!is.na(matched_name)) {
      if (is.data.frame(object) || is.matrix(object)) {
        return(safe_number(object[, matched_name]))
      }
      return(safe_number(object[[matched_name]]))
    }
  }
  if (allow_unnamed_single && is.atomic(object) && length(object) == 1L) {
    return(safe_number(object))
  }
  NA_real_
}
r2_result <- tryCatch(suppressWarnings(performance::r2_nakagawa(fit_pgi, tolerance = 1e-8)), error = function (e) NULL)
icc_result <- tryCatch(suppressWarnings(performance::icc(fit_pgi, tolerance = 1e-8)), error = function (e) NULL)
R2_marginal <- extract_performance_metric(r2_result, candidate_names = c("R2_marginal", "R2 Marginal", "Marginal R2"), allow_unnamed_single = TRUE)
R2_conditional <- extract_performance_metric(r2_result, candidate_names = c("R2_conditional", "R2 Conditional", "Conditional R2"))
ICC_adjusted <- extract_performance_metric(icc_result, candidate_names = c("ICC_adjusted", "ICC adjusted", "Adjusted ICC"), allow_unnamed_single = TRUE)
if (full_singular && (is.na(R2_conditional) || is.na(ICC_adjusted))) {
  message("The full model is singular; conditional R2 and/or ICC could not be ", "estimated and will be reported as NA. Fixed-effect tests and the ",
    "primary figure remain available.")
}
variance_table <- as.data.frame(VarCorr(fit_pgi))
get_variance <- function (group_name) {
  value <- variance_table$vcov[variance_table$grp == group_name]
  if (length(value) == 0L) NA_real_ else value[1]
}
variance_r2_table <- tibble(Metric = c("MainPlotID_variance", "PlotID_variance", "Residual_variance", "ICC_adjusted", "R2_marginal", "R2_conditional"), Value = c(
  get_variance("MainPlotID"), get_variance("PlotID"), get_variance("Residual"), ICC_adjusted, R2_marginal, R2_conditional))
write.csv(variance_r2_table, file.path(output_dir, "10_PGI_variance_R2_ICC.csv"), row.names = FALSE)
pdf(file.path(output_dir, "11_PGI_LMM_diagnostics.pdf"), width = 8, height = 7)
par(mfrow = c(2, 2))
plot(fitted(fit_pgi), residuals(fit_pgi), xlab = "Fitted values", ylab = "Residuals", main = "Residuals vs fitted")
abline(h = 0, lty = 2)
qqnorm(residuals(fit_pgi), main = "Normal Q-Q")
qqline(residuals(fit_pgi), col = "red")
hist(residuals(fit_pgi), main = "Residual distribution", xlab = "Residual")
boxplot(residuals(fit_pgi) ~ dat$Period, xlab = "Growth stage", ylab = "Residual", main = "Residuals by stage", las = 2)
dev.off()
capture.output(shapiro.test(residuals(fit_pgi)), file = file.path(output_dir, "12_PGI_residual_Shapiro_test.txt"))
fmt_p <- function (p) {
  if (is.na(p)) return("NA")
  if (p < 0.001) "< 0.001" else paste0("= ", sprintf("%.3f", p))
}
anova_line <- function (tab, effect, label) {
  z <- tab %>% dplyr::filter(Effect == effect)
  if (nrow(z) != 1L) return(paste0(label, ": unavailable"))
  paste0(label, ": F(", sprintf("%.0f", z$NumDF), ", ", sprintf("%.1f", z$DenDF), ") = ", sprintf("%.2f", z$`F value`), ", P ", fmt_p(z$`Pr(>F)`), ", partial eta2 = ",
    sprintf("%.3f", z$partial_eta2))
}
format_optional <- function (x, digits = 3) {
  if (is.na(x)) "NA" else sprintf(paste0("%.", digits, "f"), x)
}
label_text <- paste(anova_line(pgi_anova, "Genotype", "Genotype"), anova_line(pgi_anova, "Drought", "Drought"), anova_line(pgi_anova, "Period", "Stage"), anova_line(
  pgi_anova, "Drought:Period", "Drought x stage"), paste0("R2m = ", format_optional(R2_marginal), ", R2c = ", format_optional(R2_conditional), ", ICC = ", format_optional
  (ICC_adjusted)), sep = "\n")
plot_df <- pgi_emm_df %>% mutate(Period = factor(Period, levels = period_levels), Drought = factor(Drought, levels = drought_levels)) %>% left_join(pgi_letters_df, by = c
  ("Period", "Drought"))
y_max <- max(plot_df$upper.CL, na.rm = TRUE)
y_min <- min(plot_df$lower.CL, na.rm = TRUE)
y_range <- y_max - y_min
if (!is.finite(y_range) || y_range == 0) y_range <- 1
p_pgi <- ggplot(plot_df, aes(x = Period, y = emmean, group = Drought, color = Drought)) + geom_ribbon(aes(ymin = lower.CL, ymax = upper.CL, fill = Drought), alpha = 0.18,
  color = NA) + geom_line(linewidth = 1) + geom_point(size = 3) + geom_text(aes(y = upper.CL + 0.04 * y_range, label = .group), size = 4, show.legend = FALSE) + annotate(
  "text", x = 1.03, y = y_max + 0.39 * y_range, label = label_text, hjust = 0, vjust = 1, size = 3.7, color = "black") + coord_cartesian(ylim = c(y_min, y_max + 0.47 *
  y_range), clip = "off") + theme_bw() + labs(x = "Growth period", y = "Plant growth index (estimated mean Z)", title =
  "Dynamic changes of PGI under drought across growth stages", subtitle = paste0("Split-plot repeated-measures LMM; genotype controlled as a fixed effect; ",
  "ribbons = 95% CI; letters = Tukey groups")) + theme(axis.text.x = element_text(angle = 20, hjust = 1), panel.grid = element_blank(), plot.margin = margin(10, 40, 10,
  10))
print(p_pgi)
ggsave(file.path(output_dir, "Fig_PGI_dynamic_curve_splitplot_LMM.pdf"), plot = p_pgi, width = 12, height = 6.8)
ggsave(file.path(output_dir, "Fig_PGI_dynamic_curve_splitplot_LMM.png"), plot = p_pgi, width = 12, height = 6.8, dpi = 600)
capture.output(sessionInfo(), file = file.path(output_dir, "13_sessionInfo.txt"))
message("Analysis completed. Results saved in: ", output_dir)
