rm(list = ls())
options(stringsAsFactors = FALSE, contrasts = c("contr.sum", "contr.poly"))
set.seed(1234)
work_dir <- paste0("D:/IUE/山西数据/真菌/抽平/测试数据文件/", "splitplot-SMF-Fungi/群落演替")
if (!dir.exists(work_dir)) {
  stop("Working directory does not exist:\n", work_dir, "\nPlease change only `work_dir` at the top of the script.")
}
setwd(work_dir)
asv_file <- "根际_ASV_FungalTraits_with_abundance.csv"
group_file <- "根际分组.csv"
output_dir <- file.path(work_dir, "Figure3B_Rhizosphere_Jaccard_results")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
required_packages <- c("vegan", "betapart", "permute", "dplyr", "tidyr", "ggplot2", "lme4", "lmerTest", "emmeans")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(vegan)
  library(betapart)
  library(permute)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(lme4)
  library(lmerTest)
  library(emmeans)
})
stage_levels <- c("JS", "HS", "FS", "MS")
transition_levels <- c("JS-HS", "HS-FS", "FS-MS")
transition_labels <- c("JS-HS" = "Jointing\n\u2192 Heading", "HS-FS" = "Heading\n\u2192 Filling", "FS-MS" = "Filling\n\u2192 Maturity")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
genotype_levels <- c("Jinza 22", "Liangnuo 01")
component_colors <- c(Turnover = "#3787B5", Nestedness = "#E5E7EB")
nperm <- 9999L
clean_text <- function (x) {
  trimws(gsub(" ", " ", as.character(x), fixed = TRUE))
}
format_p_text <- function (p) {
  if (!is.finite(p)) return("P = NA")
  if (p < 0.001) return("P < 0.001")
  paste0("P = ", sprintf("%.3f", p))
}
parse_sample_design <- function (sample_id) {
  x <- toupper(gsub("[^A-Za-z0-9]", "", clean_text(sample_id)))
  genotype_code <- substr(x, 1, 1)
  stage_code <- substr(x, 2, 2)
  drought_code <- substr(x, 4, 4)
  block_code <- substr(x, nchar(x), nchar(x))
  data.frame(Genotype = dplyr::recode(genotype_code, Z = "Jinza 22", N = "Liangnuo 01", .default = NA_character_), Stage_from_sample = dplyr::recode(stage_code, `1` =
    "JS", `2` = "HS", `3` = "FS", `4` = "MS", .default = NA_character_), Drought = dplyr::recode(drought_code, A = "Control", B = "Drought_L", C = "Drought_M", D =
    "Drought_H", .default = NA_character_), Block = block_code, MainPlotID = paste(block_code, drought_code, sep = "_"), PlotID = paste(block_code, drought_code,
    genotype_code, sep = "_"), stringsAsFactors = FALSE)
}
make_stage_permutations <- function (plot_id, nperm = 9999L) {
  permutation_control <- permute::how(nperm = nperm)
  setBlocks(permutation_control) <- factor(plot_id)
  permutation_control
}
extract_anova_table <- function (model, metric) {
  anova_result <- tryCatch(list(table = stats::anova(model, type = 3, ddf = "Kenward-Roger"), method = "Kenward-Roger"), error = function (e) {
    list(table = stats::anova(model, type = 3, ddf = "Satterthwaite"), method = "Satterthwaite")
  })
  out <- as.data.frame(anova_result$table)
  out$Effect <- rownames(out)
  rownames(out) <- NULL
  out %>% dplyr::transmute(Metric = metric, Effect, NumDF = as.numeric(NumDF), DenDF = as.numeric(DenDF), F_value = as.numeric(`F value`), P_value = as.numeric(`Pr(>F)`),
    DDF_method = anova_result$method)
}
if (!file.exists(asv_file)) stop("Input file was not found: ", asv_file)
if (!file.exists(group_file)) stop("Input file was not found: ", group_file)
asv_tab <- read.csv(asv_file, header = TRUE, check.names = FALSE, fileEncoding = "UTF-8-BOM")
group_tab <- read.csv(group_file, header = TRUE, check.names = FALSE, fileEncoding = "UTF-8-BOM")
if (ncol(group_tab) < 2L) {
  stop(group_file, " must contain at least Sample and Group columns.")
}
names(group_tab)[1:2] <- c("Sample", "Group")
group_tab$Sample <- clean_text(group_tab$Sample)
group_tab$Group <- clean_text(group_tab$Group)
if (anyDuplicated(group_tab$Sample)) {
  stop(group_file, " contains duplicated sample IDs.")
}
parsed_design <- dplyr::bind_rows(lapply(group_tab$Sample, parse_sample_design))
stage_from_group <- toupper(sub("_.*$", "", group_tab$Group))
stage_from_group[!stage_from_group %in% stage_levels] <- NA_character_
group_tab <- dplyr::bind_cols(group_tab, parsed_design) %>% dplyr::mutate(Stage = dplyr::coalesce(stage_from_group, Stage_from_sample))
design_columns <- c("Genotype", "Stage", "Drought", "Block")
bad_design <- !stats::complete.cases(group_tab[, design_columns])
if (any(bad_design)) {
  stop("Design information could not be derived for: ", paste(group_tab$Sample[bad_design], collapse = ", "))
}
stage_disagreement <- !is.na(stage_from_group) & stage_from_group != group_tab$Stage_from_sample
if (any(stage_disagreement)) {
  stop("Sample IDs and Group labels disagree about Stage for: ", paste(group_tab$Sample[stage_disagreement], collapse = ", "))
}
group_tab <- group_tab %>% dplyr::mutate(Stage = factor(Stage, levels = stage_levels), Drought = factor(Drought, levels = drought_levels), Genotype = factor(Genotype,
  levels = genotype_levels), Block = factor(Block, levels = as.character(1:4)), MainPlotID = factor(MainPlotID), PlotID = factor(PlotID))
annotation_columns <- c("ASV", "Domain", "Phylum", "Class", "Order", "Family", "Genus", "Species", "Genus.join", "primary", "secondary")
candidate_sample_columns <- setdiff(names(asv_tab), annotation_columns)
sample_columns <- intersect(group_tab$Sample, candidate_sample_columns)
missing_samples <- setdiff(group_tab$Sample, sample_columns)
if (length(missing_samples) > 0L) {
  stop(asv_file, " is missing samples listed in ", group_file, ": ", paste(missing_samples, collapse = ", "))
}
group_tab <- group_tab[match(sample_columns, group_tab$Sample),, drop = FALSE]
abundance <- asv_tab[, sample_columns, drop = FALSE]
abundance[] <- lapply(abundance, function (x) suppressWarnings(as.numeric(as.character(x))))
abundance_matrix <- t(as.matrix(abundance))
rownames(abundance_matrix) <- sample_columns
if (any(!is.finite(abundance_matrix))) {
  stop(asv_file, " contains missing or non-numeric abundance values.")
}
if (any(abundance_matrix < 0)) {
  stop(asv_file, " contains negative abundance values.")
}
if (any(rowSums(abundance_matrix) <= 0)) {
  stop("The rhizosphere table contains one or more zero-sum samples.")
}
if (!identical(rownames(abundance_matrix), group_tab$Sample)) {
  stop("Abundance and metadata orders do not match.")
}
cell_check <- group_tab %>% dplyr::count(PlotID, Stage, name = "n")
if (nrow(cell_check) != 128L || any(cell_check$n != 1L)) {
  print(cell_check)
  stop("Every PlotID x Stage cell must occur exactly once (expected 128).")
}
plot_check <- group_tab %>% dplyr::count(PlotID, name = "n")
if (nrow(plot_check) != 32L || any(plot_check$n != 4L)) {
  print(plot_check)
  stop("Expected 32 PlotIDs, each containing all four stages.")
}
relative_abundance <- vegan::decostand(abundance_matrix, method = "total")
presence_absence <- 1L * (abundance_matrix > 0)
distance_objects <- list(Bray_Curtis = vegan::vegdist(relative_abundance, method = "bray"))
jaccard_parts <- betapart::beta.pair(presence_absence, index.family = "jaccard")
distance_objects$Jaccard_total <- jaccard_parts$beta.jac
distance_objects$Turnover <- jaccard_parts$beta.jtu
distance_objects$Nestedness <- jaccard_parts$beta.jne
decomposition_max_error <- max(abs(as.matrix(distance_objects$Jaccard_total) - as.matrix(distance_objects$Turnover) - as.matrix(distance_objects$Nestedness)), na.rm =
  TRUE)
if (!is.finite(decomposition_max_error) || decomposition_max_error > 1e-10) {
  stop("Jaccard identity beta.jac = beta.jtu + beta.jne failed; max error = ", decomposition_max_error)
}
stage_permutations <- make_stage_permutations(group_tab$PlotID, nperm)
stage_stats <- dplyr::bind_rows(lapply(names(distance_objects), function (metric) {
  distance_object <- distance_objects[[metric]]
  permanova <- vegan::adonis2(distance_object ~ Stage, data = group_tab, permutations = stage_permutations)
  dispersion <- vegan::betadisper(distance_object, group = group_tab$Stage, type = "median", bias.adjust = TRUE, add = "lingoes")
  dispersion_test <- vegan::permutest(dispersion, permutations = stage_permutations)
  data.frame(Metric = metric, N = nrow(group_tab), PERMANOVA_Df = as.numeric(permanova$Df[1]), PERMANOVA_F = as.numeric(permanova$F[1]), PERMANOVA_R2 = as.numeric(
    permanova$R2[1]), PERMANOVA_P = as.numeric(permanova$`Pr(>F)`[1]), Betadisper_F = as.numeric(dispersion_test$tab[1, "F"]), Betadisper_P = as.numeric(dispersion_test$
    tab[1, "Pr(>F)"]), stringsAsFactors = FALSE)
})) %>% dplyr::mutate(PERMANOVA_FDR = stats::p.adjust(PERMANOVA_P, method = "BH"), Betadisper_FDR = stats::p.adjust(Betadisper_P, method = "BH"))
distance_matrices <- lapply(distance_objects, as.matrix)
transition_definition <- data.frame(FromStage = c("JS", "HS", "FS"), ToStage = c("HS", "FS", "MS"), Transition = transition_levels, stringsAsFactors = FALSE)
transition_rows <- vector("list", length = 32L * 3L)
row_counter <- 0L
for (plot_id in levels(droplevels(group_tab$PlotID))) {
  one_plot <- group_tab[group_tab$PlotID == plot_id,, drop = FALSE]
  for (k in seq_len(nrow(transition_definition))) {
    from_stage <- transition_definition$FromStage[k]
    to_stage <- transition_definition$ToStage[k]
    from_sample <- one_plot$Sample[as.character(one_plot$Stage) == from_stage]
    to_sample <- one_plot$Sample[as.character(one_plot$Stage) == to_stage]
    if (length(from_sample) != 1L || length(to_sample) != 1L) {
      stop("PlotID ", plot_id, " does not contain exactly one ", from_stage, " and one ", to_stage, " sample.")
    }
    first_row <- one_plot[1,, drop = FALSE]
    row_counter <- row_counter + 1L
    transition_rows[[row_counter]] <- data.frame(PlotID = as.character(first_row$PlotID), MainPlotID = as.character(first_row$MainPlotID), Block = as.character(first_row$
      Block), Drought = as.character(first_row$Drought), Genotype = as.character(first_row$Genotype), FromStage = from_stage, ToStage = to_stage, Transition =
      transition_definition$Transition[k], Bray_Curtis = distance_matrices$Bray_Curtis[from_sample, to_sample], Jaccard_total = distance_matrices$Jaccard_total[
      from_sample, to_sample], Turnover = distance_matrices$Turnover[from_sample, to_sample], Nestedness = distance_matrices$Nestedness[from_sample, to_sample],
      stringsAsFactors = FALSE)
  }
}
transition_data <- dplyr::bind_rows(transition_rows) %>% dplyr::mutate(Block = factor(Block, levels = as.character(1:4)), Drought = factor(Drought, levels =
  drought_levels), Genotype = factor(Genotype, levels = genotype_levels), MainPlotID = factor(MainPlotID), PlotID = factor(PlotID), Transition = factor(Transition, levels
  = transition_levels), Turnover_fraction = dplyr::if_else(Jaccard_total > 0, Turnover / Jaccard_total, NA_real_), Nestedness_fraction = dplyr::if_else(Jaccard_total > 0,
  Nestedness / Jaccard_total, NA_real_))
transition_identity_error <- max(abs(transition_data$Jaccard_total - transition_data$Turnover - transition_data$Nestedness), na.rm = TRUE)
if (!is.finite(transition_identity_error) || transition_identity_error > 1e-10) {
  stop("Consecutive-transition Jaccard decomposition check failed.")
}
mainplot_transition_data <- transition_data %>% dplyr::group_by(MainPlotID, Block, Drought, Transition) %>% dplyr::summarise(dplyr::across(c(Bray_Curtis, Jaccard_total,
  Turnover, Nestedness, Turnover_fraction, Nestedness_fraction), ~ mean(.x, na.rm = TRUE)), .groups = "drop")
transition_summary <- mainplot_transition_data %>% tidyr::pivot_longer(cols = c(Bray_Curtis, Jaccard_total, Turnover, Nestedness, Turnover_fraction, Nestedness_fraction),
  names_to = "Metric", values_to = "Value") %>% dplyr::group_by(Transition, Metric) %>% dplyr::summarise(n = sum(is.finite(Value)), Mean = mean(Value, na.rm = TRUE), SD =
  stats::sd(Value, na.rm = TRUE), SE = SD / sqrt(n), Lower_95CI = Mean - stats::qt(0.975, pmax(n - 1, 1)) * SE, Upper_95CI = Mean + stats::qt(0.975, pmax(n - 1, 1)) * SE,
  .groups = "drop")
component_summary <- mainplot_transition_data %>% tidyr::pivot_longer(cols = c(Turnover, Nestedness), names_to = "Component", values_to = "Value") %>% dplyr::group_by(
  Transition, Component) %>% dplyr::summarise(n = sum(is.finite(Value)), Mean = mean(Value, na.rm = TRUE), SD = stats::sd(Value, na.rm = TRUE), SE = SD / sqrt(n), .groups
  = "drop") %>% dplyr::group_by(Transition) %>% dplyr::mutate(Total_mean = sum(Mean), Percentage = 100 * Mean / Total_mean) %>% dplyr::ungroup() %>% dplyr::mutate(
  Transition = factor(Transition, levels = transition_levels), Component = factor(Component, levels = c("Nestedness", "Turnover")))
total_jaccard_summary <- transition_summary %>% dplyr::filter(Metric == "Jaccard_total") %>% dplyr::mutate(Transition = factor(Transition, levels = transition_levels),
  Total_label = sprintf("%.2f", Mean))
turnover_labels <- component_summary %>% dplyr::filter(Component == "Turnover") %>% dplyr::mutate(Label = paste0(round(Percentage), "%"), Label_y = Mean / 2)
lmm_metrics <- c("Bray_Curtis", "Jaccard_total", "Turnover", "Nestedness", "Turnover_fraction")
model_list <- setNames(vector("list", length(lmm_metrics)), lmm_metrics)
anova_list <- setNames(vector("list", length(lmm_metrics)), lmm_metrics)
pairwise_list <- setNames(vector("list", length(lmm_metrics)), lmm_metrics)
model_check_list <- setNames(vector("list", length(lmm_metrics)), lmm_metrics)
for (metric in lmm_metrics) {
  model_data <- transition_data %>% dplyr::filter(is.finite(.data[[metric]])) %>% dplyr::mutate(Response = .data[[metric]])
  model <- lmerTest::lmer(Response ~ Block + Drought * Transition + Genotype + (1 | MainPlotID) + (1 | PlotID), data = model_data, REML = TRUE, control = lme4::
    lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 2e5)))
  model_list[[metric]] <- model
  anova_list[[metric]] <- extract_anova_table(model, metric)
  transition_emm <- tryCatch(emmeans::emmeans(model, ~ Transition, weights = "equal", lmer.df = "kenward-roger"), error = function (e) {
    emmeans::emmeans(model, ~ Transition, weights = "equal", lmer.df = "satterthwaite")
  })
  pairwise_list[[metric]] <- as.data.frame(emmeans::contrast(transition_emm, method = "pairwise", adjust = "tukey")) %>% dplyr::mutate(Metric = metric, .before = 1)
  variance_table <- as.data.frame(lme4::VarCorr(model))
  model_check_list[[metric]] <- data.frame(Metric = metric, N = stats::nobs(model), Singular_fit = lme4::isSingular(model, tol = 1e-5), MainPlot_variance = variance_table
    $vcov[match("MainPlotID", variance_table$grp)], Plot_variance = variance_table$vcov[match("PlotID", variance_table$grp)], Residual_variance = variance_table$vcov[
    match("Residual", variance_table$grp)], stringsAsFactors = FALSE)
}
transition_lmm_anova <- dplyr::bind_rows(anova_list) %>% dplyr::group_by(Effect) %>% dplyr::mutate(FDR_across_metrics = stats::p.adjust(P_value, method = "BH")) %>% dplyr::
  ungroup()
transition_pairwise <- dplyr::bind_rows(pairwise_list)
model_checks <- dplyr::bind_rows(model_check_list)
jaccard_transition_test <- transition_lmm_anova %>% dplyr::filter(Metric == "Jaccard_total", Effect == "Transition")
if (nrow(jaccard_transition_test) == 1L) {
  transition_test_label <- paste0("Transition: F(", sprintf("%.0f", jaccard_transition_test$NumDF), ", ", sprintf("%.1f", jaccard_transition_test$DenDF), ") = ", sprintf(
    "%.2f", jaccard_transition_test$F_value), ", ", format_p_text(jaccard_transition_test$P_value))
} else {
  transition_test_label <- ""
}
y_upper <- max(total_jaccard_summary$Upper_95CI, na.rm = TRUE) + 0.11
p_fig3b <- ggplot2::ggplot(component_summary, ggplot2::aes(x = Transition, y = Mean, fill = Component)) + ggplot2::geom_col(width = 0.62, colour = "black", linewidth =
  0.45) + ggplot2::geom_point(data = mainplot_transition_data, mapping = ggplot2::aes(x = Transition, y = Jaccard_total), inherit.aes = FALSE, position = ggplot2::
  position_jitter(width = 0.075, height = 0, seed = 1234), shape = 21, size = 1.55, stroke = 0.35, fill = "white", colour = "#25313B", alpha = 0.72) + ggplot2::
  geom_errorbar(data = total_jaccard_summary, mapping = ggplot2::aes(x = Transition, ymin = Lower_95CI, ymax = Upper_95CI), inherit.aes = FALSE, width = 0.13, linewidth =
  0.70, colour = "black") + ggplot2::geom_point(data = total_jaccard_summary, mapping = ggplot2::aes(x = Transition, y = Mean), inherit.aes = FALSE, shape = 23, size =
  2.8, stroke = 0.65, fill = "white", colour = "black") + ggplot2::geom_text(data = turnover_labels, mapping = ggplot2::aes(x = Transition, y = Label_y, label = Label),
  inherit.aes = FALSE, colour = "white", fontface = "bold", size = 4.0) + ggplot2::geom_text(data = total_jaccard_summary, mapping = ggplot2::aes(x = Transition, y =
  Upper_95CI + 0.022, label = Total_label), inherit.aes = FALSE, colour = "#1F2937", fontface = "bold", size = 3.4) + ggplot2::annotate("text", x = 1, y = y_upper - 0.005
  , label = transition_test_label, hjust = 0, vjust = 1, size = 3.25, colour = "black") + ggplot2::scale_fill_manual(values = component_colors, breaks = c("Turnover",
  "Nestedness"), labels = c(Turnover = "Taxon replacement", Nestedness = "Nestedness"), drop = FALSE) + ggplot2::scale_x_discrete(labels = transition_labels) + ggplot2::
  scale_y_continuous(limits = c(0, y_upper), breaks = scales::pretty_breaks(n = 5), expand = ggplot2::expansion(mult = c(0, 0))) + ggplot2::labs(tag = "B", x = NULL, y =
  "Binary Jaccard dissimilarity", fill = NULL, subtitle = "Rhizosphere succession was dominated by taxon replacement") + ggplot2::guides(fill = ggplot2::guide_legend(
  direction = "horizontal", title.position = "top", keywidth = grid::unit(0.55, "cm"), keyheight = grid::unit(0.34, "cm"))) + ggplot2::theme_classic(base_size = 11) +
  ggplot2::theme(plot.tag = ggplot2::element_text(face = "bold", size = 15, margin = ggplot2::margin(r = 5)), plot.tag.position = c(0.01, 0.99), plot.subtitle = ggplot2::
  element_text(face = "bold", size = 11, hjust = 0.5, margin = ggplot2::margin(b = 7)), axis.title.y = ggplot2::element_text(face = "bold", margin = ggplot2::margin(r = 7
  )), axis.text = ggplot2::element_text(colour = "black"), axis.text.x = ggplot2::element_text(size = 10, lineheight = 0.95, margin = ggplot2::margin(t = 6)), axis.line =
  ggplot2::element_line(linewidth = 0.55), axis.ticks = ggplot2::element_line(linewidth = 0.50), legend.position = "top", legend.justification = "center", legend.text =
  ggplot2::element_text(size = 10), legend.margin = ggplot2::margin(b = 2), plot.margin = ggplot2::margin(7, 9, 7, 8))
ggplot2::ggsave(filename = file.path(output_dir, "Fig3B_Rhizosphere_Jaccard_decomposition.pdf"), plot = p_fig3b, width = 4, height = 4.6, device = grDevices::cairo_pdf)
ggplot2::ggsave(filename = file.path(output_dir, "Fig3B_Rhizosphere_Jaccard_decomposition.png"), plot = p_fig3b, width = 4, height = 4.6, dpi = 600, bg = "white")
design_summary <- group_tab %>% dplyr::summarise(Habitat = "Rhizosphere", Samples = dplyr::n(), MainPlots = dplyr::n_distinct(MainPlotID), PlotIDs = dplyr::n_distinct(
  PlotID), Stages = dplyr::n_distinct(Stage))
write.csv(design_summary, file.path(output_dir, "00_design_summary.csv"), row.names = FALSE)
write.csv(data.frame(Full_distance_max_error = decomposition_max_error, Transition_max_error = transition_identity_error), file.path(output_dir,
  "01_Jaccard_identity_checks.csv"), row.names = FALSE)
write.csv(stage_stats, file.path(output_dir, "02_stage_PERMANOVA_and_betadisper.csv"), row.names = FALSE)
write.csv(transition_data, file.path(output_dir, "03_transition_distances_subplot_level.csv"), row.names = FALSE)
write.csv(mainplot_transition_data, file.path(output_dir, "04_transition_distances_mainplot_means.csv"), row.names = FALSE)
write.csv(transition_summary, file.path(output_dir, "05_transition_summary_mean_95CI.csv"), row.names = FALSE)
write.csv(component_summary, file.path(output_dir, "06_Fig3B_Jaccard_component_summary.csv"), row.names = FALSE)
write.csv(transition_lmm_anova, file.path(output_dir, "07_transition_splitplot_LMM_TypeIII.csv"), row.names = FALSE)
write.csv(transition_pairwise, file.path(output_dir, "08_transition_pairwise_emmeans_Tukey.csv"), row.names = FALSE)
write.csv(model_checks, file.path(output_dir, "09_model_checks.csv"), row.names = FALSE)
capture.output(sessionInfo(), file = file.path(output_dir, "10_sessionInfo.txt"))
cat("\n============================================================\n")
cat("Rhizosphere analysis completed.\n")
cat("Output directory:\n", normalizePath(output_dir), "\n", sep = "")
cat("\nFigure 3B shows:\n")
cat("- bar height: mean binary-Jaccard dissimilarity;\n")
cat("- blue/grey segments: replacement/nestedness components;\n")
cat("- open circles: 16 Block x Drought main-plot means;\n")
cat("- diamond and error bar: total mean and 95% CI;\n")
cat("- white percentage: replacement contribution.\n")
cat("============================================================\n\n")
print(p_fig3b)
print(stage_stats)
print(transition_lmm_anova %>% dplyr::filter(Effect %in% c("Drought", "Transition", "Drought:Transition")))
