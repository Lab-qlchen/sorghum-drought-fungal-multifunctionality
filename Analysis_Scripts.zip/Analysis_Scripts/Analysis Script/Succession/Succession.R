rm(list = ls())
options(stringsAsFactors = FALSE)
set.seed(1234)
wd <- "D:/IUE/山西数据/真菌/抽平/测试数据文件/26.8.28 fungi SMF/群落演替"
setwd(wd)
pkg_needed <- c("vegan", "permute")
pkg_new <- pkg_needed[!pkg_needed %in% rownames(installed.packages())]
if (length(pkg_new) > 0) {
  install.packages(pkg_new, repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
}
library(vegan)
library(permute)
stage_levels <- c("JS", "HS", "FS", "MS")
stage_num_map <- c(JS = 1, HS = 2, FS = 3, MS = 4)
drought_code_map <- c(A = "Control", B = "Drought_L", C = "Drought_M", D = "Drought_H")
genotype_code_map <- c(Z = "Jinza 22", N = "Liangnuo 01")
extract_design_from_sample <- function (sample_id) {
  sample_clean <- gsub("[^A-Za-z0-9]", "", as.character(sample_id))
  genotype_code <- substr(sample_clean, 1, 1)
  stage_code <- substr(sample_clean, 2, 2)
  compartment_code <- substr(sample_clean, 3, 3)
  drought_code <- substr(sample_clean, 4, 4)
  block_code <- substr(sample_clean, nchar(sample_clean), nchar(sample_clean))
  genotype <- unname(genotype_code_map[genotype_code])
  drought <- unname(drought_code_map[drought_code])
  stage_from_sample <- c("1" = "JS", "2" = "HS", "3" = "FS", "4" = "MS")[stage_code]
  MainPlotID <- paste("Block", block_code, drought_code, sep = "_")
  PlotID <- paste(genotype_code, drought_code, block_code, sep = "_")
  data.frame(Sample = sample_id, Genotype_code = genotype_code, Genotype = genotype, Stage_sample = unname(stage_from_sample), Compartment = compartment_code,
    Drought_code = drought_code, Drought = drought, Block = block_code, MainPlotID = MainPlotID, PlotID = PlotID, stringsAsFactors = FALSE)
}
analyze_one_habitat <- function (asv_file, group_file, habitat_name, nperm = 9999) {
  cat("\n")
  cat("============================================================\n")
  cat("Analysing:", habitat_name, "\n")
  cat("============================================================\n")
  asv_tab <- read.csv(asv_file, header = TRUE, check.names = FALSE, stringsAsFactors = FALSE)
  group_tab <- read.csv(group_file, header = TRUE, check.names = FALSE, stringsAsFactors = FALSE)
  if (ncol(group_tab) < 2) {
    stop(habitat_name, ": group file must contain at least two columns.")
  }
  colnames(group_tab)[1:2] <- c("Sample", "Group")
  if (anyDuplicated(group_tab$Sample)) {
    stop(habitat_name, ": duplicated Sample IDs were detected in the grouping file.")
  }
  group_split <- strsplit(as.character(group_tab$Group), "_")
  group_tab$Stage <- sapply(group_split, `[`, 1)
  group_tab$Stage <- factor(group_tab$Stage, levels = stage_levels)
  group_tab$Stage_num <- stage_num_map[as.character(group_tab$Stage)]
  design_info <- do.call(rbind, lapply(group_tab$Sample, extract_design_from_sample))
  group_tab$Genotype <- design_info$Genotype
  group_tab$Drought <- design_info$Drought
  group_tab$Block <- design_info$Block
  group_tab$MainPlotID <- design_info$MainPlotID
  group_tab$PlotID <- design_info$PlotID
  group_tab$Stage_sample <- design_info$Stage_sample
  if (any(is.na(group_tab$Stage_num))) {
    stop(habitat_name, ": failed to identify Stage from Group.")
  }
  if (any(is.na(group_tab$Genotype))) {
    stop(habitat_name, ": failed to identify genotype from Sample ID.")
  }
  if (any(is.na(group_tab$Drought))) {
    stop(habitat_name, ": failed to identify drought treatment from Sample ID.")
  }
  if (any(!group_tab$Block %in% c("1", "2", "3", "4"))) {
    stop(habitat_name, ": invalid Block code detected.")
  }
  stage_match <- (as.character(group_tab$Stage) == as.character(group_tab$Stage_sample))
  if (any(!stage_match)) {
    bad_samples <- group_tab$Sample[!stage_match]
    stop(habitat_name, ": Stage information from Sample ID and Group does not match. ", "Problematic samples: ", paste(bad_samples, collapse = ", "))
  }
  anno_cols <- c("ASV", "Domain", "Phylum", "Class", "Order", "Family", "Genus", "Species", "Genus.join", "primary", "secondary")
  sample_cols <- setdiff(colnames(asv_tab), anno_cols)
  sample_cols <- intersect(sample_cols, group_tab$Sample)
  if (length(sample_cols) == 0) {
    stop(habitat_name, ": no matching sample columns were found between ASV table and group file.")
  }
  group_tab <- group_tab[match(sample_cols, group_tab$Sample),, drop = FALSE]
  if (anyNA(group_tab$Sample)) {
    stop(habitat_name, ": sample matching failed.")
  }
  fung <- asv_tab[, sample_cols, drop = FALSE]
  fung[] <- lapply(fung, as.numeric)
  fung <- t(as.matrix(fung))
  rownames(fung) <- sample_cols
  if (any(is.na(fung))) {
    warning(habitat_name, ": NA values found in community matrix; replaced with 0.")
    fung[is.na(fung)] <- 0
  }
  keep <- (rowSums(fung) > 0 & !is.na(group_tab$Stage_num))
  fung <- fung[keep,, drop = FALSE]
  group_tab <- group_tab[keep,, drop = FALSE]
  if (nrow(fung) < 4) {
    stop(habitat_name, ": too few valid samples.")
  }
  plot_check <- table(group_tab$PlotID)
  cat("Number of samples:", nrow(group_tab), "\n")
  cat("Number of PlotIDs:", length(plot_check), "\n")
  cat("Observations per PlotID:\n")
  print(table(plot_check))
  if (any(plot_check != 4)) {
    warning(habitat_name, ": not every PlotID contains exactly four growth-stage observations. ", "The analysis will continue, but please check missing samples.")
  }
  stage_per_plot <- tapply(as.character(group_tab$Stage), group_tab$PlotID, function (x) length(unique(x)))
  if (any(stage_per_plot < 2)) {
    stop(habitat_name, ": at least one PlotID contains fewer than two growth stages.")
  }
  fung_hel <- vegan::decostand(fung, method = "hellinger")
  fung_dist <- vegan::vegdist(fung_hel, method = "bray")
  temporal_dist <- stats::dist(group_tab$Stage_num, method = "euclidean")
  permutation_design <- permute::how(nperm = nperm)
  permute::setBlocks(permutation_design) <- factor(group_tab$PlotID)
  ma <- vegan::mantel(xdis = fung_dist, ydis = temporal_dist, method = "pearson", permutations = permutation_design, na.rm = FALSE)
  R_value <- unname(ma$statistic)
  P_value <- ma$signif
  plot_df <- data.frame(Temporal_distance = as.vector(temporal_dist), Bray_Curtis = as.vector(fung_dist))
  design_output <- group_tab[, c("Sample", "Group", "Stage", "Stage_num", "Block", "Drought", "Genotype", "MainPlotID", "PlotID")]
  cat("\nRestricted-permutation Mantel test:\n")
  cat("Habitat =", habitat_name, "\n")
  cat("Mantel R =", round(R_value, 4), "\n")
  cat("P =", P_value, "\n")
  cat("Permutation unit = PlotID\n")
  cat("Requested permutations =", nperm, "\n")
  return(list(plot_df = plot_df, R = R_value, P = P_value, Habitat = habitat_name, design = design_output, mantel_object = ma))
}
res_leaf <- analyze_one_habitat(asv_file = "叶际_ASV_FungalTraits_with_abundance.csv", group_file = "叶际分组.csv", habitat_name = "Phyllosphere", nperm = 9999)
res_endo <- analyze_one_habitat(asv_file = "根内_ASV_FungalTraits_with_abundance.csv", group_file = "根内分组.csv", habitat_name = "Endosphere", nperm = 9999)
res_rhizo <- analyze_one_habitat(asv_file = "根际_ASV_FungalTraits_with_abundance.csv", group_file = "根际分组.csv", habitat_name = "Rhizosphere", nperm = 9999)
mantel_res <- data.frame(Habitat = c("Phyllosphere", "Endosphere", "Rhizosphere"), Mantel_R = c(res_leaf$R, res_endo$R, res_rhizo$R), Mantel_P = c(res_leaf$P, res_endo$P,
  res_rhizo$P), Permutation = rep("Restricted within PlotID", 3), Requested_permutations = rep(9999, 3))
write.csv(mantel_res, "Figure3A_Mantel_results_restricted.csv", row.names = FALSE)
write.csv(res_leaf$design, "Figure3A_Phyllosphere_design_check.csv", row.names = FALSE)
write.csv(res_endo$design, "Figure3A_Endosphere_design_check.csv", row.names = FALSE)
write.csv(res_rhizo$design, "Figure3A_Rhizosphere_design_check.csv", row.names = FALSE)
draw_panel <- function (res_obj) {
  plot(jitter(res_obj$plot_df$Temporal_distance, amount = 0.08), res_obj$plot_df$Bray_Curtis, xlab = "Temporal distance (stage)", ylab = "Bray-Curtis dissimilarity", xlim
    = c(- 0.1, 3.1), ylim = c(0, 1), pch = 16, cex = 0.55, col = rgb(0, 0, 0, alpha = 0.18))
  lines(lowess(res_obj$plot_df$Temporal_distance, res_obj$plot_df$Bray_Curtis), col = "red", lwd = 4)
  text(1.5, 0.92, res_obj$Habitat, col = "#e64b35", cex = 1.5, font = 2)
  p_label <- if (res_obj$P < 0.001) {
    "P < 0.001"
  } else {
    paste0("P = ", sprintf("%.3f", res_obj$P))
  }
  stat_label <- paste0("R = ", sprintf("%.3f", res_obj$R), ", ", p_label)
  text(1.5, 0.08, labels = stat_label, col = "#4dbbd5", cex = 1.2, font = 2)
  box()
}
par(mfrow = c(1, 3), mar = c(4, 4, 2, 1))
draw_panel(res_leaf)
draw_panel(res_endo)
draw_panel(res_rhizo)
pdf("Figure3A_TemporalDistance_Mantel_restricted.pdf", width = 12, height = 4)
par(mfrow = c(1, 3), mar = c(4, 4, 2, 1))
draw_panel(res_leaf)
draw_panel(res_endo)
draw_panel(res_rhizo)
dev.off()
png("Figure3A_TemporalDistance_Mantel_restricted.png", width = 12, height = 4, units = "in", res = 600)
par(mfrow = c(1, 3), mar = c(4, 4, 2, 1))
draw_panel(res_leaf)
draw_panel(res_endo)
draw_panel(res_rhizo)
dev.off()
print(mantel_res)
cat("\n============================================================\n")
cat("Analysis completed.\n")
cat("Experimental design: RCBD with a split-plot structure ", "and repeated measures.\n", sep = "")
cat("Mantel permutations were restricted within PlotID.\n")
cat("Generated files:\n")
cat("1. Figure3A_Mantel_results_restricted.csv\n")
cat("2. Figure3A_Phyllosphere_design_check.csv\n")
cat("3. Figure3A_Endosphere_design_check.csv\n")
cat("4. Figure3A_Rhizosphere_design_check.csv\n")
cat("5. Figure3A_TemporalDistance_Mantel_restricted.pdf\n")
cat("6. Figure3A_TemporalDistance_Mantel_restricted.png\n")
cat("============================================================\n")
