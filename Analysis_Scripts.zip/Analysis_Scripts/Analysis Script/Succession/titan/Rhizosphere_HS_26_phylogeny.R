rm(list = ls())
options(stringsAsFactors = FALSE)
options(contrasts = c("contr.sum", "contr.poly"))
required_packages <- c("ape", "phytools", "tidyverse", "ggtree", "ggtreeExtra", "ggnewscale", "cowplot", "lme4", "lmerTest", "emmeans", "multcomp")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(ape)
  library(phytools)
  library(tidyverse)
  library(ggtree)
  library(ggtreeExtra)
  library(ggnewscale)
  library(cowplot)
  library(lme4)
  library(lmerTest)
  library(emmeans)
  library(multcomp)
})
work_dir <- paste0("D:/IUE/山西数据/真菌/抽平/测试数据文件/", "splitplot-SMF-Fungi/titan/Rhizosphere_TITAN_results")
if (!dir.exists(work_dir)) {
  stop("Working directory does not exist:\n", work_dir, "\nPlease correct work_dir at the top of the script.")
}
setwd(work_dir)
asv_file <- "根际F_ASV.csv"
annotation_file <- "根际_ASV_FungalTraits_with_abundance.csv"
group_file <- "根际分组.csv"
tree_file <- "phylo.tre"
titan_file <- file.path("Rhizosphere_TITAN_results", "TITAN_R_SIG.csv")
if (!file.exists(titan_file) && file.exists("TITAN_R_SIG.csv")) {
  titan_file <- "TITAN_R_SIG.csv"
}
output_dir <- file.path(work_dir, "Rhizosphere_HS_zminus_phylogeny_results")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
hs_cp <- 2
cp_tolerance <- 1e-8
phylo_runs <- 9999
set.seed(20260901)
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
drought_labels <- c(Control = "Control", Drought_L = "Light", Drought_M = "Moderate", Drought_H = "Heavy")
drought_colors <- c(Control = "#E87D6D", Drought_L = "#8DB446", Drought_M = "#3DB4B8", Drought_H = "#AE83C5")
phylum_colors <- c(Ascomycota = "#4DAF4A", Basidiomycota = "#377EB8", Mortierellomycota = "#FF7F00", Chytridiomycota = "#984EA3", Rozellomycota = "#E41A1C", Glomeromycota
  = "#A65628", Other = "grey80")
primary_colors <- c(animal_parasite = "#72B285", dung_saprotroph = "#EB8B39", foliar_endophyte = "#B379B4", litter_saprotroph = "#DB6968", plant_pathogen = "#81B21F",
  soil_saprotroph = "#65A2D2", unspecified_saprotroph = "#BEBFB4", wood_saprotroph = "#2BAE9E", Unassigned = "white")
check_file <- function (path) {
  if (!file.exists(path)) {
    stop("Input file was not found:\n", normalizePath(path, mustWork = FALSE), "\nEdit the corresponding path in Section 1.")
  }
  path
}
find_col <- function (x, candidates, required = TRUE) {
  nms <- names(x)
  hit <- match(tolower(candidates), tolower(nms))
  hit <- hit[!is.na(hit)]
  if (length(hit) > 0L) {
    return(nms[hit[1]])
  }
  if (required) {
    stop("Required column not found. Candidates: ", paste(candidates, collapse = ", "), "\nAvailable columns: ", paste(nms, collapse = ", "))
  }
  NA_character_
}
clean_taxon <- function (x, prefix) {
  x <- trimws(gsub(prefix, "", as.character(x)))
  x[is.na(x) | x == ""] <- NA_character_
  x
}
read_asv_table <- function (path) {
  x <- readr::read_csv(check_file(path), show_col_types = FALSE, name_repair = "minimal")
  asv_col <- find_col(x, c("ASV", "OTU", "FeatureID", "#OTU ID"), required = FALSE)
  if (is.na(asv_col)) {
    first_values <- as.character(x[[1]])
    if (mean(grepl("^(ASV|OTU)", first_values), na.rm = TRUE) > 0.5) {
      names(x)[1] <- "ASV"
    } else {
      stop("The ASV identifier column could not be recognized in ", path)
    }
  } else {
    names(x)[names(x) == asv_col] <- "ASV"
  }
  phylum_col <- find_col(x, c("Phylum", "phylum", "p__phylum"), FALSE)
  family_col <- find_col(x, c("Family", "family", "f__family"), FALSE)
  if (!is.na(phylum_col) && phylum_col != "Phylum") {
    names(x)[names(x) == phylum_col] <- "Phylum"
  }
  if (!is.na(family_col) && family_col != "Family") {
    names(x)[names(x) == family_col] <- "Family"
  }
  if (!"Phylum" %in% names(x)) x$Phylum <- NA_character_
  if (!"Family" %in% names(x)) x$Family <- NA_character_
  x %>% dplyr::mutate(ASV = as.character(ASV), Phylum = clean_taxon(Phylum, "^p__"), Family = clean_taxon(Family, "^f__"), Phylum = dplyr::if_else(is.na(Phylum) | !Phylum
    %in% names(phylum_colors), "Other", Phylum), Family = dplyr::coalesce(Family, "Unclassified_family")) %>% dplyr::distinct(ASV, .keep_all = TRUE)
}
read_annotation <- function (path) {
  x <- readr::read_csv(check_file(path), show_col_types = FALSE, name_repair = "minimal")
  asv_col <- find_col(x, c("ASV", "OTU", "FeatureID", "#OTU ID"))
  primary_col <- find_col(x, c("Primary", "primary", "primary_group", "Primary2"), required = FALSE)
  out <- tibble::tibble(ASV = as.character(x[[asv_col]]))
  out$Primary_annotation <- if (is.na(primary_col)) {
    NA_character_
  } else {
    as.character(x[[primary_col]])
  }
  out %>% dplyr::mutate(Primary_annotation = trimws(Primary_annotation), Primary_annotation = dplyr::na_if(Primary_annotation, "")) %>% dplyr::distinct(ASV, .keep_all =
    TRUE)
}
read_group <- function (path, asv_names) {
  x <- readr::read_csv(check_file(path), show_col_types = FALSE, name_repair = "minimal")
  if (ncol(x) < 2L) {
    stop("The group file must contain at least Sample and Group columns.")
  }
  sample_col <- find_col(x, c("Sample", "sample", "SampleID"), FALSE)
  group_col <- find_col(x, c("Group", "group", "Treatment_group"), FALSE)
  if (is.na(sample_col)) sample_col <- names(x)[1]
  if (is.na(group_col)) group_col <- names(x)[2]
  out <- tibble::tibble(Sample = trimws(as.character(x[[sample_col]])), Group = trimws(as.character(x[[group_col]])))
  if (anyDuplicated(out$Sample)) {
    stop("Duplicated sample names were found in the group file.")
  }
  missing_samples <- setdiff(out$Sample, asv_names)
  if (length(missing_samples) > 0L) {
    stop("Samples in the group file but absent from the ASV table:\n", paste(missing_samples, collapse = ", "))
  }
  group_upper <- stringr::str_to_upper(out$Group)
  sample_upper <- stringr::str_to_upper(out$Sample)
  out <- out %>% dplyr::mutate(Period = dplyr::case_when(stringr::str_detect(group_upper, "JS") ~ "JS", stringr::str_detect(group_upper, "HS") ~ "HS", stringr::str_detect
    (group_upper, "FS") ~ "FS", stringr::str_detect(group_upper, "MS") ~ "MS", TRUE ~ NA_character_), Drought = dplyr::case_when(stringr::str_detect(group_upper,
    "DROUGHT_H") ~ "Drought_H", stringr::str_detect(group_upper, "DROUGHT_M") ~ "Drought_M", stringr::str_detect(group_upper, "DROUGHT_L") ~ "Drought_L", stringr::
    str_detect(group_upper, "CONTROL") ~ "Control", TRUE ~ NA_character_), Genotype = dplyr::case_when(stringr::str_sub(sample_upper, 1, 1) == "Z" ~ "Jinza 22", stringr::
    str_sub(sample_upper, 1, 1) == "N" ~ "Liangnuo 01", TRUE ~ NA_character_), Block = stringr::str_match(Sample, "([1-4])$")[, 2])
  if (anyNA(out[, c("Period", "Drought", "Genotype", "Block")])) {
    bad <- out %>% dplyr::filter(is.na(Period) | is.na(Drought) | is.na(Genotype) | is.na(Block))
    print(bad)
    stop("Period, Drought, Genotype or Block could not be derived.")
  }
  out %>% dplyr::mutate(Period = factor(Period, levels = c("JS", "HS", "FS", "MS")), Drought = factor(Drought, levels = drought_levels), Genotype = factor(Genotype,
    levels = c("Jinza 22", "Liangnuo 01")), Block = factor(Block, levels = as.character(1:4)), MainPlotID = interaction(Block, Drought, drop = TRUE, sep = "_"), PlotID =
    interaction(Block, Drought, Genotype, drop = TRUE, sep = "_"))
}
format_p <- function (p) {
  if (is.na(p)) return("NA")
  if (p < 0.001) return("< 0.001")
  paste0("= ", sprintf("%.3f", p))
}
extract_type3 <- function (model) {
  method <- "Kenward-Roger"
  ans <- tryCatch(stats::anova(model, type = 3, ddf = "Kenward-Roger"), error = function (e) {
    method <<- "Satterthwaite"
    stats::anova(model, type = 3, ddf = "Satterthwaite")
  })
  tab <- as.data.frame(ans)
  tab$Effect <- rownames(tab)
  rownames(tab) <- NULL
  tibble::tibble(Effect = tab$Effect, Sum_Sq = as.numeric(tab[["Sum Sq"]]), Mean_Sq = as.numeric(tab[["Mean Sq"]]), NumDF = as.numeric(tab[["NumDF"]]), DenDF = as.numeric
    (tab[["DenDF"]]), F_value = as.numeric(tab[["F value"]]), P_value = as.numeric(tab[["Pr(>F)"]]), DDF_method = method)
}
calc_mpd <- function (taxa, dist_mat) {
  taxa <- intersect(taxa, rownames(dist_mat))
  if (length(taxa) < 2L) return(NA_real_)
  d <- dist_mat[taxa, taxa, drop = FALSE]
  mean(d[upper.tri(d)], na.rm = TRUE)
}
calc_mntd <- function (taxa, dist_mat) {
  taxa <- intersect(taxa, rownames(dist_mat))
  if (length(taxa) < 2L) return(NA_real_)
  d <- dist_mat[taxa, taxa, drop = FALSE]
  diag(d) <- Inf
  mean(apply(d, 1, min, na.rm = TRUE), na.rm = TRUE)
}
ses_one <- function (observed, null_values) {
  null_values <- null_values[is.finite(null_values)]
  if (!is.finite(observed) || length(null_values) < 100L) {
    return(c(SES = NA_real_, P_two_sided = NA_real_))
  }
  null_mean <- mean(null_values)
  null_sd <- stats::sd(null_values)
  ses <- if (null_sd > 0)(observed - null_mean) / null_sd else NA_real_
  p_two <- (sum(abs(null_values - null_mean) >= abs(observed - null_mean)) + 1) / (length(null_values) + 1)
  c(SES = ses, P_two_sided = p_two)
}
asv <- read_asv_table(asv_file)
annotation <- read_annotation(annotation_file)
group <- read_group(group_file, names(asv))
tree_all <- ape::read.tree(check_file(tree_file))
if (is.null(tree_all$tip.label) || length(tree_all$tip.label) < 3L) {
  stop("The phylogenetic tree contains fewer than three labelled tips.")
}
if (nrow(group) != 128L) {
  stop("Expected 128 rhizosphere samples; found ", nrow(group), ".")
}
hs_group <- group %>% dplyr::filter(Period == "HS")
if (nrow(hs_group) != 32L || dplyr::n_distinct(hs_group$MainPlotID) != 16L || dplyr::n_distinct(hs_group$PlotID) != 32L) {
  stop("At HS, expected 32 subplot observations, 16 main plots and 32 PlotIDs.")
}
design_check <- hs_group %>% dplyr::count(Block, Drought, Genotype, name = "n")
if (nrow(design_check) != 32L || any(design_check$n != 1L)) {
  print(design_check)
  stop("Each HS Block x Drought x Genotype cell must occur exactly once.")
}
readr::write_csv(design_check, file.path(output_dir, "00_HS_splitplot_design_check.csv"))
titan_raw <- readr::read_csv(check_file(titan_file), show_col_types = FALSE, name_repair = "minimal")
titan_asv_col <- find_col(titan_raw, c("ASV", "OTU", "FeatureID"))
titan_cp_col <- find_col(titan_raw, c("zenv.cp"))
titan_filter_col <- find_col(titan_raw, c("filter"))
titan_habitat_col <- find_col(titan_raw, c("Habitat", "Niche"), FALSE)
titan_primary_col <- find_col(titan_raw, c("Primary", "primary", "primary_group"), FALSE)
titan_genus_col <- find_col(titan_raw, c("Genus", "genus"), FALSE)
titan <- titan_raw %>% dplyr::mutate(ASV = as.character(.data[[titan_asv_col]]), zenv_cp = suppressWarnings(as.numeric(.data[[titan_cp_col]])), filter_value =
  suppressWarnings(as.numeric(.data[[titan_filter_col]])), Habitat_clean = if (is.na(titan_habitat_col)) {
  "Rhizosphere"
} else {
  as.character(.data[[titan_habitat_col]])
}, Primary_TITAN = if (is.na(titan_primary_col)) {
  NA_character_
} else {
  as.character(.data[[titan_primary_col]])
}, Genus = if (is.na(titan_genus_col)) {
  NA_character_
} else {
  as.character(.data[[titan_genus_col]])
}) %>% dplyr::filter(Habitat_clean %in% c("Rhizosphere", "rhizosphere", "根际", "Soil"), filter_value == 1, is.finite(zenv_cp), abs(zenv_cp - hs_cp) < cp_tolerance) %>%
  dplyr::distinct(ASV, .keep_all = TRUE)
if (nrow(titan) == 0L) {
  stop("No pure/reliable z- ASVs had zenv.cp exactly equal to 2. ", "The script will not widen the change-point window automatically.")
}
selected_all <- titan$ASV
selected_common <- Reduce(intersect, list(selected_all, asv$ASV, tree_all$tip.label))
missing_asv_table <- setdiff(selected_all, asv$ASV)
missing_tree <- setdiff(selected_all, tree_all$tip.label)
if (length(selected_common) < 3L) {
  stop("Fewer than three exact-HS z- ASVs remain after intersecting TITAN, ", "the ASV table and the phylogenetic tree.")
}
selected_meta <- titan %>% dplyr::filter(ASV %in% selected_common) %>% dplyr::left_join(asv %>% dplyr::select(ASV, Phylum, Family), by = "ASV") %>% dplyr::left_join(
  annotation, by = "ASV") %>% dplyr::mutate(Primary = dplyr::coalesce(Primary_annotation, Primary_TITAN), Primary = trimws(Primary), Primary = dplyr::if_else(is.na(
  Primary) | !Primary %in% names(primary_colors), "Unassigned", Primary), TITAN_direction = "z-", Selection = "filter = 1 and zenv.cp = 2 exactly")
readr::write_csv(selected_meta, file.path(output_dir, "01_HS_exact_zminus_selected_ASVs.csv"))
selection_audit <- tibble::tibble(Item = c("TITAN exact-HS z- ASVs before intersection", "Retained after ASV-table/tree intersection", "Absent from ASV table",
  "Absent from phylogenetic tree"), N = c(length(selected_all), length(selected_common), length(missing_asv_table), length(missing_tree)), ASVs = c(paste(selected_all,
  collapse = ";"), paste(selected_common, collapse = ";"), paste(missing_asv_table, collapse = ";"), paste(missing_tree, collapse = ";")))
readr::write_csv(selection_audit, file.path(output_dir, "02_HS_exact_zminus_selection_audit.csv"))
missing_abundance_columns <- setdiff(hs_group$Sample, names(asv))
if (length(missing_abundance_columns) > 0L) {
  stop("HS samples missing from the ASV table: ", paste(missing_abundance_columns, collapse = ", "))
}
abundance_long <- asv %>% dplyr::filter(ASV %in% selected_common) %>% dplyr::select(ASV, dplyr::all_of(hs_group$Sample)) %>% tidyr::pivot_longer(cols = - ASV, names_to =
  "Sample", values_to = "Abundance") %>% dplyr::mutate(Abundance = suppressWarnings(as.numeric(Abundance))) %>% dplyr::left_join(hs_group, by = "Sample")
if (any(!is.finite(abundance_long$Abundance))) {
  stop("The selected ASV abundance matrix contains missing/non-numeric values.")
}
if (any(abundance_long$Abundance < 0)) {
  stop("Negative ASV abundance values were found.")
}
heatmap_data <- abundance_long %>% dplyr::group_by(ASV, Drought) %>% dplyr::summarise(Mean_rarefied_count = mean(Abundance), .groups = "drop") %>% tidyr::complete(ASV =
  selected_common, Drought = factor(drought_levels, levels = drought_levels), fill = list(Mean_rarefied_count = 0)) %>% dplyr::mutate(Drought = factor(Drought, levels =
  drought_levels), Log2_mean_count = log2(Mean_rarefied_count + 1)) %>% dplyr::group_by(ASV) %>% dplyr::mutate(Standardized_log2_abundance = {
  z <- as.numeric(scale(Log2_mean_count))
  ifelse(is.finite(z), z, 0)
}) %>% dplyr::ungroup()
readr::write_csv(heatmap_data, file.path(output_dir, "03_HS_exact_zminus_drought_heatmap_data.csv"))
prevalence_input <- asv %>% dplyr::filter(ASV %in% selected_common)
prevalence_matrix <- prevalence_input %>% dplyr::select(dplyr::all_of(group$Sample)) %>% dplyr::mutate(dplyr::across(dplyr::everything(), ~ suppressWarnings(as.numeric(.x
  )))) %>% as.matrix()
if (any(!is.finite(prevalence_matrix))) {
  stop("Non-numeric values were found while calculating ASV prevalence.")
}
prevalence_data <- tibble::tibble(ASV = prevalence_input$ASV, N_detected = rowSums(prevalence_matrix > 0), N_samples = ncol(prevalence_matrix), Prevalence = N_detected /
  N_samples, Prevalence_scope = "All 128 rhizosphere samples")
readr::write_csv(prevalence_data, file.path(output_dir, "03b_HS_exact_zminus_overall_prevalence.csv"))
guild_composition <- selected_meta %>% dplyr::count(Primary, name = "N_ASV") %>% dplyr::mutate(Percentage = 100 * N_ASV / sum(N_ASV), Label = paste0(N_ASV, " (", round(
  Percentage), "%)"), Primary = factor(Primary, levels = names(primary_colors))) %>% dplyr::arrange(Primary)
readr::write_csv(guild_composition, file.path(output_dir, "03c_HS_exact_zminus_functional_composition.csv"))
fit_one_asv <- function (df) {
  df <- df %>% dplyr::mutate(Log2_abundance = log2(Abundance + 1))
  if (dplyr::n_distinct(df$Log2_abundance) < 2L) {
    return(tibble::tibble(F_value = NA_real_, NumDF = NA_real_, DenDF = NA_real_, P_value = NA_real_, Heavy_minus_control = NA_real_, Singular_fit = NA))
  }
  model <- tryCatch(lmerTest::lmer(Log2_abundance ~ Block + Genotype + Drought + (1 | MainPlotID), data = df, REML = TRUE, control = lme4::lmerControl(optimizer =
    "bobyqa", optCtrl = list(maxfun = 1e5))), error = function (e) NULL)
  if (is.null(model)) {
    return(tibble::tibble(F_value = NA_real_, NumDF = NA_real_, DenDF = NA_real_, P_value = NA_real_, Heavy_minus_control = NA_real_, Singular_fit = NA))
  }
  a <- tryCatch(extract_type3(model), error = function (e) NULL)
  d <- if (is.null(a)) NULL else a[a$Effect == "Drought",, drop = FALSE]
  emm_df <- tryCatch(as.data.frame(emmeans::emmeans(model, ~ Drought)), error = function (e) NULL)
  heavy_minus_control <- NA_real_
  if (!is.null(emm_df)) {
    heavy <- emm_df$emmean[as.character(emm_df$Drought) == "Drought_H"]
    control <- emm_df$emmean[as.character(emm_df$Drought) == "Control"]
    if (length(heavy) == 1L && length(control) == 1L) {
      heavy_minus_control <- heavy - control
    }
  }
  tibble::tibble(F_value = if (is.null(d) || nrow(d) == 0L) NA_real_ else d$F_value[1], NumDF = if (is.null(d) || nrow(d) == 0L) NA_real_ else d$NumDF[1], DenDF = if (
    is.null(d) || nrow(d) == 0L) NA_real_ else d$DenDF[1], P_value = if (is.null(d) || nrow(d) == 0L) NA_real_ else d$P_value[1], Heavy_minus_control =
    heavy_minus_control, Singular_fit = lme4::isSingular(model, tol = 1e-5))
}
asv_drought_tests <- abundance_long %>% dplyr::group_by(ASV) %>% dplyr::group_modify(~ fit_one_asv(.x)) %>% dplyr::ungroup() %>% dplyr::mutate(FDR = stats::p.adjust(
  P_value, method = "BH"), Direction = dplyr::case_when(Heavy_minus_control > 0 ~ "Increase", Heavy_minus_control < 0 ~ "Decrease", TRUE ~ "Unclear"), FDR_mark = dplyr::
  case_when(!is.na(FDR) & FDR < 0.001 ~ "***", !is.na(FDR) & FDR < 0.01 ~ "**", !is.na(FDR) & FDR < 0.05 ~ "*", TRUE ~ ""), Track = "Drought\nFDR")
readr::write_csv(asv_drought_tests, file.path(output_dir, "04_HS_exact_zminus_per_ASV_drought_tests.csv"))
score_long <- abundance_long %>% dplyr::group_by(ASV) %>% dplyr::mutate(Log2_abundance = log2(Abundance + 1), ASV_z = {
  z <- as.numeric(scale(Log2_abundance))
  ifelse(is.finite(z), z, NA_real_)
}) %>% dplyr::ungroup()
zero_variance_asvs <- score_long %>% dplyr::group_by(ASV) %>% dplyr::summarise(All_NA = all(is.na(ASV_z)), .groups = "drop") %>% dplyr::filter(All_NA) %>% dplyr::pull(ASV
  )
score_data <- score_long %>% dplyr::filter(!ASV %in% zero_variance_asvs) %>% dplyr::group_by(Sample, Block, Drought, Genotype, MainPlotID, PlotID) %>% dplyr::summarise(
  HS_zminus_score = mean(ASV_z, na.rm = TRUE), N_ASVs_in_score = sum(is.finite(ASV_z)), .groups = "drop")
if (nrow(score_data) != 32L || any(!is.finite(score_data$HS_zminus_score))) {
  stop("The aggregate HS z- score could not be calculated for all 32 samples.")
}
score_model <- lmerTest::lmer(HS_zminus_score ~ Block + Genotype + Drought + (1 | MainPlotID), data = score_data, REML = TRUE, control = lme4::lmerControl(optimizer =
  "bobyqa", optCtrl = list(maxfun = 1e5)))
score_anova <- extract_type3(score_model)
score_anova$Singular_fit <- lme4::isSingular(score_model, tol = 1e-5)
score_emm <- emmeans::emmeans(score_model, ~ Drought)
score_emm_df <- as.data.frame(confint(score_emm))
score_letters <- multcomp::cld(score_emm, Letters = letters, adjust = "tukey", sort = FALSE) %>% as.data.frame() %>% dplyr::transmute(Drought, Letter = trimws(.group))
score_emm_df <- score_emm_df %>% dplyr::left_join(score_letters, by = "Drought")
score_pairs <- as.data.frame(emmeans::contrast(score_emm, method = "pairwise", adjust = "tukey"))
readr::write_csv(score_data, file.path(output_dir, "05_HS_exact_zminus_score_raw.csv"))
readr::write_csv(score_anova, file.path(output_dir, "06_HS_exact_zminus_score_ANOVA.csv"))
readr::write_csv(score_emm_df, file.path(output_dir, "07_HS_exact_zminus_score_emmeans.csv"))
readr::write_csv(score_pairs, file.path(output_dir, "08_HS_exact_zminus_score_Tukey.csv"))
background_asvs <- intersect(asv$ASV, tree_all$tip.label)
selected_for_phylo <- intersect(selected_common, background_asvs)
if (length(background_asvs) <= length(selected_for_phylo)) {
  stop("The phylogenetic background is not larger than the selected ASV set.")
}
tree_background <- ape::keep.tip(tree_all, background_asvs)
phylo_dist <- as.matrix(ape::cophenetic.phylo(tree_background))
good_taxa <- rownames(phylo_dist)[rowSums(!is.finite(phylo_dist)) == 0]
phylo_dist <- phylo_dist[good_taxa, good_taxa, drop = FALSE]
selected_for_phylo <- intersect(selected_for_phylo, good_taxa)
if (length(selected_for_phylo) < 3L) {
  stop("Fewer than three selected ASVs have valid phylogenetic distances.")
}
observed_mpd <- calc_mpd(selected_for_phylo, phylo_dist)
observed_mntd <- calc_mntd(selected_for_phylo, phylo_dist)
null_mpd <- numeric(phylo_runs)
null_mntd <- numeric(phylo_runs)
background_valid <- rownames(phylo_dist)
for (i in seq_len(phylo_runs)) {
  random_taxa <- sample(background_valid, size = length(selected_for_phylo), replace = FALSE)
  null_mpd[i] <- calc_mpd(random_taxa, phylo_dist)
  null_mntd[i] <- calc_mntd(random_taxa, phylo_dist)
}
mpd_ses <- ses_one(observed_mpd, null_mpd)
mntd_ses <- ses_one(observed_mntd, null_mntd)
phylo_test <- tibble::tibble(Group = "HS-change-point z- indicator ASVs", N_selected = length(selected_for_phylo), N_background = length(background_valid), Null_runs =
  phylo_runs, MPD_observed = observed_mpd, MPD_null_mean = mean(null_mpd, na.rm = TRUE), SES_MPD = unname(mpd_ses["SES"]), MPD_P_two_sided = unname(mpd_ses["P_two_sided"]
  ), MNTD_observed = observed_mntd, MNTD_null_mean = mean(null_mntd, na.rm = TRUE), SES_MNTD = unname(mntd_ses["SES"]), MNTD_P_two_sided = unname(mntd_ses["P_two_sided"])
  )
readr::write_csv(phylo_test, file.path(output_dir, "09_HS_exact_zminus_phylogenetic_test.csv"))
tree_selected <- ape::keep.tip(tree_all, selected_common)
if (length(tree_selected$tip.label) >= 3L) {
  tree_selected <- tryCatch(phytools::midpoint.root(tree_selected), error = function (e) tree_selected)
}
tree_meta <- selected_meta %>% dplyr::select(ASV, Phylum, Primary)
asv_labels <- tibble::tibble(ASV = selected_common, Label = selected_common)
drought_marks <- asv_drought_tests %>% dplyr::mutate(Direction_plot = dplyr::if_else(FDR_mark == "", NA_character_, Direction), Direction_plot = factor(Direction_plot,
  levels = c("Increase", "Decrease")))
p_tree <- suppressWarnings(ggtree::ggtree(tree_selected, layout = "circular", open.angle = 3, branch.length = "branch.length", size = 0.60, colour = "grey40")) + ggplot2::
  scale_x_continuous(expand = ggplot2::expansion(mult = c(0.02, 0.02)))
p_tree <- p_tree + ggtreeExtra::geom_fruit(data = tree_meta, geom = geom_tile, mapping = ggplot2::aes(y = ASV, x = "Phylum", fill = Phylum), width = 0.38, offset = 0.09) +
  ggplot2::scale_fill_manual(values = phylum_colors, name = "Phylum", drop = FALSE, guide = ggplot2::guide_legend(nrow = 2, byrow = TRUE, order = 1)) + ggnewscale::
  new_scale_fill()
p_tree <- p_tree + ggtreeExtra::geom_fruit(data = asv_labels, geom = geom_text, mapping = ggplot2::aes(y = ASV, x = 0, label = Label), size = 2.60, colour = "black",
  offset = 0.035)
p_tree <- p_tree + ggtreeExtra::geom_fruit(data = tree_meta, geom = geom_tile, mapping = ggplot2::aes(y = ASV, x = "Guild", fill = Primary), width = 0.30, offset = 0.08) +
  ggplot2::scale_fill_manual(values = primary_colors, name = "Primary guild", drop = FALSE, guide = ggplot2::guide_legend(nrow = 2, byrow = TRUE, order = 2)) + ggnewscale::
  new_scale_fill()
p_tree <- p_tree + ggtreeExtra::geom_fruit(data = heatmap_data, geom = geom_tile, mapping = ggplot2::aes(y = ASV, x = Drought, fill = Standardized_log2_abundance), pwidth
  = 0.16, offset = 0.08, colour = "grey90", linewidth = 0.08, axis.params = list(expand = c(0, 0))) + ggplot2::scale_fill_gradient2(low = "#8FB3D9", mid = "white", high =
  "#F29A91", midpoint = 0, name = "Standardized log2 abundance", guide = ggplot2::guide_colourbar(direction = "horizontal", title.position = "top", barwidth = grid::unit(
  1.8, "cm"), barheight = grid::unit(0.18, "cm"), order = 3))
if (any(nzchar(drought_marks$FDR_mark))) {
  p_tree <- p_tree + ggnewscale::new_scale_colour() + ggtreeExtra::geom_fruit(data = drought_marks, geom = geom_text, mapping = ggplot2::aes(y = ASV, x = Track, label =
    FDR_mark, colour = Direction_plot), size = 3.0, offset = 0.04, na.rm = TRUE) + ggplot2::scale_colour_manual(values = c(Increase = "#D73027", Decrease = "#2166AC"),
    breaks = c("Increase", "Decrease"), name = "HS drought response\n(BH-FDR < 0.05)", na.translate = FALSE, drop = TRUE)
}
p_tree <- p_tree + ggnewscale::new_scale_fill() + ggtreeExtra::geom_fruit(data = prevalence_data, geom = geom_bar, stat = "identity", mapping = ggplot2::aes(y = ASV, x =
  Prevalence, fill = "Overall prevalence"), colour = "#2B6C96", linewidth = 0.16, width = 0.50, pwidth = 0.10, offset = 0.07) + ggplot2::scale_fill_manual(values = c(
  "Overall prevalence" = "#4B97C4"), name = "Outermost bar", guide = ggplot2::guide_legend(order = 4)) + ggplot2::ggtitle(paste0(
  "Rhizosphere HS-change-point z− indicator ASVs (n = ", length(selected_common), ")")) + ggplot2::theme_void() + ggplot2::theme(plot.title = ggplot2::element_text(hjust
  = 0.5, face = "bold", size = 11), legend.position = "right", legend.box = "vertical", legend.direction = "vertical", legend.key.size = grid::unit(0.38, "cm"),
  legend.text = ggplot2::element_text(size = 7.8), legend.title = ggplot2::element_text(size = 8.8), legend.spacing.y = grid::unit(0.12, "cm"), legend.box.spacing = grid
  ::unit(0.08, "cm"), plot.margin = ggplot2::margin(5, 5, 5, 5))
drought_row <- score_anova %>% dplyr::filter(Effect == "Drought")
if (nrow(drought_row) != 1L) {
  stop("Drought was not found in the aggregate-score ANOVA table.")
}
score_range <- diff(range(score_data$HS_zminus_score))
if (!is.finite(score_range) || score_range == 0) score_range <- 1
score_emm_df <- score_emm_df %>% dplyr::mutate(Letter_y = upper.CL + 0.10 * score_range)
anova_label <- paste0("Drought: F(", sprintf("%.0f", drought_row$NumDF), ", ", sprintf("%.1f", drought_row$DenDF), ") = ", sprintf("%.2f", drought_row$F_value), ", P ",
  format_p(drought_row$P_value))
p_score <- ggplot2::ggplot(score_data, ggplot2::aes(x = Drought, y = HS_zminus_score, fill = Drought)) + ggplot2::geom_boxplot(width = 0.62, outlier.shape = NA, colour =
  "black", linewidth = 0.55, alpha = 0.82) + ggplot2::geom_jitter(width = 0.11, shape = 21, size = 1.5, stroke = 0.35, colour = "black", alpha = 0.70) + ggplot2::
  geom_errorbar(data = score_emm_df, ggplot2::aes(x = Drought, ymin = lower.CL, ymax = upper.CL), width = 0.16, linewidth = 0.65, colour = "black", inherit.aes = FALSE) +
  ggplot2::geom_point(data = score_emm_df, ggplot2::aes(x = Drought, y = emmean), shape = 23, size = 2.3, fill = "white", colour = "black", inherit.aes = FALSE) + ggplot2::
  geom_text(data = score_emm_df, ggplot2::aes(x = Drought, y = Letter_y, label = Letter), size = 3.0, inherit.aes = FALSE) + ggplot2::annotate("text", x = 0.60, y = max(
  score_emm_df$Letter_y) + 0.18 * score_range, label = anova_label, hjust = 0, vjust = 1, size = 2.5) + ggplot2::scale_fill_manual(values = drought_colors, guide = "none"
  ) + ggplot2::scale_x_discrete(labels = drought_labels) + ggplot2::labs(title = "Overall drought response", subtitle = NULL, x = NULL, y = "HS-associated z− score") +
  ggplot2::theme_classic(base_size = 9.2) + ggplot2::theme(plot.title = ggplot2::element_text(face = "bold", hjust = 0.5, size = 10), axis.title.y = ggplot2::element_text
  (size = 9), axis.text = ggplot2::element_text(size = 8), axis.text.x = ggplot2::element_text(angle = 25, hjust = 1), plot.margin = ggplot2::margin(5, 7, 5, 7)) +
  ggplot2::coord_cartesian(ylim = c(min(score_data$HS_zminus_score) - 0.08 * score_range, max(score_emm_df$Letter_y) + 0.28 * score_range), clip = "off")
phylo_label <- paste0("Phylogenetic clustering\n", "SES.MPD = ", sprintf("%.2f", phylo_test$SES_MPD), ", P = ", sprintf("%.3f", phylo_test$MPD_P_two_sided), "\n",
  "SES.MNTD = ", sprintf("%.2f", phylo_test$SES_MNTD), ", P = ", sprintf("%.3f", phylo_test$MNTD_P_two_sided))
p_info <- ggplot2::ggplot() + ggplot2::annotate("text", x = 0, y = 1, label = phylo_label, hjust = 0, vjust = 1, size = 3.05, lineheight = 1.08) + ggplot2::xlim(0, 1) +
  ggplot2::ylim(0, 1) + ggplot2::theme_void() + ggplot2::theme(plot.margin = ggplot2::margin(3, 6, 3, 6), plot.background = ggplot2::element_rect(fill = "white", colour =
  NA))
p_guild <- ggplot2::ggplot(guild_composition, ggplot2::aes(y = "HS z− ASVs", x = Percentage, fill = Primary)) + ggplot2::geom_col(width = 0.58, colour = "black",
  linewidth = 0.35) + ggplot2::geom_text(ggplot2::aes(label = ifelse(Percentage >= 7, Label, "")), position = ggplot2::position_stack(vjust = 0.5), size = 2.7, colour =
  "black") + ggplot2::scale_fill_manual(values = primary_colors, drop = FALSE, guide = "none") + ggplot2::scale_x_continuous(limits = c(0, 100), breaks = c(0, 25, 50, 75,
  100), labels = function (x) paste0(x, "%"), expand = ggplot2::expansion(mult = c(0, 0))) + ggplot2::labs(title = "Functional-guild composition", x =
  "Proportion of selected ASVs", y = NULL) + ggplot2::theme_classic(base_size = 8.8) + ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5, face = "bold", size
  = 9.5), axis.text.y = ggplot2::element_blank(), axis.ticks.y = ggplot2::element_blank(), plot.margin = ggplot2::margin(4, 7, 4, 7))
right_panel <- cowplot::plot_grid(p_score, p_guild, p_info, ncol = 1, rel_heights = c(0.57, 0.24, 0.19))
p_final <- cowplot::plot_grid(p_tree, right_panel, ncol = 2, rel_widths = c(1.72, 0.88), labels = c("C", ""), label_size = 16, label_fontface = "bold")
print(p_final)
ggplot2::ggsave(file.path(output_dir, "Figure3C_Rhizosphere_HS_zminus_integrated.pdf"), p_final, width = 15.2, height = 8.2, device = grDevices::cairo_pdf)
ggplot2::ggsave(file.path(output_dir, "Figure3C_Rhizosphere_HS_zminus_integrated.png"), p_final, width = 15.2, height = 8.2, dpi = 600)
capture.output(summary(score_model), file = file.path(output_dir, "10_HS_exact_zminus_score_model_summary.txt"))
capture.output(sessionInfo(), file = file.path(output_dir, "11_sessionInfo.txt"))
writeLines(c("Definition of the main-tree taxon set:", "Rhizosphere only; TITAN filter = 1; zenv.cp = 2 exactly.", "No +/- 0.5 interval was used.",
  "The set is an HS-change-point z- subset, not the fsumz- threshold set.", "z+ taxa are intentionally excluded from this mechanism-focused tree and",
  "should remain visible in the community TITAN panel or supplementary data."), con = file.path(output_dir, "12_analysis_definition.txt"))
message("Analysis completed. Results saved in: ", output_dir, "\nExact-HS z- ASVs selected before intersection: ", length(selected_all), "\nASVs retained in the tree: ",
  length(selected_common))
