rm(list = ls())
options(stringsAsFactors = FALSE)
set.seed(1234)
work_dir <- "D:/IUE/山西数据/真菌/抽平/测试数据文件/splitplot-SMF-Fungi/titan/Rhizosphere_TITAN_results"
if (!dir.exists(work_dir)) {
  stop("Working directory does not exist:\n", work_dir, "\nPlease change only `work_dir` at the top of the script.")
}
setwd(work_dir)
sig_file <- "TITAN_R_SIG.csv"
fsumz_file <- "fsumz.csv"
output_dir <- file.path(work_dir, "Figure3A_Rhizosphere_TITAN_density_results")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
required_packages <- c("ggplot2", "dplyr")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Install the missing packages first: ", paste(missing_packages, collapse = ", "))
}
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
})
stage_breaks <- 1:4
stage_labels <- c("Jointing", "Heading", "Filling", "Maturity")
direction_levels <- c("z-", "z+")
direction_colors <- c("z-" = "#69A6D4", "z+" = "#DE706D")
density_bandwidth <- 0.20
clean_text <- function (x) {
  trimws(gsub(" ", " ", as.character(x), fixed = TRUE))
}
clean_habitat <- function (x) {
  x <- tolower(clean_text(x))
  dplyr::case_when(x %in% c("rhizosphere", "rhizo", "r", "根际") ~ "Rhizosphere", x %in% c("phyllosphere", "leaf", "l", "叶际") ~ "Phyllosphere", x %in% c("endosphere",
    "root", "t", "根内") ~ "Endosphere", TRUE ~ clean_text(x))
}
format_cp <- function (x) {
  dplyr::case_when(abs(x - 1.0) < 1e-8 ~ "JS", abs(x - 2.0) < 1e-8 ~ "HS", abs(x - 2.5) < 1e-8 ~ "HS-FS", abs(x - 3.0) < 1e-8 ~ "FS", abs(x - 4.0) < 1e-8 ~ "MS", TRUE ~
    sprintf("%.2f", x))
}
if (!file.exists(sig_file)) stop("Input file was not found: ", sig_file)
if (!file.exists(fsumz_file)) stop("Input file was not found: ", fsumz_file)
sig_raw <- read.csv(sig_file, header = TRUE, check.names = FALSE, fileEncoding = "UTF-8-BOM")
fsumz_raw <- read.csv(fsumz_file, header = TRUE, check.names = FALSE, fileEncoding = "UTF-8-BOM")
required_sig_columns <- c("ASV", "zenv.cp")
missing_sig_columns <- setdiff(required_sig_columns, names(sig_raw))
if (length(missing_sig_columns) > 0L) {
  stop(sig_file, " is missing: ", paste(missing_sig_columns, collapse = ", "))
}
required_fsumz_columns <- c("Metric", "cp")
missing_fsumz_columns <- setdiff(required_fsumz_columns, names(fsumz_raw))
if (length(missing_fsumz_columns) > 0L) {
  stop(fsumz_file, " is missing: ", paste(missing_fsumz_columns, collapse = ", "))
}
sig_raw$ASV <- clean_text(sig_raw$ASV)
if (anyNA(sig_raw$ASV) || any(sig_raw$ASV == "")) {
  stop(sig_file, " contains missing or empty ASV identifiers.")
}
if (anyDuplicated(sig_raw$ASV)) {
  duplicated_asvs <- unique(sig_raw$ASV[duplicated(sig_raw$ASV)])
  stop(sig_file, " contains duplicated ASVs: ", paste(duplicated_asvs, collapse = ", "))
}
if ("Habitat" %in% names(sig_raw)) {
  sig_raw$Habitat <- clean_habitat(sig_raw$Habitat)
  sig_raw <- sig_raw[sig_raw$Habitat == "Rhizosphere",, drop = FALSE]
}
if (nrow(sig_raw) == 0L) {
  stop("No rhizosphere ASVs were found in ", sig_file, ".")
}
if ("Titan" %in% names(sig_raw)) {
  direction_value <- clean_text(sig_raw$Titan)
  direction_value[direction_value == "1"] <- "z-"
  direction_value[direction_value == "2"] <- "z+"
} else if ("filter" %in% names(sig_raw)) {
  filter_value <- suppressWarnings(as.numeric(sig_raw$filter))
  direction_value <- dplyr::case_when(filter_value == 1 ~ "z-", filter_value == 2 ~ "z+", TRUE ~ NA_character_)
} else {
  stop(sig_file, " must contain either `Titan` or `filter`.")
}
sig_df <- sig_raw %>% dplyr::mutate(Direction = factor(direction_value, levels = direction_levels), Change_point = suppressWarnings(as.numeric(zenv.cp))) %>% dplyr::
  filter(!is.na(Direction), is.finite(Change_point), Change_point >= 1, Change_point <= 4)
if (nrow(sig_df) == 0L) {
  stop("No valid reliable z- or z+ rhizosphere ASVs remained.")
}
if (!all(direction_levels %in% as.character(unique(sig_df$Direction)))) {
  stop("Both z- and z+ indicator ASVs are required for this figure.")
}
if (all(c("purity", "reliability") %in% names(sig_df))) {
  purity_value <- suppressWarnings(as.numeric(sig_df$purity))
  reliability_value <- suppressWarnings(as.numeric(sig_df$reliability))
  if (any(purity_value < 0.95 | reliability_value < 0.95, na.rm = TRUE)) {
    warning("Some rows have purity or reliability below 0.95 although the input ", "file is expected to contain significant/reliable ASVs. They remain ",
      "in the figure because TITAN_R_SIG.csv is treated as authoritative.")
  }
}
if ("Habitat" %in% names(fsumz_raw)) {
  fsumz_raw$Habitat <- clean_habitat(fsumz_raw$Habitat)
  fsumz_raw <- fsumz_raw[fsumz_raw$Habitat == "Rhizosphere",, drop = FALSE]
}
fsumz_thresholds <- fsumz_raw %>% dplyr::mutate(Metric_clean = tolower(gsub("[[:space:]()]", "", Metric)), Direction = dplyr::case_when(Metric_clean == "fsumz-" ~ "z-",
  Metric_clean == "fsumz+" ~ "z+", TRUE ~ NA_character_), Direction = factor(Direction, levels = direction_levels), Change_point = suppressWarnings(as.numeric(cp))) %>%
  dplyr::filter(!is.na(Direction), is.finite(Change_point))
if (nrow(fsumz_thresholds) != 2L) {
  stop("Expected exactly one fsumz- and one fsumz+ row in ", fsumz_file, "; found ", nrow(fsumz_thresholds), ".")
}
if (anyDuplicated(fsumz_thresholds$Direction)) {
  stop(fsumz_file, " contains duplicated fsumz- or fsumz+ rows.")
}
fsumz_thresholds <- fsumz_thresholds %>% dplyr::mutate(Threshold_label = paste0(as.character(Direction), " fsumz CP = ", sprintf("%.1f", Change_point), " (", format_cp(
  Change_point), ")"), Label_vjust = dplyr::if_else(Direction == "z-", 1.35, 3.05))
indicator_counts <- sig_df %>% dplyr::count(Direction, name = "N_ASVs") %>% dplyr::mutate(Direction = factor(Direction, levels = direction_levels))
n_minus <- indicator_counts$N_ASVs[indicator_counts$Direction == "z-"]
n_plus <- indicator_counts$N_ASVs[indicator_counts$Direction == "z+"]
legend_labels <- c("z-" = paste0("z- decreases (n = ", n_minus, ")"), "z+" = paste0("z+ increases (n = ", n_plus, ")"))
p_titan_density <- ggplot2::ggplot(sig_df, ggplot2::aes(x = Change_point, fill = Direction, colour = Direction)) + ggplot2::geom_vline(xintercept = stage_breaks, colour =
  "grey88", linewidth = 0.45, linetype = "dotted") + ggplot2::geom_density(ggplot2::aes(group = Direction), position = "identity", bw = density_bandwidth, trim = FALSE,
  alpha = 0.48, linewidth = 0.95, lineend = "round") + ggplot2::geom_rug(ggplot2::aes(colour = Direction), sides = "b", alpha = 0.32, linewidth = 0.35, length = grid::
  unit(0.030, "npc")) + ggplot2::geom_vline(data = fsumz_thresholds, mapping = ggplot2::aes(xintercept = Change_point, colour = Direction), inherit.aes = FALSE, linetype
  = "longdash", linewidth = 0.95, show.legend = FALSE) + ggplot2::geom_text(data = fsumz_thresholds, mapping = ggplot2::aes(x = Change_point, y = Inf, label =
  Threshold_label, colour = Direction, vjust = Label_vjust), inherit.aes = FALSE, hjust = - 0.06, size = 3.05, fontface = "bold", show.legend = FALSE) + ggplot2::
  scale_fill_manual(values = direction_colors, breaks = direction_levels, labels = legend_labels, drop = FALSE) + ggplot2::scale_colour_manual(values = direction_colors,
  breaks = direction_levels, labels = legend_labels, drop = FALSE) + ggplot2::scale_x_continuous(breaks = stage_breaks, labels = stage_labels, limits = c(0.75, 4.25),
  expand = ggplot2::expansion(mult = c(0, 0))) + ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0, 0.13))) + ggplot2::coord_cartesian(clip = "off") +
  ggplot2::labs(tag = "A", title = "Rhizosphere TITAN indicator change points", x = "Developmental stage", y = "Density of change points", fill = NULL, colour = NULL) +
  ggplot2::guides(fill = ggplot2::guide_legend(direction = "horizontal", override.aes = list(alpha = 0.65, linewidth = 0.9)), colour = "none") + ggplot2::theme_classic(
  base_size = 11) + ggplot2::theme(plot.tag = ggplot2::element_text(face = "bold", size = 15, margin = ggplot2::margin(r = 4)), plot.tag.position = c(0.01, 0.99),
  plot.title = ggplot2::element_text(face = "bold", size = 12, hjust = 0.5, margin = ggplot2::margin(b = 6)), axis.title = ggplot2::element_text(face = "bold", colour =
  "black"), axis.title.y = ggplot2::element_text(margin = ggplot2::margin(r = 7)), axis.text = ggplot2::element_text(colour = "black"), axis.text.x = ggplot2::
  element_text(angle = 24, hjust = 1, size = 10, margin = ggplot2::margin(t = 5)), axis.line = ggplot2::element_line(linewidth = 0.55), axis.ticks = ggplot2::element_line
  (linewidth = 0.50), legend.position = "top", legend.justification = "center", legend.text = ggplot2::element_text(size = 9.5), legend.margin = ggplot2::margin(b = 2),
  plot.margin = ggplot2::margin(8, 24, 7, 8))
print(p_titan_density)
ggplot2::ggsave(filename = file.path(output_dir, "Figure3A_Rhizosphere_TITAN_significant_ASV_density.pdf"), plot = p_titan_density, width = 4.3, height = 4.6)
ggplot2::ggsave(filename = file.path(output_dir, "Figure3A_Rhizosphere_TITAN_significant_ASV_density.png"), plot = p_titan_density, width = 4.3, height = 4.6, dpi = 600,
  bg = "white")
write.csv(sig_df, file.path(output_dir, "01_significant_ASVs_used_in_density.csv"), row.names = FALSE)
write.csv(fsumz_thresholds, file.path(output_dir, "02_fsumz_thresholds_used.csv"), row.names = FALSE)
write.csv(indicator_counts, file.path(output_dir, "03_indicator_ASV_counts.csv"), row.names = FALSE)
capture.output(sessionInfo(), file = file.path(output_dir, "04_sessionInfo.txt"))
cat("\n============================================================\n")
cat("Figure 3A completed.\n")
cat("Rhizosphere reliable indicators used:\n")
cat("  z- = ", n_minus, " ASVs\n", sep = "")
cat("  z+ = ", n_plus, " ASVs\n", sep = "")
cat("Filtered community thresholds:\n")
print(fsumz_thresholds %>% dplyr::select(Direction, Change_point, Threshold_label))
cat("Output directory:\n", normalizePath(output_dir), "\n", sep = "")
cat("============================================================\n")
