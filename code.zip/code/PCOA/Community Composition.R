## ================= 环境 =================
rm(list = ls())
options(stringsAsFactors = FALSE)

library(tidyverse)
library(scales)

## ================= 工作路径 =================
setwd("D:/IUE/山西数据/真菌/抽平/群落分类水平结构分析/群落结构分析")

## ================= 读入数据 =================
asv_raw <- read.csv("叶际F_ASV.csv", check.names = FALSE)
group   <- read.csv("叶际分组.csv", check.names = FALSE)

## ================= 分组信息 =================
colnames(group)[1] <- "Sample"
grp_col <- if ("Group" %in% names(group)) "Group" else "L_G1234_ABCD"

meta <- group %>%
  mutate(
    Period = case_when(
      str_detect(.data[[grp_col]], "^JS_") ~ "Jointing stage",
      str_detect(.data[[grp_col]], "^HS_") ~ "Heading stage",
      str_detect(.data[[grp_col]], "^FS_") ~ "Filling stage",
      str_detect(.data[[grp_col]], "^MS_") ~ "Maturity stage"
    ),
    Drought = case_when(
      str_detect(.data[[grp_col]], "_Control$")   ~ "Control",
      str_detect(.data[[grp_col]], "_Drought_L$") ~ "Drought_L",
      str_detect(.data[[grp_col]], "_Drought_M$") ~ "Drought_M",
      str_detect(.data[[grp_col]], "_Drought_H$") ~ "Drought_H"
    )
  )

meta$Period  <- factor(meta$Period,
                       levels = c("Jointing stage","Heading stage","Filling stage","Maturity stage"))
meta$Drought <- factor(meta$Drought,
                       levels = c("Control","Drought_L","Drought_M","Drought_H"))

## ================= ASV 转长表 =================
sample_cols <- grep("^(Z|N)", colnames(asv_raw), value = TRUE)

asv_long <- asv_raw %>%
  pivot_longer(
    cols = all_of(sample_cols),
    names_to = "Sample",
    values_to = "Abundance"
  ) %>%
  mutate(Abundance = as.numeric(Abundance)) %>%
  left_join(meta, by = "Sample") %>%
  filter(!is.na(Period), !is.na(Drought))

## ================= 指定配色（你给的那套） =================
base_colors <- c(
  "#E64B35", "#4DBBD5", "#00A087", "#3C5488",
  "#F39B7F", "#8491B4", "#91D1C2", "#7E6148",
  "#008B8B", "#CC5B45"
)

## ================= 堆积柱状图函数 =================
plot_stack_topN <- function(df_long, tax_col, top_n, out_pdf, plot_title){
  
  tax_col <- rlang::ensym(tax_col)
  
  ## 每样本相对丰度
  rel_df <- df_long %>%
    filter(!is.na(!!tax_col), !!tax_col != "") %>%
    group_by(Sample, Period, Drought, !!tax_col) %>%
    summarise(Abundance = sum(Abundance), .groups = "drop") %>%
    group_by(Sample) %>%
    mutate(RelAbundance = Abundance / sum(Abundance)) %>%
    ungroup()
  
  ## Period × Drought 平均
  mean_df <- rel_df %>%
    group_by(Period, Drought, !!tax_col) %>%
    summarise(MeanRel = mean(RelAbundance), .groups = "drop")
  
  ## TopN（按总相对丰度）
  top_taxa <- mean_df %>%
    group_by(!!tax_col) %>%
    summarise(Total = sum(MeanRel), .groups = "drop") %>%
    arrange(desc(Total)) %>%
    slice_head(n = top_n) %>%
    pull(!!tax_col)
  
  ## 合并 Others
  plot_df <- mean_df %>%
    mutate(Taxon = ifelse(
      as.character(!!tax_col) %in% as.character(top_taxa),
      as.character(!!tax_col), "Others"
    )) %>%
    group_by(Period, Drought, Taxon) %>%
    summarise(MeanRel = sum(MeanRel), .groups = "drop")
  
  ## 因子顺序（按丰度 + Others 最后）
  tax_levels <- plot_df %>%
    group_by(Taxon) %>%
    summarise(Total = sum(MeanRel)) %>%
    arrange(desc(Total)) %>%
    pull(Taxon)
  
  tax_levels <- c(setdiff(tax_levels, "Others"), "Others")
  plot_df$Taxon <- factor(plot_df$Taxon, levels = tax_levels)
  
  ## 颜色（严格给 10 个，其余 Others 灰）
  fill_cols <- c(
    setNames(base_colors[seq_len(length(tax_levels) - 1)],
             tax_levels[tax_levels != "Others"]),
    Others = "#D9D9D9"
  )
  
  ## 作图
  p <- ggplot(plot_df, aes(Drought, MeanRel, fill = Taxon)) +
    geom_col(width = 0.8, color = NA) +
    facet_wrap(~ Period, ncol = 2) +
    scale_fill_manual(values = fill_cols) +
    scale_y_continuous(labels = percent_format(accuracy = 1)) +
    labs(
      x = "Drought gradient",
      y = "Relative abundance (%)",
      title = plot_title,
      fill = NULL
    ) +
    theme_bw() +
    theme(
      panel.grid = element_blank(),
      plot.title = element_text(hjust = 0.5),
      axis.text.x = element_text(angle = 30, hjust = 1)
    )
  
  print(p)
  ggsave(out_pdf, p, width = 10, height = 7, dpi = 300)
  
  return(invisible(plot_df))
}

## ================= 门 Top10 =================
plot_stack_topN(
  asv_long,
  phylum,
  10,
  "叶际_Phylum_Top10_final.pdf",
  "Phyllosphere fungal community (Phylum)"
)

## ================= 属 Top10 =================
plot_stack_topN(
  asv_long,
  genus,
  10,
  "叶际_Genus_Top10_final.pdf",
  "Phyllosphere fungal community (Genus)"
)
