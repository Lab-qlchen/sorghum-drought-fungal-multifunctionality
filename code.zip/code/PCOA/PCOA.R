## ================= 环境 =================
rm(list = ls())
options(stringsAsFactors = FALSE)

library(tidyverse)
library(vegan)
library(ggplot2)
library(patchwork)

set.seed(123)

## ================= 工作路径 =================
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/群落组成")

## ================= 读入数据 =================
asv_raw <- read.csv("根内F_ASV.csv", check.names = FALSE)
group   <- read.csv("根内分组.csv", check.names = FALSE)

## ================= ASV 矩阵 =================
## 优先根据分组表中的样本名精确匹配 ASV 表列名
colnames(group)[1] <- "Sample"
sample_names <- group$Sample

sample_cols <- match(sample_names, colnames(asv_raw))
sample_cols <- sample_cols[!is.na(sample_cols)]

if (length(sample_cols) == 0) {
  stop("ASV表中没有找到与分组表匹配的样本列，请检查样本名。")
}

asv_mat <- t(asv_raw[, sample_cols, drop = FALSE])
asv_mat <- as.matrix(asv_mat)
storage.mode(asv_mat) <- "numeric"

## 行名设置为样本名
rownames(asv_mat) <- colnames(asv_raw)[sample_cols]

## 去掉全零样本（整体分析前先处理）
keep_all <- rowSums(asv_mat) > 0
asv_mat <- asv_mat[keep_all, , drop = FALSE]

## ================= 分组信息 =================
grp_col <- if ("Group" %in% names(group)) "Group" else "T_G1234_ABCD"

meta <- group %>%
  mutate(
    Period = case_when(
      str_detect(.data[[grp_col]], "^JS_") ~ "Jointing stage",
      str_detect(.data[[grp_col]], "^HS_") ~ "Heading stage",
      str_detect(.data[[grp_col]], "^FS_") ~ "Filling stage",
      str_detect(.data[[grp_col]], "^MS_") ~ "Maturity stage",
      TRUE ~ NA_character_
    ),
    Drought = case_when(
      str_detect(.data[[grp_col]], "_Control$")   ~ "Control",
      str_detect(.data[[grp_col]], "_Drought_L$") ~ "Drought_L",
      str_detect(.data[[grp_col]], "_Drought_M$") ~ "Drought_M",
      str_detect(.data[[grp_col]], "_Drought_H$") ~ "Drought_H",
      TRUE ~ NA_character_
    ),
    Genotype = ifelse(str_detect(Sample, "^Z"), "Jinza 22", "Liangnuo 01")
  )

meta$Period <- factor(
  meta$Period,
  levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
)

meta$Drought <- factor(
  meta$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

meta$Genotype <- factor(
  meta$Genotype,
  levels = c("Jinza 22", "Liangnuo 01")
)

## 按 ASV 矩阵样本顺序匹配元数据
meta <- meta[match(rownames(asv_mat), meta$Sample), , drop = FALSE]

## 检查是否匹配成功
if (any(is.na(meta$Sample))) {
  stop("分组表中的 Sample 与 ASV 矩阵样本名不完全匹配，请检查。")
}
if (!identical(rownames(asv_mat), meta$Sample)) {
  stop("ASV矩阵与分组信息样本顺序不一致。")
}

## 检查是否有 NA 分组信息
if (any(is.na(meta$Period))) {
  warning("有样本未能识别 Period，请检查分组命名。")
}
if (any(is.na(meta$Drought))) {
  warning("有样本未能识别 Drought，请检查分组命名。")
}

## ================= 工具函数 =================
fmt_p <- function(p) {
  ifelse(is.na(p), "NA",
         ifelse(p < 0.001, "< 0.001", paste0("= ", sprintf("%.3f", p))))
}

get_term_value <- function(tab, term, col) {
  idx <- which(trimws(rownames(tab)) == term)
  if (length(idx) == 0) return(NA_real_)
  as.numeric(tab[idx[1], col])
}

## ================= PCoA（整体） =================
bray <- vegdist(asv_mat, method = "bray")
pcoa <- cmdscale(bray, eig = TRUE, k = 2)

pcoa_df <- data.frame(
  PCoA1 = pcoa$points[, 1],
  PCoA2 = pcoa$points[, 2],
  meta
)

eig <- pcoa$eig
eig_pos <- eig[eig > 0]

if (length(eig_pos) < 2) {
  stop("PCoA 正特征值少于2个，无法绘制二维排序图。")
}

p1 <- round(eig_pos[1] / sum(eig_pos) * 100, 2)
p2 <- round(eig_pos[2] / sum(eig_pos) * 100, 2)

## ================= PERMANOVA（整体） =================
adon_int <- adonis2(
  asv_mat ~ Period * Drought * Genotype,
  data = meta,
  method = "bray",
  permutations = 999,
  by = "terms"
)

r2_p   <- get_term_value(adon_int, "Period", "R2")
p_p    <- get_term_value(adon_int, "Period", "Pr(>F)")
f_p    <- get_term_value(adon_int, "Period", "F")

r2_d   <- get_term_value(adon_int, "Drought", "R2")
p_d    <- get_term_value(adon_int, "Drought", "Pr(>F)")
f_d    <- get_term_value(adon_int, "Drought", "F")

r2_g   <- get_term_value(adon_int, "Genotype", "R2")
p_g    <- get_term_value(adon_int, "Genotype", "Pr(>F)")
f_g    <- get_term_value(adon_int, "Genotype", "F")

r2_pd  <- get_term_value(adon_int, "Period:Drought", "R2")
p_pd   <- get_term_value(adon_int, "Period:Drought", "Pr(>F)")
f_pd   <- get_term_value(adon_int, "Period:Drought", "F")

r2_pg  <- get_term_value(adon_int, "Period:Genotype", "R2")
p_pg   <- get_term_value(adon_int, "Period:Genotype", "Pr(>F)")
f_pg   <- get_term_value(adon_int, "Period:Genotype", "F")

r2_dg  <- get_term_value(adon_int, "Drought:Genotype", "R2")
p_dg   <- get_term_value(adon_int, "Drought:Genotype", "Pr(>F)")
f_dg   <- get_term_value(adon_int, "Drought:Genotype", "F")

r2_pdg <- get_term_value(adon_int, "Period:Drought:Genotype", "R2")
p_pdg  <- get_term_value(adon_int, "Period:Drought:Genotype", "Pr(>F)")
f_pdg  <- get_term_value(adon_int, "Period:Drought:Genotype", "F")

overall_R2 <- 1 - get_term_value(adon_int, "Residual", "R2")

lab_text <- paste0(
  "PERMANOVA (Bray–Curtis)\n",
  "Stage: R² = ", round(r2_p, 3),
  ", P ", fmt_p(p_p), "\n",
  "Treatment: R² = ", round(r2_d, 3),
  ", P ", fmt_p(p_d), "\n",
  "Genotype: R² = ", round(r2_g, 3),
  ", P ", fmt_p(p_g), "\n",
  "Stage × Treatment: R² = ", round(r2_pd, 3),
  ", P ", fmt_p(p_pd), "\n",
  "Stage × Genotype: R² = ", round(r2_pg, 3),
  ", P ", fmt_p(p_pg), "\n",
  "Treatment × Genotype: R² = ", round(r2_dg, 3),
  ", P ", fmt_p(p_dg), "\n",
  "Stage × Treatment × Genotype:\n",
  "R² = ", round(r2_pdg, 3),
  ", P ", fmt_p(p_pdg)
)

## ================= 作图（整体） =================
pcoa_df$Genotype_fill <- ifelse(
  pcoa_df$Genotype == "Jinza 22",
  "Empty",
  "Filled"
)

p <- ggplot(
  pcoa_df,
  aes(
    PCoA1, PCoA2,
    color = Drought,
    shape = Period
  )
) +
  geom_point(
    data = subset(pcoa_df, Genotype == "Jinza 22"),
    size = 4,
    stroke = 0.9,
    fill = "white"
  ) +
  geom_point(
    data = subset(pcoa_df, Genotype == "Liangnuo 01"),
    aes(fill = Drought),
    size = 4,
    stroke = 0.9
  ) +
  scale_shape_manual(
    values = c(
      "Jointing stage" = 21,
      "Heading stage"  = 24,
      "Filling stage"  = 22,
      "Maturity stage" = 23
    )
  ) +
  scale_color_manual(
    values = c(
      "Control"   = "#F8766D",
      "Drought_L" = "#7CAE00",
      "Drought_M" = "#00BFC4",
      "Drought_H" = "#C77CFF"
    )
  ) +
  scale_fill_manual(
    values = c(
      "Control"   = "#F8766D",
      "Drought_L" = "#7CAE00",
      "Drought_M" = "#00BFC4",
      "Drought_H" = "#C77CFF"
    ),
    guide = "none"
  ) +
  annotate(
    "text",
    x = min(pcoa_df$PCoA1, na.rm = TRUE),
    y = max(pcoa_df$PCoA2, na.rm = TRUE),
    label = lab_text,
    hjust = 0,
    vjust = 1,
    size = 4
  ) +
  labs(
    x = paste0("PCoA1 (", p1, "%)"),
    y = paste0("PCoA2 (", p2, "%)"),
    title = "Endosphere",
    color = "Treatment",
    shape = "Stage"
  ) +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    plot.title = element_text(hjust = 0.5)
  )

print(p)

ggsave(
  "PCoA_根内.pdf",
  p,
  width = 8.5,
  height = 6.5,
  dpi = 300
)

## ================= 导出整体 PERMANOVA 结果 =================
permanova_csv <- data.frame(
  Factor = c(
    "Stage",
    "Treatment",
    "Genotype",
    "Stage × Treatment",
    "Stage × Genotype",
    "Treatment × Genotype",
    "Stage × Treatment × Genotype",
    "Overall explained variation"
  ),
  R2 = c(
    r2_p,
    r2_d,
    r2_g,
    r2_pd,
    r2_pg,
    r2_dg,
    r2_pdg,
    overall_R2
  ),
  F_value = c(
    f_p,
    f_d,
    f_g,
    f_pd,
    f_pg,
    f_dg,
    f_pdg,
    NA
  ),
  P_value = c(
    p_p,
    p_d,
    p_g,
    p_pd,
    p_pg,
    p_dg,
    p_pdg,
    NA
  )
)

write.csv(
  permanova_csv,
  file = "根内PERMANOVA_results.csv",
  row.names = FALSE
)

## ================= 分四个时期分析 =================
period_levels <- levels(meta$Period)

period_plot_list <- list()
period_perm_list <- list()

for (pd in period_levels) {
  
  ## ---------- 当前时期数据 ----------
  idx <- meta$Period == pd
  meta_sub <- meta[idx, , drop = FALSE]
  asv_sub  <- asv_mat[idx, , drop = FALSE]
  
  ## 去掉全零样本
  keep <- rowSums(asv_sub) > 0
  meta_sub <- meta_sub[keep, , drop = FALSE]
  asv_sub  <- asv_sub[keep, , drop = FALSE]
  
  ## 去掉空水平
  meta_sub <- droplevels(meta_sub)
  
  ## 样本数或水平数不足时跳过
  if (nrow(meta_sub) < 4) {
    warning(paste("时期", pd, "样本数不足，跳过。"))
    next
  }
  if (length(unique(meta_sub$Drought)) < 2) {
    warning(paste("时期", pd, "的 Drought 水平不足，跳过。"))
    next
  }
  if (length(unique(meta_sub$Genotype)) < 2) {
    warning(paste("时期", pd, "的 Genotype 水平不足，跳过。"))
    next
  }
  
  ## ---------- 距离矩阵与 PCoA ----------
  bray_sub <- vegdist(asv_sub, method = "bray")
  pcoa_sub <- cmdscale(bray_sub, eig = TRUE, k = 2)
  
  pcoa_sub_df <- data.frame(
    PCoA1 = pcoa_sub$points[, 1],
    PCoA2 = pcoa_sub$points[, 2],
    meta_sub
  )
  
  eig_sub <- pcoa_sub$eig
  eig_sub_pos <- eig_sub[eig_sub > 0]
  
  if (length(eig_sub_pos) < 2) {
    warning(paste("时期", pd, "PCoA正特征值不足2个，跳过。"))
    next
  }
  
  p1_sub <- round(eig_sub_pos[1] / sum(eig_sub_pos) * 100, 2)
  p2_sub <- round(eig_sub_pos[2] / sum(eig_sub_pos) * 100, 2)
  
  ## ---------- 每个时期内做 PERMANOVA ----------
  adon_int_sub <- adonis2(
    asv_sub ~ Drought * Genotype,
    data = meta_sub,
    method = "bray",
    permutations = 999,
    by = "terms"
  )
  
  r2_d_sub  <- get_term_value(adon_int_sub, "Drought", "R2")
  p_d_sub   <- get_term_value(adon_int_sub, "Drought", "Pr(>F)")
  f_d_sub   <- get_term_value(adon_int_sub, "Drought", "F")
  
  r2_g_sub  <- get_term_value(adon_int_sub, "Genotype", "R2")
  p_g_sub   <- get_term_value(adon_int_sub, "Genotype", "Pr(>F)")
  f_g_sub   <- get_term_value(adon_int_sub, "Genotype", "F")
  
  r2_dg_sub <- get_term_value(adon_int_sub, "Drought:Genotype", "R2")
  p_dg_sub  <- get_term_value(adon_int_sub, "Drought:Genotype", "Pr(>F)")
  f_dg_sub  <- get_term_value(adon_int_sub, "Drought:Genotype", "F")
  
  overall_R2_sub <- 1 - get_term_value(adon_int_sub, "Residual", "R2")
  
  ## ---------- 保存 PERMANOVA 结果 ----------
  period_perm_list[[pd]] <- data.frame(
    Period = rep(pd, 4),
    Factor = c("Drought", "Genotype", "Drought × Genotype", "Overall explained variation"),
    R2 = c(r2_d_sub, r2_g_sub, r2_dg_sub, overall_R2_sub),
    F_value = c(f_d_sub, f_g_sub, f_dg_sub, NA),
    P_value = c(p_d_sub, p_g_sub, p_dg_sub, NA)
  )
  
  ## ---------- 图中文字 ----------
  lab_text_sub <- paste0(
    "PERMANOVA\n",
    "Treatment: R² = ", round(r2_d_sub, 3),
    ", P ", fmt_p(p_d_sub), "\n",
    "Genotype: R² = ", round(r2_g_sub, 3),
    ", P ", fmt_p(p_g_sub), "\n",
    "Treatment × Genotype:\n",
    "R² = ", round(r2_dg_sub, 3),
    ", P ", fmt_p(p_dg_sub)
  )
  
  ## ---------- 作图 ----------
  p_sub <- ggplot(
    pcoa_sub_df,
    aes(
      PCoA1, PCoA2,
      color = Drought,
      shape = Period
    )
  ) +
    geom_point(
      data = subset(pcoa_sub_df, Genotype == "Jinza 22"),
      size = 4,
      stroke = 1,
      fill = "white"
    ) +
    geom_point(
      data = subset(pcoa_sub_df, Genotype == "Liangnuo 01"),
      aes(fill = Drought),
      size = 4,
      stroke = 1
    ) +
    scale_shape_manual(
      values = c(
        "Jointing stage" = 21,
        "Heading stage"  = 24,
        "Filling stage"  = 22,
        "Maturity stage" = 23
      )
    ) +
    scale_color_manual(
      values = c(
        "Control"   = "#F8766D",
        "Drought_L" = "#7CAE00",
        "Drought_M" = "#00BFC4",
        "Drought_H" = "#C77CFF"
      )
    ) +
    scale_fill_manual(
      values = c(
        "Control"   = "#F8766D",
        "Drought_L" = "#7CAE00",
        "Drought_M" = "#00BFC4",
        "Drought_H" = "#C77CFF"
      ),
      guide = "none"
    ) +
    annotate(
      "text",
      x = min(pcoa_sub_df$PCoA1, na.rm = TRUE),
      y = max(pcoa_sub_df$PCoA2, na.rm = TRUE),
      label = lab_text_sub,
      hjust = 0,
      vjust = 1,
      size = 4
    ) +
    labs(
      x = paste0("PCoA1 (", p1_sub, "%)"),
      y = paste0("PCoA2 (", p2_sub, "%)"),
      title = pd,
      color = "Treatment",
      shape = "Stage"
    ) +
    theme_bw() +
    theme(
      panel.grid = element_blank(),
      plot.title = element_text(hjust = 0.5)
    )
  
  period_plot_list[[pd]] <- p_sub
  
  ## ---------- 保存单图 ----------
  ggsave(
    filename = paste0("PCoA_根内_", gsub(" ", "_", pd), ".pdf"),
    plot = p_sub,
    width = 8,
    height = 6.2,
    dpi = 300
  )
}

## ================= 四图拼接 =================
valid_plots <- period_plot_list[!sapply(period_plot_list, is.null)]

if (length(valid_plots) == 4) {
  p_period_all <- (valid_plots[[1]] | valid_plots[[2]]) /
    (valid_plots[[3]] | valid_plots[[4]])
  
  print(p_period_all)
  
  ggsave(
    filename = "PCoA_根内_四时期分开展示.pdf",
    plot = p_period_all,
    width = 14,
    height = 10.5,
    dpi = 300
  )
} else {
  warning("有效的时期子图不足4个，未生成四图拼接文件。")
}

## ================= 导出分时期 PERMANOVA 结果 =================
if (length(period_perm_list) > 0) {
  period_permanova_csv <- bind_rows(period_perm_list)
  
  write.csv(
    period_permanova_csv,
    file = "根内_四时期分别_PERMANOVA_results.csv",
    row.names = FALSE
  )
} else {
  warning("没有可导出的分时期 PERMANOVA 结果。")
}