
# =========================================================
# 抽穗期 HS：根际真菌机制 Piecewise SEM
#
# 最终路径：
# Drought -> Shannon
# Drought -> betaNTI
# Drought + betaNTI + Shannon -> key_ASV6
# betaNTI + key_ASV6 -> Network_PC1
# Drought + Network_PC1 + key_ASV6 -> Negative cohesion
# Drought + key_ASV6 + Network_PC1 + Negative cohesion + Shannon -> SMF
# Drought + SMF -> PGI
# Drought + PGI -> Yield
#
# 注意：
# 1. 不再使用 Drought_num，Drought = -RWC，作为干旱程度的连续表征。
# 2. 删除 SMF -> Yield 直接路径。
# 3. 删除 betaNTI -> Yield 直接路径。
# 4. Yield 只保留 Drought 和 PGI 的直接效应。
# 5. 【新增】Shannon -> SMF_meanZ 直接路径
# =========================================================

rm(list = ls())
options(stringsAsFactors = FALSE)

# =========================================================
# 0. 工作目录
# =========================================================

setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/随机森林/根际5.19/1")

# =========================================================
# 1. 加载包
# =========================================================

pkg_needed <- c(
  "tidyverse",
  "piecewiseSEM",
  "ggplot2",
  "igraph"
)

pkg_new <- pkg_needed[!pkg_needed %in% installed.packages()[, "Package"]]

if (length(pkg_new) > 0) {
  install.packages(pkg_new, repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
}

library(tidyverse)
library(piecewiseSEM)
library(ggplot2)
library(igraph)

# =========================================================
# 2. 辅助函数
# =========================================================

trim_all_char <- function(df) {
  df[] <- lapply(df, function(x) {
    if (is.character(x)) trimws(x) else x
  })
  df
}

num_convert <- function(df, cols) {
  for (cc in cols) {
    if (cc %in% colnames(df)) {
      df[[cc]] <- suppressWarnings(as.numeric(df[[cc]]))
    }
  }
  df
}

get_first_existing <- function(nms, candidates) {
  hit <- candidates[candidates %in% nms]
  if (length(hit) == 0) return(NA_character_)
  hit[1]
}

read_first_csv <- function(candidates, required = TRUE) {
  hit <- candidates[file.exists(candidates)]
  
  if (length(hit) == 0) {
    if (required) {
      stop("没有找到文件：", paste(candidates, collapse = " 或 "))
    } else {
      return(NULL)
    }
  }
  
  message("读取文件：", hit[1])
  read.csv(hit[1], check.names = FALSE)
}

safe_write_csv <- function(x, file) {
  ok <- try(write.csv(x, file, row.names = FALSE), silent = TRUE)
  
  if (inherits(ok, "try-error")) {
    file2 <- paste0(
      tools::file_path_sans_ext(file),
      "_",
      format(Sys.time(), "%Y%m%d_%H%M%S"),
      ".csv"
    )
    write.csv(x, file2, row.names = FALSE)
    message("原文件可能被占用，已改名输出：", file2)
  }
}

parse_sample_id <- function(x) {
  
  x <- trimws(as.character(x))
  
  out <- data.frame(
    Sample = x,
    GenoCode    = substr(x, 1, 1),
    PeriodNum   = substr(x, 2, 2),
    HabitatCode = substr(x, 3, 3),
    DroughtCode = substr(x, 4, 4),
    Rep         = sub(".*_", "", x),
    stringsAsFactors = FALSE
  )
  
  out$Period <- dplyr::case_when(
    out$PeriodNum == "1" ~ "JS",
    out$PeriodNum == "2" ~ "HS",
    out$PeriodNum == "3" ~ "FS",
    out$PeriodNum == "4" ~ "MS",
    TRUE ~ NA_character_
  )
  
  out$Period_full <- dplyr::case_when(
    out$Period == "JS" ~ "Jointing",
    out$Period == "HS" ~ "Heading",
    out$Period == "FS" ~ "Filling",
    out$Period == "MS" ~ "Maturity",
    TRUE ~ NA_character_
  )
  
  out$Drought <- dplyr::case_when(
    out$DroughtCode == "A" ~ "Control",
    out$DroughtCode == "B" ~ "Drought_L",
    out$DroughtCode == "C" ~ "Drought_M",
    out$DroughtCode == "D" ~ "Drought_H",
    TRUE ~ NA_character_
  )
  
  out$Drought_num <- dplyr::case_when(
    out$Drought == "Control"   ~ 0,
    out$Drought == "Drought_L" ~ 1,
    out$Drought == "Drought_M" ~ 2,
    out$Drought == "Drought_H" ~ 3,
    TRUE ~ NA_real_
  )
  
  # 用于把成熟期产量回填到同一小区的其它时期样本
  out$TrackID <- paste0(
    out$GenoCode,
    out$HabitatCode,
    out$DroughtCode,
    "_",
    out$Rep
  )
  
  out
}

scale_z <- function(x) {
  as.numeric(scale(x))
}

drop_zero_var <- function(df) {
  if (is.null(df) || ncol(df) == 0) return(df)
  
  keep <- sapply(df, function(x) {
    x <- x[!is.na(x)]
    length(unique(x)) > 1
  })
  
  df[, keep, drop = FALSE]
}

safe_col_pick <- function(nms, patterns) {
  hit <- unlist(
    lapply(patterns, function(p) {
      grep(p, nms, value = TRUE, ignore.case = TRUE)
    })
  )
  hit <- unique(hit)
  if (length(hit) == 0) return(NA_character_)
  hit[1]
}

sum_asv_abundance <- function(asv_vec, otu_rel, var_name) {
  
  asv_use <- intersect(asv_vec, rownames(otu_rel))
  
  if (length(asv_use) == 0) {
    warning(paste0("没有在丰度表中找到 ", var_name, " 对应的 ASV。"))
    
    out <- data.frame(
      Sample = colnames(otu_rel),
      value = NA_real_
    )
  } else {
    out <- data.frame(
      Sample = colnames(otu_rel),
      value = as.numeric(
        colSums(
          otu_rel[asv_use, , drop = FALSE],
          na.rm = TRUE
        )
      )
    )
  }
  
  colnames(out)[2] <- var_name
  out
}

# =========================================================
# 3. 读取文件
# =========================================================

cohesion <- read_first_csv(c(
  "根际negative cohesion.csv",
  "根际sample_cohesion_Hernandez.csv"
))

rwc <- read_first_csv(c(
  "RWC.csv",
  "含水量和PH.csv"
))

net <- read_first_csv(c(
  "Rhizosphere_all_period_sample_specific_subnetwork_metrics.csv",
  "Rhizosphere_subnetwork_metrics.csv"
))

asv <- read_first_csv(c(
  "根际_ASV.csv",
  "根际F_ASV.csv",
  "根际网络.csv"
))

smf <- read_first_csv(c(
  "测试数据SMF_MeanZ_results.csv"
))

gpi <- read_first_csv(c(
  "GPI_calculated_values.csv",
  "PGI_calculated_values.csv"
))

grp <- read_first_csv(c(
  "根际分组.csv"
))

shannon <- read_first_csv(c(
  "Rhizosphere_Shannon.csv",
  "Rhizosphere_Shannon_perSample.csv"
))

beta_nti <- read_first_csv(c(
  "pairwise_betaNTI_RCbray_process.csv"
))

titan <- read_first_csv(c(
  "根际_TITAN_threshold_nearby_by_Titan_ASVs_used_with_drought_and_SMF_response.csv"
))

yield_raw <- read_first_csv(c(
  "yield.csv",
  "Yield.csv"
))

cohesion  <- trim_all_char(cohesion)
rwc       <- trim_all_char(rwc)
net       <- trim_all_char(net)
asv       <- trim_all_char(asv)
smf       <- trim_all_char(smf)
gpi       <- trim_all_char(gpi)
grp       <- trim_all_char(grp)
shannon   <- trim_all_char(shannon)
beta_nti  <- trim_all_char(beta_nti)
titan     <- trim_all_char(titan)
yield_raw <- trim_all_char(yield_raw)

# =========================================================
# 4. 分组信息
# =========================================================

colnames(grp)[1:2] <- c("Sample", "Group")

group_info <- grp %>%
  dplyr::select(Sample, Group) %>%
  distinct()

sample_info <- parse_sample_id(group_info$Sample)

group_info <- cbind(
  group_info,
  sample_info[, c(
    "GenoCode",
    "PeriodNum",
    "HabitatCode",
    "DroughtCode",
    "Rep",
    "Period",
    "Period_full",
    "Drought",
    "Drought_num",
    "TrackID"
  )]
)

group_info$Period <- factor(
  group_info$Period,
  levels = c("JS", "HS", "FS", "MS")
)

group_info$Period_full <- factor(
  group_info$Period_full,
  levels = c("Jointing", "Heading", "Filling", "Maturity")
)

group_info$Drought <- factor(
  group_info$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

cat("\n分组信息：\n")
print(table(group_info$Period, group_info$Drought, useNA = "ifany"))

# =========================================================
# 5. 整理 SMF / GPI / Yield / RWC / Shannon / Cohesion / Network
# =========================================================

# ------------------------------
# SMF
# ------------------------------

smf_col <- get_first_existing(
  colnames(smf),
  c("SMF_meanZ", "SMF", "MeanZ", "SMF_MeanZ")
)

if (is.na(smf_col)) {
  stop("SMF 文件中没有找到 SMF_meanZ 或类似列名。")
}

smf2 <- smf %>%
  dplyr::select(Sample, SMF_meanZ = all_of(smf_col)) %>%
  distinct()

# ------------------------------
# GPI / PGI
# ------------------------------

gpi_col <- get_first_existing(
  colnames(gpi),
  c("GPI_meanZ", "PGI_meanZ", "GPI", "PGI")
)

if (is.na(gpi_col)) {
  stop("GPI/PGI 文件中没有找到 GPI_meanZ / PGI_meanZ 或类似列名。")
}

gpi2 <- gpi %>%
  dplyr::select(Sample, GPI_meanZ = all_of(gpi_col)) %>%
  distinct()

# ------------------------------
# Yield：成熟期产量回填到同一小区 TrackID
# ------------------------------

yield_col <- get_first_existing(
  colnames(yield_raw),
  c("Yield", "yield", "Grain_yield", "grain_yield")
)

if (is.na(yield_col)) {
  stop("yield.csv 中没有识别到 Yield 列。")
}

yield_df <- yield_raw %>%
  mutate(
    Sample = trimws(as.character(Sample)),
    Yield = as.numeric(.data[[yield_col]])
  )

yield_info <- parse_sample_id(yield_df$Sample)

yield_df <- cbind(
  yield_df,
  yield_info[, c("Period", "TrackID"), drop = FALSE]
)

yield_track <- yield_df %>%
  filter(Period == "MS") %>%
  dplyr::select(TrackID, Yield) %>%
  distinct()

cat("\n成熟期产量 TrackID 数量：", nrow(yield_track), "\n")

# ------------------------------
# RWC
# ------------------------------

rwc_col <- get_first_existing(
  colnames(rwc),
  c("RWC", "rwc", "Soil_moisture", "Soil moisture")
)

if (is.na(rwc_col)) {
  stop("RWC 文件中没有找到 RWC 列。")
}

rwc2 <- rwc %>%
  dplyr::select(Sample, RWC = all_of(rwc_col)) %>%
  distinct()

# ------------------------------
# Shannon
# ------------------------------

shannon_col <- get_first_existing(
  colnames(shannon),
  c("Shannon", "shannon", "Rhizosphere_Shannon")
)

if (is.na(shannon_col)) {
  stop("Shannon 文件中没有找到 Shannon 列。")
}

shannon2 <- shannon %>%
  dplyr::select(Sample, Shannon = all_of(shannon_col)) %>%
  distinct()

# ------------------------------
# Negative cohesion
# ------------------------------

neg_col <- get_first_existing(
  colnames(cohesion),
  c("Negative_Cohesion", "negative_cohesion", "Negative cohesion")
)

if (is.na(neg_col)) {
  stop("内聚力文件中没有找到 Negative_Cohesion 列。")
}

cohesion2 <- cohesion %>%
  dplyr::select(Sample, Negative_Cohesion = all_of(neg_col)) %>%
  mutate(
    Negative_Cohesion = as.numeric(Negative_Cohesion),
    Negative_cohesion_strength = abs(Negative_Cohesion)
  ) %>%
  distinct()

# ------------------------------
# Network: average_degree + complexity
# ------------------------------

net_cols_needed <- c("average_degree", "complexity")

missing_net_cols <- setdiff(net_cols_needed, colnames(net))

if (length(missing_net_cols) > 0) {
  stop(
    "网络参数表中缺少以下列：",
    paste(missing_net_cols, collapse = ", ")
  )
}

net2 <- net %>%
  dplyr::select(Sample, average_degree, complexity) %>%
  distinct()

# =========================================================
# 6. pairwise betaNTI 转为样本级 betaNTI_mean
# =========================================================

need_beta_cols <- c("Sample1", "Sample2", "betaNTI")

missing_beta_cols <- setdiff(need_beta_cols, colnames(beta_nti))

if (length(missing_beta_cols) > 0) {
  stop(
    "pairwise_betaNTI_RCbray_process.csv 缺少以下列：",
    paste(missing_beta_cols, collapse = ", ")
  )
}

sample_period_map <- group_info %>%
  dplyr::select(Sample, Period) %>%
  distinct()

beta_nti2 <- beta_nti %>%
  dplyr::select(Sample1, Sample2, betaNTI) %>%
  mutate(
    betaNTI = as.numeric(betaNTI)
  ) %>%
  left_join(
    sample_period_map %>%
      rename(Sample1 = Sample, Period1 = Period),
    by = "Sample1"
  ) %>%
  left_join(
    sample_period_map %>%
      rename(Sample2 = Sample, Period2 = Period),
    by = "Sample2"
  ) %>%
  filter(
    !is.na(Period1),
    !is.na(Period2),
    Period1 == Period2
  )

beta_sample <- bind_rows(
  beta_nti2 %>%
    transmute(
      Sample = Sample1,
      betaNTI = betaNTI
    ),
  beta_nti2 %>%
    transmute(
      Sample = Sample2,
      betaNTI = betaNTI
    )
) %>%
  group_by(Sample) %>%
  summarise(
    betaNTI_mean = mean(betaNTI, na.rm = TRUE),
    betaNTI_abs_mean = mean(abs(betaNTI), na.rm = TRUE),
    .groups = "drop"
  )

# =========================================================
# 7. TITAN 关键 ASV6 丰度
# =========================================================

titan <- titan %>%
  mutate(
    ASV = as.character(ASV),
    Titan = as.character(Titan),
    primary_group = ifelse(
      is.na(primary_group) | primary_group == "",
      "NA",
      primary_group
    ),
    mark_p = as.numeric(mark_p),
    smf_p = as.numeric(smf_p),
    spearman_r = as.numeric(spearman_r),
    smf_r = as.numeric(smf_r)
  )

drought_alpha <- 0.05
smf_alpha <- 0.05

titan <- titan %>%
  mutate(
    drought_sig = !is.na(mark_p) & mark_p < drought_alpha,
    smf_sig = !is.na(smf_p) & smf_p < smf_alpha,
    CoreGroup = case_when(
      drought_sig &
        drought_trend == "increase_with_drought" &
        smf_sig &
        smf_trend == "negative_with_SMF" ~
        "Drought-enriched & SMF-negative",
      
      drought_sig &
        drought_trend == "decrease_with_drought" &
        smf_sig &
        smf_trend == "positive_with_SMF" ~
        "Drought-depleted & SMF-positive",
      
      drought_sig & !smf_sig ~
        "Drought-responsive only",
      
      !drought_sig & smf_sig ~
        "SMF-correlated only",
      
      TRUE ~ "Other TITAN ASVs"
    )
  )

key_ASV6 <- titan %>%
  filter(CoreGroup == "Drought-depleted & SMF-positive") %>%
  pull(ASV) %>%
  unique()

cat("\n关键 ASV6 数量：", length(key_ASV6), "\n")
print(key_ASV6)

safe_write_csv(
  titan %>% filter(CoreGroup == "Drought-depleted & SMF-positive"),
  "HS_SEM_key_ASV6_from_TITAN_table.csv"
)

# ------------------------------
# 读取 ASV 丰度表
# ------------------------------

asv_id_col <- get_first_existing(
  colnames(asv),
  c("ASV", "asv", "OTU", "otu", "FeatureID", "feature")
)

if (is.na(asv_id_col)) {
  if (ncol(asv) >= 4) {
    asv_id_col <- colnames(asv)[4]
  } else {
    asv_id_col <- colnames(asv)[1]
  }
}

sample_cols_asv <- intersect(group_info$Sample, colnames(asv))

if (length(sample_cols_asv) == 0) {
  sample_cols_asv <- colnames(asv)[grepl("^[ZN][1-4]R[ABCD]_\\d+$", colnames(asv))]
}

if (length(sample_cols_asv) == 0) {
  stop("ASV 丰度表中没有识别到样本列。")
}

otu <- asv[, sample_cols_asv, drop = FALSE]
otu[] <- lapply(otu, function(x) suppressWarnings(as.numeric(as.character(x))))
otu[is.na(otu)] <- 0
rownames(otu) <- as.character(asv[[asv_id_col]])

otu_rel <- sweep(
  otu,
  2,
  colSums(otu, na.rm = TRUE),
  "/"
)

otu_rel[is.na(otu_rel)] <- 0

key_ASV6_abund_df <- sum_asv_abundance(
  key_ASV6,
  otu_rel,
  "key_ASV6_abundance"
)

safe_write_csv(
  key_ASV6_abund_df,
  "HS_SEM_key_ASV6_abundance_by_sample.csv"
)

# =========================================================
# 8. 合并 SEM 数据
# =========================================================

merged <- group_info %>%
  dplyr::select(
    Sample,
    Group,
    Period,
    Period_full,
    Drought,
    Drought_num,
    TrackID,
    Rep
  ) %>%
  left_join(yield_track, by = "TrackID") %>%
  left_join(smf2, by = "Sample") %>%
  left_join(gpi2, by = "Sample") %>%
  left_join(rwc2, by = "Sample") %>%
  left_join(shannon2, by = "Sample") %>%
  left_join(beta_sample, by = "Sample") %>%
  left_join(cohesion2, by = "Sample") %>%
  left_join(net2, by = "Sample") %>%
  left_join(key_ASV6_abund_df, by = "Sample")

num_cols <- c(
  "Drought_num",
  "Yield",
  "SMF_meanZ",
  "GPI_meanZ",
  "RWC",
  "Shannon",
  "betaNTI_mean",
  "betaNTI_abs_mean",
  "Negative_Cohesion",
  "Negative_cohesion_strength",
  "average_degree",
  "complexity",
  "key_ASV6_abundance"
)

merged <- num_convert(merged, num_cols)

merged$Period <- factor(
  merged$Period,
  levels = c("JS", "HS", "FS", "MS")
)

merged$Period_full <- factor(
  merged$Period_full,
  levels = c("Jointing", "Heading", "Filling", "Maturity")
)

merged$Drought <- factor(
  merged$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

safe_write_csv(
  merged,
  "HS_SEM_merged_all_period_table.csv"
)

cat("\n合并表总样本数：", nrow(merged), "\n")
cat("各时期样本数：\n")
print(table(merged$Period, useNA = "ifany"))

# =========================================================
# 9. 只保留抽穗期 HS
# =========================================================

need_vars <- c(
  "RWC",
  "Shannon",
  "betaNTI_mean",
  "key_ASV6_abundance",
  "average_degree",
  "complexity",
  "Negative_cohesion_strength",
  "SMF_meanZ",
  "GPI_meanZ",
  "Yield"
)

cat("\n抽穗期变量缺失情况：\n")
print(
  colSums(
    is.na(
      merged %>%
        filter(Period == "HS") %>%
        dplyr::select(all_of(need_vars))
    )
  )
)

dat_hs <- merged %>%
  filter(Period == "HS") %>%
  dplyr::select(all_of(need_vars)) %>%
  mutate(
    Drought = -RWC
  ) %>%
  dplyr::select(-RWC) %>%
  drop_na()

safe_write_csv(
  dat_hs,
  "HS_SEM_input_complete_cases.csv"
)

cat("\n抽穗期 SEM 完整样本数：", nrow(dat_hs), "\n")

if (nrow(dat_hs) < 10) {
  stop("抽穗期完整样本数不足 10，不建议运行 SEM。")
}

# =========================================================
# 10. 构建 Network_PC1
#     average_degree + complexity 表示网络复杂度
# =========================================================

network_df <- dat_hs %>%
  dplyr::select(average_degree, complexity)

network_df <- drop_zero_var(network_df)

if (ncol(network_df) < 2) {
  stop("average_degree 和 complexity 有效列不足，无法构建 Network_PC1。")
}

pca_net <- prcomp(
  network_df,
  center = TRUE,
  scale. = TRUE
)

dat_hs$Network_PC1 <- as.numeric(predict(pca_net)[, 1])

# 统一方向：让 Network_PC1 与 complexity 正相关
cor_net <- suppressWarnings(
  cor(
    dat_hs$Network_PC1,
    dat_hs$complexity,
    use = "complete.obs"
  )
)

if (!is.na(cor_net) && cor_net < 0) {
  dat_hs$Network_PC1 <- -dat_hs$Network_PC1
  pca_net$rotation[, 1] <- -pca_net$rotation[, 1]
}

network_loading <- data.frame(
  Variable = rownames(pca_net$rotation),
  Loading_PC1 = pca_net$rotation[, 1],
  row.names = NULL
)

network_var <- data.frame(
  PC1_variance_explained = summary(pca_net)$importance[2, 1]
)

safe_write_csv(
  network_loading,
  "HS_SEM_Network_PC1_loadings.csv"
)

safe_write_csv(
  network_var,
  "HS_SEM_Network_PC1_variance.csv"
)

cat("\nNetwork_PC1 loading：\n")
print(network_loading)

cat("\nNetwork_PC1 解释方差比例：\n")
print(network_var)

# =========================================================
# 11. 标准化变量
# =========================================================

dat_std <- dat_hs %>%
  mutate(
    Drought = scale_z(Drought),
    Shannon = scale_z(Shannon),
    betaNTI_mean = scale_z(betaNTI_mean),
    key_ASV6_abundance = scale_z(key_ASV6_abundance),
    Network_PC1 = scale_z(Network_PC1),
    Negative_cohesion_strength = scale_z(Negative_cohesion_strength),
    SMF_meanZ = scale_z(SMF_meanZ),
    GPI_meanZ = scale_z(GPI_meanZ),
    Yield = scale_z(Yield)
  )

check_vars <- c(
  "Drought",
  "Shannon",
  "betaNTI_mean",
  "key_ASV6_abundance",
  "Network_PC1",
  "Negative_cohesion_strength",
  "SMF_meanZ",
  "GPI_meanZ",
  "Yield"
)

ok_flag <- sapply(dat_std[, check_vars, drop = FALSE], function(x) {
  x <- x[!is.na(x)]
  length(unique(x)) > 1
})

if (!all(ok_flag)) {
  stop(
    "以下变量在抽穗期无变异，无法 SEM：",
    paste(names(ok_flag)[!ok_flag], collapse = ", ")
  )
}

# =========================================================
# 12. 构建 Piecewise SEM：Drought = -RWC 作为上游驱动
#     加入 Shannon -> SMF 的直接路径
# =========================================================

m1 <- lm(
  Shannon ~ Drought,
  data = dat_std
)

m2 <- lm(
  betaNTI_mean ~ Drought,
  data = dat_std
)

m3 <- lm(
  key_ASV6_abundance ~ Drought + betaNTI_mean + Shannon,
  data = dat_std
)

m4 <- lm(
  Network_PC1 ~ betaNTI_mean + key_ASV6_abundance,
  data = dat_std
)

m5 <- lm(
  Negative_cohesion_strength ~ Drought + Network_PC1 + key_ASV6_abundance,
  data = dat_std
)

# 在这里新增了 Shannon 作为 SMF 的解释变量
m6 <- lm(
  SMF_meanZ ~ Drought + key_ASV6_abundance + Network_PC1 + Negative_cohesion_strength + Shannon,
  data = dat_std
)

m7 <- lm(
  GPI_meanZ ~ Drought + SMF_meanZ,
  data = dat_std
)

m8 <- lm(
  Yield ~ Drought + GPI_meanZ,
  data = dat_std
)

sem_fit <- piecewiseSEM::psem(
  m1, m2, m3, m4, m5, m6, m7, m8
)

# =========================================================
# 13. 输出 SEM 结果
# =========================================================

sem_summary <- summary(sem_fit)
print(sem_summary)

sink("HS_SEM_summary.txt")
print(sem_summary)
sink()

coef_tab_raw <- as.data.frame(piecewiseSEM::coefs(sem_fit))
r2_tab <- as.data.frame(piecewiseSEM::rsquared(sem_fit))

fit_obj <- try(piecewiseSEM::fisherC(sem_fit), silent = TRUE)

if (inherits(fit_obj, "try-error") || is.null(fit_obj)) {
  fit_tab <- data.frame(
    C = NA_real_,
    df = NA_real_,
    P = NA_real_
  )
} else {
  fit_tab <- data.frame(
    C = ifelse(is.null(fit_obj$C), NA_real_, fit_obj$C[1]),
    df = ifelse(is.null(fit_obj$df), NA_real_, fit_obj$df[1]),
    P = ifelse(is.null(fit_obj$P), NA_real_, fit_obj$P[1])
  )
}

dsep_tab <- try(as.data.frame(piecewiseSEM::dSep(sem_fit)), silent = TRUE)

if (inherits(dsep_tab, "try-error")) {
  dsep_tab <- data.frame()
}

safe_write_csv(
  coef_tab_raw,
  "HS_SEM_piecewise_coefficients_raw.csv"
)

safe_write_csv(
  r2_tab,
  "HS_SEM_piecewise_R2.csv"
)

safe_write_csv(
  fit_tab,
  "HS_SEM_piecewise_fit.csv"
)

if (nrow(dsep_tab) > 0) {
  safe_write_csv(
    dsep_tab,
    "HS_SEM_directed_separation_tests.csv"
  )
}

# =========================================================
# 14. 整理路径系数表
# =========================================================

coef_tab <- coef_tab_raw

names(coef_tab) <- make.names(names(coef_tab), unique = TRUE)

pred_col <- safe_col_pick(names(coef_tab), c("^Predictor$", "Predictor"))
resp_col <- safe_col_pick(names(coef_tab), c("^Response$", "Response"))

std_col <- safe_col_pick(names(coef_tab), c("^Std.Estimate$", "Std.Estimate", "Std.Est"))
est_col <- safe_col_pick(names(coef_tab), c("^Estimate$", "Estimate"))

if (!is.na(std_col)) {
  use_est_col <- std_col
} else {
  use_est_col <- est_col
}

p_col <- safe_col_pick(names(coef_tab), c("^P.Value$", "P.Value", "^P$", "p.value"))

if (is.na(pred_col) || is.na(resp_col) || is.na(use_est_col) || is.na(p_col)) {
  stop(
    "无法识别 coef_tab 中的关键列名。当前列名为：",
    paste(names(coef_tab), collapse = ", ")
  )
}

coef_plot <- coef_tab %>%
  dplyr::filter(.data[[pred_col]] != "(Intercept)") %>%
  dplyr::transmute(
    Predictor = .data[[pred_col]],
    Response  = .data[[resp_col]],
    Estimate  = as.numeric(.data[[use_est_col]]),
    P.Value   = as.numeric(.data[[p_col]])
  ) %>%
  dplyr::mutate(
    Path = paste(Predictor, "->", Response),
    sig = dplyr::case_when(
      P.Value < 0.001 ~ "***",
      P.Value < 0.01  ~ "**",
      P.Value < 0.05  ~ "*",
      TRUE ~ ""
    ),
    label = paste0(sprintf("%.2f", Estimate), sig)
  )

safe_write_csv(
  coef_plot,
  "HS_SEM_path_coefficients_for_plot.csv"
)

# =========================================================
# 15. 路径系数热图
# =========================================================

path_order <- c(
  "Drought -> Shannon",
  "Drought -> betaNTI_mean",
  "Drought -> key_ASV6_abundance",
  "betaNTI_mean -> key_ASV6_abundance",
  "Shannon -> key_ASV6_abundance",
  "betaNTI_mean -> Network_PC1",
  "key_ASV6_abundance -> Network_PC1",
  "Drought -> Negative_cohesion_strength",
  "Network_PC1 -> Negative_cohesion_strength",
  "key_ASV6_abundance -> Negative_cohesion_strength",
  "Drought -> SMF_meanZ",
  "key_ASV6_abundance -> SMF_meanZ",
  "Network_PC1 -> SMF_meanZ",
  "Negative_cohesion_strength -> SMF_meanZ",
  "Shannon -> SMF_meanZ",          # <--- 新增
  "Drought -> GPI_meanZ",
  "SMF_meanZ -> GPI_meanZ",
  "Drought -> Yield",
  "GPI_meanZ -> Yield"
)

coef_plot$Path <- factor(
  coef_plot$Path,
  levels = rev(path_order)
)

p_heat <- ggplot(
  coef_plot,
  aes(
    x = "Heading stage",
    y = Path,
    fill = Estimate
  )
) +
  geom_tile(color = "white") +
  geom_text(
    aes(label = label),
    size = 4
  ) +
  scale_fill_gradient2(
    low = "#3B4CC0",
    mid = "white",
    high = "#B40426",
    midpoint = 0,
    name = "Std. path\ncoef."
  ) +
  labs(
    x = NULL,
    y = NULL,
    title = "Heading-stage piecewise SEM path coefficients"
  ) +
  theme_bw(base_size = 13) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text.x = element_text(face = "bold"),
    axis.text.y = element_text(size = 10),
    panel.grid = element_blank()
  )

print(p_heat)

ggsave(
  "HS_SEM_path_coefficients_heatmap.png",
  p_heat,
  width = 7,
  height = 8,
  dpi = 300
)

ggsave(
  "HS_SEM_path_coefficients_heatmap.pdf",
  p_heat,
  width = 7,
  height = 8
)

# =========================================================
# 16. 直接效应 / 间接效应图
# =========================================================

var_label_map <- c(
  Drought = "Drought",
  Shannon = "Shannon",
  betaNTI_mean = "betaNTI",
  key_ASV6_abundance = "Key ASV6",
  Network_PC1 = "Network complexity",
  Negative_cohesion_strength = "Negative cohesion",
  SMF_meanZ = "SMF",
  GPI_meanZ = "PGI",
  Yield = "Yield"
)

target_label_map <- c(
  SMF_meanZ = "SMF",
  GPI_meanZ = "PGI",
  Yield = "Yield"
)

calc_sem_effects <- function(coef_df, target_var) {
  
  edge_df <- coef_df %>%
    dplyr::select(Predictor, Response, Estimate, P.Value) %>%
    distinct() %>%
    filter(!is.na(Estimate))
  
  if (nrow(edge_df) == 0) {
    stop("coef_plot 中没有可用于计算效应的路径。")
  }
  
  edge_df$edge_id <- paste(edge_df$Predictor, edge_df$Response, sep = "->")
  
  g <- igraph::graph_from_data_frame(
    edge_df[, c("Predictor", "Response", "Estimate")],
    directed = TRUE
  )
  
  E(g)$weight <- edge_df$Estimate
  
  all_nodes <- unique(c(edge_df$Predictor, edge_df$Response))
  pred_candidates <- setdiff(all_nodes, target_var)
  
  res_list <- lapply(pred_candidates, function(pred) {
    
    path_list <- igraph::all_simple_paths(
      g,
      from = pred,
      to = target_var,
      mode = "out"
    )
    
    if (length(path_list) == 0) {
      return(NULL)
    }
    
    path_df <- lapply(path_list, function(p) {
      vn <- igraph::V(g)[p]$name
      
      edge_keys <- paste(vn[-length(vn)], vn[-1], sep = "->")
      edge_vals <- edge_df$Estimate[match(edge_keys, edge_df$edge_id)]
      
      data.frame(
        Predictor = pred,
        Target = target_var,
        n_edges = length(edge_keys),
        path = paste(vn, collapse = " -> "),
        effect = prod(edge_vals),
        stringsAsFactors = FALSE
      )
    }) %>%
      bind_rows()
    
    direct_eff <- sum(path_df$effect[path_df$n_edges == 1], na.rm = TRUE)
    indirect_eff <- sum(path_df$effect[path_df$n_edges >= 2], na.rm = TRUE)
    total_eff <- direct_eff + indirect_eff
    
    data.frame(
      Predictor = pred,
      Target = target_var,
      Direct = direct_eff,
      Indirect = indirect_eff,
      Total = total_eff,
      stringsAsFactors = FALSE
    )
  })
  
  res <- bind_rows(res_list)
  
  if (nrow(res) == 0) {
    return(data.frame())
  }
  
  res %>%
    mutate(
      Predictor_label = dplyr::recode(Predictor, !!!var_label_map),
      Target_label = dplyr::recode(Target, !!!target_label_map)
    ) %>%
    arrange(desc(abs(Total)))
}

plot_sem_effect_bar <- function(effect_df, target_var, file_prefix = "HS_SEM") {
  
  df1 <- effect_df %>%
    filter(Target == target_var)
  
  if (nrow(df1) == 0) {
    warning(paste0("目标变量 ", target_var, " 没有可绘制的效应。"))
    return(NULL)
  }
  
  df1 <- df1 %>%
    filter(abs(Direct) > 1e-10 | abs(Indirect) > 1e-10)
  
  ord_df <- df1 %>%
    arrange(abs(Total))
  
  df_long <- df1 %>%
    dplyr::select(Predictor, Predictor_label, Target, Target_label, Direct, Indirect, Total) %>%
    tidyr::pivot_longer(
      cols = c(Direct, Indirect),
      names_to = "Effect_type",
      values_to = "Effect_size"
    ) %>%
    mutate(
      Effect_type = factor(
        Effect_type,
        levels = c("Direct", "Indirect")
      ),
      Predictor_label = factor(
        Predictor_label,
        levels = ord_df$Predictor_label
      )
    )
  
  p <- ggplot(
    df_long,
    aes(
      x = Effect_size,
      y = Predictor_label,
      fill = Effect_type
    )
  ) +
    geom_vline(xintercept = 0, color = "grey25", linewidth = 0.6) +
    geom_col(
      position = position_dodge(width = 0.72),
      width = 0.62,
      color = NA
    ) +
    scale_fill_manual(
      values = c(
        Direct = "#E9786A",
        Indirect = "#22B8BE"
      ),
      name = NULL
    ) +
    labs(
      x = "Standardized effect size (β)",
      y = NULL,
      title = paste0("Effects on ", unique(df_long$Target_label))
    ) +
    theme_bw(base_size = 13) +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold"),
      axis.text.y = element_text(color = "black"),
      axis.text.x = element_text(color = "black"),
      legend.position = "right",
      panel.grid.major.y = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", linewidth = 0.8)
    )
  
  print(p)
  
  ggsave(
    paste0(file_prefix, "_", target_var, "_direct_indirect_barplot.png"),
    p,
    width = 6.8,
    height = 4.8,
    dpi = 300
  )
  
  ggsave(
    paste0(file_prefix, "_", target_var, "_direct_indirect_barplot.pdf"),
    p,
    width = 6.8,
    height = 4.8
  )
  
  invisible(p)
}

effect_smf <- calc_sem_effects(coef_plot, "SMF_meanZ")
effect_gpi <- calc_sem_effects(coef_plot, "GPI_meanZ")
effect_yld <- calc_sem_effects(coef_plot, "Yield")

safe_write_csv(effect_smf, "HS_SEM_SMF_effects_direct_indirect_total.csv")
safe_write_csv(effect_gpi, "HS_SEM_PGI_effects_direct_indirect_total.csv")
safe_write_csv(effect_yld, "HS_SEM_Yield_effects_direct_indirect_total.csv")

plot_sem_effect_bar(effect_smf, "SMF_meanZ", file_prefix = "HS_SEM")
plot_sem_effect_bar(effect_gpi, "GPI_meanZ", file_prefix = "HS_SEM")
plot_sem_effect_bar(effect_yld, "Yield", file_prefix = "HS_SEM")

# =========================================================
# 17. 绘制 SEM 路径图
# =========================================================

node_map <- data.frame(
  node = c(
    "Drought",
    "Shannon",
    "betaNTI_mean",
    "key_ASV6_abundance",
    "Network_PC1",
    "Negative_cohesion_strength",
    "SMF_meanZ",
    "GPI_meanZ",
    "Yield"
  ),
  label = c(
    "Drought",
    "Shannon",
    "betaNTI",
    "Key ASV6",
    "Network\ncomplexity",
    "Negative\ncohesion",
    "SMF",
    "PGI",
    "Yield"
  ),
  x = c(
    0.06,
    0.28,
    0.28,
    0.48,
    0.68,
    0.88,
    0.88,
    1.08,
    1.08
  ),
  y = c(
    0.80,
    0.96,
    0.64,
    0.80,
    0.90,
    0.82,
    0.52,
    0.66,
    0.38
  ),
  stringsAsFactors = FALSE
)

path_template <- data.frame(
  from = c(
    "Drought",
    "Drought",
    "Drought", "betaNTI_mean", "Shannon",
    "betaNTI_mean", "key_ASV6_abundance",
    "Drought", "Network_PC1", "key_ASV6_abundance",
    "Drought", "key_ASV6_abundance", "Network_PC1", "Negative_cohesion_strength", "Shannon",
    "Drought", "SMF_meanZ",
    "Drought", "GPI_meanZ"
  ),
  to = c(
    "Shannon",
    "betaNTI_mean",
    "key_ASV6_abundance", "key_ASV6_abundance", "key_ASV6_abundance",
    "Network_PC1", "Network_PC1",
    "Negative_cohesion_strength", "Negative_cohesion_strength", "Negative_cohesion_strength",
    "SMF_meanZ", "SMF_meanZ", "SMF_meanZ", "SMF_meanZ", "SMF_meanZ",
    "GPI_meanZ", "GPI_meanZ",
    "Yield", "Yield"
  ),
  stringsAsFactors = FALSE
)

get_label_offset <- function(from, to) {
  key <- paste(from, to, sep = "->")
  
  off <- list(
    "Drought->Shannon" = c(0.00, 0.04),
    "Drought->betaNTI_mean" = c(0.00, -0.04),
    "Drought->key_ASV6_abundance" = c(-0.02, 0.04),
    "betaNTI_mean->key_ASV6_abundance" = c(0.00, -0.05),
    "Shannon->key_ASV6_abundance" = c(0.00, 0.06),
    "betaNTI_mean->Network_PC1" = c(0.00, -0.06),
    "key_ASV6_abundance->Network_PC1" = c(0.00, 0.04),
    "Drought->Negative_cohesion_strength" = c(0.00, 0.06),
    "Network_PC1->Negative_cohesion_strength" = c(0.00, 0.04),
    "key_ASV6_abundance->Negative_cohesion_strength" = c(0.00, -0.05),
    "Drought->SMF_meanZ" = c(0.00, -0.06),
    "key_ASV6_abundance->SMF_meanZ" = c(-0.02, -0.05),
    "Network_PC1->SMF_meanZ" = c(0.00, 0.06),
    "Negative_cohesion_strength->SMF_meanZ" = c(0.00, -0.05),
    "Shannon->SMF_meanZ" = c(0.02, 0.04), # <--- 新增偏移量避免重叠
    "Drought->GPI_meanZ" = c(0.00, 0.06),
    "SMF_meanZ->GPI_meanZ" = c(0.00, 0.04),
    "Drought->Yield" = c(0.00, -0.06),
    "GPI_meanZ->Yield" = c(0.00, 0.04)
  )
  
  if (key %in% names(off)) return(off[[key]])
  c(0, 0)
}

draw_node <- function(
    x,
    y,
    label,
    w = 0.12,
    h = 0.07,
    fill = "white",
    border = "grey20",
    cex = 0.85
) {
  symbols(
    x = x,
    y = y,
    rectangles = matrix(c(w, h), ncol = 2),
    inches = FALSE,
    add = TRUE,
    bg = fill,
    fg = border,
    lwd = 1.3
  )
  
  text(
    x,
    y,
    labels = label,
    cex = cex,
    font = 2
  )
}

draw_hs_sem_panel <- function(coef_df, fit_df = NULL, n_sample = NULL) {
  
  plot.new()
  plot.window(xlim = c(0.00, 1.20), ylim = c(0.24, 1.04))
  title(main = "Heading stage SEM", font.main = 2, line = 0.8, cex.main = 1.3)
  
  fmt_num <- function(x, digits = 3) {
    if (is.null(x) || length(x) == 0 || is.na(x)) return("NA")
    format(round(as.numeric(x), digits), nsmall = digits, trim = TRUE)
  }
  
  fmt_p <- function(x) {
    if (is.null(x) || length(x) == 0 || is.na(x)) return("NA")
    if (as.numeric(x) < 0.001) return("< 0.001")
    format(round(as.numeric(x), 3), nsmall = 3, trim = TRUE)
  }
  
  if (!is.null(fit_df) && nrow(fit_df) > 0) {
    fit_label <- paste0(
      "Model fit\n",
      "Fisher's C = ", fmt_num(fit_df$C[1]), "\n",
      "df = ", fmt_num(fit_df$df[1], digits = 0), "\n",
      "P = ", fmt_p(fit_df$P[1])
    )
    if (!is.null(n_sample)) {
      fit_label <- paste0(fit_label, "\nn = ", n_sample)
    }
  } else {
    fit_label <- NULL
  }
  
  dat <- coef_df
  dat$from <- dat$Predictor
  dat$to   <- dat$Response
  
  edges <- merge(
    path_template,
    dat,
    by = c("from", "to"),
    all.x = TRUE,
    sort = FALSE
  )
  
  for (i in seq_len(nrow(edges))) {
    
    est  <- edges$Estimate[i]
    pval <- edges$P.Value[i]
    
    if (is.na(est)) next
    
    p1 <- node_map[node_map$node == edges$from[i], ]
    p2 <- node_map[node_map$node == edges$to[i], ]
    
    if (nrow(p1) == 0 || nrow(p2) == 0) next
    
    edge_col <- ifelse(est >= 0, "#D95F5F", "#4C72B0")
    
    if (!is.na(pval) && pval < 0.05) {
      edge_lwd <- 2.0 + 4.5 * abs(est)
    } else {
      edge_lwd <- 1.0 + 1.6 * abs(est)
    }
    
    arrows(
      x0 = p1$x,
      y0 = p1$y,
      x1 = p2$x,
      y1 = p2$y,
      length = 0.06,
      angle = 20,
      lwd = edge_lwd,
      col = edge_col
    )
    
    sig <- ifelse(
      is.na(pval),
      "",
      ifelse(
        pval < 0.001,
        "***",
        ifelse(
          pval < 0.01,
          "**",
          ifelse(pval < 0.05, "*", "")
        )
      )
    )
    
    xm <- (p1$x + p2$x) / 2
    ym <- (p1$y + p2$y) / 2
    
    offs <- get_label_offset(edges$from[i], edges$to[i])
    
    lab <- paste0(sprintf("%.2f", est), sig)
    
    text(
      xm + offs[1],
      ym + offs[2],
      labels = lab,
      cex = 0.72,
      font = 2,
      col = "black"
    )
  }
  
  for (i in seq_len(nrow(node_map))) {
    draw_node(
      x = node_map$x[i],
      y = node_map$y[i],
      label = node_map$label[i],
      w = ifelse(
        node_map$node[i] %in% c("key_ASV6_abundance", "Negative_cohesion_strength"),
        0.16,
        0.12
      ),
      h = 0.07,
      fill = "white",
      border = "grey20",
      cex = 0.75
    )
  }
  
  legend(
    "bottomleft",
    legend = c("Positive path", "Negative path"),
    col = c("#D95F5F", "#4C72B0"),
    lwd = c(3, 3),
    lty = c(1, 1),
    bty = "n",
    cex = 0.8
  )
  
  if (!is.null(fit_label)) {
    text(
      x = 1.18,
      y = 0.27,
      labels = fit_label,
      adj = c(1, 0),
      cex = 0.78,
      font = 2
    )
  }
  
  box(lwd = 1)
}

pdf(
  "HS_SEM_path_diagram.pdf",
  width = 14,
  height = 8.5
)

draw_hs_sem_panel(coef_plot, fit_df = fit_tab, n_sample = nrow(dat_std))

dev.off()

png(
  "HS_SEM_path_diagram.png",
  width = 4200,
  height = 2550,
  res = 300
)

draw_hs_sem_panel(coef_plot, fit_df = fit_tab, n_sample = nrow(dat_std))

dev.off()

# =========================================================
# 18. 完成提示
# =========================================================

cat("\n抽穗期 SEM 完成！\n")
cat("主要输出文件：\n")
cat("1. HS_SEM_merged_all_period_table.csv\n")
cat("2. HS_SEM_input_complete_cases.csv\n")
cat("3. HS_SEM_key_ASV6_from_TITAN_table.csv\n")
cat("4. HS_SEM_key_ASV6_abundance_by_sample.csv\n")
cat("5. HS_SEM_Network_PC1_loadings.csv\n")
cat("6. HS_SEM_Network_PC1_variance.csv\n")
cat("7. HS_SEM_summary.txt\n")
cat("8. HS_SEM_piecewise_coefficients_raw.csv\n")
cat("9. HS_SEM_piecewise_R2.csv\n")
cat("10. HS_SEM_piecewise_fit.csv\n")
cat("11. HS_SEM_directed_separation_tests.csv\n")
cat("12. HS_SEM_path_coefficients_for_plot.csv\n")
cat("13. HS_SEM_path_coefficients_heatmap.png / pdf\n")
cat("14. HS_SEM_SMF/PIG/Yield direct_indirect_barplot.png / pdf\n")
cat("15. HS_SEM_path_diagram.png / pdf\n")

```