# =========================================================
# 0. 环境与包
# =========================================================
rm(list = ls())
gc()

library(tidyverse)
library(igraph)
library(scales)
library(microeco)
library(ggplot2)
library(ggpubr)
library(rstatix)
library(ggplotify)
library(cowplot)
library(patchwork)

setwd("D:/IUE/山西数据/真菌/抽平/真菌_网络分析")

# =========================================================
# 1. 读取数据（根际）
# =========================================================
asv <- read.csv("根内网络.csv", check.names = FALSE)
group <- read.csv("根内分组.csv", check.names = FALSE)
colnames(group) <- c("Sample", "Group")

# 去掉无用列
asv <- asv[, !grepl("^Unnamed", colnames(asv))]

# taxonomy 信息
tax <- asv[, 1:4]
colnames(tax)[1] <- "Function"
rownames(tax) <- asv[, 4]

# otu 丰度表
otu <- asv[, -(1:4)]
rownames(otu) <- asv[, 4]

# 样本对齐
common_samples <- intersect(colnames(otu), group$Sample)
otu <- otu[, common_samples, drop = FALSE]
group <- group %>% filter(Sample %in% common_samples)

# =========================================================
# 2. 提取时期和干旱信息
# =========================================================
group <- group %>%
  mutate(
    Period = case_when(
      str_detect(Group, "^JS_") ~ "JS",
      str_detect(Group, "^HS_") ~ "HS",
      str_detect(Group, "^FS_") ~ "FS",
      str_detect(Group, "^MS_") ~ "MS",
      TRUE ~ NA_character_
    ),
    Period_full = case_when(
      str_detect(Group, "^JS_") ~ "Jointing stage",
      str_detect(Group, "^HS_") ~ "Heading stage",
      str_detect(Group, "^FS_") ~ "Filling stage",
      str_detect(Group, "^MS_") ~ "Maturity stage",
      TRUE ~ NA_character_
    ),
    Drought = case_when(
      str_detect(Group, "_Control$")   ~ "Control",
      str_detect(Group, "_Drought_L$") ~ "Drought_L",
      str_detect(Group, "_Drought_M$") ~ "Drought_M",
      str_detect(Group, "_Drought_H$") ~ "Drought_H",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(Period), !is.na(Drought))

group$Period <- factor(group$Period, levels = c("JS", "HS", "FS", "MS"))
group$Period_full <- factor(
  group$Period_full,
  levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
)
group$Drought <- factor(
  group$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

# =========================================================
# 3. 参数设置（SpiecEasi）
# =========================================================
base_outdir <- "5.19根内_按时期_SpiecEasi_meta_network_final"
dir.create(base_outdir, showWarnings = FALSE, recursive = TRUE)

# taxa 过滤参数
REL_ABUND_CUTOFF <- 0.0001
FREQ_CUTOFF      <- 0.20

# SpiecEasi 参数
SPIEC_METHOD      <- "mb"
LAMBDA_MIN_RATIO  <- 0.01
NLAMBDA           <- 20
SEL_CRITERION     <- "bstars"
PULSAR_REP_NUM    <- 20
PULSAR_SEED       <- 123
PULSAR_NCORES     <- 1

# 关键指标：做合并差异图
KEY_METRICS <- c(
  "edges_num",
  "average_degree",
  "network_density",
  "modularity",
  "complexity"
)

# 干旱颜色（用于差异图）
drought_cols <- c(
  "Control"   = "#F8766D",
  "Drought_L" = "#7CAE00",
  "Drought_M" = "#00BFC4",
  "Drought_H" = "#C77CFF"
)

# =========================================================
# 4. 固定功能颜色映射（网络图和ZIPI图统一）
#    指定7个功能固定颜色；NA灰色；其它功能统一棕色
# =========================================================
global_func_cols <- c(
  "plant_pathogen"         = "#69aed5",
  "soil_saprotroph"        = "#84B300",
  "dung_saprotroph"        = "#00BFC4",
  "unspecified_saprotroph" = "#B07BE3",
  "litter_saprotroph"      = "#f8766d",
  "animal_parasite"        = "#84C492",
  "wood_saprotroph"        = "#e6ab02",
  "Other"                  = "#8C6D31",
  "NA"                     = "grey70"
)

recode_function_group <- function(x) {
  x <- as.character(x)
  x[is.na(x) | x == ""] <- "NA"
  
  keep_funcs <- c(
    "plant_pathogen",
    "soil_saprotroph",
    "dung_saprotroph",
    "unspecified_saprotroph",
    "litter_saprotroph",
    "animal_parasite",
    "wood_saprotroph"
  )
  
  x2 <- ifelse(x %in% keep_funcs, x, "Other")
  x2[x == "NA"] <- "NA"
  x2
}

# =========================================================
# 5. 辅助函数：安全计算网络参数
# =========================================================
safe_mean_distance <- function(g) {
  if (vcount(g) < 2 || ecount(g) < 1) return(NA_real_)
  comps <- components(g)
  giant_id <- which.max(comps$csize)
  g_giant <- induced_subgraph(g, vids = V(g)[comps$membership == giant_id])
  if (vcount(g_giant) < 2 || ecount(g_giant) < 1) return(NA_real_)
  mean_distance(g_giant, directed = FALSE, weights = NA)
}

safe_diameter <- function(g) {
  if (vcount(g) < 2 || ecount(g) < 1) return(NA_real_)
  comps <- components(g)
  giant_id <- which.max(comps$csize)
  g_giant <- induced_subgraph(g, vids = V(g)[comps$membership == giant_id])
  if (vcount(g_giant) < 2 || ecount(g_giant) < 1) return(NA_real_)
  diameter(g_giant, directed = FALSE, weights = NA)
}

safe_modularity <- function(g) {
  if (vcount(g) < 2 || ecount(g) < 1) {
    return(list(modules_num = NA_real_, modularity = NA_real_))
  }
  
  comm <- tryCatch(
    cluster_fast_greedy(as.undirected(g)),
    error = function(e) NULL
  )
  
  if (is.null(comm)) {
    return(list(modules_num = NA_real_, modularity = NA_real_))
  } else {
    return(list(
      modules_num = length(comm),
      modularity  = modularity(comm)
    ))
  }
}


# =========================================================
# 5B. 追加：时期整体网络鲁棒性分析函数
#     只基于已经构建好的 g_meta，不改变建网逻辑和网络参数
# =========================================================
rob_giant_fraction <- function(g) {
  if (vcount(g) == 0) return(0)
  comps <- components(g)
  max(comps$csize) / vcount(g)
}

rob_global_efficiency <- function(g) {
  if (vcount(g) < 2 || ecount(g) < 1) return(0)
  
  d <- distances(g, weights = NA)
  diag(d) <- NA
  
  inv_d <- 1 / d
  inv_d[is.infinite(inv_d)] <- 0
  
  eff <- mean(inv_d[!is.na(inv_d)])
  
  if (is.nan(eff) || is.na(eff)) eff <- 0
  
  return(eff)
}

calc_period_robustness_curve <- function(
    g,
    period_name,
    mode = c("random", "degree"),
    remove_seq = seq(0, 0.9, by = 0.1),
    nrep = 100,
    seed = 123
) {
  
  mode <- match.arg(mode)
  set.seed(seed)
  
  g0 <- as.undirected(g, mode = "collapse")
  g0 <- delete_vertices(g0, which(degree(g0) == 0))
  
  if (vcount(g0) < 2 || ecount(g0) < 1) {
    return(data.frame(
      Period = period_name,
      mode = mode,
      rep = 1,
      remove_fraction = remove_seq,
      giant_fraction = NA_real_,
      edge_fraction = NA_real_,
      efficiency = NA_real_
    ))
  }
  
  n0 <- vcount(g0)
  e0 <- ecount(g0)
  
  out_list <- list()
  
  for (rp in seq_len(nrep)) {
    
    if (mode == "random") {
      remove_order <- sample(V(g0)$name, n0, replace = FALSE)
    }
    
    if (mode == "degree") {
      deg0 <- degree(g0)
      remove_order <- names(sort(deg0, decreasing = TRUE))
    }
    
    tmp <- lapply(remove_seq, function(fr) {
      
      n_remove <- floor(fr * n0)
      
      if (n_remove == 0) {
        g_sub <- g0
      } else {
        remove_nodes <- remove_order[1:n_remove]
        g_sub <- delete_vertices(g0, remove_nodes)
      }
      
      data.frame(
        Period = period_name,
        mode = mode,
        rep = rp,
        remove_fraction = fr,
        giant_fraction = rob_giant_fraction(g_sub),
        edge_fraction = ifelse(e0 > 0, ecount(g_sub) / e0, NA_real_),
        efficiency = rob_global_efficiency(g_sub)
      )
    })
    
    out_list[[rp]] <- bind_rows(tmp)
  }
  
  bind_rows(out_list)
}

calc_period_robustness_auc <- function(curve_df) {
  
  curve_df %>%
    group_by(Period, mode, rep) %>%
    arrange(remove_fraction) %>%
    summarise(
      robustness_giant_auc = sum(
        diff(remove_fraction) *
          (head(giant_fraction, -1) + tail(giant_fraction, -1)) / 2,
        na.rm = TRUE
      ),
      robustness_edge_auc = sum(
        diff(remove_fraction) *
          (head(edge_fraction, -1) + tail(edge_fraction, -1)) / 2,
        na.rm = TRUE
      ),
      robustness_efficiency_auc = sum(
        diff(remove_fraction) *
          (head(efficiency, -1) + tail(efficiency, -1)) / 2,
        na.rm = TRUE
      ),
      .groups = "drop"
    ) %>%
    group_by(Period, mode) %>%
    summarise(
      robustness_giant_auc_mean = mean(robustness_giant_auc, na.rm = TRUE),
      robustness_giant_auc_sd   = sd(robustness_giant_auc, na.rm = TRUE),
      robustness_edge_auc_mean  = mean(robustness_edge_auc, na.rm = TRUE),
      robustness_edge_auc_sd    = sd(robustness_edge_auc, na.rm = TRUE),
      robustness_efficiency_auc_mean = mean(robustness_efficiency_auc, na.rm = TRUE),
      robustness_efficiency_auc_sd   = sd(robustness_efficiency_auc, na.rm = TRUE),
      .groups = "drop"
    )
}

# =========================================================
# 6. 函数：计算单个样本子网络参数
# =========================================================
calc_sample_subgraph_metrics <- function(sample_name, otu_rel, g_meta) {
  
  present_taxa <- rownames(otu_rel)[otu_rel[, sample_name] > 0]
  present_taxa <- intersect(present_taxa, V(g_meta)$name)
  
  if (length(present_taxa) < 2) {
    return(data.frame(
      Sample = sample_name,
      nodes_num = length(present_taxa),
      edges_num = 0,
      average_degree = NA_real_,
      network_density = NA_real_,
      clustering_coefficient = NA_real_,
      average_clustering = NA_real_,
      average_path_length = NA_real_,
      network_diameter = NA_real_,
      modules_num = NA_real_,
      modularity = NA_real_,
      complexity = NA_real_
    ))
  }
  
  g_sub <- induced_subgraph(g_meta, vids = present_taxa)
  
  if (vcount(g_sub) < 2) {
    return(data.frame(
      Sample = sample_name,
      nodes_num = vcount(g_sub),
      edges_num = ecount(g_sub),
      average_degree = NA_real_,
      network_density = NA_real_,
      clustering_coefficient = NA_real_,
      average_clustering = NA_real_,
      average_path_length = NA_real_,
      network_diameter = NA_real_,
      modules_num = NA_real_,
      modularity = NA_real_,
      complexity = NA_real_
    ))
  }
  
  mod_res <- safe_modularity(g_sub)
  
  avg_clust <- tryCatch(
    mean(transitivity(g_sub, type = "local"), na.rm = TRUE),
    error = function(e) NA_real_
  )
  if (is.nan(avg_clust)) avg_clust <- NA_real_
  
  data.frame(
    Sample = sample_name,
    nodes_num = vcount(g_sub),
    edges_num = ecount(g_sub),
    average_degree = mean(degree(g_sub)),
    network_density = if (vcount(g_sub) > 1) edge_density(g_sub) else NA_real_,
    clustering_coefficient = if (vcount(g_sub) > 2) transitivity(g_sub, type = "global") else NA_real_,
    average_clustering = avg_clust,
    average_path_length = safe_mean_distance(g_sub),
    network_diameter = safe_diameter(g_sub),
    modules_num = mod_res$modules_num,
    modularity = mod_res$modularity,
    complexity = ifelse(vcount(g_sub) > 0, ecount(g_sub) / vcount(g_sub), NA_real_)
  )
}

# =========================================================
# 7. 函数：单个网络基础图（base），用于合并
#    去掉边标签；底部标注节点数和边数
# =========================================================
plot_meta_network_base <- function(g, tax, title_txt, func_cols) {
  
  g_plot <- delete_vertices(g, which(degree(g) == 0))
  
  if (vcount(g_plot) == 0) {
    plot.new()
    title(main = paste0(title_txt, "\n(no connected nodes)"))
    return(invisible(NULL))
  }
  
  # 节点 Function
  V(g_plot)$Function_raw <- tax[V(g_plot)$name, "Function"]
  V(g_plot)$Function <- recode_function_group(V(g_plot)$Function_raw)
  
  node_func <- as.character(V(g_plot)$Function)
  V(g_plot)$color <- func_cols[node_func]
  V(g_plot)$color[is.na(V(g_plot)$color)] <- "grey70"
  
  # 节点大小
  deg_vals <- degree(g_plot)
  if (length(unique(deg_vals)) > 1) {
    V(g_plot)$size <- rescale(deg_vals, to = c(4, 10))
  } else {
    V(g_plot)$size <- 7
  }
  
  # 边宽
  if (!is.null(E(g_plot)$weight)) {
    w_abs <- abs(E(g_plot)$weight)
    if (length(unique(w_abs)) > 1) {
      E(g_plot)$width <- rescale(w_abs, to = c(0.5, 2.2))
    } else {
      E(g_plot)$width <- 1
    }
  } else {
    E(g_plot)$width <- 1
  }
  
  # 边颜色统一灰色；去掉边标签（即不显示 +/-）
  E(g_plot)$color <- "grey70"
  
  lay <- layout_with_fr(g_plot)
  
  plot(
    g_plot,
    layout = lay,
    vertex.label = NA,
    edge.label = NA,
    edge.curved = 0.3,
    main = title_txt,
    margin = 0.2
  )
  
  mtext(
    side = 1,
    line = 1,
    cex = 0.9,
    text = paste0("Nodes = ", vcount(g_plot), "    Edges = ", ecount(g_plot))
  )
}

# =========================================================
# 8. 函数：单独导出单个网络图
# =========================================================
save_single_network_pdf <- function(g, tax, title_txt, func_cols, file) {
  pdf(file, width = 8, height = 8)
  par(mar = c(2.5, 1.5, 3, 1.5))
  plot_meta_network_base(g, tax, title_txt, func_cols)
  dev.off()
}

# =========================================================
# 9. 函数：创建共享图例
# =========================================================
make_shared_legend <- function(func_cols) {
  legend_df <- data.frame(
    Function = factor(names(func_cols), levels = names(func_cols)),
    x = 1,
    y = seq_along(func_cols)
  )
  
  p_leg <- ggplot(legend_df, aes(x = x, y = y, color = Function)) +
    geom_point(size = 4) +
    scale_color_manual(values = func_cols, drop = FALSE) +
    theme_void() +
    theme(
      legend.position = "right",
      legend.title = element_text(size = 11),
      legend.text = element_text(size = 9)
    ) +
    guides(color = guide_legend(title = "Function", ncol = 1))
  
  cowplot::get_legend(p_leg)
}

# =========================================================
# 10. 函数：按示例风格作图
#     geom_boxplot + geom_jitter + facet_wrap + Dunn(BH) + stat_pvalue_manual
# =========================================================
plot_metric_faceted_dunn <- function(dat, metric_name) {
  
  plot_df <- dat %>%
    select(Sample, Period_full, Drought, all_of(metric_name)) %>%
    rename(Value = all_of(metric_name)) %>%
    filter(!is.na(Value), !is.na(Drought), !is.na(Period_full))
  
  plot_df$Drought <- factor(
    plot_df$Drought,
    levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
  )
  plot_df$Period_full <- factor(
    plot_df$Period_full,
    levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
  )
  
  # Dunn 检验（和示例代码一致）
  stat_df <- plot_df %>%
    group_by(Period_full) %>%
    dunn_test(as.formula(paste0("Value ~ Drought")), p.adjust.method = "BH") %>%
    filter(p.adj < 0.05) %>%
    add_xy_position(x = "Drought")
  
  p <- ggplot(
    plot_df,
    aes(x = Drought, y = Value, fill = Drought)
  ) +
    geom_boxplot(width = 0.6, outlier.shape = NA) +
    geom_jitter(width = 0.15, size = 1, alpha = 0.7) +
    facet_wrap(~ Period_full, nrow = 1, scales = "free_y") +
    scale_fill_manual(values = drought_cols) +
    theme_bw() +
    labs(
      x = "Drought treatment",
      y = metric_name
    ) +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "none",
      strip.text = element_text(size = 12)
    )
  
  if (nrow(stat_df) > 0) {
    p <- p +
      stat_pvalue_manual(
        stat_df,
        label = "p.adj.signif",
        hide.ns = TRUE
      )
  }
  
  return(list(plot = p, stat = stat_df))
}

# =========================================================
# 11. 按时期建整体网络（SpiecEasi），再提取样本子网络
# =========================================================
periods <- c("JS", "HS", "FS", "MS")

all_period_metrics <- list()
all_period_network_param <- list()
all_period_graphs <- list()
all_period_tax <- list()

# 追加：保存时期整体网络鲁棒性结果
all_period_robustness_curve <- list()
all_period_robustness_auc <- list()


for (pd in periods) {
  
  cat("\n=====================================\n")
  cat("Processing Period:", pd, "\n")
  cat("=====================================\n")
  
  outdir_pd <- file.path(base_outdir, pd)
  dir.create(outdir_pd, showWarnings = FALSE, recursive = TRUE)
  
  # 当前时期样本
  group_pd <- group %>% filter(Period == pd)
  samples_pd <- group_pd$Sample
  otu_pd <- otu[, samples_pd, drop = FALSE]
  
  # 相对丰度（用于样本子图提取）
  otu_rel_pd <- sweep(otu_pd, 2, colSums(otu_pd), "/")
  otu_rel_pd[is.na(otu_rel_pd)] <- 0
  
  # ------------------------------
  # 用 microeco + SpiecEasi 建立该时期整体网络
  # ------------------------------
  micro_pd <- as.data.frame(otu_pd)
  tax_pd   <- tax[rownames(micro_pd), , drop = FALSE]
  
  sample_pd <- group_pd %>% as.data.frame()
  rownames(sample_pd) <- sample_pd$Sample
  
  dataset_pd <- microtable$new(
    otu_table = micro_pd,
    sample_table = sample_pd,
    tax_table = tax_pd
  )
  
  dataset_pd$filter_taxa(
    rel_abund = REL_ABUND_CUTOFF,
    freq = FREQ_CUTOFF
  )
  
  cat(
    "After filtering:",
    "taxa =", nrow(dataset_pd$otu_table),
    "samples =", nrow(dataset_pd$sample_table), "\n"
  )
  
  t1 <- trans_network$new(
    dataset = dataset_pd,
    cor_method = NULL,
    group_column = "Drought"
  )
  
  pargs2 <- list(
    rep.num = PULSAR_REP_NUM,
    seed = PULSAR_SEED,
    ncores = PULSAR_NCORES
  )
  
  t1$cal_network(
    network_method = "SpiecEasi",
    SpiecEasi_method = SPIEC_METHOD,
    lambda.min.ratio = LAMBDA_MIN_RATIO,
    nlambda = NLAMBDA,
    sel.criterion = SEL_CRITERION,
    pulsar.select = TRUE,
    pulsar.params = pargs2
  )
  
  g_meta <- t1$res_network
  
  cat(
    "Meta-network built:",
    "nodes =", vcount(g_meta),
    "edges =", ecount(g_meta), "\n"
  )
  

  # ------------------------------
  # 追加：时期整体网络鲁棒性分析
  # 只使用当前时期已经构建好的 g_meta
  # 不改变网络构建逻辑、不改变原有网络参数计算
  # ------------------------------
  cat("Calculating period-level network robustness:", pd, "\n")
  
  rob_random_pd <- calc_period_robustness_curve(
    g = g_meta,
    period_name = pd,
    mode = "random",
    remove_seq = seq(0, 0.9, by = 0.1),
    nrep = 100,
    seed = PULSAR_SEED
  )
  
  rob_degree_pd <- calc_period_robustness_curve(
    g = g_meta,
    period_name = pd,
    mode = "degree",
    remove_seq = seq(0, 0.9, by = 0.1),
    nrep = 1,
    seed = PULSAR_SEED
  )
  
  rob_curve_pd <- bind_rows(
    rob_random_pd,
    rob_degree_pd
  )
  
  write.csv(
    rob_curve_pd,
    file.path(outdir_pd, paste0(pd, "_period_network_robustness_curve.csv")),
    row.names = FALSE
  )
  
  rob_auc_pd <- calc_period_robustness_auc(rob_curve_pd)
  
  write.csv(
    rob_auc_pd,
    file.path(outdir_pd, paste0(pd, "_period_network_robustness_AUC.csv")),
    row.names = FALSE
  )
  
  all_period_robustness_curve[[pd]] <- rob_curve_pd
  all_period_robustness_auc[[pd]] <- rob_auc_pd
  
  # 保存整体网络
  saveRDS(
    g_meta,
    file.path(outdir_pd, paste0(pd, "_meta_network_SpiecEasi.rds"))
  )
  write_graph(
    g_meta,
    file.path(outdir_pd, paste0(pd, "_meta_network_SpiecEasi.graphml")),
    format = "graphml"
  )
  
  # 给网络补 taxonomy 属性
  node_names <- V(g_meta)$name
  tax_use <- dataset_pd$tax_table[node_names, , drop = FALSE]
  
  for (col_name in colnames(tax_use)) {
    g_meta <- set_vertex_attr(
      g_meta,
      name = col_name,
      value = as.character(tax_use[[col_name]])
    )
  }
  
  # 存起来，后面合并作图
  all_period_graphs[[pd]] <- g_meta
  all_period_tax[[pd]] <- dataset_pd$tax_table
  
  # 单独导出单个网络图
  save_single_network_pdf(
    g = g_meta,
    tax = dataset_pd$tax_table,
    title_txt = paste0("Endosphere ", pd, " meta-network (SpiecEasi)"),
    func_cols = global_func_cols,
    file = file.path(outdir_pd, paste0(pd, "_meta_network.pdf"))
  )
  
  # ------------------------------
  # 整体网络参数
  # ------------------------------
  mod_meta <- safe_modularity(g_meta)
  
  avg_clust_meta <- tryCatch(
    mean(transitivity(g_meta, type = "local"), na.rm = TRUE),
    error = function(e) NA_real_
  )
  if (is.nan(avg_clust_meta)) avg_clust_meta <- NA_real_
  
  network_param_meta <- data.frame(
    Period = pd,
    Sample_number = ncol(dataset_pd$otu_table),
    nodes_num = vcount(g_meta),
    edges_num = ecount(g_meta),
    average_degree = if (vcount(g_meta) > 0) mean(degree(g_meta)) else NA_real_,
    network_density = if (vcount(g_meta) > 1) edge_density(g_meta) else NA_real_,
    clustering_coefficient = if (vcount(g_meta) > 2) transitivity(g_meta, type = "global") else NA_real_,
    average_clustering = avg_clust_meta,
    average_path_length = safe_mean_distance(g_meta),
    network_diameter = safe_diameter(g_meta),
    modules_num = mod_meta$modules_num,
    modularity = mod_meta$modularity,
    complexity = ifelse(vcount(g_meta) > 0, ecount(g_meta) / vcount(g_meta), NA_real_)
  )
  
  write.csv(
    network_param_meta,
    file.path(outdir_pd, paste0(pd, "_meta_network_parameter.csv")),
    row.names = FALSE
  )
  
  all_period_network_param[[pd]] <- network_param_meta
  
  # ------------------------------
  # 样本子网络参数
  # ------------------------------
  otu_rel_pd2 <- otu_rel_pd[rownames(dataset_pd$otu_table), , drop = FALSE]
  
  sample_metrics_pd <- map_dfr(
    colnames(otu_rel_pd2),
    calc_sample_subgraph_metrics,
    otu_rel = otu_rel_pd2,
    g_meta = g_meta
  )
  
  sample_metrics_pd <- sample_metrics_pd %>%
    left_join(group_pd, by = "Sample")
  
  write.csv(
    sample_metrics_pd,
    file.path(outdir_pd, paste0(pd, "_sample_specific_subnetwork_metrics.csv")),
    row.names = FALSE
  )
  
  all_period_metrics[[pd]] <- sample_metrics_pd
}

# =========================================================
# 12. 合并四个时期结果
# =========================================================
all_sample_metrics <- bind_rows(all_period_metrics)
all_meta_param <- bind_rows(all_period_network_param)

write.csv(
  all_sample_metrics,
  file.path(base_outdir, "Endosphere_all_period_sample_specific_subnetwork_metrics.csv"),
  row.names = FALSE
)

write.csv(
  all_meta_param,
  file.path(base_outdir, "Endosphere_all_period_meta_network_parameters.csv"),
  row.names = FALSE
)


# =========================================================
# 12B. 追加：合并四个时期整体网络鲁棒性结果
# =========================================================
all_robustness_curve <- bind_rows(all_period_robustness_curve)
all_robustness_auc <- bind_rows(all_period_robustness_auc)

write.csv(
  all_robustness_curve,
  file.path(base_outdir, "Endosphere_all_period_network_robustness_curve.csv"),
  row.names = FALSE
)

write.csv(
  all_robustness_auc,
  file.path(base_outdir, "Endosphere_all_period_network_robustness_AUC.csv"),
  row.names = FALSE
)

# =========================================================
# 12C. 追加：时期整体网络鲁棒性线图
# =========================================================
period_cols <- c(
  "JS" = "#F8766D",
  "HS" = "#7CAE00",
  "FS" = "#00BFC4",
  "MS" = "#C77CFF"
)

rob_curve_summary <- all_robustness_curve %>%
  group_by(Period, mode, remove_fraction) %>%
  summarise(
    giant_fraction_mean = mean(giant_fraction, na.rm = TRUE),
    giant_fraction_sd   = sd(giant_fraction, na.rm = TRUE),
    edge_fraction_mean  = mean(edge_fraction, na.rm = TRUE),
    edge_fraction_sd    = sd(edge_fraction, na.rm = TRUE),
    efficiency_mean     = mean(efficiency, na.rm = TRUE),
    efficiency_sd       = sd(efficiency, na.rm = TRUE),
    .groups = "drop"
  )

rob_curve_summary$Period <- factor(
  rob_curve_summary$Period,
  levels = c("JS", "HS", "FS", "MS")
)

rob_curve_summary$mode <- factor(
  rob_curve_summary$mode,
  levels = c("random", "degree"),
  labels = c("Random removal", "Degree-targeted removal")
)

# 最大连通子图比例鲁棒性曲线
p_rob_giant <- ggplot(
  rob_curve_summary,
  aes(
    x = remove_fraction,
    y = giant_fraction_mean,
    color = Period,
    group = Period
  )
) +
  geom_line(linewidth = 1) +
  geom_point(size = 2) +
  facet_wrap(~ mode, nrow = 1) +
  scale_color_manual(values = period_cols) +
  theme_bw(base_size = 12) +
  labs(
    x = "Removed node fraction",
    y = "Relative size of giant component",
    title = "Robustness of period-level rhizosphere networks"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(color = "black"),
    legend.title = element_blank()
  )

print(p_rob_giant)

ggsave(
  filename = file.path(base_outdir, "Endosphere_period_network_robustness_giant_component_curve.pdf"),
  plot = p_rob_giant,
  width = 8,
  height = 4.5
)

ggsave(
  filename = file.path(base_outdir, "Endosphere_period_network_robustness_giant_component_curve.png"),
  plot = p_rob_giant,
  width = 8,
  height = 4.5,
  dpi = 300
)

# 三个鲁棒性指标合并线图
rob_curve_long <- rob_curve_summary %>%
  select(
    Period,
    mode,
    remove_fraction,
    giant_fraction_mean,
    edge_fraction_mean,
    efficiency_mean
  ) %>%
  pivot_longer(
    cols = c(
      giant_fraction_mean,
      edge_fraction_mean,
      efficiency_mean
    ),
    names_to = "Robustness_metric",
    values_to = "Value"
  ) %>%
  mutate(
    Robustness_metric = recode(
      Robustness_metric,
      "giant_fraction_mean" = "Giant component",
      "edge_fraction_mean"  = "Remaining edges",
      "efficiency_mean"     = "Global efficiency"
    )
  )

p_rob_combined <- ggplot(
  rob_curve_long,
  aes(
    x = remove_fraction,
    y = Value,
    color = Period,
    group = Period
  )
) +
  geom_line(linewidth = 1) +
  geom_point(size = 1.8) +
  facet_grid(Robustness_metric ~ mode, scales = "free_y") +
  scale_color_manual(values = period_cols) +
  theme_bw(base_size = 12) +
  labs(
    x = "Removed node fraction",
    y = NULL,
    title = "Network robustness of period-level Endosphere networks"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    strip.text = element_text(face = "bold"),
    axis.text = element_text(color = "black"),
    legend.title = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold")
  )

print(p_rob_combined)

ggsave(
  filename = file.path(base_outdir, "Endosphere_period_network_robustness_combined_curve.pdf"),
  plot = p_rob_combined,
  width = 9,
  height = 8
)

ggsave(
  filename = file.path(base_outdir, "Endosphere_period_network_robustness_combined_curve.png"),
  plot = p_rob_combined,
  width = 9,
  height = 8,
  dpi = 300
)

# =========================================================
# 13. 合并四个网络图 + 统一图例 + 下方节点边数标注
#     并在 R 中直接显示
# =========================================================
network_plot_list <- list()

for (pd in periods) {
  g_tmp <- all_period_graphs[[pd]]
  tax_tmp <- all_period_tax[[pd]]
  
  network_plot_list[[pd]] <- ggplotify::as.ggplot(~{
    par(mar = c(2.5, 1.5, 3, 1.5))
    plot_meta_network_base(
      g = g_tmp,
      tax = tax_tmp,
      title_txt = paste0("Endosphere ", pd),
      func_cols = global_func_cols
    )
  })
}

legend_grob <- make_shared_legend(global_func_cols)

network_grid <- cowplot::plot_grid(
  plotlist = network_plot_list,
  ncol = 2
)

network_combined <- cowplot::plot_grid(
  network_grid,
  legend_grob,
  ncol = 2,
  rel_widths = c(1, 0.28)
)

# R 中直接显示
print(network_combined)

ggsave(
  filename = file.path(base_outdir, "Endosphere_all_period_meta_network_combined.pdf"),
  plot = network_combined,
  width = 14,
  height = 10
)

ggsave(
  filename = file.path(base_outdir, "Endosphere_all_period_meta_network_combined.png"),
  plot = network_combined,
  width = 14,
  height = 10,
  dpi = 300
)

library(agricolae)
library(multcompView)

# =========================================================
# =========================================================
# =========================================================
# 14. 网络拓扑参数：折线式雷达图
#     使用样本子网络参数，不改变前面网络构建和参数计算
#     指标包括：
#     Edges, Degree, Density, Clustering,
#     Path efficiency, Modularity, Complexity
#     星号表示每个时期内该指标在四个干旱处理间的总体差异
# =========================================================

# ---------------------------------------------------------
# 14.1 增加路径效率指标
#      average_path_length 越小，路径越短；
#      转换为 path_efficiency 后，数值越大表示连接效率越高
# ---------------------------------------------------------

all_sample_metrics <- all_sample_metrics %>%
  mutate(
    path_efficiency = ifelse(
      is.na(average_path_length) | average_path_length <= 0,
      NA_real_,
      1 / average_path_length
    )
  )

# ---------------------------------------------------------
# 14.2 设置雷达图指标
# ---------------------------------------------------------

RADAR_METRICS_SAMPLE <- c(
  "edges_num",
  "average_degree",
  "network_density",
  "clustering_coefficient",
  "path_efficiency",
  "modularity",
  "complexity"
)

metric_labels <- c(
  "edges_num"              = "Edges",
  "average_degree"         = "Degree",
  "network_density"        = "Density",
  "clustering_coefficient" = "Clustering",
  "path_efficiency"        = "Path efficiency",
  "modularity"             = "Modularity",
  "complexity"             = "Complexity"
)

# ---------------------------------------------------------
# 14.3 计算 Period × Drought 下各网络参数均值
# ---------------------------------------------------------

radar_sample_df <- all_sample_metrics %>%
  select(Sample, Period_full, Drought, all_of(RADAR_METRICS_SAMPLE)) %>%
  group_by(Period_full, Drought) %>%
  summarise(
    across(
      all_of(RADAR_METRICS_SAMPLE),
      ~ {
        x <- .x
        if (all(is.na(x))) {
          NA_real_
        } else {
          mean(x, na.rm = TRUE)
        }
      }
    ),
    .groups = "drop"
  ) %>%
  pivot_longer(
    cols = all_of(RADAR_METRICS_SAMPLE),
    names_to = "Metric",
    values_to = "Value"
  )

# ---------------------------------------------------------
# 14.4 0-1 标准化，仅用于雷达图展示；原始参数不改变
# ---------------------------------------------------------

radar_sample_df <- radar_sample_df %>%
  group_by(Metric) %>%
  mutate(
    Value_scaled = case_when(
      all(is.na(Value)) ~ NA_real_,
      max(Value, na.rm = TRUE) == min(Value, na.rm = TRUE) ~ 0.5,
      TRUE ~ (Value - min(Value, na.rm = TRUE)) /
        (max(Value, na.rm = TRUE) - min(Value, na.rm = TRUE))
    )
  ) %>%
  ungroup()

radar_sample_df$Metric <- factor(
  radar_sample_df$Metric,
  levels = RADAR_METRICS_SAMPLE,
  labels = metric_labels[RADAR_METRICS_SAMPLE]
)

radar_sample_df$Drought <- factor(
  radar_sample_df$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

radar_sample_df$Period_full <- factor(
  radar_sample_df$Period_full,
  levels = c(
    "Jointing stage",
    "Heading stage",
    "Filling stage",
    "Maturity stage"
  )
)

# ---------------------------------------------------------
# 14.5 显著性检验：
#      每个时期内，每个指标检验四个干旱处理是否存在总体差异
#      Kruskal-Wallis + BH 校正
# ---------------------------------------------------------

radar_stat_input <- all_sample_metrics %>%
  select(Period_full, Drought, all_of(RADAR_METRICS_SAMPLE)) %>%
  pivot_longer(
    cols = all_of(RADAR_METRICS_SAMPLE),
    names_to = "Metric",
    values_to = "Value"
  ) %>%
  filter(!is.na(Value), !is.na(Drought), !is.na(Period_full))

safe_kruskal_radar <- function(df) {
  
  if (length(unique(df$Drought)) < 2) {
    return(data.frame(p = NA_real_))
  }
  
  if (length(unique(df$Value)) <= 1) {
    return(data.frame(p = NA_real_))
  }
  
  res <- tryCatch(
    kruskal.test(Value ~ Drought, data = df),
    error = function(e) NULL
  )
  
  if (is.null(res)) {
    data.frame(p = NA_real_)
  } else {
    data.frame(p = res$p.value)
  }
}

radar_stat_df <- radar_stat_input %>%
  group_by(Period_full, Metric) %>%
  group_modify(~ safe_kruskal_radar(.x)) %>%
  ungroup() %>%
  group_by(Period_full) %>%
  mutate(
    p.adj = p.adjust(p, method = "BH")
  ) %>%
  ungroup() %>%
  mutate(
    sig = case_when(
      is.na(p.adj)   ~ "NA",
      p.adj < 0.001 ~ "***",
      p.adj < 0.01  ~ "**",
      p.adj < 0.05  ~ "*",
      TRUE          ~ "ns"
    )
  )

write.csv(
  radar_stat_df,
  file.path(base_outdir, "Endosphere_extended_radar_metrics_Kruskal_BH.csv"),
  row.names = FALSE
)

radar_sig_df <- radar_stat_df %>%
  mutate(
    Metric = factor(
      Metric,
      levels = RADAR_METRICS_SAMPLE,
      labels = metric_labels[RADAR_METRICS_SAMPLE]
    ),
    Period_full = factor(
      Period_full,
      levels = c(
        "Jointing stage",
        "Heading stage",
        "Filling stage",
        "Maturity stage"
      )
    ),
    sig = ifelse(sig %in% c("ns", "NA"), "", sig)
  )

# =========================================================
# 14.6 手动坐标转换：生成折线式雷达图坐标
#      不使用 coord_polar()，避免弧形连线
# =========================================================

metric_levels <- levels(radar_sample_df$Metric)
n_metric <- length(metric_levels)

axis_df <- data.frame(
  Metric = factor(metric_levels, levels = metric_levels),
  axis_id = seq_along(metric_levels)
) %>%
  mutate(
    angle = pi / 2 - 2 * pi * (axis_id - 1) / n_metric,
    x_axis = cos(angle),
    y_axis = sin(angle),
    x_label = 1.22 * cos(angle),
    y_label = 1.22 * sin(angle)
  )

radar_xy <- radar_sample_df %>%
  left_join(axis_df, by = "Metric") %>%
  mutate(
    x = Value_scaled * cos(angle),
    y = Value_scaled * sin(angle),
    group_id = interaction(Period_full, Drought, drop = TRUE)
  ) %>%
  arrange(Period_full, Drought, axis_id)

radar_xy_closed <- radar_xy %>%
  group_by(Period_full, Drought, group_id) %>%
  group_modify(~ bind_rows(.x, .x[1, ])) %>%
  ungroup()

# 背景网格
grid_df <- expand.grid(
  r = c(0.25, 0.5, 0.75, 1),
  Metric = metric_levels
) %>%
  mutate(
    Metric = factor(Metric, levels = metric_levels)
  ) %>%
  left_join(axis_df, by = "Metric") %>%
  mutate(
    x = r * cos(angle),
    y = r * sin(angle)
  ) %>%
  arrange(r, axis_id)

grid_closed <- grid_df %>%
  group_by(r) %>%
  group_modify(~ bind_rows(.x, .x[1, ])) %>%
  ungroup()

# 坐标轴线
axis_segment_df <- axis_df %>%
  transmute(
    Metric,
    x = 0,
    y = 0,
    xend = x_axis,
    yend = y_axis
  )

# 指标标签
axis_label_df <- axis_df %>%
  transmute(
    Metric,
    x = x_label,
    y = y_label,
    label = as.character(Metric)
  )

# 星号坐标
radar_sig_xy <- radar_sig_df %>%
  left_join(axis_df, by = "Metric") %>%
  mutate(
    x = 1.08 * cos(angle),
    y = 1.08 * sin(angle)
  )

# =========================================================
# 14.7 绘制折线式雷达图
# =========================================================

p_radar_extended_metrics <- ggplot() +
  
  # 背景网格
  geom_path(
    data = grid_closed,
    aes(x = x, y = y, group = r),
    color = "grey80",
    linewidth = 0.4
  ) +
  
  # 中心到各指标的轴线
  geom_segment(
    data = axis_segment_df,
    aes(x = x, y = y, xend = xend, yend = yend),
    color = "grey80",
    linewidth = 0.4
  ) +
  
  # 雷达多边形填充
  geom_polygon(
    data = radar_xy_closed,
    aes(
      x = x,
      y = y,
      group = group_id,
      color = Drought,
      fill = Drought
    ),
    alpha = 0.14,
    linewidth = 0.8,
    na.rm = TRUE
  ) +
  
  # 折线边界
  geom_path(
    data = radar_xy_closed,
    aes(
      x = x,
      y = y,
      group = group_id,
      color = Drought
    ),
    linewidth = 0.9,
    na.rm = TRUE
  ) +
  
  # 节点
  geom_point(
    data = radar_xy,
    aes(
      x = x,
      y = y,
      color = Drought
    ),
    size = 2,
    na.rm = TRUE
  ) +
  
  # 指标名称
  geom_text(
    data = axis_label_df,
    aes(x = x, y = y, label = label),
    size = 3.6,
    color = "black"
  ) +
  
  # 显著性星号
  geom_text(
    data = radar_sig_xy,
    aes(x = x, y = y, label = sig),
    size = 4.5,
    color = "black",
    fontface = "bold"
  ) +
  
  facet_wrap(~ Period_full, ncol = 2) +
  scale_fill_manual(values = drought_cols, drop = FALSE) +
  scale_color_manual(values = drought_cols, drop = FALSE) +
  coord_equal(
    xlim = c(-1.35, 1.35),
    ylim = c(-1.35, 1.35),
    clip = "off"
  ) +
  theme_void(base_size = 12) +
  labs(
    title = "Network topological parameters under drought treatments"
  ) +
  theme(
    strip.background = element_rect(fill = "grey90", color = "black"),
    strip.text = element_text(face = "bold", size = 12),
    legend.title = element_blank(),
    legend.position = "bottom",
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
    plot.margin = margin(15, 20, 15, 20)
  )

print(p_radar_extended_metrics)

ggsave(
  filename = file.path(
    base_outdir,
    "Endosphere_extended_network_metrics_radar_by_drought_with_significance.pdf"
  ),
  plot = p_radar_extended_metrics,
  width = 10,
  height = 8
)

ggsave(
  filename = file.path(
    base_outdir,
    "Endosphere_extended_network_metrics_radar_by_drought_with_significance.png"
  ),
  plot = p_radar_extended_metrics,
  width = 10,
  height = 8,
  dpi = 300
)

write.csv(
  radar_sample_df,
  file.path(base_outdir, "Endosphere_extended_network_metrics_radar_mean_scaled.csv"),
  row.names = FALSE
)

cat("\n扩展网络拓扑参数折线式雷达图已完成！\n")

# =========================================================
# 16. ZIPI 图：节点形状代表时期，颜色代表功能类群
# =========================================================

# ---------- 辅助函数：计算 Zi 和 Pi ----------
calc_zipi_from_graph <- function(g, tax_df, period_name) {
  
  # 去掉孤立节点
  g_use <- delete_vertices(g, which(degree(g) == 0))
  
  if (vcount(g_use) == 0 || ecount(g_use) == 0) {
    return(data.frame(
      Node = character(0),
      Period = character(0),
      Function_raw = character(0),
      Function = character(0),
      Zi = numeric(0),
      Pi = numeric(0)
    ))
  }
  
  # 无向图
  g_use <- as.undirected(g_use, mode = "collapse")
  
  # 社区划分
  comm <- tryCatch(
    cluster_fast_greedy(g_use),
    error = function(e) NULL
  )
  
  if (is.null(comm)) {
    node_func_raw <- tax_df[V(g_use)$name, "Function", drop = TRUE] %>% as.character()
    node_func <- recode_function_group(node_func_raw)
    
    return(data.frame(
      Node = V(g_use)$name,
      Period = period_name,
      Function_raw = node_func_raw,
      Function = node_func,
      Zi = NA_real_,
      Pi = NA_real_
    ))
  }
  
  memb <- membership(comm)
  node_names <- V(g_use)$name
  deg_all <- degree(g_use)
  
  # Function 注释
  node_func_raw <- tax_df[node_names, "Function", drop = TRUE] %>% as.character()
  node_func <- recode_function_group(node_func_raw)
  
  # ---------- 计算 Zi ----------
  zi_vec <- rep(NA_real_, length(node_names))
  names(zi_vec) <- node_names
  
  for (md in unique(memb)) {
    nodes_md <- names(memb)[memb == md]
    subg_md <- induced_subgraph(g_use, vids = nodes_md)
    k_in_md <- degree(subg_md)
    
    if (length(nodes_md) == 1) {
      zi_vec[nodes_md] <- 0
    } else {
      k_mean <- mean(k_in_md)
      k_sd   <- stats::sd(k_in_md)
      
      if (is.na(k_sd) || k_sd == 0) {
        zi_vec[nodes_md] <- 0
      } else {
        zi_vec[nodes_md] <- (k_in_md - k_mean) / k_sd
      }
    }
  }
  
  # ---------- 计算 Pi ----------
  pi_vec <- rep(NA_real_, length(node_names))
  names(pi_vec) <- node_names
  
  for (nd in node_names) {
    ki <- deg_all[nd]
    
    if (is.na(ki) || ki == 0) {
      pi_vec[nd] <- 0
    } else {
      nei <- neighbors(g_use, nd)
      nei_names <- V(g_use)[nei]$name
      nei_mods <- memb[nei_names]
      k_is <- table(nei_mods)
      pi_vec[nd] <- 1 - sum((as.numeric(k_is) / ki)^2)
    }
  }
  
  out <- data.frame(
    Node = node_names,
    Period = period_name,
    Function_raw = node_func_raw,
    Function = node_func,
    Zi = as.numeric(zi_vec[node_names]),
    Pi = as.numeric(pi_vec[node_names]),
    stringsAsFactors = FALSE
  )
  
  return(out)
}

# ---------- 四个时期分别计算 ZIPI ----------
zipi_list <- list()

for (pd in periods) {
  g_tmp <- all_period_graphs[[pd]]
  tax_tmp <- all_period_tax[[pd]]
  
  zipi_list[[pd]] <- calc_zipi_from_graph(
    g = g_tmp,
    tax_df = tax_tmp,
    period_name = pd
  )
}

zipi_df <- bind_rows(zipi_list)

# 因子顺序
zipi_df$Period <- factor(zipi_df$Period, levels = c("JS", "HS", "FS", "MS"))
zipi_df$Function[is.na(zipi_df$Function)] <- "NA"
zipi_df$Function <- factor(
  zipi_df$Function,
  levels = c(
    "plant_pathogen",
    "soil_saprotroph",
    "dung_saprotroph",
    "unspecified_saprotroph",
    "litter_saprotroph",
    "animal_parasite",
    "wood_saprotroph",
    "Other",
    "NA"
  )
)

# 形状映射（四个时期）
period_shapes <- c(
  "JS" = 16,
  "HS" = 17,
  "FS" = 15,
  "MS" = 18
)

# 节点角色分类（可选）
zipi_df <- zipi_df %>%
  mutate(
    Topo_role = case_when(
      Zi < 2.5 & Pi < 0.62 ~ "Peripheral",
      Zi < 2.5 & Pi >= 0.62 ~ "Connector",
      Zi >= 2.5 & Pi < 0.62 ~ "Module hub",
      Zi >= 2.5 & Pi >= 0.62 ~ "Network hub",
      TRUE ~ NA_character_
    )
  )

# 保存节点表
write.csv(
  zipi_df,
  file.path(base_outdir, "Endosphere_all_period_ZiPi_node_table.csv"),
  row.names = FALSE
)

# ---------- ZIPI 作图 ----------
p_zipi <- ggplot(
  zipi_df,
  aes(x = Pi, y = Zi, color = Function, shape = Period)
) +
  geom_point(size = 3, alpha = 0.85) +
  geom_vline(xintercept = 0.62, linetype = 2, color = "grey40") +
  geom_hline(yintercept = 2.5, linetype = 2, color = "grey40") +
  scale_color_manual(values = global_func_cols, drop = FALSE) +
  scale_shape_manual(values = period_shapes, drop = FALSE) +
  theme_bw() +
  labs(
    x = "Participation coefficient (Pi)",
    y = "Within-module connectivity (Zi)",
    color = "Function",
    shape = "Period"
  ) +
  theme(
    panel.grid = element_blank(),
    legend.title = element_text(size = 11),
    legend.text = element_text(size = 9),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10)
  )

# R 中直接显示
print(p_zipi)

# 导出图片
ggsave(
  filename = file.path(base_outdir, "Endosphere_ZiPi_plot.pdf"),
  plot = p_zipi,
  width = 10,
  height = 7
)

cat("\nZIPI 图已输出完成！\n")