# =========================================================
# SMF 与网络拓扑参数 / 内聚力的 Spearman 相关性
# 按四个生长期（JS/HS/FS/MS）分别计算，并绘制气泡图
# =========================================================

rm(list = ls())
options(stringsAsFactors = FALSE)

setwd("D:/IUE/山西数据/真菌/抽平/真菌_网络分析/网络参数与SMF_GPI相关性")

library(tidyverse)

# =========================================================
# 1. 读取数据
# =========================================================

smf <- read.csv("测试数据SMF_MeanZ_results.csv", check.names = FALSE)
coh <- read.csv("根际sample_cohesion_Hernandez.csv", check.names = FALSE)
net <- read.csv("Rhizosphere_all_period_sample_specific_subnetwork_metrics.csv", check.names = FALSE)
grp <- read.csv("根际分组.csv", check.names = FALSE)

# 分组文件前两列标准化命名
colnames(grp)[1:2] <- c("Sample", "Group")

# =========================================================
# 2. 从 Group 提取时期
# =========================================================

grp <- grp %>%
  mutate(
    Period = case_when(
      str_detect(Group, "^JS_") ~ "JS",
      str_detect(Group, "^HS_") ~ "HS",
      str_detect(Group, "^FS_") ~ "FS",
      str_detect(Group, "^MS_") ~ "MS",
      TRUE ~ NA_character_
    ),
    Period_full = case_when(
      str_detect(Group, "^JS_") ~ "Jointing stage",
      str_detect(Group, "^HS_") ~ "Heading stage",
      str_detect(Group, "^FS_") ~ "Filling stage",
      str_detect(Group, "^MS_") ~ "Maturity stage",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(Period))

# =========================================================
# 3. 设置网络参数
#    使用雷达图中的网络参数，并额外加入内聚力
# =========================================================

# 雷达图中使用的网络参数
radar_network_vars <- c(
  "edges_num",
  "average_degree",
  "network_density",
  "clustering_coefficient",
  "path_efficiency",
  "modularity",
  "complexity"
)

# 由 average_path_length 计算 path_efficiency
# average_path_length 越小，路径越短；
# path_efficiency 越高，表示网络路径效率越高
net <- net %>%
  mutate(
    path_efficiency = ifelse(
      is.na(average_path_length) | average_path_length <= 0,
      NA_real_,
      1 / average_path_length
    )
  )

# 内聚力列
# 如果你的文件里只有 Negative_Cohesion，就只用 Negative_Cohesion；
# 如果同时有 Positive_Cohesion，也会一起纳入。
cohesion_vars <- intersect(
  c("Negative_Cohesion", "Positive_Cohesion"),
  colnames(coh)
)

if (length(cohesion_vars) == 0) {
  stop("内聚力文件中没有找到 Negative_Cohesion 或 Positive_Cohesion 列，请检查 coh 文件列名。")
}

# 最终用于相关分析的变量
network_vars <- c(
  cohesion_vars,
  radar_network_vars
)

# 检查 net 中是否缺少网络参数
missing_net_vars <- setdiff(radar_network_vars, colnames(net))

if (length(missing_net_vars) > 0) {
  stop(
    "net 文件中缺少以下网络参数列：",
    paste(missing_net_vars, collapse = ", ")
  )
}

# =========================================================
# 4. 按 Sample 合并数据
# =========================================================

dat <- net %>%
  select(Sample, all_of(radar_network_vars)) %>%
  left_join(
    coh %>% select(Sample, all_of(cohesion_vars)),
    by = "Sample"
  ) %>%
  left_join(
    smf %>% select(Sample, SMF_meanZ),
    by = "Sample"
  ) %>%
  left_join(
    grp %>% select(Sample, Group, Period, Period_full),
    by = "Sample"
  )

cat("合并后总样本数：", nrow(dat), "\n")
cat("各时期样本数：\n")
print(table(dat$Period, useNA = "ifany"))

# =========================================================
# 5. 各时期分别计算 Spearman 相关
#    只计算 SMF_meanZ，不再计算 GPI
# =========================================================

periods <- c("JS", "HS", "FS", "MS")

res_list <- list()

for (pd in periods) {
  
  dat_pd <- dat %>% filter(Period == pd)
  
  for (x in network_vars) {
    
    sub <- dat_pd %>%
      select(SMF_meanZ, all_of(x)) %>%
      drop_na()
    
    if (nrow(sub) < 3) {
      
      tmp <- data.frame(
        Period = pd,
        Variable = x,
        n = nrow(sub),
        Spearman_rho = NA_real_,
        P_value = NA_real_
      )
      
    } else {
      
      ct <- cor.test(
        sub$SMF_meanZ,
        sub[[x]],
        method = "spearman",
        exact = FALSE
      )
      
      tmp <- data.frame(
        Period = pd,
        Variable = x,
        n = nrow(sub),
        Spearman_rho = unname(ct$estimate),
        P_value = ct$p.value
      )
    }
    
    res_list[[paste(pd, x, sep = "_")]] <- tmp
  }
}

res <- bind_rows(res_list)

# =========================================================
# 6. P 值校正
#    这里沿用原逻辑：全部检验一起做 BH 校正
# =========================================================

res <- res %>%
  mutate(
    P_BH = p.adjust(P_value, method = "BH")
  )

# =========================================================
# 7. 添加显著性标记
# =========================================================

# =========================================================
# 7. 添加显著性、相关系数和 -log10(P_BH)
#    颜色表示 Spearman rho
#    气泡大小表示 -log10(BH-adjusted P)
# =========================================================

res <- res %>%
  mutate(
    sig = case_when(
      is.na(P_BH)   ~ "",
      P_BH < 0.001 ~ "***",
      P_BH < 0.01  ~ "**",
      P_BH < 0.05  ~ "*",
      TRUE         ~ ""
    ),
    
    rho_round = round(Spearman_rho, 2),
    
    # 避免 P_BH = 0 时 -log10(0) = Inf
    P_BH_for_log = case_when(
      is.na(P_BH) ~ NA_real_,
      P_BH <= 0   ~ .Machine$double.xmin,
      TRUE        ~ P_BH
    ),
    
    neg_log10_PBH = -log10(P_BH_for_log),
    
    # 可选：用于图上标注 rho
    rho_label = ifelse(
      is.na(rho_round),
      "",
      sprintf("%.2f", rho_round)
    )
  )

# =========================================================
# 8. 设置顺序和显示名称
# =========================================================

res$Period <- factor(
  res$Period,
  levels = c("JS", "HS", "FS", "MS")
)

# 显示标签
variable_label_map <- c(
  "Negative_Cohesion"       = "Negative cohesion",
  "Positive_Cohesion"       = "Positive cohesion",
  "edges_num"               = "Edges",
  "average_degree"          = "Degree",
  "network_density"         = "Density",
  "clustering_coefficient"  = "Clustering",
  "path_efficiency"         = "Path efficiency",
  "modularity"              = "Modularity",
  "complexity"              = "Complexity"
)

variable_order <- c(
  "Negative_Cohesion",
  "Positive_Cohesion",
  "edges_num",
  "average_degree",
  "network_density",
  "clustering_coefficient",
  "path_efficiency",
  "modularity",
  "complexity"
)

variable_order <- variable_order[variable_order %in% network_vars]

res <- res %>%
  mutate(
    Variable_label = recode(
      Variable,
      !!!variable_label_map
    )
  )

res$Variable <- factor(
  res$Variable,
  levels = variable_order
)

res$Variable_label <- factor(
  res$Variable_label,
  levels = variable_label_map[variable_order]
)

# =========================================================
# =========================================================
# 9. 绘制气泡图
#    颜色：Spearman rho，表示正/负相关及相关强度
#    大小：-log10(P_BH)，表示显著性强弱
#    星号：BH 校正后的显著性
# =========================================================

p_bubble <- ggplot(
  res,
  aes(
    x = Variable_label,
    y = Period
  )
) +
  geom_point(
    aes(
      size = neg_log10_PBH,
      fill = Spearman_rho
    ),
    shape = 21,
    color = "grey30",
    stroke = 0.35,
    alpha = 0.9,
    na.rm = TRUE
  ) +
  geom_text(
    aes(label = sig),
    size = 5,
    fontface = "bold",
    color = "black",
    na.rm = TRUE
  ) +
  scale_fill_gradient2(
    low = "#3B4CC0",
    mid = "white",
    high = "#B40426",
    midpoint = 0,
    limits = c(-1, 1),
    name = "Spearman rho"
  ) +
  scale_size_continuous(
    range = c(2.5, 11),
    name = expression(-log[10]("BH-adjusted P"))
  ) +
  labs(
    x = NULL,
    y = NULL,
    title = "Spearman correlations between SMF and network properties"
  ) +
  theme_bw(base_size = 14) +
  theme(
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      size = 16
    ),
    axis.text.x = element_text(
      angle = 35,
      hjust = 1,
      vjust = 1,
      color = "black"
    ),
    axis.text.y = element_text(
      face = "bold",
      color = "black"
    ),
    panel.grid.major = element_line(color = "grey88"),
    panel.grid.minor = element_blank(),
    legend.title = element_text(face = "bold"),
    legend.position = "right"
  )

print(p_bubble)

ggsave(
  filename = "SMF_network_cohesion_spearman_bubble_by_period.png",
  plot = p_bubble,
  width = 12,
  height = 5,
  dpi = 300
)

ggsave(
  filename = "SMF_network_cohesion_spearman_bubble_by_period.pdf",
  plot = p_bubble,
  width = 12,
  height = 5
)

# =========================================================
# 10. 可选：输出带显示标签的结果表
# =========================================================

write.csv(
  res,
  "SMF_network_cohesion_spearman_by_period_with_labels.csv",
  row.names = FALSE
)

cat("\nDONE.\n")
cat("Main outputs:\n")
cat("1. SMF_network_cohesion_spearman_by_period.csv\n")
cat("2. SMF_network_cohesion_spearman_by_period_with_labels.csv\n")
cat("3. SMF_network_cohesion_spearman_bubble_by_period.png / pdf\n")