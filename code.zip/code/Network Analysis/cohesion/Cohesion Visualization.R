############################################################
## Final code
## Show drought trend (NOT time trend)
## x = Drought gradient
## color = Period
## facet = Habitat
## show only:
##   1) raw points
##   2) fitted trend lines for each period
##   3) b and r² labels
## remove:
##   - mean points
##   - SE bars
##   - extra connecting lines
##   - significance tests / letters
############################################################

rm(list = ls())

############################
## 0. 工作目录 & 包
############################
setwd("D:/IUE/山西数据/真菌/抽平/totalASVs 内聚力_宽度_重叠指数/正负内聚力比评估群落稳定性")

library(tidyverse)

############################
## 1. 文件信息
############################
file_info <- tibble(
  Habitat = c("Phyllosphere", "Endosphere", "Rhizosphere"),
  cohesion_file = c(
    "叶际sample_cohesion_Hernandez.csv",
    "根内sample_cohesion_Hernandez.csv",
    "根际sample_cohesion_Hernandez.csv"
  ),
  group_file = c(
    "叶际分组.csv",
    "根内分组.csv",
    "根际分组.csv"
  )
)

############################
## 2. 辅助函数
############################
p_to_star <- function(p){
  case_when(
    is.na(p)  ~ "",
    p < 0.001 ~ "***",
    p < 0.01  ~ "**",
    p < 0.05  ~ "*",
    TRUE      ~ ""
  )
}

read_cohesion_data <- function(cohesion_file, group_file, habitat_name){
  
  cohesion_df <- read.csv(cohesion_file, check.names = FALSE, stringsAsFactors = FALSE)
  group_df    <- read.csv(group_file, check.names = FALSE, stringsAsFactors = FALSE)
  colnames(group_df)[1:2] <- c("Sample", "Group")
  
  dat <- cohesion_df %>%
    left_join(group_df, by = "Sample") %>%
    mutate(
      Period = case_when(
        grepl("^JS_", Group) ~ "JS",
        grepl("^HS_", Group) ~ "HS",
        grepl("^FS_", Group) ~ "FS",
        grepl("^MS_", Group) ~ "MS",
        TRUE ~ NA_character_
      ),
      Drought = case_when(
        grepl("_Control$",   Group) ~ "Control",
        grepl("_Drought_L$", Group) ~ "Drought_L",
        grepl("_Drought_M$", Group) ~ "Drought_M",
        grepl("_Drought_H$", Group) ~ "Drought_H",
        TRUE ~ NA_character_
      ),
      Drought_num = case_when(
        Drought == "Control"   ~ 0,
        Drought == "Drought_L" ~ 1,
        Drought == "Drought_M" ~ 2,
        Drought == "Drought_H" ~ 3,
        TRUE ~ NA_real_
      ),
      NPC_ratio = abs(Negative_Cohesion) / Positive_Cohesion,
      Habitat   = habitat_name
    ) %>%
    filter(!is.na(Period), !is.na(Drought), !is.na(Drought_num)) %>%
    filter(Positive_Cohesion > 0, is.finite(NPC_ratio))
  
  dat$Drought <- factor(
    dat$Drought,
    levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
  )
  
  dat$Period <- factor(
    dat$Period,
    levels = c("JS", "HS", "FS", "MS")
  )
  
  dat$Habitat <- factor(
    dat$Habitat,
    levels = c("Phyllosphere", "Endosphere", "Rhizosphere")
  )
  
  return(dat)
}

############################
## 3. 读入三个部位数据
############################
cohesion_all <- purrr::pmap_dfr(
  file_info,
  function(Habitat, cohesion_file, group_file){
    read_cohesion_data(cohesion_file, group_file, Habitat)
  }
)

############################
## 4. 拟合函数：按 Habitat × Period，对 Drought_num 拟合
############################
fit_metric_lm <- function(dat, metric_col){
  dat %>%
    group_by(Habitat, Period) %>%
    group_modify(~{
      fit <- lm(reformulate("Drought_num", response = metric_col), data = .x)
      tibble(
        slope = unname(coef(fit)[2]),
        r2    = summary(fit)$r.squared,
        p     = summary(fit)$coefficients[2, 4]
      )
    }) %>%
    ungroup() %>%
    mutate(
      star  = p_to_star(p),
      label = paste0("b = ", sprintf("%.4f", slope),
                     ",  r² = ", sprintf("%.2f", r2), star)
    )
}

############################
## 5. 给注释安排位置
############################
make_label_pos <- function(dat, lm_res, metric_col){
  
  label_pos <- dat %>%
    group_by(Habitat) %>%
    summarise(
      y_max = max(.data[[metric_col]], na.rm = TRUE),
      y_min = min(.data[[metric_col]], na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      y_span = ifelse(y_max - y_min == 0, 0.1, y_max - y_min)
    )
  
  lm_res %>%
    left_join(label_pos, by = "Habitat") %>%
    group_by(Habitat) %>%
    arrange(Period, .by_group = TRUE) %>%
    mutate(
      x = 0.05,
      y = y_max - 0.06 * y_span - (row_number() - 1) * 0.12 * y_span
    ) %>%
    ungroup()
}

############################
## 6. 通用作图函数
############################
plot_metric_drought_trend <- function(dat, metric_col, ylab_txt, out_pdf, out_lm_csv){
  
  lm_df <- fit_metric_lm(dat, metric_col)
  lm_df <- make_label_pos(dat, lm_df, metric_col)
  
  write.csv(lm_df, out_lm_csv, row.names = FALSE)
  
  my_cols <- c(
    "JS" = "#F8766D",
    "HS" = "#7CAE00",
    "FS" = "#00BFC4",
    "MS" = "#C77CFF"
  )
  
  p <- ggplot() +
    geom_point(
      data = dat,
      aes(x = Drought_num, y = .data[[metric_col]], color = Period),
      size = 2.5,
      alpha = 0.75,
      position = position_jitter(width = 0.06, height = 0)
    ) +
    geom_smooth(
      data = dat,
      aes(x = Drought_num, y = .data[[metric_col]], color = Period),
      method = "lm",
      se = FALSE,
      linewidth = 0.8
    ) +
    geom_text(
      data = lm_df,
      aes(x = x, y = y, label = label, color = Period),
      hjust = 0,
      size = 3.6,
      show.legend = FALSE
    ) +
    facet_wrap(~ Habitat, nrow = 1, scales = "free_y") +
    scale_x_continuous(
      breaks = c(0, 1, 2, 3),
      labels = c("Control", "Drought_L", "Drought_M", "Drought_H"),
      limits = c(-0.1, 3.2)
    ) +
    scale_color_manual(values = my_cols) +
    labs(
      x = "Drought",
      y = ylab_txt
    ) +
    theme_classic(base_size = 14) +
    theme(
      axis.line = element_line(linewidth = 1),
      axis.ticks = element_line(linewidth = 1),
      axis.text = element_text(color = "black"),
      axis.text.x = element_text(angle = 25, hjust = 1),
      strip.text = element_text(size = 14, face = "bold"),
      legend.position = "right",
      legend.title = element_blank(),
      plot.margin = margin(8, 12, 8, 8)
    ) +
    coord_cartesian(clip = "off")
  
  ggsave(
    filename = out_pdf,
    plot = p,
    width = 15,
    height = 5,
    device = cairo_pdf
  )
  
  return(p)
}

############################
## 7. 输出三个最终图
############################

# 7.1 NPC ratio
plot_metric_drought_trend(
  dat        = cohesion_all,
  metric_col = "NPC_ratio",
  ylab_txt   = "|Negative cohesion| / Positive cohesion",
  out_pdf    = "NPC_ratio_drought_trend_3habitats.pdf",
  out_lm_csv = "NPC_ratio_drought_trend_lm_results.csv"
)

# 7.2 Positive cohesion
plot_metric_drought_trend(
  dat        = cohesion_all,
  metric_col = "Positive_Cohesion",
  ylab_txt   = "Positive cohesion",
  out_pdf    = "Positive_cohesion_drought_trend_3habitats.pdf",
  out_lm_csv = "Positive_cohesion_drought_trend_lm_results.csv"
)

# 7.3 Negative cohesion
plot_metric_drought_trend(
  dat        = cohesion_all,
  metric_col = "Negative_Cohesion",
  ylab_txt   = "Negative cohesion",
  out_pdf    = "Negative_cohesion_drought_trend_3habitats.pdf",
  out_lm_csv = "Negative_cohesion_drought_trend_lm_results.csv"
)

cat("完成，已输出：\n")
cat("1. NPC_ratio_drought_trend_3habitats.pdf\n")
cat("2. Positive_cohesion_drought_trend_3habitats.pdf\n")
cat("3. Negative_cohesion_drought_trend_3habitats.pdf\n")
cat("4. 三个指标对应的 drought trend lm 结果 csv\n")