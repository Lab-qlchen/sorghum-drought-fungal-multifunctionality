# =====================================================
# 0. 加载必要包
# =====================================================
library(tidyverse)
library(lme4)
library(lmerTest)      # 为 lmer 提供 p 值 / ANOVA
library(emmeans)       # 边际均值与事后比较
library(multcomp)      # cld() 所需
library(multcompView)  # 字母分组显示
library(performance)   # R2, ICC

# =====================================================
# 1. 读取数据
# =====================================================
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/PGI")

ind <- read.csv("PGI.csv", check.names = FALSE)
grp <- read.csv("根际分组.csv", check.names = FALSE)
colnames(grp)[1:2] <- c("Sample", "Group")

dat <- left_join(ind, grp, by = "Sample")

# =====================================================
# 2. 基本检查
# =====================================================
required_cols_ind <- c("Sample", "Plant_height_simulated", "Leaf_area_simulated", "Block")
required_cols_grp <- c("Sample", "Group")

missing_ind <- setdiff(required_cols_ind, colnames(ind))
missing_grp <- setdiff(required_cols_grp, colnames(grp))

if (length(missing_ind) > 0) {
  stop("PGI.csv 缺少以下必要列：", paste(missing_ind, collapse = ", "))
}
if (length(missing_grp) > 0) {
  stop("根际分组.csv 缺少以下必要列：", paste(missing_grp, collapse = ", "))
}

# =====================================================
# 3. 提取 Period、Drought、Variety
# =====================================================
dat <- dat %>%
  mutate(
    Period = case_when(
      str_detect(Group, "^JS_") ~ "Jointing stage",
      str_detect(Group, "^HS_") ~ "Heading stage",
      str_detect(Group, "^FS_") ~ "Filling stage",
      str_detect(Group, "^MS_") ~ "Maturity stage",
      TRUE ~ NA_character_
    ),
    Drought = case_when(
      str_detect(Group, "_Control$")   ~ "Control",
      str_detect(Group, "_Drought_L$") ~ "Drought_L",
      str_detect(Group, "_Drought_M$") ~ "Drought_M",
      str_detect(Group, "_Drought_H$") ~ "Drought_H",
      TRUE ~ NA_character_
    ),
    Variety = case_when(
      str_detect(Sample, "^Z") ~ "Variety_1",
      str_detect(Sample, "^N") ~ "Variety_2",
      TRUE ~ NA_character_
    )
  )

dat$Period <- factor(
  dat$Period,
  levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
)

dat$Drought <- factor(
  dat$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

dat$Variety <- factor(
  dat$Variety,
  levels = c("Variety_1", "Variety_2")
)

dat$Block  <- factor(dat$Block)
dat$Sample <- factor(dat$Sample)

# =====================================================
# 4. 过滤缺失值
# =====================================================
dat2 <- dat %>%
  filter(
    !is.na(Drought),
    !is.na(Period),
    !is.na(Variety),
    !is.na(Plant_height_simulated),
    !is.na(Leaf_area_simulated),
    !is.na(Block)
  )

if (nrow(dat2) == 0) {
  stop("过滤缺失值后没有可用于分析的数据，请检查原始数据。")
}

# =====================================================
# 5. 计算 GPI
# =====================================================
height_col <- "Plant_height_simulated"
leaf_col   <- "Leaf_area_simulated"

trait_mat <- dat2[, c(height_col, leaf_col)]
Z_trait <- scale(trait_mat)
dat2$GPI_meanZ <- rowMeans(Z_trait, na.rm = TRUE)

range01 <- function(x) {
  rng <- range(x, na.rm = TRUE)
  if (rng[1] == rng[2]) return(rep(0, length(x)))
  (x - rng[1]) / (rng[2] - rng[1])
}
dat2$GPI_01 <- range01(dat2$GPI_meanZ)
# 导出每个样本计算得到的 GPI
gpi_output <- dat2 %>%
  select(
    Sample, Group, Block, Variety, Period, Drought,
    Plant_height_simulated, Leaf_area_simulated,
    GPI_meanZ, GPI_01
  )

write.csv(gpi_output, "GPI_calculated_values.csv", row.names = FALSE)

# =====================================================
# 6. 线性混合模型（LMM）：控制 Variety，但不分析其交互
# =====================================================
lmm_model <- lmer(
  GPI_meanZ ~ Drought * Period + Variety + (1 | Block),
  data = dat2
)

# 模型摘要
sink("GPI_LMM_summary_control_variety.txt")
print(summary(lmm_model))
sink()

# =====================================================
# 7. 固定效应检验（ANOVA 风格）
# =====================================================
lmm_anova <- anova(lmm_model, ddf = "Satterthwaite")
lmm_anova_df <- as.data.frame(lmm_anova)
lmm_anova_df$Effect <- rownames(lmm_anova_df)
rownames(lmm_anova_df) <- NULL

# 计算 partial eta squared（近似）
lmm_anova_df <- lmm_anova_df %>%
  mutate(
    partial_eta2 = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF),
    p_label = case_when(
      is.na(`Pr(>F)`)  ~ "",
      `Pr(>F)` < 0.001 ~ "<0.001",
      TRUE             ~ formatC(`Pr(>F)`, format = "f", digits = 3)
    )
  )

write.csv(lmm_anova_df, "GPI_LMM_ANOVA_with_eta2_control_variety.csv", row.names = FALSE)

# =====================================================
# 8. 模型解释度与随机效应比例
# =====================================================
r2_res <- performance::r2_nakagawa(lmm_model)
R2_marginal    <- unname(r2_res$R2_marginal)
R2_conditional <- unname(r2_res$R2_conditional)

icc_res <- performance::icc(lmm_model)
ICC_adj <- unname(icc_res$ICC_adjusted)

vc <- as.data.frame(VarCorr(lmm_model))
block_var <- vc$vcov[vc$grp == "Block"]
resid_var <- vc$vcov[vc$grp == "Residual"]

var_df <- data.frame(
  metric = c(
    "Block_variance",
    "Residual_variance",
    "ICC_adjusted",
    "R2_marginal",
    "R2_conditional"
  ),
  value = c(block_var, resid_var, ICC_adj, R2_marginal, R2_conditional)
)

write.csv(var_df, "GPI_LMM_variance_R2_ICC_control_variety.csv", row.names = FALSE)

# =====================================================
# 9. 固定效应系数
# =====================================================
fixed_df <- as.data.frame(summary(lmm_model)$coefficients)
fixed_df$term <- rownames(fixed_df)
rownames(fixed_df) <- NULL
write.csv(fixed_df, "GPI_LMM_fixed_effects_coefficients_control_variety.csv", row.names = FALSE)

# =====================================================
# 10. 边际均值与事后比较
# 这里仍按 Drought | Period 出图
# 但结果已经控制了 Variety 主效应
# =====================================================
emm <- emmeans(lmm_model, ~ Drought | Period)
emm_df <- as.data.frame(emm)

pair_df <- as.data.frame(pairs(emm, adjust = "BH"))

cld_df <- multcomp::cld(
  emm,
  adjust = "BH",
  Letters = letters
) %>%
  as.data.frame() %>%
  select(Period, Drought, .group) %>%
  mutate(
    .group = stringr::str_trim(.group)
  )

plot_df <- left_join(emm_df, cld_df, by = c("Period", "Drought"))

write.csv(emm_df,  "GPI_LMM_emmeans_control_variety.csv", row.names = FALSE)
write.csv(pair_df, "GPI_LMM_pairwise_BH_control_variety.csv", row.names = FALSE)
write.csv(cld_df,  "GPI_LMM_letters_control_variety.csv", row.names = FALSE)

# =====================================================
# 11. 随机效应
# =====================================================
ranef_df <- as.data.frame(ranef(lmm_model)$Block)
ranef_df$Block <- rownames(ranef(lmm_model)$Block)
rownames(ranef_df) <- NULL
write.csv(ranef_df, "GPI_LMM_random_effects_control_variety.csv", row.names = FALSE)

# =====================================================
# 12. 组织图中要显示的统计信息
# 这里显示 Variety 主效应 + Drought + Period + Drought:Period
# =====================================================
get_effect_row <- function(df, effect_name) {
  df %>% filter(Effect == effect_name)
}

variety_row <- get_effect_row(lmm_anova_df, "Variety")
drought_row <- get_effect_row(lmm_anova_df, "Drought")
period_row  <- get_effect_row(lmm_anova_df, "Period")
inter_row   <- get_effect_row(lmm_anova_df, "Drought:Period")

label_text <- paste0(
  "Variety: F=", round(variety_row$`F value`, 2),
  ", p=", variety_row$p_label,
  ", eta_p2=", round(variety_row$partial_eta2, 3), "\n",
  "Drought: F=", round(drought_row$`F value`, 2),
  ", p=", drought_row$p_label,
  ", eta_p2=", round(drought_row$partial_eta2, 3), "\n",
  "Period: F=", round(period_row$`F value`, 2),
  ", p=", period_row$p_label,
  ", eta_p2=", round(period_row$partial_eta2, 3), "\n",
  "Drought x Period: F=", round(inter_row$`F value`, 2),
  ", p=", inter_row$p_label,
  ", eta_p2=", round(inter_row$partial_eta2, 3), "\n",
  "R2m=", round(R2_marginal, 3),
  ", R2c=", round(R2_conditional, 3),
  ", ICC=", round(ICC_adj, 3), "\n",
  "Var(Block)=", round(block_var, 3),
  ", Var(Residual)=", round(resid_var, 3)
)

# =====================================================
# 13. 绘图（主体保持不变）
# =====================================================
y_max <- max(plot_df$upper.CL, na.rm = TRUE)
y_min <- min(plot_df$lower.CL, na.rm = TRUE)
y_range <- y_max - y_min

p_gpi <- ggplot(plot_df, aes(x = Period, y = emmean, group = Drought, color = Drought)) +
  geom_line(linewidth = 1) +
  geom_point(size = 3) +
  geom_ribbon(
    aes(ymin = lower.CL, ymax = upper.CL, fill = Drought),
    alpha = 0.18, color = NA
  ) +
  geom_text(
    aes(y = upper.CL + 0.04 * y_range, label = .group),
    size = 4,
    show.legend = FALSE
  ) +
  annotate(
    "text",
    x = 1.05,
    y = y_max + 0.35 * y_range,
    label = label_text,
    hjust = 0,
    vjust = 1,
    size = 4.1,
    color = "black"
  ) +
  coord_cartesian(ylim = c(y_min, y_max + 0.42 * y_range), clip = "off") +
  theme_bw() +
  labs(
    x = "Growth period",
    y = "GPI (Estimated Mean Z)",
    title = "Dynamic changes of GPI under Drought x Period (LMM, controlling for Variety)",
    subtitle = "Lines = estimated marginal means; ribbons = 95% CI; letters = post hoc groups"
  ) +
  theme(
    axis.text.x = element_text(angle = 20, hjust = 1),
    panel.grid = element_blank(),
    plot.margin = margin(10, 20, 10, 10)
  )

print(p_gpi)

ggsave(
  "GPI_dynamic_curve_LMM_control_variety.pdf",
  p_gpi,
  width = 11,
  height = 6
)