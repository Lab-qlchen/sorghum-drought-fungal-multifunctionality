###############################
## Figure 3C: TITAN analysis
## Use raw "primary" annotation directly
## No guild mapping
###############################

rm(list = ls())
options(stringsAsFactors = FALSE)

###############################
## 1. 工作目录
###############################
wd <- "D:/IUE/山西数据/真菌/抽平/群落演替动态"
setwd(wd)

###############################
## 2. 加载包
###############################
pkg_needed <- c("TITAN2", "ggplot2", "dplyr")
pkg_new <- pkg_needed[!pkg_needed %in% installed.packages()[, "Package"]]
if(length(pkg_new) > 0){
  install.packages(pkg_new, repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
}

library(TITAN2)
library(ggplot2)
library(dplyr)

###############################
## 3. 基本设置
###############################
stage_levels <- c("JS", "HS", "FS", "MS")
stage_num_map <- c(JS = 1, HS = 2, FS = 3, MS = 4)

###############################
## 4. 读入并整理单个生态位数据
###############################
prepare_one_habitat_for_titan <- function(asv_file, group_file, habitat_name, min_occ = 13){
  
  asv_tab <- read.csv(asv_file, header = TRUE, check.names = FALSE)
  group_tab <- read.csv(group_file, header = TRUE, check.names = FALSE)
  
  colnames(group_tab)[1:2] <- c("Sample", "Group")
  
  ## 解析 Stage（不分处理）
  group_split <- strsplit(group_tab$Group, "_")
  group_tab$Stage <- sapply(group_split, `[`, 1)
  group_tab$Stage <- factor(group_tab$Stage, levels = stage_levels)
  group_tab$Stage_num <- stage_num_map[as.character(group_tab$Stage)]
  
  ## 注释列
  anno_cols <- c("ASV","Domain","Phylum","Class","Order","Family",
                 "Genus","Species","Genus.join","primary","secondary")
  
  ## 样本列
  sample_cols <- setdiff(colnames(asv_tab), anno_cols)
  sample_cols <- intersect(sample_cols, group_tab$Sample)
  
  if(length(sample_cols) == 0){
    stop(paste0(habitat_name, ": ASV表样本列与分组表 Sample 没有匹配上。"))
  }
  
  group_tab <- group_tab[match(sample_cols, group_tab$Sample), , drop = FALSE]
  
  ## 群落矩阵：行=样本，列=ASV
  comm <- asv_tab[, sample_cols, drop = FALSE]
  comm[] <- lapply(comm, as.numeric)
  
  ## 关键：把 ASV 名称设为行名
  rownames(comm) <- asv_tab$ASV
  
  ## 转置后，列名就会变成真正的 ASV 名称
  comm <- t(as.matrix(comm))
  if(any(is.na(comm))){
    warning(paste0(habitat_name, ": 群落矩阵中存在 NA，已替换为 0。"))
    comm[is.na(comm)] <- 0
  }
  
  ## 去掉全零样本和无阶段样本
  keep <- rowSums(comm) > 0 & !is.na(group_tab$Stage_num)
  comm <- comm[keep, , drop = FALSE]
  group_tab <- group_tab[keep, , drop = FALSE]
  
  if(nrow(comm) < 8){
    stop(paste0(habitat_name, ": 有效样本数过少，TITAN不稳定。"))
  }
  
  ## 过滤低出现频次 + 低总丰度 OTU
  otu_occ <- colSums(comm > 0)
  otu_sum <- colSums(comm)
  
  keep_otu <- otu_occ >= min_occ & otu_sum >= 10
  comm <- comm[, keep_otu, drop = FALSE]
  
  if(ncol(comm) < 5){
    stop(paste0(habitat_name, ": 过滤后OTU太少，不适合做TITAN。"))
  }
  
  ## 直接使用 primary 原值
  otu_anno <- asv_tab[match(colnames(comm), asv_tab$ASV), c("ASV","Genus","primary"), drop = FALSE]
  colnames(otu_anno) <- c("ASV", "Genus", "Primary")
  
  otu_anno$Genus[is.na(otu_anno$Genus) | otu_anno$Genus == ""] <- otu_anno$ASV[is.na(otu_anno$Genus) | otu_anno$Genus == ""]
  otu_anno$Primary <- as.character(otu_anno$Primary)
  otu_anno$Primary[is.na(otu_anno$Primary) | otu_anno$Primary == ""] <- "NA"
  
  return(list(
    habitat = habitat_name,
    env = group_tab,
    comm = comm,
    otu_anno = otu_anno
  ))
}

###############################
## 5. 运行单个生态位的 TITAN
###############################
run_titan_one_habitat <- function(prep_obj,
                                  minSplt = 5,
                                  nBoot = 500,
                                  numPerm = 50,
                                  pur.cut = 0.95,
                                  rel.cut = 0.95){
  
  env <- prep_obj$env
  comm <- prep_obj$comm
  otu_anno <- prep_obj$otu_anno
  
  titan_out <- titan(
    env = env$Stage_num,
    txa = comm,
    minSplt = minSplt,
    numPerm = numPerm,
    boot = TRUE,
    nBoot = nBoot,
    imax = FALSE,
    ivTot = FALSE,
    pur.cut = pur.cut,
    rel.cut = rel.cut,
    memory = TRUE
  )
  
  spp <- data.frame(titan_out$sppmax)
  spp$ASV <- rownames(spp)
  
  spp_sig <- spp[spp$filter %in% c(1, 2), , drop = FALSE]
  
  if(nrow(spp_sig) == 0){
    warning(paste0(prep_obj$habitat, ": 没有通过阈值的 OTU。"))
    return(list(
      habitat = prep_obj$habitat,
      titan = titan_out,
      plot_df = data.frame(),
      spp = spp
    ))
  }
  
  da1 <- spp_sig[spp_sig$filter == 1, , drop = FALSE]
  da2 <- spp_sig[spp_sig$filter == 2, , drop = FALSE]
  
  if(nrow(da1) > 0) da1 <- da1[order(-da1$zenv.cp), , drop = FALSE]
  if(nrow(da2) > 0) da2 <- da2[order( da2$zenv.cp), , drop = FALSE]
  
  plot_df <- rbind(da1, da2)
  plot_df$ASV <- rownames(plot_df)
  
  plot_df <- merge(
    plot_df,
    otu_anno[, c("ASV", "Genus", "Primary")],
    by = "ASV",
    all.x = TRUE,
    sort = FALSE
  )
  
  plot_df <- plot_df[match(c(rownames(da1), rownames(da2)), plot_df$ASV), , drop = FALSE]
  plot_df$ord <- seq_len(nrow(plot_df))
  
  plot_df$Titan <- factor(plot_df$filter, levels = c(1, 2), labels = c("z-", "z+"))
  plot_df$Habitat <- prep_obj$habitat
  
  plot_df$Primary <- as.character(plot_df$Primary)
  plot_df$Primary[is.na(plot_df$Primary) | plot_df$Primary == ""] <- "NA"
  
  return(list(
    habitat = prep_obj$habitat,
    titan = titan_out,
    plot_df = plot_df,
    spp = spp
  ))
}

###############################
## 6. 准备三个生态位数据
###############################
prep_leaf <- prepare_one_habitat_for_titan(
  asv_file = "叶际_ASV_FungalTraits_with_abundance.csv",
  group_file = "叶际分组.csv",
  habitat_name = "Phyllosphere",
  min_occ = 13
)

prep_endo <- prepare_one_habitat_for_titan(
  asv_file = "根内_ASV_FungalTraits_with_abundance.csv",
  group_file = "根内分组.csv",
  habitat_name = "Endosphere",
  min_occ = 13
)

prep_rhizo <- prepare_one_habitat_for_titan(
  asv_file = "根际_ASV_FungalTraits_with_abundance.csv",
  group_file = "根际分组.csv",
  habitat_name = "Rhizosphere",
  min_occ = 13
)

###############################
## 7. 运行 TITAN
###############################
res_leaf <- run_titan_one_habitat(prep_leaf, minSplt = 5, nBoot = 500, numPerm = 50)
res_endo <- run_titan_one_habitat(prep_endo, minSplt = 5, nBoot = 500, numPerm = 50)
res_rhizo <- run_titan_one_habitat(prep_rhizo, minSplt = 5, nBoot = 500, numPerm = 50)

###############################
###############################
## 8. 合并绘图数据
###############################
plot_all <- bind_rows(
  res_leaf$plot_df,
  res_endo$plot_df,
  res_rhizo$plot_df
)

plot_all$Habitat <- factor(
  plot_all$Habitat,
  levels = c("Phyllosphere", "Endosphere", "Rhizosphere"),
  labels = c("Leaf", "Root", "Rhizosphere")
)

###############################
## 重新整理 Primary 分类
## 只保留前5个最多的，其余设为 Others
###############################
plot_all$Primary <- as.character(plot_all$Primary)
plot_all$Primary[is.na(plot_all$Primary) | plot_all$Primary == ""] <- "NA"

primary_freq <- sort(table(plot_all$Primary), decreasing = TRUE)
primary_freq_noNA <- primary_freq[names(primary_freq) != "NA"]
top5_primary <- names(primary_freq_noNA)[1:min(5, length(primary_freq_noNA))]

plot_all$Primary2 <- plot_all$Primary
plot_all$Primary2[!(plot_all$Primary2 %in% c(top5_primary, "NA"))] <- "Others"

primary2_levels <- c(top5_primary, "Others", "NA")
primary2_levels <- unique(primary2_levels[primary2_levels %in% unique(plot_all$Primary2)])

plot_all$Primary2 <- factor(plot_all$Primary2, levels = primary2_levels)
plot_all$Titan <- factor(plot_all$Titan, levels = c("z-", "z+"))

###############################
## 固定颜色
###############################
fixed_cols <- c(
  "#3C5488",  # 深蓝
  "#00A087",  # 绿
  "#4DBBD5",  # 青
  "#E64B35",  # 红
  "#7E6148"   # 棕
)

primary_palette <- setNames(
  c(fixed_cols[seq_len(min(length(top5_primary), 5))], "grey60", "grey85"),
  c(top5_primary[seq_len(min(length(top5_primary), 5))], "Others", "NA")
)

primary_palette <- primary_palette[names(primary_palette) %in% levels(plot_all$Primary2)]

###############################
## 9. 保存 TITAN 结果表
###############################
write.csv(plot_all, "Figure3C_TITAN_significant_OTUs.csv", row.names = FALSE)

###############################
## 10. 主图：带 genus 标签
###############################
p1 <- ggplot() +
  geom_text(
    data = plot_all,
    aes(x = ord + 0.5, y = zenv.cp + 0.10, label = Genus, color = Primary2),
    size = 2
  ) +
  geom_pointrange(
    data = plot_all,
    aes(
      x = ord,
      y = zenv.cp,
      ymin = X5.,
      ymax = X95.,
      color = Primary2,
      shape = Titan,
      linetype = Titan
    ),
    size = 0.8
  ) +
  scale_shape_manual(values = c("z-" = 16, "z+" = 1)) +
  scale_linetype_manual(values = c("z-" = 1, "z+" = 2)) +
  coord_flip() +
  xlab("OTUs") +
  ylab("Stage") +
  scale_y_continuous(
    breaks = c(1, 2, 3, 4),
    labels = c("JS", "HS", "FS", "MS"),
    limits = c(0.8, 4.3)
  ) +
  facet_wrap(~Habitat, nrow = 1, strip.position = "top", scales = "free_y") +
  theme_bw() +
  guides(color = guide_legend(title = "Primary")) +
  theme(
    strip.text = element_text(size = 14, face = "bold"),
    legend.title = element_text(size = 14, face = "bold"),
    legend.text = element_text(size = 12),
    axis.text = element_text(size = 10, face = "bold"),
    axis.title = element_text(size = 14, face = "bold"),
    panel.grid = element_blank()
  ) +
  scale_color_manual(values = primary_palette)

###############################
## 11. 简化图：不带 genus 标签
###############################
p2 <- ggplot() +
  geom_pointrange(
    data = plot_all,
    aes(
      x = ord,
      y = zenv.cp,
      ymin = X5.,
      ymax = X95.,
      color = Primary2,
      shape = Titan,
      linetype = Titan
    ),
    size = 0.8
  ) +
  scale_shape_manual(values = c("z-" = 16, "z+" = 1)) +
  scale_linetype_manual(values = c("z-" = 1, "z+" = 2)) +
  coord_flip() +
  xlab("OTUs") +
  ylab("Stage") +
  scale_y_continuous(
    breaks = c(1, 2, 3, 4),
    labels = c("JS", "HS", "FS", "MS"),
    limits = c(0.8, 4.3)
  ) +
  facet_wrap(~Habitat, nrow = 1, strip.position = "top", scales = "free_y") +
  theme_bw() +
  guides(color = guide_legend(title = "Primary")) +
  theme(
    strip.text = element_text(size = 14, face = "bold"),
    legend.title = element_text(size = 14, face = "bold"),
    legend.text = element_text(size = 12),
    axis.text = element_text(size = 10, face = "bold"),
    axis.title = element_text(size = 14, face = "bold"),
    panel.grid = element_blank()
  ) +
  scale_color_manual(values = primary_palette)

###############################
## 12. 显示图形
###############################
print(p1)
print(p2)

###############################
## 13. 输出 PDF
###############################
ggsave("Figure3C_TITAN_with_genus_labels.pdf", p1, width = 12, height = 7)
ggsave("Figure3C_TITAN_no_genus_labels.pdf", p2, width = 12, height = 4.5)

###############################
## 14. 输出摘要信息
###############################
summary_tab <- plot_all %>%
  group_by(Habitat, Titan, Primary2) %>%
  summarise(n_OTU = n(), .groups = "drop")

write.csv(summary_tab, "Figure3C_TITAN_summary_counts.csv", row.names = FALSE)

###############################
###############################
## 15. 输出各生态位关键阈值汇总
###############################

cat("\n===== TITAN summary change points =====\n")

## Leaf
cat("\nLeaf:\n")
leaf_cp <- as.data.frame(res_leaf$titan$sumz.cp)
leaf_cp$Metric <- rownames(leaf_cp)
leaf_cp$Habitat <- "Leaf"
print(leaf_cp)

## Root
cat("\nRoot:\n")
root_cp <- as.data.frame(res_endo$titan$sumz.cp)
root_cp$Metric <- rownames(root_cp)
root_cp$Habitat <- "Root"
print(root_cp)

## Rhizosphere
cat("\nRhizosphere:\n")
rhizo_cp <- as.data.frame(res_rhizo$titan$sumz.cp)
rhizo_cp$Metric <- rownames(rhizo_cp)
rhizo_cp$Habitat <- "Rhizosphere"
print(rhizo_cp)

## 合并三个生态位
titan_cp_all <- rbind(
  leaf_cp,
  root_cp,
  rhizo_cp
)

## 调整列顺序
titan_cp_all <- titan_cp_all[, c("Habitat","Metric","cp","0.05","0.10","0.50","0.90","0.95")]

## 输出 CSV
write.csv(
  titan_cp_all,
  "Figure3C_TITAN_change_points_summary.csv",
  row.names = FALSE
)

###############################
## 输出提示
###############################
cat("\n已生成文件：\n")
cat("1) Figure3C_TITAN_significant_OTUs.csv\n")
cat("2) Figure3C_TITAN_with_genus_labels.pdf\n")
cat("3) Figure3C_TITAN_no_genus_labels.pdf\n")
cat("4) Figure3C_TITAN_summary_counts.csv\n")
cat("5) Figure3C_TITAN_change_points_summary.csv\n")