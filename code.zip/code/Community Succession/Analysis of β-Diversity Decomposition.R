###############################
## Succession mechanism analysis
## Adapted from paper's Figure 3B logic
## Compare:
## 1) Bray-Curtis (No Hellinger transformation)
## 2) Jaccard (No Hellinger transformation)
## 3) Turnover (beta.jtu)
## 4) Nestedness (beta.jne)
## plus richness test
##
## Phyllosphere + Endosphere + Rhizosphere
## All treatments pooled, grouped only by Stage
###############################

rm(list = ls())
options(stringsAsFactors = FALSE)

###############################
## 1. 工作目录
###############################
wd <- "D:/IUE/山西数据/真菌/抽平/群落演替动态"
setwd(wd)

###############################
## 2. 加载包
###############################
pkg_needed <- c("vegan", "betapart")
pkg_new <- pkg_needed[!pkg_needed %in% installed.packages()[, "Package"]]
if(length(pkg_new) > 0){
  install.packages(pkg_new, repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
}

library(vegan)
library(betapart)

###############################
## 3. 颜色与顺序
###############################
stage_levels <- c("JS", "HS", "FS", "MS")
stage_cols <- c(
  JS = "#3C5488FF",
  HS = "#00A087FF",
  FS = "#4DBBD5FF",
  MS = "#E64B35FF"
)

###############################
## 4. P值格式化函数
###############################
format_p <- function(p){
  if(is.na(p)) return("NA")
  if(p < 0.001) return("< 0.001")
  sprintf("= %.3f", p)
}

###############################
## 5. 单个生态位数据准备
###############################
prepare_one_habitat <- function(asv_file, group_file, habitat_name){
  
  asv_tab <- read.csv(asv_file, header = TRUE, check.names = FALSE)
  group_tab <- read.csv(group_file, header = TRUE, check.names = FALSE)
  
  colnames(group_tab)[1:2] <- c("Sample", "Group")
  
  ## 只解析 Stage，不考虑处理
  group_split <- strsplit(group_tab$Group, "_")
  group_tab$Stage <- sapply(group_split, `[`, 1)
  group_tab$Stage <- factor(group_tab$Stage, levels = stage_levels)
  
  anno_cols <- c("ASV","Domain","Phylum","Class","Order","Family",
                 "Genus","Species","Genus.join","primary","secondary")
  
  sample_cols <- setdiff(colnames(asv_tab), anno_cols)
  sample_cols <- intersect(sample_cols, group_tab$Sample)
  
  if(length(sample_cols) == 0){
    stop(paste0(habitat_name, ": ASV表样本列与分组表 Sample 没有匹配上。"))
  }
  
  group_tab <- group_tab[match(sample_cols, group_tab$Sample), , drop = FALSE]
  
  ## 行=样本，列=ASV
  fung <- asv_tab[, sample_cols, drop = FALSE]
  fung[] <- lapply(fung, as.numeric)
  fung <- t(as.matrix(fung))
  
  if(any(is.na(fung))){
    warning(paste0(habitat_name, ": 群落矩阵中存在 NA，已替换为 0。"))
    fung[is.na(fung)] <- 0
  }
  
  keep <- rowSums(fung) > 0 & !is.na(group_tab$Stage)
  fung <- fung[keep, , drop = FALSE]
  group_tab <- group_tab[keep, , drop = FALSE]
  
  if(nrow(fung) < 4){
    stop(paste0(habitat_name, ": 有效样本数太少，无法分析。"))
  }
  
  if(length(unique(group_tab$Stage)) < 2){
    stop(paste0(habitat_name, ": 生长期不足2组。"))
  }
  
  list(
    Habitat = habitat_name,
    fung = fung,
    group_tab = group_tab
  )
}

###############################
## 6. 单个生态位 × 单个指标分析
###############################
analyze_metric <- function(prep_obj, metric = c("bray", "jaccard", "turnover", "nestedness")){
  
  metric <- match.arg(metric)
  fung <- prep_obj$fung
  group_tab <- prep_obj$group_tab
  
  ## richness
  richness <- specnumber(fung)
  
  ## 距离矩阵 (已移除 Hellinger 转化，直接使用原始/抽平丰度计算，保证与常规PCoA完全一致)
  if(metric == "bray"){
    fung_dist <- vegdist(fung, method = "bray")
  }
  
  if(metric == "jaccard"){
    fung_dist <- vegdist(fung, method = "jaccard")
  }
  
  if(metric %in% c("turnover", "nestedness")){
    fung_pa <- fung
    fung_pa[fung_pa > 0] <- 1
    fd <- beta.pair(fung_pa, index.family = "jaccard")
    if(metric == "turnover"){
      fung_dist <- fd$beta.jtu
    }
    if(metric == "nestedness"){
      fung_dist <- fd$beta.jne
    }
  }
  
  ## betadisper
  bd <- betadisper(fung_dist, factor(group_tab$Stage, levels = stage_levels))
  bd_aov <- anova(bd)
  bd_F <- bd_aov$`F value`[1]
  bd_P <- bd_aov$`Pr(>F)`[1]
  
  ## adonis2
  ad <- adonis2(fung_dist ~ Stage, data = group_tab, permutations = 999)
  ad_F <- ad$F[1]
  ad_R2 <- ad$R2[1]
  ad_P <- ad$`Pr(>F)`[1]
  
  ## richness 检验
  rich_kw <- kruskal.test(richness ~ group_tab$Stage)
  rich_P <- rich_kw$p.value
  
  ## ordination 坐标
  site_scores <- as.data.frame(scores(bd, display = "sites"))
  site_scores$Sample <- rownames(site_scores)
  site_scores$Stage <- group_tab$Stage
  
  centroid_scores <- as.data.frame(scores(bd, display = "centroids"))
  centroid_scores$Stage <- rownames(centroid_scores)
  
  dist_df <- data.frame(
    Sample = rownames(bd$vectors),
    Stage = group_tab$Stage,
    Distance_to_centroid = bd$distances,
    Habitat = prep_obj$Habitat,
    Metric = metric
  )
  
  richness_df <- data.frame(
    Sample = rownames(fung),
    Stage = group_tab$Stage,
    Richness = richness,
    Habitat = prep_obj$Habitat
  )
  
  list(
    Habitat = prep_obj$Habitat,
    Metric = metric,
    bd = bd,
    site_scores = site_scores,
    centroid_scores = centroid_scores,
    dist_df = dist_df,
    richness_df = richness_df,
    Betadisper_F = bd_F,
    Betadisper_P = bd_P,
    Adonis_F = ad_F,
    Adonis_R2 = ad_R2,
    Adonis_P = ad_P,
    Richness_P = rich_P
  )
}

###############################
## 7. 作图函数
###############################
draw_panel_metric <- function(res_obj, show_ylab = TRUE){
  
  site_scores <- res_obj$site_scores
  centroid_scores <- res_obj$centroid_scores
  
  x_all <- c(site_scores$PCoA1, centroid_scores$PCoA1)
  y_all <- c(site_scores$PCoA2, centroid_scores$PCoA2)
  
  xpad <- 0.12 * diff(range(x_all))
  ypad <- 0.18 * diff(range(y_all))
  if(is.na(xpad) || xpad == 0) xpad <- 0.1
  if(is.na(ypad) || ypad == 0) ypad <- 0.1
  
  plot(NA,
       xlim = c(min(x_all) - xpad, max(x_all) + xpad),
       ylim = c(min(y_all) - ypad, max(y_all) + ypad),
       xlab = "PCo1",
       ylab = if(show_ylab) "PCo2" else "",
       xaxt = "s", yaxt = "s",
       cex.lab = 1.1,
       cex.axis = 0.95,
       bty = "n")
  
  abline(h = 0, v = 0, col = "grey90", lwd = 1)
  
  for(i in seq_len(nrow(site_scores))){
    stg <- as.character(site_scores$Stage[i])
    cen <- centroid_scores[centroid_scores$Stage == stg, , drop = FALSE]
    if(nrow(cen) == 1){
      segments(site_scores$PCoA1[i], site_scores$PCoA2[i],
               cen$PCoA1, cen$PCoA2,
               col = adjustcolor(stage_cols[stg], alpha.f = 0.65),
               lwd = 0.8)
    }
  }
  
  points(site_scores$PCoA1, site_scores$PCoA2,
         pch = 3,
         cex = 0.7,
         lwd = 0.85,
         col = stage_cols[as.character(site_scores$Stage)])
  
  points(centroid_scores$PCoA1, centroid_scores$PCoA2,
         pch = 16,
         cex = 1.0,
         col = stage_cols[as.character(centroid_scores$Stage)])
  
  text(centroid_scores$PCoA1,
       centroid_scores$PCoA2,
       labels = centroid_scores$Stage,
       pos = 3,
       cex = 0.85,
       font = 2,
       col = stage_cols[as.character(centroid_scores$Stage)])
  
  usr <- par("usr")
  
  panel_title <- paste(
    switch(res_obj$Habitat,
           "Phyllosphere" = "Leaf",
           "Endosphere" = "Root",
           "Rhizosphere" = "Rhizosphere",
           res_obj$Habitat),
    "|",
    res_obj$Metric
  )
  
  text(usr[1] + 0.50 * (usr[2] - usr[1]),
       usr[3] + 0.05 * (usr[4] - usr[3]),
       labels = panel_title,
       cex = 1.0,
       font = 2)
  
  text(usr[1] + 0.02 * (usr[2] - usr[1]),
       usr[4] - 0.03 * (usr[4] - usr[3]),
       labels = paste0("Adonis: P ", format_p(res_obj$Adonis_P)),
       adj = c(0,1), cex = 0.82)
  
  text(usr[1] + 0.02 * (usr[2] - usr[1]),
       usr[4] - 0.12 * (usr[4] - usr[3]),
       labels = paste0("Betadisper: P ", format_p(res_obj$Betadisper_P)),
       adj = c(0,1), cex = 0.82)
  
  box(col = "black")
}

###############################
## 8. richness 作图函数
###############################
draw_richness_panel <- function(rich_df, habitat_name, show_ylab = TRUE){
  
  boxplot(Richness ~ Stage,
          data = rich_df,
          col = stage_cols[stage_levels],
          border = "black",
          xlab = "",
          ylab = if(show_ylab) "Richness" else "",
          main = switch(habitat_name,
                        "Phyllosphere" = "Leaf",
                        "Endosphere" = "Root",
                        "Rhizosphere" = "Rhizosphere",
                        habitat_name),
          cex.main = 1.1,
          cex.axis = 0.9,
          cex.lab = 1.0)
}

###############################
## 9. 准备三个生态位
###############################
prep_leaf <- prepare_one_habitat(
  asv_file = "叶际_ASV_FungalTraits_with_abundance.csv",
  group_file = "叶际分组.csv",
  habitat_name = "Phyllosphere"
)

prep_endo <- prepare_one_habitat(
  asv_file = "根内_ASV_FungalTraits_with_abundance.csv",
  group_file = "根内分组.csv",
  habitat_name = "Endosphere"
)

prep_rhizo <- prepare_one_habitat(
  asv_file = "根际_ASV_FungalTraits_with_abundance.csv",
  group_file = "根际分组.csv",
  habitat_name = "Rhizosphere"
)

###############################
## 10. 跑四类指标
###############################
metrics <- c("bray", "jaccard", "turnover", "nestedness")

res_list <- list()

for(hab in list(prep_leaf, prep_endo, prep_rhizo)){
  for(m in metrics){
    key <- paste(hab$Habitat, m, sep = "__")
    res_list[[key]] <- analyze_metric(hab, m)
  }
}

###############################
## 11. 汇总统计表
###############################
stat_res <- do.call(rbind, lapply(res_list, function(x){
  data.frame(
    Habitat = x$Habitat,
    Metric = x$Metric,
    Betadisper_F = x$Betadisper_F,
    Betadisper_P = x$Betadisper_P,
    Adonis_F = x$Adonis_F,
    Adonis_R2 = x$Adonis_R2,
    Adonis_P = x$Adonis_P,
    Richness_P = x$Richness_P
  )
}))

write.csv(stat_res, "Succession_metric_comparison_stats.csv", row.names = FALSE)

###############################
## 12. 汇总 distance-to-centroid 和 richness
###############################
dist_all <- do.call(rbind, lapply(res_list, function(x) x$dist_df))
write.csv(dist_all, "Succession_distance_to_centroid_all_metrics.csv", row.names = FALSE)

richness_all <- do.call(rbind, lapply(res_list[c("Phyllosphere__turnover",
                                                 "Endosphere__turnover",
                                                 "Rhizosphere__turnover")], function(x) x$richness_df))
write.csv(richness_all, "Succession_richness_by_stage.csv", row.names = FALSE)

###############################
## 13. 画四类指标图（3 × 4）
###############################
pdf("Succession_metric_comparison_12panels.pdf", width = 16, height = 10)

par(mfrow = c(3, 4), mar = c(3.2, 3.2, 1.8, 0.8))

for(hab_name in c("Phyllosphere", "Endosphere", "Rhizosphere")){
  for(m in metrics){
    key <- paste(hab_name, m, sep = "__")
    draw_panel_metric(res_list[[key]], show_ylab = (m == "bray"))
  }
}

legend("topright",
       legend = stage_levels,
       col = stage_cols[stage_levels],
       pch = 16,
       pt.cex = 1.0,
       bty = "n",
       cex = 0.85)

dev.off()

###############################
## 14. 画 richness 图
###############################
leaf_rich <- res_list[["Phyllosphere__turnover"]]$richness_df
endo_rich <- res_list[["Endosphere__turnover"]]$richness_df
rhizo_rich <- res_list[["Rhizosphere__turnover"]]$richness_df

pdf("Succession_richness_by_stage.pdf", width = 10, height = 3.5)

par(mfrow = c(1, 3), mar = c(4, 4, 2, 1))
draw_richness_panel(leaf_rich, "Phyllosphere", show_ylab = TRUE)
draw_richness_panel(endo_rich, "Endosphere", show_ylab = FALSE)
draw_richness_panel(rhizo_rich, "Rhizosphere", show_ylab = FALSE)

dev.off()

###############################
## 15. 给出机制解释建议
###############################
cat("\n===== 机制解释建议 =====\n")

for(h in c("Phyllosphere", "Endosphere", "Rhizosphere")){
  
  sub <- stat_res[stat_res$Habitat == h, ]
  p_bray <- sub[sub$Metric == "bray", "Adonis_P"]
  p_jac  <- sub[sub$Metric == "jaccard", "Adonis_P"]
  p_jtu  <- sub[sub$Metric == "turnover", "Adonis_P"]
  p_jne  <- sub[sub$Metric == "nestedness", "Adonis_P"]
  p_rich <- unique(sub$Richness_P)
  
  cat("\nHabitat:", h, "\n")
  cat("Bray Adonis P =", format_p(p_bray), "\n")
  cat("Jaccard Adonis P =", format_p(p_jac), "\n")
  cat("Turnover Adonis P =", format_p(p_jtu), "\n")
  cat("Nestedness Adonis P =", format_p(p_jne), "\n")
  cat("Richness Kruskal P =", format_p(p_rich), "\n")
  
  if(!is.na(p_jtu) && p_jtu < 0.05 && (is.na(p_jne) || p_jne >= 0.05) && (is.na(p_rich) || p_rich >= 0.05)){
    cat("Interpretation: temporal change is mainly consistent with species turnover rather than richness variation.\n")
  } else if(!is.na(p_jtu) && p_jtu < 0.05 && !is.na(p_rich) && p_rich < 0.05){
    cat("Interpretation: turnover is important, but richness variation may also contribute.\n")
  } else {
    cat("Interpretation: evidence is insufficient to claim turnover-dominated change alone.\n")
  }
}

###############################
## 16. 输出结果
###############################
print(stat_res)
cat("\n已生成文件：\n")
cat("1) Succession_metric_comparison_stats.csv\n")
cat("2) Succession_distance_to_centroid_all_metrics.csv\n")
cat("3) Succession_richness_by_stage.csv\n")
cat("4) Succession_metric_comparison_12panels.pdf\n")
cat("5) Succession_richness_by_stage.pdf\n")