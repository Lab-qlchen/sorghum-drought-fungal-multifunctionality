############################################################
## Sample-level Niche Breadth analysis (fungi)
## Calculate Levin's niche breadth for ASVs and 
## community-weighted mean (CWM) for each sample
## Non-parametric statistics (Dunn + BH)
############################################################
setwd("D:/IUE/山西数据/真菌/抽平/totalASVs 内聚力_宽度_重叠指数")

library(tidyverse)
library(ggpubr)
library(rstatix)

############################################################
## 0. 读取 ASV 表并构建相对丰度 otu_rel
############################################################

asv <- read.csv("根内.csv", check.names = FALSE)

# 行 = ASV，列 = Sample
rownames(asv) <- asv[, 1]
otu <- asv[, -1]

# 相对丰度（按列归一化，使得每个样本丰度总和为1）
otu_rel <- sweep(otu, 2, colSums(otu), "/")
otu_rel[is.na(otu_rel)] <- 0

############################################################
## 1. 读取分组信息
############################################################

group <- read.csv("根内分组.csv", stringsAsFactors = FALSE)
colnames(group) <- c("Sample", "Group")

meta <- group %>%
  mutate(
    Period = case_when(
      grepl("^JS_", Group) ~ "Jointing stage",
      grepl("^HS_", Group) ~ "Heading stage",
      grepl("^FS_", Group) ~ "Filling stage",
      grepl("^MS_", Group) ~ "Maturity stage"
    ),
    Drought = case_when(
      grepl("_Control$",   Group) ~ "Control",
      grepl("_Drought_L$", Group) ~ "Drought_L",
      grepl("_Drought_M$", Group) ~ "Drought_M",
      grepl("_Drought_H$", Group) ~ "Drought_H"
    )
  )

############################################################
## 2. 计算物种水平与群落水平 生态位宽度 (Niche Breadth)
############################################################

# 过滤掉整个数据集中丰度为0的假ASV
otu_row_sums <- rowSums(otu)
keep_asv <- otu_row_sums > 0
otu_f <- otu[keep_asv, , drop = FALSE]
otu_rel_f <- otu_rel[keep_asv, , drop = FALSE]

# 步骤 2.1: 计算每个 ASV 的标准化 Levin's niche breadth (Bi)
# P_ij = ASV i 在样本 j 中的丰度 / ASV i 在所有样本中的总丰度
P_ij <- sweep(otu_f, 1, rowSums(otu_f), "/")

# Levin's index: B = 1 / sum(P_ij^2)
B_i <- 1 / rowSums(P_ij^2)

# 标准化 B_norm = (B - 1) / (N_samples - 1)，将值域缩放到 0~1 之间
N_samples <- ncol(otu_f)
B_norm <- (B_i - 1) / (N_samples - 1)
############################################################
## 补充：输出单个物种 (ASV) 的生态位宽度
############################################################

asv_niche_breadth <- data.frame(
  ASV = rownames(otu_f),
  Niche_Breadth_Raw = as.numeric(B_i),       # 原始 Levin's B (范围: 1 到 样本总数)
  Niche_Breadth_Norm = as.numeric(B_norm)    # 标准化后的 B (范围: 0 到 1)
)

# 按照标准化生态位宽度从大到小排序，方便你直接看谁是泛化种
asv_niche_breadth <- asv_niche_breadth[order(asv_niche_breadth$Niche_Breadth_Norm, decreasing = TRUE), ]

write.csv(asv_niche_breadth,
          "根内_ASV_level_Niche_Breadth.csv",
          row.names = FALSE)

# 步骤 2.2: 计算群落水平加权平均生态位宽度 (Community-weighted mean niche breadth)
# 针对每一个样本 (列)，用 ASV 的标准化生态位宽度 乘以 其在样本中的相对丰度 并求和
B_com <- colSums(otu_rel_f * B_norm)

# 构建最终的 Sample-level dataframe
nb_sample_raw <- data.frame(
  Sample = names(B_com),
  Niche_Breadth = as.numeric(B_com)
)

# 与 metadata 合并
nb_sample <- merge(nb_sample_raw, meta, by = "Sample")

write.csv(nb_sample,
          "根内_sample_level_Niche_Breadth.csv",
          row.names = FALSE)

############################################################
## 3. 因子顺序（保证图表显示顺序符合逻辑）
############################################################

nb_sample$Drought <- factor(
  nb_sample$Drought,
  levels = c("Control","Drought_L","Drought_M","Drought_H")
)

nb_sample$Period <- factor(
  nb_sample$Period,
  levels = c("Jointing stage",
             "Heading stage",
             "Filling stage",
             "Maturity stage")
)

############################################################
## 4. Dunn 检验（输出全部 FDR）
############################################################

stat_nb_all <- nb_sample %>%
  group_by(Period) %>%
  dunn_test(Niche_Breadth ~ Drought, p.adjust.method = "BH")

write.csv(
  stat_nb_all,
  "根内Niche_Breadth_Dunn_test_results_FDR_all.csv",
  row.names = FALSE
)

# 提取显著差异（FDR < 0.05）用于图中标注
stat_nb_sig <- stat_nb_all %>%
  filter(p.adj < 0.05) %>%
  add_xy_position(x = "Drought")

############################################################
## 5. 箱线图 + jitter（与 Dunn 检验一致）
############################################################

p_nb <- ggplot(
  nb_sample,
  aes(x = Drought, y = Niche_Breadth, fill = Drought)
) +
  geom_boxplot(width = 0.6, outlier.shape = NA) +
  geom_jitter(width = 0.15, size = 1, alpha = 0.7) +
  facet_wrap(~ Period, nrow = 1, scales = "free_y") +
  theme_bw() +
  labs(
    x = "Drought treatment",
    y = "Community-level niche breadth"
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none",
    strip.text = element_text(size = 12)
  )

# 保存基础图
print(p_nb)
ggsave("根内_sample_level_Niche_Breadth_boxplot.pdf",
       plot = p_nb,
       width = 12, height = 4)

# 若存在显著性差异，保存带显著性字母/星号的版本
if (nrow(stat_nb_sig) > 0) {
  p_nb_sig <- p_nb +
    stat_pvalue_manual(
      stat_nb_sig,
      label = "p.adj.signif",
      hide.ns = TRUE
    )
  
  print(p_nb_sig)
  ggsave("根内_sample_level_Niche_Breadth_boxplot_with_significance.pdf",
         plot = p_nb_sig,
         width = 12, height = 4)
}

############################################################
## END
############################################################