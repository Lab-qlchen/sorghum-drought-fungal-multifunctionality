############################################################
## Extract Z- and Z+ taxa within the community threshold ±0.5 window
## Compare ASV-level niche breadth across three compartments
## Combine plots: Phyllosphere, Endosphere, Rhizosphere
############################################################

rm(list = ls())
options(stringsAsFactors = FALSE)

library(tidyverse)
library(ggpubr)

# 1. Set working directory
setwd("D:/IUE/山西数据/真菌/抽平/totalASVs 内聚力_宽度_重叠指数") 

# 2. Read TITAN significant OTUs
titan_raw <- read_csv("TITAN_significant_OTUs.csv", show_col_types = FALSE)

# 3. Threshold plan for three compartments
threshold_plan <- tibble::tribble(
  ~Habitat,       ~Compartment,    ~z_minus_th, ~z_plus_th,
  "Leaf",         "Phyllosphere",  1.5,         1.5,
  "Root",         "Endosphere",    2.0,         2.0,
  "Rhizosphere",  "Rhizosphere",   2.0,         2.5
)

# Chinese file prefixes for reading niche breadth tables
file_prefix <- tibble::tribble(
  ~Compartment,    ~CN,
  "Phyllosphere",  "叶际",
  "Endosphere",    "根内",
  "Rhizosphere",   "根际"
)

threshold_plan <- threshold_plan %>%
  left_join(file_prefix, by = "Compartment")

# 4. Lists for saving plots, data and statistics
plot_list <- list()
data_list <- list()
stat_list <- list()

# 5. Loop over three compartments
for(i in seq_len(nrow(threshold_plan))) {
  
  hab_en <- threshold_plan$Habitat[i]
  comp   <- threshold_plan$Compartment[i]
  cn     <- threshold_plan$CN[i]
  zm_th  <- threshold_plan$z_minus_th[i]
  zp_th  <- threshold_plan$z_plus_th[i]
  
  cat(sprintf("\n================= Processing: %s =================\n", comp))
  
  # 5.1 Strict filtering within Z- and Z+ threshold ±0.5 windows
  titan_strict <- titan_raw %>%
    filter(Habitat == hab_en) %>%
    mutate(
      keep = case_when(
        Titan == "z-" & zenv.cp >= (zm_th - 0.5) & zenv.cp <= (zm_th + 0.5) ~ TRUE,
        Titan == "z+" & zenv.cp >= (zp_th - 0.5) & zenv.cp <= (zp_th + 0.5) ~ TRUE,
        TRUE ~ FALSE
      )
    ) %>%
    filter(keep) %>%
    select(ASV, Titan, zenv.cp)
  
  cat("Number of threshold-associated taxa after strict filtering:\n")
  print(table(titan_strict$Titan))
  
  # 5.2 Read ASV-level niche breadth table
  nb_file <- paste0(cn, "_ASV_level_Niche_Breadth.csv")
  
  if(!file.exists(nb_file)) {
    cat("Warning: file not found: ", nb_file, ". Skipping this compartment.\n", sep = "")
    next
  }
  
  nb_asv <- read_csv(nb_file, show_col_types = FALSE)
  
  # 5.3 Merge TITAN taxa with niche breadth
  merged_data <- titan_strict %>%
    inner_join(nb_asv, by = "ASV") %>%
    mutate(
      Titan = factor(Titan, levels = c("z-", "z+")),
      Habitat = hab_en,
      Compartment = factor(
        comp,
        levels = c("Phyllosphere", "Endosphere", "Rhizosphere")
      )
    )
  
  if(nrow(merged_data) < 2 || n_distinct(merged_data$Titan) < 2) {
    cat("Warning: too few data or only one TITAN group in ", comp, ". Skipping.\n", sep = "")
    next
  }
  
  # 5.4 Wilcoxon rank-sum test
  stat_test <- compare_means(
    Niche_Breadth_Norm ~ Titan,
    data = merged_data,
    method = "wilcox.test"
  ) %>%
    mutate(
      Habitat = hab_en,
      Compartment = comp,
      y.position = max(merged_data$Niche_Breadth_Norm, na.rm = TRUE) + 0.05
    )
  
  cat(sprintf("===== Wilcoxon test for Z- vs Z+ niche breadth in %s =====\n", comp))
  print(stat_test)
  
  # 5.5 Single-compartment plot
  p_tradeoff <- ggplot(
    merged_data,
    aes(x = Titan, y = Niche_Breadth_Norm, fill = Titan)
  ) +
    geom_boxplot(
      width = 0.5,
      outlier.shape = NA,
      alpha = 0.8
    ) +
    geom_jitter(
      width = 0.15,
      size = 2.2,
      alpha = 0.7,
      color = "grey20"
    ) +
    scale_fill_manual(
      values = c("z-" = "#377eb8", "z+" = "#4daf4a")
    ) +
    stat_pvalue_manual(
      stat_test,
      y.position = "y.position",
      label = "p.signif",
      size = 5
    ) +
    labs(
      x = "Threshold-associated taxa",
      y = "Standardized niche breadth",
      title = comp
    ) +
    theme_bw(base_size = 12) +
    theme(
      legend.position = "none",
      plot.title = element_text(
        hjust = 0.5,
        face = "bold",
        size = 14
      ),
      axis.text = element_text(size = 11, color = "black"),
      axis.title = element_text(size = 12),
      panel.grid.major.x = element_blank()
    )
  
  # 5.6 Save single plot
  out_pdf <- paste0(comp, "_threshold_taxa_niche_breadth_Zminus_Zplus.pdf")
  
  ggsave(
    out_pdf,
    plot = p_tradeoff,
    width = 4.5,
    height = 5,
    dpi = 300
  )
  
  cat("Single plot saved: ", out_pdf, "\n", sep = "")
  
  # 5.7 Store results
  plot_list[[comp]] <- p_tradeoff
  data_list[[comp]] <- merged_data
  stat_list[[comp]] <- stat_test
}

############################################################
## 6. Combine plots in the order:
## Phyllosphere → Endosphere → Rhizosphere
############################################################

plot_order <- c("Phyllosphere", "Endosphere", "Rhizosphere")

plot_list_ordered <- plot_list[plot_order]
plot_list_ordered <- plot_list_ordered[!sapply(plot_list_ordered, is.null)]

if(length(plot_list_ordered) == 0) {
  
  stop("No plots were generated. Please check input files and data.")
  
} else {
  
  p_combined <- ggarrange(
    plotlist = plot_list_ordered,
    ncol = length(plot_list_ordered),
    nrow = 1,
    labels = LETTERS[1:length(plot_list_ordered)],
    font.label = list(size = 14, face = "bold")
  )
  
  p_combined <- annotate_figure(
    p_combined,
    top = text_grob(
      "Niche breadth of TITAN Z- and Z+ threshold-associated taxa",
      face = "bold",
      size = 15
    )
  )
  
  # Show combined plot in R
  print(p_combined)
  
  # Save combined plot
  ggsave(
    "Three_compartments_TITAN_Zminus_Zplus_niche_breadth_combined.pdf",
    plot = p_combined,
    width = 12,
    height = 5.2,
    dpi = 300
  )
  
  ggsave(
    "Three_compartments_TITAN_Zminus_Zplus_niche_breadth_combined.png",
    plot = p_combined,
    width = 12,
    height = 5.2,
    dpi = 300
  )
  
  cat("\nCombined plot saved:\n")
  cat("Three_compartments_TITAN_Zminus_Zplus_niche_breadth_combined.pdf\n")
  cat("Three_compartments_TITAN_Zminus_Zplus_niche_breadth_combined.png\n")
}

############################################################
## 7. Optional: export merged data and statistics
############################################################

if(length(data_list) > 0) {
  all_data <- bind_rows(data_list)
  write_csv(
    all_data,
    "Three_compartments_TITAN_threshold_taxa_niche_breadth_data.csv"
  )
}

if(length(stat_list) > 0) {
  all_stat <- bind_rows(stat_list)
  write_csv(
    all_stat,
    "Three_compartments_TITAN_threshold_taxa_niche_breadth_statistics.csv"
  )
}

cat("\n================= All three compartments processed! =================\n")