########################################
## Figure 3B：根际 TITAN ASV 的干旱响应与 SMF 关系
##
## 不再叠加到系统发育图上
## 独立绘制：
## 1. response bubble plot
## 2. drought response × SMF relationship quadrant plot
########################################

rm(list = ls())
options(stringsAsFactors = FALSE)

########################################
## 0. 工作目录
########################################

setwd("D:/IUE/山西数据/真菌/抽平/群落演替动态/TITAN阈值物种系统发育")

########################################
## 1. 加载 R 包
########################################

library(tidyverse)
library(readr)
library(cowplot)

## 如果想给象限图标注 ASV 名称，建议安装 ggrepel
if(!requireNamespace("ggrepel", quietly = TRUE)){
  message("Package 'ggrepel' is not installed. Labels will use geom_text(check_overlap = TRUE).")
} else {
  library(ggrepel)
}

########################################
## 2. 参数
########################################

## 读取之前系统发育图代码输出的根际结果表
used_file <- "根际_TITAN_threshold_nearby_by_Titan_ASVs_used_with_drought_and_SMF_response.csv"

## 显著性阈值
drought_alpha <- 0.05
smf_alpha <- 0.05

## 是否用 FDR 筛核心类群
## 现在建议先用 FALSE，因为显著 ASV 本来不多
use_fdr <- FALSE
fdr_alpha <- 0.10

## 展示模式：
## "all"：展示全部根际 TITAN 阈值 ASV
## "sig"：只展示干旱响应显著或 SMF 显著的 ASV
show_mode <- "sig"

########################################
## 3. 读取数据
########################################

used_tab <- read_csv(used_file, show_col_types = FALSE) %>%
  mutate(
    ASV = as.character(ASV),
    Titan = as.character(Titan),
    phylum = ifelse(is.na(phylum) | phylum == "", "Other", phylum),
    family = ifelse(is.na(family) | family == "", "Unclassified_family", family),
    primary_group = ifelse(is.na(primary_group) | primary_group == "", "NA", primary_group),
    
    spearman_r = as.numeric(spearman_r),
    mark_p = as.numeric(mark_p),
    smf_r = as.numeric(smf_r),
    smf_p = as.numeric(smf_p)
  ) %>%
  mutate(
    drought_fdr = if("drought_fdr" %in% colnames(.)) drought_fdr else p.adjust(mark_p, method = "BH"),
    smf_fdr = if("smf_fdr" %in% colnames(.)) smf_fdr else p.adjust(smf_p, method = "BH")
  )

########################################
## 4. 定义显著性和核心类群
########################################

if(use_fdr){
  used_tab <- used_tab %>%
    mutate(
      drought_sig = !is.na(drought_fdr) & drought_fdr < fdr_alpha,
      smf_sig = !is.na(smf_fdr) & smf_fdr < fdr_alpha
    )
} else {
  used_tab <- used_tab %>%
    mutate(
      drought_sig = !is.na(mark_p) & mark_p < drought_alpha,
      smf_sig = !is.na(smf_p) & smf_p < smf_alpha
    )
}

plot_tab <- used_tab %>%
  mutate(
    CoreGroup = case_when(
      drought_sig &
        drought_trend == "increase_with_drought" &
        smf_sig &
        smf_trend == "negative_with_SMF" ~
        "Drought-enriched & SMF-negative",
      
      drought_sig &
        drought_trend == "decrease_with_drought" &
        smf_sig &
        smf_trend == "positive_with_SMF" ~
        "Drought-depleted & SMF-positive",
      
      drought_sig & !smf_sig ~
        "Drought-responsive only",
      
      !drought_sig & smf_sig ~
        "SMF-correlated only",
      
      TRUE ~ "Other TITAN ASVs"
    ),
    CoreGroup = factor(
      CoreGroup,
      levels = c(
        "Drought-enriched & SMF-negative",
        "Drought-depleted & SMF-positive",
        "Drought-responsive only",
        "SMF-correlated only",
        "Other TITAN ASVs"
      )
    ),
    ASV_label = paste0(ASV, " | ", Titan, " | ", primary_group),
    minus_log10_drought_p = -log10(mark_p),
    minus_log10_smf_p = -log10(smf_p),
    minus_log10_drought_p = ifelse(is.infinite(minus_log10_drought_p), NA, minus_log10_drought_p),
    minus_log10_smf_p = ifelse(is.infinite(minus_log10_smf_p), NA, minus_log10_smf_p),
    
    ## conservative combined score:
    ## 只有干旱和 SMF 都强时这个值才大
    combined_p = pmax(mark_p, smf_p, na.rm = TRUE),
    combined_score = -log10(combined_p),
    combined_score = ifelse(is.infinite(combined_score), NA, combined_score)
  )

if(show_mode == "sig"){
  plot_tab_show <- plot_tab %>%
    filter(drought_sig | smf_sig)
} else {
  plot_tab_show <- plot_tab
}

########################################
## 5. 排序
########################################

asv_order <- plot_tab_show %>%
  mutate(
    is_core = CoreGroup %in% c(
      "Drought-enriched & SMF-negative",
      "Drought-depleted & SMF-positive"
    ),
    abs_smf_r = abs(smf_r),
    abs_drought_r = abs(spearman_r)
  ) %>%
  arrange(
    desc(is_core),
    CoreGroup,
    Titan,
    desc(abs_smf_r),
    desc(abs_drought_r)
  ) %>%
  pull(ASV_label)

plot_tab_show <- plot_tab_show %>%
  mutate(
    ASV_label = factor(ASV_label, levels = rev(asv_order))
  )

########################################
## 6. 气泡图数据
########################################

bubble_tab <- plot_tab_show %>%
  select(
    ASV, ASV_label, Titan, phylum, primary_group, CoreGroup,
    spearman_r, mark_p, drought_fdr, drought_trend, drought_sig,
    smf_r, smf_p, smf_fdr, smf_trend, smf_sig
  ) %>%
  pivot_longer(
    cols = c(spearman_r, smf_r),
    names_to = "Metric_raw",
    values_to = "Effect"
  ) %>%
  mutate(
    Metric = case_when(
      Metric_raw == "spearman_r" ~ "Drought response",
      Metric_raw == "smf_r" ~ "SMF relationship",
      TRUE ~ Metric_raw
    ),
    P_value = case_when(
      Metric_raw == "spearman_r" ~ mark_p,
      Metric_raw == "smf_r" ~ smf_p,
      TRUE ~ NA_real_
    ),
    FDR = case_when(
      Metric_raw == "spearman_r" ~ drought_fdr,
      Metric_raw == "smf_r" ~ smf_fdr,
      TRUE ~ NA_real_
    ),
    Significant = case_when(
      Metric_raw == "spearman_r" ~ drought_sig,
      Metric_raw == "smf_r" ~ smf_sig,
      TRUE ~ FALSE
    ),
    neg_log10_p = -log10(P_value),
    neg_log10_p = ifelse(is.infinite(neg_log10_p), NA, neg_log10_p),
    Metric = factor(
      Metric,
      levels = c("Drought response", "SMF relationship")
    )
  )

write_csv(
  bubble_tab,
  "Rhizosphere_TITAN_ASV_drought_SMF_response_bubble_data.csv"
)

########################################
## 7. 图 1：响应气泡图
########################################

p_bubble <- ggplot(
  bubble_tab,
  aes(
    x = Metric,
    y = ASV_label
  )
) +
  geom_point(
    aes(
      size = neg_log10_p,
      fill = Effect,
      alpha = Significant,
      shape = Titan
    ),
    color = "black",
    stroke = 0.25
  ) +
  scale_shape_manual(
    values = c("z-" = 21, "z+" = 24),
    name = "TITAN"
  ) +
  scale_fill_gradient2(
    low = "#2C7BB6",
    mid = "white",
    high = "#D7191C",
    midpoint = 0,
    name = "Spearman r"
  ) +
  scale_size_continuous(
    name = "-log10(P)",
    range = c(1.8, 6.5)
  ) +
  scale_alpha_manual(
    values = c("TRUE" = 1, "FALSE" = 0.25),
    name = "Significant"
  ) +
  facet_grid(
    CoreGroup ~ .,
    scales = "free_y",
    space = "free_y"
  ) +
  labs(
    x = NULL,
    y = NULL,
    title = "Drought response and SMF relationship of rhizosphere TITAN ASVs",
    subtitle = "Each ASV was analyzed within its corresponding TITAN threshold stage/window"
  ) +
  theme_bw() +
  theme(
    strip.background = element_rect(fill = "grey90"),
    strip.text.y = element_text(face = "bold", size = 9),
    axis.text.x = element_text(angle = 25, hjust = 1),
    axis.text.y = element_text(size = 7),
    legend.position = "right"
  )

########################################
## 8. 图 2：象限图
########################################

core_label_tab <- plot_tab %>%
  filter(
    CoreGroup %in% c(
      "Drought-enriched & SMF-negative",
      "Drought-depleted & SMF-positive"
    )
  )

p_quadrant <- ggplot(
  plot_tab,
  aes(
    x = spearman_r,
    y = smf_r
  )
) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey50"
  ) +
  geom_vline(
    xintercept = 0,
    linetype = "dashed",
    color = "grey50"
  ) +
  geom_point(
    aes(
      color = CoreGroup,
      shape = Titan,
      size = combined_score
    ),
    alpha = 0.85
  ) +
  scale_shape_manual(
    values = c("z-" = 16, "z+" = 17),
    name = "TITAN"
  ) +
  scale_size_continuous(
    name = "-log10(max P)",
    range = c(1.8, 6)
  ) +
  scale_color_manual(
    values = c(
      "Drought-enriched & SMF-negative" = "#D7191C",
      "Drought-depleted & SMF-positive" = "#2C7BB6",
      "Drought-responsive only" = "#Fdae61",
      "SMF-correlated only" = "#80cdc1",
      "Other TITAN ASVs" = "grey70"
    ),
    name = "Response group"
  ) +
  labs(
    x = "Drought response of ASV abundance\nSpearman r",
    y = "Relationship with SMF\nSpearman r",
    title = "Coupled drought response and SMF relationship of rhizosphere TITAN ASVs",
    subtitle = "Core ASVs occur in the lower-right and upper-left quadrants"
  ) +
  theme_bw() +
  theme(
    legend.position = "right"
  )

if(requireNamespace("ggrepel", quietly = TRUE)){
  p_quadrant <- p_quadrant +
    ggrepel::geom_text_repel(
      data = core_label_tab,
      aes(label = ASV),
      size = 3,
      max.overlaps = Inf,
      box.padding = 0.3,
      point.padding = 0.2
    )
} else {
  p_quadrant <- p_quadrant +
    geom_text(
      data = core_label_tab,
      aes(label = ASV),
      size = 3,
      check_overlap = TRUE,
      vjust = -0.5
    )
}

########################################
## 9. 核心类群 guild 组成
########################################

guild_tab <- plot_tab %>%
  filter(
    CoreGroup %in% c(
      "Drought-enriched & SMF-negative",
      "Drought-depleted & SMF-positive"
    )
  ) %>%
  count(CoreGroup, primary_group, name = "N_ASV")

p_guild <- ggplot(
  guild_tab,
  aes(
    x = primary_group,
    y = N_ASV,
    fill = CoreGroup
  )
) +
  geom_col(
    position = position_dodge(width = 0.75),
    width = 0.65
  ) +
  coord_flip() +
  scale_fill_manual(
    values = c(
      "Drought-enriched & SMF-negative" = "#D7191C",
      "Drought-depleted & SMF-positive" = "#2C7BB6"
    )
  ) +
  labs(
    x = NULL,
    y = "Number of core ASVs",
    title = "Potential functional guilds of core ASVs"
  ) +
  theme_bw() +
  theme(
    legend.position = "bottom",
    axis.text.y = element_text(size = 9)
  )

########################################
########################################
## 10. 单独展示并输出象限图和 guild 图
## 不再合并 p_bubble / p_quadrant / p_guild
########################################

## 在 R / RStudio 中直接展示象限图
print(p_quadrant)

ggsave(
  "Rhizosphere_TITAN_ASV_drought_SMF_quadrant_only.pdf",
  p_quadrant,
  width = 8,
  height = 6,
  dpi = 300
)

ggsave(
  "Rhizosphere_TITAN_ASV_drought_SMF_quadrant_only.png",
  p_quadrant,
  width = 8,
  height = 6,
  dpi = 300
)

## 在 R / RStudio 中直接展示功能 guild 图
print(p_guild)

ggsave(
  "Rhizosphere_TITAN_core_ASV_guild_only.pdf",
  p_guild,
  width = 6,
  height = 5,
  dpi = 300
)

ggsave(
  "Rhizosphere_TITAN_core_ASV_guild_only.png",
  p_guild,
  width = 6,
  height = 5,
  dpi = 300
)

########################################
## 11. 输出结果表
########################################

write_csv(
  plot_tab,
  "Rhizosphere_TITAN_ASV_drought_SMF_response_summary.csv"
)

write_csv(
  guild_tab,
  "Rhizosphere_TITAN_core_ASV_guild_summary.csv"
)

########################################
## 12. 输出统计信息
########################################

cat("\n完成！\n")

cat("\n不同响应类型数量：\n")
print(table(plot_tab$CoreGroup))

cat("\n核心类群数量：\n")
print(
  plot_tab %>%
    filter(
      CoreGroup %in% c(
        "Drought-enriched & SMF-negative",
        "Drought-depleted & SMF-positive"
      )
    ) %>%
    count(CoreGroup)
)

cat("\n输出文件：\n")
cat("1. Rhizosphere_TITAN_ASV_drought_SMF_quadrant_only.pdf/png\n")
cat("2. Rhizosphere_TITAN_core_ASV_guild_only.pdf/png\n")
cat("3. Rhizosphere_TITAN_ASV_drought_SMF_response_summary.csv\n")
cat("4. Rhizosphere_TITAN_core_ASV_guild_summary.csv\n")