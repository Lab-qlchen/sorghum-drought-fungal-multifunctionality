############################################
## 单独绘制三生态位 TITAN 指示物种系统发育检验结果
## 只读取三个输出表
## 只输出 SES.MPD / SES.MNTD 点线汇总图
############################################

rm(list = ls())
options(stringsAsFactors = FALSE)

library(tidyverse)
library(ggplot2)

############################################
## 1. 设置工作目录
############################################

setwd("D:/IUE/山西数据/真菌/抽平/群落演替动态/TITAN阈值物种系统发育")

############################################
## 2. 文件列表
############################################

file_info <- tibble::tribble(
  ~Habitat,        ~CN,     ~file,
  "Phyllosphere", "叶际",  "叶际_TITAN_threshold_phylogenetic_clustering_test.csv",
  "Endosphere",   "根内",  "根内_TITAN_threshold_phylogenetic_clustering_test.csv",
  "Rhizosphere",  "根际",  "根际_TITAN_threshold_phylogenetic_clustering_test.csv"
)

############################################
## 3. 读取三个系统发育检验表
############################################

read_phylo_test <- function(Habitat, CN, file){
  
  if(!file.exists(file)){
    stop(paste0("找不到文件：", file))
  }
  
  df <- readr::read_csv(file, show_col_types = FALSE)
  
  required_cols <- c(
    "Group", "N_ASV",
    "MPD_SES", "MPD_P_two_sided", "Interpretation_MPD",
    "MNTD_SES", "MNTD_P_two_sided", "Interpretation_MNTD"
  )
  
  missing_cols <- setdiff(required_cols, colnames(df))
  
  if(length(missing_cols) > 0){
    stop(
      paste0(
        file, " 缺少以下列：",
        paste(missing_cols, collapse = ", ")
      )
    )
  }
  
  df %>%
    mutate(
      Habitat = Habitat,
      CN = CN
    )
}

phylo_raw <- purrr::pmap_dfr(file_info, read_phylo_test)

############################################
## 4. 整理成长表
############################################

plot_df <- bind_rows(
  
  phylo_raw %>%
    transmute(
      Habitat,
      CN,
      Group,
      N_ASV,
      Metric = "SES.MPD",
      SES = MPD_SES,
      P_value = MPD_P_two_sided,
      Interpretation = Interpretation_MPD
    ),
  
  phylo_raw %>%
    transmute(
      Habitat,
      CN,
      Group,
      N_ASV,
      Metric = "SES.MNTD",
      SES = MNTD_SES,
      P_value = MNTD_P_two_sided,
      Interpretation = Interpretation_MNTD
    )
  
) %>%
  mutate(
    Habitat = factor(
      Habitat,
      levels = c("Phyllosphere", "Endosphere", "Rhizosphere")
    ),
    CN = factor(
      CN,
      levels = c("叶际", "根内", "根际")
    ),
    Group = case_when(
      Group == "all_TITAN_threshold_ASVs" ~ "All threshold ASVs",
      Group == "z_minus" ~ "Z- ASVs",
      Group == "z_plus"  ~ "Z+ ASVs",
      TRUE ~ Group
    ),
    Group = factor(
      Group,
      levels = c("All threshold ASVs", "Z- ASVs", "Z+ ASVs")
    ),
    Metric = factor(
      Metric,
      levels = c("SES.MPD", "SES.MNTD")
    ),
    Interpretation_short = case_when(
      Interpretation == "Phylogenetic clustering" ~ "Clustering",
      Interpretation == "Phylogenetic overdispersion" ~ "Overdispersion",
      Interpretation == "Not significant" ~ "Not significant",
      Interpretation == "Too few ASVs" ~ "Too few ASVs",
      TRUE ~ Interpretation
    ),
    sig = case_when(
      is.na(P_value) ~ "",
      P_value < 0.001 ~ "***",
      P_value < 0.01  ~ "**",
      P_value < 0.05  ~ "*",
      TRUE ~ "ns"
    )
  )

############################################
## 5. 输出整理后的长表
############################################

readr::write_csv(
  plot_df,
  "三生态位_TITAN系统发育检验_整理后用于作图.csv"
)

############################################
## 6. 只绘制 SES.MPD / SES.MNTD 点线汇总图
############################################

p_ses <- ggplot(
  plot_df,
  aes(
    x = Group,
    y = SES,
    fill = Interpretation_short
  )
) +
  geom_hline(
    yintercept = 0,
    linetype = "solid",
    linewidth = 0.4,
    color = "grey40"
  ) +
  geom_hline(
    yintercept = c(-1.96, 1.96),
    linetype = "dashed",
    linewidth = 0.3,
    color = "grey70"
  ) +
  geom_segment(
    aes(
      x = Group,
      xend = Group,
      y = 0,
      yend = SES
    ),
    linewidth = 0.6,
    color = "grey50",
    na.rm = TRUE
  ) +
  geom_point(
    shape = 21,
    size = 4,
    color = "black",
    stroke = 0.4,
    na.rm = TRUE
  ) +
  geom_text(
    aes(
      label = sig,
      y = ifelse(
        is.na(SES),
        0,
        SES + ifelse(SES >= 0, 0.35, -0.35)
      )
    ),
    size = 4,
    na.rm = TRUE
  ) +
  geom_text(
    data = plot_df %>% filter(is.na(SES)),
    aes(
      x = Group,
      y = 0,
      label = Interpretation_short
    ),
    inherit.aes = FALSE,
    size = 3,
    color = "grey30"
  ) +
  facet_grid(
    Metric ~ Habitat,
    scales = "free_y"
  ) +
  scale_fill_manual(
    values = c(
      "Clustering" = "#377EB8",
      "Overdispersion" = "#E41A1C",
      "Not significant" = "#4DAF4A",
      "Too few ASVs" = "grey90"
    ),
    name = "Interpretation"
  ) +
  labs(
    x = NULL,
    y = "Standardized effect size",
    title = "Phylogenetic clustering test of TITAN threshold-associated ASVs",
    subtitle = "Negative SES indicates phylogenetic clustering; positive SES indicates overdispersion"
  ) +
  theme_bw(base_size = 12) +
  theme(
    strip.background = element_rect(fill = "grey95", color = "grey70"),
    strip.text = element_text(size = 12, face = "bold"),
    axis.text.x = element_text(angle = 35, hjust = 1),
    panel.grid.major.x = element_blank(),
    legend.position = "right",
    plot.title = element_text(face = "bold", size = 14),
    plot.subtitle = element_text(size = 11)
  )

print(p_ses)

############################################
## 7. 保存点线汇总图
############################################

ggsave(
  "三生态位_TITAN系统发育检验_SES点线汇总图.pdf",
  p_ses,
  width = 12,
  height = 7,
  dpi = 300
)

ggsave(
  "三生态位_TITAN系统发育检验_SES点线汇总图.png",
  p_ses,
  width = 12,
  height = 7,
  dpi = 300
)

cat("\n全部完成！\n")
cat("只输出 SES.MPD / SES.MNTD 点线汇总图：\n")
cat("1. 三生态位_TITAN系统发育检验_SES点线汇总图.pdf\n")
cat("2. 三生态位_TITAN系统发育检验_SES点线汇总图.png\n")
cat("3. 三生态位_TITAN系统发育检验_整理后用于作图.csv\n")