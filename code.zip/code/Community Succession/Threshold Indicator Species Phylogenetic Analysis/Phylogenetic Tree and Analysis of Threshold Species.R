########################################
## TITAN 阈值附近 z+ / z- 物种系统发育图
## 加入干旱响应显著性星号
## 加入 SMF 相关性显著性星号
## 加入系统发育聚集检验，并在图例侧展示结果
##
## 重要筛选逻辑：
## z- 物种：按 z- 阈值 ±0.5 筛选
## z+ 物种：按 z+ 阈值 ±0.5 筛选
## 不再把 z- 和 z+ 合并成同一个整体阈值区间
########################################

rm(list = ls())
options(stringsAsFactors = FALSE)

########################################
## 0. 设置工作目录
########################################
setwd("D:/IUE/山西数据/真菌/抽平/群落演替动态/TITAN阈值物种系统发育")

########################################
## 1. 加载 R 包
########################################
library(ape)
library(phytools)
library(tidyverse)
library(ggtree)
library(ggtreeExtra)
library(ggnewscale)
library(readr)
library(viridis)
library(cowplot)

########################################
## 2. 用户参数
########################################

## 阈值附近范围
## z- 和 z+ 分别按照各自阈值 ±0.5 筛选
cp_window <- 0.5

## 如果想限制每个生态位每类 z+/z- 最多绘制多少个 ASV，可以改这里
## 默认 Inf 表示不限制
max_asv_each_titan <- Inf

## 干旱响应差异分析方法
## spearman：检验随干旱梯度是否单调增加或降低
## kruskal ：检验四个干旱处理总体是否有差异
## both    ：Spearman 或 Kruskal 任一显著即标星
drought_response_method <- "spearman"

## 干旱响应显著性阈值
## 不进行 FDR 校正，直接使用原始 P 值
drought_alpha <- 0.05

## SMF 文件
smf_file <- "测试数据SMF_MeanZ_results.csv"

## 使用哪个 SMF 指标
## 可选：SMF_meanZ 或 SMF_meanZ_01
smf_value_col <- "SMF_meanZ"

## SMF 相关性显著性阈值
## 不进行 FDR 校正，直接使用原始 P 值
smf_alpha <- 0.05

## 系统发育聚集检验随机置换次数
## 测试时可先改为 999；正式结果建议 9999
phylo_runs <- 9999

## 阶段编号
stage_name <- c(
  "1" = "JS",
  "2" = "HS",
  "3" = "FS",
  "4" = "MS"
)

## 根据 TITAN 结果手动设定阈值
## 叶际：z- = 1.5, z+ = 1.5
## 根内：z- = 2.0, z+ = 2.0
## 根际：z- = 2.0, z+ = 2.5
threshold_plan <- tibble::tribble(
  ~Habitat,        ~CN,     ~Titan, ~threshold_cp,
  "Phyllosphere", "叶际",  "z-",   1.5,
  "Phyllosphere", "叶际",  "z+",   1.5,
  "Endosphere",   "根内",  "z-",   2.0,
  "Endosphere",   "根内",  "z+",   2.0,
  "Rhizosphere",  "根际",  "z-",   2.0,
  "Rhizosphere",  "根际",  "z+",   2.5
)

get_stage_used <- function(cp){
  if(abs(cp - round(cp)) < 1e-8){
    return(stage_name[as.character(round(cp))])
  } else {
    lo <- floor(cp)
    hi <- ceiling(cp)
    return(paste(
      stage_name[as.character(lo)],
      stage_name[as.character(hi)],
      sep = "+"
    ))
  }
}

threshold_plan$StageUsed <- vapply(
  threshold_plan$threshold_cp,
  get_stage_used,
  character(1)
)

threshold_plan <- threshold_plan %>%
  mutate(
    StageLow       = floor(threshold_cp),
    StageHigh      = ceiling(threshold_cp),
    UseSingleStage = abs(threshold_cp - round(threshold_cp)) < 1e-8
  )

print(threshold_plan)

########################################
## 3. 文件配置
########################################

habitat_files <- tibble::tribble(
  ~Habitat,        ~CN,     ~asv_file,        ~anno_file,                                  ~grp_file,
  "Phyllosphere", "叶际",  "叶际F_ASV.csv", "叶际_ASV_FungalTraits_with_abundance.csv",   "叶际分组.csv",
  "Endosphere",   "根内",  "根内F_ASV.csv", "根内_ASV_FungalTraits_with_abundance.csv",   "根内分组.csv",
  "Rhizosphere",  "根际",  "根际F_ASV.csv", "根际_ASV_FungalTraits_with_abundance.csv",   "根际分组.csv"
)

tree_file      <- "phylo.tre"
titan_otu_file <- "Figure3C_TITAN_significant_OTUs.csv"

########################################
## 4. 辅助函数
########################################

find_first_col <- function(df, candidates, required = TRUE){
  cn <- colnames(df)
  idx <- match(tolower(candidates), tolower(cn))
  idx <- idx[!is.na(idx)]
  
  if(length(idx) > 0){
    return(cn[idx[1]])
  }
  
  if(required){
    stop(
      paste0(
        "未找到必需列。候选列名为：",
        paste(candidates, collapse = ", "),
        "\n当前数据列名为：",
        paste(cn, collapse = ", ")
      )
    )
  } else {
    return(NA_character_)
  }
}

standardize_habitat <- function(x){
  x <- as.character(x)
  dplyr::case_when(
    x %in% c("Leaf", "leaf", "叶际", "Phyllosphere", "phyllosphere") ~ "Phyllosphere",
    x %in% c("Root", "root", "根内", "Endosphere", "endosphere") ~ "Endosphere",
    x %in% c("Soil", "soil", "根际", "Rhizosphere", "rhizosphere") ~ "Rhizosphere",
    TRUE ~ x
  )
}

standardize_titan <- function(x){
  x <- as.character(x)
  dplyr::case_when(
    x %in% c("1", "z-", "Z-", "decrease", "decreasing", "negative") ~ "z-",
    x %in% c("2", "z+", "Z+", "increase", "increasing", "positive") ~ "z+",
    stringr::str_detect(x, "z\\-") ~ "z-",
    stringr::str_detect(x, "z\\+") ~ "z+",
    TRUE ~ x
  )
}

clean_taxon_name <- function(x, prefix_pattern){
  x <- as.character(x)
  x <- gsub(prefix_pattern, "", x)
  x <- trimws(x)
  x[is.na(x) | x == ""] <- NA_character_
  x
}

standardize_asv_table <- function(asv){
  asv_col <- find_first_col(
    asv,
    c("ASV", "asv", "OTU", "otu", "FeatureID", "#OTU ID"),
    required = TRUE
  )
  colnames(asv)[colnames(asv) == asv_col] <- "ASV"
  
  phylum_col <- find_first_col(
    asv,
    c("phylum", "Phylum", "p__phylum"),
    required = FALSE
  )
  
  family_col <- find_first_col(
    asv,
    c("family", "Family", "f__family"),
    required = FALSE
  )
  
  if(!is.na(phylum_col) && phylum_col != "phylum"){
    colnames(asv)[colnames(asv) == phylum_col] <- "phylum"
  }
  
  if(!is.na(family_col) && family_col != "family"){
    colnames(asv)[colnames(asv) == family_col] <- "family"
  }
  
  if(!"phylum" %in% colnames(asv)){
    asv$phylum <- "Other"
  }
  
  if(!"family" %in% colnames(asv)){
    asv$family <- "Unclassified_family"
  }
  
  asv <- asv %>%
    mutate(
      ASV    = as.character(ASV),
      phylum = clean_taxon_name(phylum, "^p__"),
      family = clean_taxon_name(family, "^f__"),
      phylum = ifelse(is.na(phylum) | phylum == "", "Other", phylum),
      family = ifelse(is.na(family) | family == "", "Unclassified_family", family)
    ) %>%
    distinct(ASV, .keep_all = TRUE)
  
  asv
}

standardize_anno_table <- function(anno){
  asv_col <- find_first_col(
    anno,
    c("ASV", "asv", "OTU", "otu", "FeatureID", "#OTU ID"),
    required = TRUE
  )
  colnames(anno)[colnames(anno) == asv_col] <- "ASV"
  
  primary_col <- find_first_col(
    anno,
    c("primary", "Primary", "primary_group", "Primary2"),
    required = FALSE
  )
  
  if(!is.na(primary_col)){
    anno$primary_group <- as.character(anno[[primary_col]])
  } else {
    anno$primary_group <- NA_character_
  }
  
  anno <- anno %>%
    mutate(
      ASV = as.character(ASV),
      primary_group = ifelse(
        is.na(primary_group) | primary_group == "",
        NA,
        primary_group
      )
    ) %>%
    select(ASV, primary_group) %>%
    distinct(ASV, .keep_all = TRUE)
  
  anno
}

parse_group_file <- function(grp, habitat_cn, asv_colnames){
  
  grp <- grp %>%
    rename(Sample = 1, Group = 2) %>%
    mutate(
      Sample = as.character(Sample),
      Group  = as.character(Group)
    )
  
  sample_ids <- grp$Sample
  
  if(!all(sample_ids %in% asv_colnames)){
    bad_samples <- sample_ids[!sample_ids %in% asv_colnames]
    stop(
      paste0(
        habitat_cn,
        " 的分组文件中以下样本在 ASV 表中找不到：\n",
        paste(bad_samples, collapse = ", ")
      )
    )
  }
  
  grp <- grp %>%
    mutate(
      Stage = case_when(
        str_detect(Group, regex("JS", ignore_case = TRUE)) ~ "JS",
        str_detect(Group, regex("HS", ignore_case = TRUE)) ~ "HS",
        str_detect(Group, regex("FS", ignore_case = TRUE)) ~ "FS",
        str_detect(Group, regex("MS", ignore_case = TRUE)) ~ "MS",
        TRUE ~ NA_character_
      ),
      StageNum = case_when(
        Stage == "JS" ~ 1,
        Stage == "HS" ~ 2,
        Stage == "FS" ~ 3,
        Stage == "MS" ~ 4,
        TRUE ~ NA_real_
      ),
      Drought = case_when(
        str_detect(Group, "_Control$")   ~ "Control",
        str_detect(Group, "_Drought_L$") ~ "Drought_L",
        str_detect(Group, "_Drought_M$") ~ "Drought_M",
        str_detect(Group, "_Drought_H$") ~ "Drought_H",
        str_detect(Group, "Control")     ~ "Control",
        str_detect(Group, "Drought_L")   ~ "Drought_L",
        str_detect(Group, "Drought_M")   ~ "Drought_M",
        str_detect(Group, "Drought_H")   ~ "Drought_H",
        TRUE ~ NA_character_
      )
    )
  
  if(any(is.na(grp$StageNum))){
    bad <- grp %>% filter(is.na(StageNum)) %>% pull(Group)
    stop(
      paste0(
        habitat_cn,
        " 的分组文件中以下 Group 无法识别时期 JS/HS/FS/MS：\n",
        paste(bad, collapse = ", ")
      )
    )
  }
  
  if(any(is.na(grp$Drought))){
    bad <- grp %>% filter(is.na(Drought)) %>% pull(Group)
    stop(
      paste0(
        habitat_cn,
        " 的分组文件中以下 Group 无法识别干旱处理 Control/Drought_L/Drought_M/Drought_H：\n",
        paste(bad, collapse = ", ")
      )
    )
  }
  
  drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
  
  grp <- grp %>%
    mutate(
      Stage   = factor(Stage, levels = c("JS", "HS", "FS", "MS")),
      Drought = factor(Drought, levels = drought_levels)
    )
  
  grp
}

format_phylo_p <- function(x){
  ifelse(
    is.na(x),
    "NA",
    ifelse(x < 0.001, "<0.001", sprintf("%.3f", x))
  )
}

short_phylo_interpret <- function(x){
  dplyr::case_when(
    x == "Phylogenetic clustering" ~ "Cluster",
    x == "Phylogenetic overdispersion" ~ "Overdisp.",
    x == "Not significant" ~ "NS",
    x == "Too few ASVs" ~ "Too few",
    x == "Background too small" ~ "Bg small",
    x == "Invalid phylogenetic distance" ~ "Invalid dist.",
    x == "Invalid observed MPD/MNTD" ~ "Invalid obs.",
    x == "Invalid null MPD/MNTD" ~ "Invalid null",
    TRUE ~ as.character(x)
  )
}

make_phylo_summary_text <- function(phylo_cluster_results, habitat_cn){
  
  habitat_show <- dplyr::case_when(
    habitat_cn == "叶际" ~ "Phyllosphere",
    habitat_cn == "根内" ~ "Endosphere",
    habitat_cn == "根际" ~ "Rhizosphere",
    TRUE ~ habitat_cn
  )
  
  if(nrow(phylo_cluster_results) == 0){
    return(paste0(habitat_show, "\nPhylogenetic test\nNo result"))
  }
  
  tab <- phylo_cluster_results %>%
    mutate(
      Group_show = case_when(
        Group == "all_TITAN_threshold_ASVs" ~ "All threshold ASVs",
        Group == "z_minus" ~ "z- ASVs",
        Group == "z_plus" ~ "z+ ASVs",
        TRUE ~ Group
      ),
      MPD_short   = short_phylo_interpret(Interpretation_MPD),
      MNTD_short  = short_phylo_interpret(Interpretation_MNTD),
      MPD_p_show  = format_phylo_p(MPD_P_two_sided),
      MNTD_p_show = format_phylo_p(MNTD_P_two_sided),
      line = paste0(
        Group_show, " (n=", N_ASV, ")\n",
        "  MPD: ", MPD_short, ", P=", MPD_p_show, "\n",
        "  MNTD: ", MNTD_short, ", P=", MNTD_p_show
      )
    )
  
  paste(
    c(
      paste0(habitat_show, " phylogenetic test"),
      "SES.MPD / SES.MNTD",
      paste0("Null: random taxa; runs=", phylo_runs),
      "P: two-sided raw P",
      "",
      tab$line
    ),
    collapse = "\n"
  )
}

########################################
## 5. 读入系统发育树、TITAN 结果和 SMF 数据
########################################

tr0 <- read.tree(tree_file)

titan_raw <- read_csv(titan_otu_file, show_col_types = FALSE)

hab_col <- find_first_col(
  titan_raw,
  c("Habitat", "habitat", "Niche", "niche"),
  required = TRUE
)

titan_col <- find_first_col(
  titan_raw,
  c("Titan", "titan", "z", "direction"),
  required = TRUE
)

asv_col <- find_first_col(
  titan_raw,
  c("ASV", "asv", "OTU", "otu", "FeatureID"),
  required = TRUE
)

## 强制使用 zenv.cp
cp_col <- find_first_col(
  titan_raw,
  c("zenv.cp"),
  required = TRUE
)

x5_col <- find_first_col(
  titan_raw,
  c("X5.", "X5", "5%", "q5", "lower"),
  required = FALSE
)

x95_col <- find_first_col(
  titan_raw,
  c("X95.", "X95", "95%", "q95", "upper"),
  required = FALSE
)

primary_col_titan <- find_first_col(
  titan_raw,
  c("Primary", "primary", "primary_group"),
  required = FALSE
)

titan_sig <- titan_raw %>%
  mutate(
    ASV     = as.character(.data[[asv_col]]),
    Habitat = standardize_habitat(.data[[hab_col]]),
    Titan   = standardize_titan(.data[[titan_col]]),
    zenv_cp = as.numeric(.data[[cp_col]]),
    X5      = if(!is.na(x5_col))  as.numeric(.data[[x5_col]])  else NA_real_,
    X95     = if(!is.na(x95_col)) as.numeric(.data[[x95_col]]) else NA_real_,
    Primary_from_TITAN = if(!is.na(primary_col_titan)) {
      as.character(.data[[primary_col_titan]])
    } else {
      NA_character_
    }
  ) %>%
  filter(
    Habitat %in% c("Phyllosphere", "Endosphere", "Rhizosphere"),
    Titan %in% c("z-", "z+"),
    !is.na(ASV),
    !is.na(zenv_cp)
  )

cat("\nTITAN 结果读取完成。\n")
cat("强制使用的变化点列为：", cp_col, "\n")
cat("各生态位 z+ / z- 物种数量如下：\n")
print(table(titan_sig$Habitat, titan_sig$Titan))

########################################
## 5.2 读入 SMF 数据
########################################

if(!file.exists(smf_file)){
  stop(paste0("未找到 SMF 文件：", smf_file))
}

smf_raw <- read_csv(smf_file, show_col_types = FALSE)

if(!"Sample" %in% colnames(smf_raw)){
  stop("SMF 文件中没有 Sample 列，请检查文件。")
}

if(!smf_value_col %in% colnames(smf_raw)){
  stop(paste0("SMF 文件中没有 ", smf_value_col, " 列，请检查文件。"))
}

smf_tab <- smf_raw %>%
  mutate(
    Sample = as.character(Sample),
    SMF_value = as.numeric(.data[[smf_value_col]])
  ) %>%
  select(Sample, SMF_value) %>%
  distinct(Sample, .keep_all = TRUE)

cat("\nSMF 数据读取完成。\n")
cat("使用的 SMF 指标为：", smf_value_col, "\n")
cat("SMF 样本数：", nrow(smf_tab), "\n")

########################################
## 6. 颜色设置
########################################

phylum_colors <- c(
  Ascomycota        = "#4DAF4A",
  Basidiomycota     = "#377EB8",
  Mortierellomycota = "#FF7F00",
  Chytridiomycota   = "#984EA3",
  Rozellomycota     = "#E41A1C",
  Glomeromycota     = "#A65628",
  Other             = "grey80"
)

primary_colors <- c(
  animal_parasite        = "#72B285",
  dung_saprotroph        = "#EB8B39",
  foliar_endophyte       = "#B379B4",
  litter_saprotroph      = "#DB6968",
  plant_pathogen         = "#81B21F",
  soil_saprotroph        = "#65A2D2",
  unspecified_saprotroph = "#BEBFB4",
  wood_saprotroph        = "#2BAE9E"
)

titan_colors <- c(
  "z-" = "#65A2D2",
  "z+" = "#DB6968"
)

drought_star_colors <- c(
  "increase_with_drought" = "#D7191C",
  "decrease_with_drought" = "#2C7BB6"
)

smf_star_colors <- c(
  "positive_with_SMF" = "#D7191C",
  "negative_with_SMF" = "#2C7BB6"
)

########################################
## 7. 单个生态位绘图函数
########################################

plot_one_habitat <- function(habitat_id, habitat_cn, asv_file, anno_file, grp_file){
  
  cat("\n==============================\n")
  cat("开始处理：", habitat_cn, " / ", habitat_id, "\n")
  cat("==============================\n")
  
  ########################################
  ## 7.1 读入数据
  ########################################
  
  asv  <- read_csv(asv_file, show_col_types = FALSE)
  anno <- read_csv(anno_file, show_col_types = FALSE)
  grp  <- read_csv(grp_file, show_col_types = FALSE)
  
  asv  <- standardize_asv_table(asv)
  anno <- standardize_anno_table(anno)
  
  ########################################
  ## 7.2 分组文件解析
  ########################################
  
  grp <- parse_group_file(
    grp = grp,
    habitat_cn = habitat_cn,
    asv_colnames = colnames(asv)
  )
  
  sample_ids <- grp$Sample
  drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
  
  cat("识别到样本数：", length(sample_ids), "\n")
  cat("识别到时期：", paste(unique(as.character(grp$Stage)), collapse = ", "), "\n")
  cat("识别到干旱梯度：", paste(unique(as.character(grp$Drought)), collapse = ", "), "\n")
  
  ########################################
  ## 7.3 筛选 TITAN 阈值附近 z+ / z- 物种
  ## 重要：
  ## z- 按 z- 阈值 ±0.5 筛选
  ## z+ 按 z+ 阈值 ±0.5 筛选
  ## 不合并成生态位整体区间
  ########################################
  
  th_plan_hab <- threshold_plan %>%
    filter(Habitat == habitat_id)
  
  titan_hab_check <- titan_sig %>%
    filter(Habitat == habitat_id) %>%
    left_join(th_plan_hab, by = c("Habitat", "Titan")) %>%
    mutate(
      threshold_low  = threshold_cp - cp_window,
      threshold_high = threshold_cp + cp_window,
      cp_dist = abs(zenv_cp - threshold_cp),
      ci_width = X95 - X5,
      near_threshold = zenv_cp >= threshold_low & zenv_cp <= threshold_high
    )
  
  cat("\n", habitat_cn, "TITAN 阈值附近筛选检查：\n", sep = "")
  cat("当前 cp_window = ", cp_window, "\n", sep = "")
  cat("按 z- / z+ 各自阈值 ±0.5 分别筛选。\n")
  print(
    th_plan_hab %>%
      mutate(
        threshold_low = threshold_cp - cp_window,
        threshold_high = threshold_cp + cp_window
      ) %>%
      select(Titan, threshold_cp, threshold_low, threshold_high, StageUsed)
  )
  
  cat("\n按阈值附近筛选前，各类型数量：\n")
  print(table(titan_hab_check$Titan))
  
  cat("\nzenv.cp 落在各自阈值 ±0.5 内的数量：\n")
  print(table(titan_hab_check$Titan, titan_hab_check$near_threshold))
  
  titan_hab <- titan_hab_check %>%
    filter(near_threshold) %>%
    arrange(Titan, zenv_cp, cp_dist, ci_width)
  
  if(is.finite(max_asv_each_titan)){
    titan_hab <- titan_hab %>%
      group_by(Titan) %>%
      slice_head(n = max_asv_each_titan) %>%
      ungroup()
  }
  
  ########################################
  ## 7.4 与 ASV 表和系统发育树取交集
  ########################################
  
  common_asv <- Reduce(
    intersect,
    list(titan_hab$ASV, asv$ASV, tr0$tip.label)
  )
  
  if(length(common_asv) < 2){
    stop(
      paste0(
        habitat_cn,
        " 的 TITAN 阈值物种、ASV 表和系统发育树交集少于 2 个，无法正常绘图。"
      )
    )
  }
  
  titan_hab <- titan_hab %>%
    filter(ASV %in% common_asv)
  
  asv_sel <- asv %>%
    filter(ASV %in% common_asv)
  
  anno_sel <- anno %>%
    filter(ASV %in% common_asv)
  
  anno_sel <- tibble(ASV = common_asv) %>%
    left_join(anno_sel, by = "ASV") %>%
    left_join(
      titan_hab %>% select(ASV, Primary_from_TITAN),
      by = "ASV"
    ) %>%
    mutate(
      primary_group = ifelse(
        is.na(primary_group) | primary_group == "",
        Primary_from_TITAN,
        primary_group
      ),
      primary_group = ifelse(
        primary_group %in% names(primary_colors),
        primary_group,
        NA
      )
    ) %>%
    select(ASV, primary_group)
  
  cat("阈值附近保留 ASV 数量：", length(common_asv), "\n")
  print(table(titan_hab$Titan))
  
  ########################################
  ## 7.5 修剪系统发育树
  ########################################
  
  tr_filt <- keep.tip(tr0, common_asv)
  
  if(length(tr_filt$tip.label) >= 3){
    tr_filt <- midpoint.root(tr_filt)
  }
  
  ########################################
  ## 7.6 taxonomy 清洗
  ########################################
  
  asv_sel <- asv_sel %>%
    mutate(
      phylum = as.character(phylum),
      family = as.character(family)
    )
  
  asv_sel$phylum <- gsub("^p__", "", asv_sel$phylum)
  asv_sel$family <- gsub("^f__", "", asv_sel$family)
  
  asv_sel$phylum <- trimws(asv_sel$phylum)
  asv_sel$family <- trimws(asv_sel$family)
  
  asv_sel$phylum[is.na(asv_sel$phylum) | asv_sel$phylum == ""] <- "Other"
  asv_sel$family[is.na(asv_sel$family) | asv_sel$family == ""] <- "Unclassified_family"
  
  asv_sel <- asv_sel %>%
    mutate(phylum = ifelse(phylum %in% names(phylum_colors), phylum, "Other"))
  
  ########################################
  ## 7.7 TITAN 二分环数据
  ########################################
  
  titan_ring <- titan_hab %>%
    select(
      ASV, Titan, threshold_cp, StageUsed,
      StageLow, StageHigh, UseSingleStage,
      zenv_cp, X5, X95, cp_dist,
      threshold_low, threshold_high
    ) %>%
    mutate(
      Titan = factor(Titan, levels = c("z-", "z+"))
    )
  
  ########################################
  ## 7.8 ASV 标签
  ########################################
  
  asv_label <- titan_ring %>%
    select(ASV) %>%
    distinct() %>%
    mutate(ASV_label = ASV)
  
  ########################################
  ## 7.9 阈值时期样本丰度
  ########################################
  
  abundance_long <- asv_sel %>%
    select(ASV, all_of(sample_ids)) %>%
    pivot_longer(
      -ASV,
      names_to  = "Sample",
      values_to = "Abundance"
    ) %>%
    mutate(Abundance = as.numeric(Abundance)) %>%
    left_join(grp, by = "Sample") %>%
    left_join(
      titan_ring %>%
        select(
          ASV, Titan, threshold_cp, StageUsed,
          StageLow, StageHigh, UseSingleStage
        ),
      by = "ASV"
    ) %>%
    filter(
      case_when(
        UseSingleStage  ~ StageNum == StageLow,
        !UseSingleStage ~ StageNum >= StageLow & StageNum <= StageHigh,
        TRUE ~ FALSE
      )
    )
  
  ########################################
  ## 7.9.1 干旱响应分析
  ## 只使用阈值时期内的样本
  ## 不进行 FDR 校正
  ########################################
  
  drought_response <- abundance_long %>%
    mutate(
      Drought = factor(
        Drought,
        levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
      ),
      Drought_num = as.numeric(Drought) - 1,
      log2_abd = log2(Abundance + 1)
    ) %>%
    group_by(ASV) %>%
    group_modify(~{
      
      df <- .x %>%
        filter(!is.na(Drought), !is.na(Drought_num), !is.na(log2_abd))
      
      if(
        nrow(df) < 4 ||
        n_distinct(df$Drought) < 2 ||
        n_distinct(df$log2_abd) < 2
      ){
        return(tibble(
          kw_p = NA_real_,
          spearman_r = NA_real_,
          spearman_p = NA_real_
        ))
      }
      
      kw_p <- tryCatch(
        kruskal.test(log2_abd ~ Drought, data = df)$p.value,
        error = function(e) NA_real_
      )
      
      spearman_test <- tryCatch(
        suppressWarnings(
          cor.test(
            df$Drought_num,
            df$log2_abd,
            method = "spearman",
            exact = FALSE
          )
        ),
        error = function(e) NULL
      )
      
      spearman_r <- if(is.null(spearman_test)){
        NA_real_
      } else {
        unname(spearman_test$estimate)
      }
      
      spearman_p <- if(is.null(spearman_test)){
        NA_real_
      } else {
        spearman_test$p.value
      }
      
      tibble(
        kw_p = kw_p,
        spearman_r = spearman_r,
        spearman_p = spearman_p
      )
      
    }) %>%
    ungroup() %>%
    mutate(
      mark_p = if(drought_response_method == "spearman"){
        spearman_p
      } else if(drought_response_method == "kruskal"){
        kw_p
      } else {
        pmin(kw_p, spearman_p, na.rm = TRUE)
      },
      mark_p = ifelse(is.infinite(mark_p), NA_real_, mark_p),
      drought_response = !is.na(mark_p) & mark_p < drought_alpha,
      star = case_when(
        !is.na(mark_p) & mark_p < 0.001 ~ "***",
        !is.na(mark_p) & mark_p < 0.01  ~ "**",
        !is.na(mark_p) & mark_p < 0.05  ~ "*",
        TRUE ~ ""
      ),
      drought_trend = case_when(
        is.na(spearman_r) ~ "unknown",
        spearman_r > 0   ~ "increase_with_drought",
        spearman_r < 0   ~ "decrease_with_drought",
        TRUE             ~ "flat"
      ),
      drought_trend_label = case_when(
        drought_trend == "increase_with_drought" ~ "Increase with drought",
        drought_trend == "decrease_with_drought" ~ "Decrease with drought",
        TRUE ~ "Not significant"
      )
    )
  
  drought_star <- titan_ring %>%
    select(ASV) %>%
    distinct() %>%
    left_join(
      drought_response %>%
        select(
          ASV,
          star,
          drought_response,
          drought_trend,
          drought_trend_label,
          mark_p
        ),
      by = "ASV"
    ) %>%
    mutate(
      star = ifelse(
        !is.na(drought_response) & drought_response & !is.na(star),
        star,
        ""
      ),
      drought_trend = ifelse(
        star != "" & drought_trend %in% c("increase_with_drought", "decrease_with_drought"),
        drought_trend,
        NA_character_
      ),
      drought_trend = factor(
        drought_trend,
        levels = c("increase_with_drought", "decrease_with_drought")
      ),
      StarTrack = "Drought response"
    )
  
  drought_star_sig <- drought_star %>%
    filter(
      star != "",
      !is.na(drought_trend)
    )
  
  cat("\n", habitat_cn, "干旱响应显著 ASV 数量：\n", sep = "")
  if(nrow(drought_star_sig) > 0){
    print(table(drought_star_sig$drought_trend))
  } else {
    cat("无显著干旱响应 ASV。\n")
  }
  
  ########################################
  ## 7.9.2 SMF 相关分析
  ## 只使用 abundance_long 中已经筛选好的阈值时期样本
  ## 不进行 FDR 校正
  ########################################
  
  smf_input <- abundance_long %>%
    left_join(smf_tab, by = "Sample") %>%
    mutate(
      log2_abd = log2(Abundance + 1)
    ) %>%
    filter(!is.na(SMF_value))
  
  missing_smf_samples <- setdiff(unique(abundance_long$Sample), unique(smf_tab$Sample))
  
  if(length(missing_smf_samples) > 0){
    warning(
      paste0(
        habitat_cn,
        " 中有样本在 SMF 文件中找不到：\n",
        paste(missing_smf_samples, collapse = ", ")
      )
    )
  }
  
  if(nrow(smf_input) == 0){
    
    smf_response <- titan_ring %>%
      select(ASV) %>%
      distinct() %>%
      mutate(
        smf_r = NA_real_,
        smf_p = NA_real_,
        smf_response = FALSE,
        smf_star = "",
        smf_trend = "unknown",
        smf_trend_label = "Not significant"
      )
    
  } else {
    
    smf_response <- smf_input %>%
      group_by(ASV) %>%
      group_modify(~{
        
        df <- .x %>%
          filter(!is.na(SMF_value), !is.na(log2_abd))
        
        if(
          nrow(df) < 4 ||
          n_distinct(df$SMF_value) < 2 ||
          n_distinct(df$log2_abd) < 2
        ){
          return(tibble(
            smf_r = NA_real_,
            smf_p = NA_real_
          ))
        }
        
        smf_test <- tryCatch(
          suppressWarnings(
            cor.test(
              df$SMF_value,
              df$log2_abd,
              method = "spearman",
              exact = FALSE
            )
          ),
          error = function(e) NULL
        )
        
        smf_r <- if(is.null(smf_test)){
          NA_real_
        } else {
          unname(smf_test$estimate)
        }
        
        smf_p <- if(is.null(smf_test)){
          NA_real_
        } else {
          smf_test$p.value
        }
        
        tibble(
          smf_r = smf_r,
          smf_p = smf_p
        )
        
      }) %>%
      ungroup() %>%
      mutate(
        smf_response = !is.na(smf_p) & smf_p < smf_alpha,
        smf_star = case_when(
          !is.na(smf_p) & smf_p < 0.001 ~ "***",
          !is.na(smf_p) & smf_p < 0.01  ~ "**",
          !is.na(smf_p) & smf_p < 0.05  ~ "*",
          TRUE ~ ""
        ),
        smf_trend = case_when(
          is.na(smf_r) ~ "unknown",
          smf_r > 0   ~ "positive_with_SMF",
          smf_r < 0   ~ "negative_with_SMF",
          TRUE        ~ "flat"
        ),
        smf_trend_label = case_when(
          smf_trend == "positive_with_SMF" ~ "Positive with SMF",
          smf_trend == "negative_with_SMF" ~ "Negative with SMF",
          TRUE ~ "Not significant"
        )
      )
  }
  
  smf_star <- titan_ring %>%
    select(ASV) %>%
    distinct() %>%
    left_join(
      smf_response %>%
        select(
          ASV,
          smf_r,
          smf_p,
          smf_response,
          smf_star,
          smf_trend,
          smf_trend_label
        ),
      by = "ASV"
    ) %>%
    mutate(
      smf_star = ifelse(
        !is.na(smf_response) & smf_response & !is.na(smf_star),
        smf_star,
        ""
      ),
      smf_trend = ifelse(
        smf_star != "" & smf_trend %in% c("positive_with_SMF", "negative_with_SMF"),
        smf_trend,
        NA_character_
      ),
      smf_trend = factor(
        smf_trend,
        levels = c("positive_with_SMF", "negative_with_SMF")
      ),
      SMFTrack = "SMF"
    )
  
  smf_star_sig <- smf_star %>%
    filter(
      smf_star != "",
      !is.na(smf_trend)
    )
  
  cat("\n", habitat_cn, "与 SMF 显著相关 ASV 数量：\n", sep = "")
  if(nrow(smf_star_sig) > 0){
    print(table(smf_star_sig$smf_trend))
  } else {
    cat("无显著 SMF 相关 ASV。\n")
  }
  
  ########################################
  ## 7.9.3 系统发育聚集检验
  ## 只检验：
  ## 1) 所有 TITAN 阈值附近 ASV
  ## 2) z- ASV
  ## 3) z+ ASV
  ##
  ## 这里不用 picante::ses.mpd / ses.mntd
  ## 改为手动随机抽取相同数量 ASV 构建零模型
  ########################################
  
  background_asv <- intersect(asv$ASV, tr0$tip.label)
  
  out_phylo_csv <- paste0(
    habitat_cn,
    "_TITAN_threshold_phylogenetic_clustering_test.csv"
  )
  
  make_empty_phylo_result <- function(reason = "No result"){
    tibble(
      Group = c("all_TITAN_threshold_ASVs", "z_minus", "z_plus"),
      N_ASV = NA_integer_,
      MPD_obs = NA_real_,
      MPD_SES = NA_real_,
      MPD_P_low = NA_real_,
      MPD_P_high = NA_real_,
      MPD_P_two_sided = NA_real_,
      MNTD_obs = NA_real_,
      MNTD_SES = NA_real_,
      MNTD_P_low = NA_real_,
      MNTD_P_high = NA_real_,
      MNTD_P_two_sided = NA_real_,
      Interpretation_MPD = reason,
      Interpretation_MNTD = reason
    )
  }
  
  if(length(background_asv) < 5){
    
    warning(paste0(habitat_cn, " 背景 ASV 少于 5 个，跳过系统发育聚集检验。"))
    
    phylo_cluster_results <- make_empty_phylo_result("Background too small")
    write_csv(phylo_cluster_results, out_phylo_csv)
    
  } else {
    
    tr_bg <- keep.tip(tr0, background_asv)
    
    if(is.null(tr_bg$edge.length)){
      warning(paste0(habitat_cn, " 的系统发育树没有 branch.length，已临时将所有分支长度设为 1。"))
      tr_bg$edge.length <- rep(1, nrow(tr_bg$edge))
    }
    
    if(any(is.na(tr_bg$edge.length))){
      warning(paste0(habitat_cn, " 的系统发育树 branch.length 含 NA，已用非 NA 中位数替换。"))
      replacement_length <- median(tr_bg$edge.length, na.rm = TRUE)
      if(is.na(replacement_length) | !is.finite(replacement_length)){
        replacement_length <- 1
      }
      tr_bg$edge.length[is.na(tr_bg$edge.length)] <- replacement_length
    }
    
    if(any(!is.finite(tr_bg$edge.length))){
      warning(paste0(habitat_cn, " 的系统发育树 branch.length 含非有限值，已替换为 1。"))
      tr_bg$edge.length[!is.finite(tr_bg$edge.length)] <- 1
    }
    
    if(any(tr_bg$edge.length < 0)){
      warning(paste0(habitat_cn, " 的系统发育树 branch.length 含负值，已替换为 0。"))
      tr_bg$edge.length[tr_bg$edge.length < 0] <- 0
    }
    
    phylo_dist <- as.matrix(cophenetic.phylo(tr_bg))
    
    cat("\n", habitat_cn, " 系统发育距离矩阵检查：\n", sep = "")
    cat("背景 ASV 数量：", length(background_asv), "\n")
    cat("距离矩阵维度：", nrow(phylo_dist), " × ", ncol(phylo_dist), "\n")
    cat("距离矩阵 NA 数量：", sum(is.na(phylo_dist)), "\n")
    cat("距离矩阵非有限值数量：", sum(!is.finite(phylo_dist)), "\n")
    cat("距离矩阵范围：", paste(range(phylo_dist, na.rm = TRUE), collapse = " - "), "\n")
    
    good_taxa <- rownames(phylo_dist)[
      rowSums(!is.finite(phylo_dist)) == 0
    ]
    
    if(length(good_taxa) < 5){
      
      warning(paste0(habitat_cn, " 清理 NA/Inf 后背景 ASV 少于 5 个，跳过系统发育聚集检验。"))
      
      phylo_cluster_results <- make_empty_phylo_result("Invalid phylogenetic distance")
      write_csv(phylo_cluster_results, out_phylo_csv)
      
    } else {
      
      phylo_dist <- phylo_dist[good_taxa, good_taxa, drop = FALSE]
      background_asv <- intersect(background_asv, good_taxa)
      
      phylo_trait_tab <- titan_ring %>%
        select(ASV, Titan) %>%
        filter(ASV %in% background_asv)
      
      group_list <- list(
        all_TITAN_threshold_ASVs = phylo_trait_tab$ASV,
        
        z_minus = phylo_trait_tab %>%
          filter(Titan == "z-") %>%
          pull(ASV),
        
        z_plus = phylo_trait_tab %>%
          filter(Titan == "z+") %>%
          pull(ASV)
      )
      
      calc_mpd <- function(asv_vec, phylo_dist){
        asv_vec <- unique(asv_vec)
        asv_vec <- intersect(asv_vec, rownames(phylo_dist))
        if(length(asv_vec) < 2){
          return(NA_real_)
        }
        d <- phylo_dist[asv_vec, asv_vec, drop = FALSE]
        mean(d[lower.tri(d)], na.rm = TRUE)
      }
      
      calc_mntd <- function(asv_vec, phylo_dist){
        asv_vec <- unique(asv_vec)
        asv_vec <- intersect(asv_vec, rownames(phylo_dist))
        if(length(asv_vec) < 2){
          return(NA_real_)
        }
        d <- phylo_dist[asv_vec, asv_vec, drop = FALSE]
        diag(d) <- NA
        nearest <- apply(d, 1, function(x){
          min(x, na.rm = TRUE)
        })
        mean(nearest, na.rm = TRUE)
      }
      
      run_phylo_clustering_manual <- function(
    asv_vec,
    group_name,
    phylo_dist,
    background_asv,
    runs = 9999
      ){
        
        asv_vec <- unique(asv_vec)
        asv_vec <- intersect(asv_vec, background_asv)
        n_asv <- length(asv_vec)
        
        if(n_asv < 3){
          return(tibble(
            Group = group_name,
            N_ASV = n_asv,
            MPD_obs = NA_real_,
            MPD_SES = NA_real_,
            MPD_P_low = NA_real_,
            MPD_P_high = NA_real_,
            MPD_P_two_sided = NA_real_,
            MNTD_obs = NA_real_,
            MNTD_SES = NA_real_,
            MNTD_P_low = NA_real_,
            MNTD_P_high = NA_real_,
            MNTD_P_two_sided = NA_real_,
            Interpretation_MPD = "Too few ASVs",
            Interpretation_MNTD = "Too few ASVs"
          ))
        }
        
        MPD_obs <- calc_mpd(asv_vec, phylo_dist)
        MNTD_obs <- calc_mntd(asv_vec, phylo_dist)
        
        if(!is.finite(MPD_obs) | !is.finite(MNTD_obs)){
          return(tibble(
            Group = group_name,
            N_ASV = n_asv,
            MPD_obs = MPD_obs,
            MPD_SES = NA_real_,
            MPD_P_low = NA_real_,
            MPD_P_high = NA_real_,
            MPD_P_two_sided = NA_real_,
            MNTD_obs = MNTD_obs,
            MNTD_SES = NA_real_,
            MNTD_P_low = NA_real_,
            MNTD_P_high = NA_real_,
            MNTD_P_two_sided = NA_real_,
            Interpretation_MPD = "Invalid observed MPD/MNTD",
            Interpretation_MNTD = "Invalid observed MPD/MNTD"
          ))
        }
        
        MPD_null <- numeric(runs)
        MNTD_null <- numeric(runs)
        
        for(i in seq_len(runs)){
          rand_asv <- sample(background_asv, n_asv, replace = FALSE)
          MPD_null[i] <- calc_mpd(rand_asv, phylo_dist)
          MNTD_null[i] <- calc_mntd(rand_asv, phylo_dist)
        }
        
        MPD_null <- MPD_null[is.finite(MPD_null)]
        MNTD_null <- MNTD_null[is.finite(MNTD_null)]
        
        if(length(MPD_null) < 10 | length(MNTD_null) < 10){
          return(tibble(
            Group = group_name,
            N_ASV = n_asv,
            MPD_obs = MPD_obs,
            MPD_SES = NA_real_,
            MPD_P_low = NA_real_,
            MPD_P_high = NA_real_,
            MPD_P_two_sided = NA_real_,
            MNTD_obs = MNTD_obs,
            MNTD_SES = NA_real_,
            MNTD_P_low = NA_real_,
            MNTD_P_high = NA_real_,
            MNTD_P_two_sided = NA_real_,
            Interpretation_MPD = "Invalid null MPD/MNTD",
            Interpretation_MNTD = "Invalid null MPD/MNTD"
          ))
        }
        
        MPD_SES <- (MPD_obs - mean(MPD_null)) / sd(MPD_null)
        MNTD_SES <- (MNTD_obs - mean(MNTD_null)) / sd(MNTD_null)
        
        MPD_P_low <- (sum(MPD_null <= MPD_obs) + 1) / (length(MPD_null) + 1)
        MPD_P_high <- (sum(MPD_null >= MPD_obs) + 1) / (length(MPD_null) + 1)
        MPD_P_two <- min(1, 2 * min(MPD_P_low, MPD_P_high))
        
        MNTD_P_low <- (sum(MNTD_null <= MNTD_obs) + 1) / (length(MNTD_null) + 1)
        MNTD_P_high <- (sum(MNTD_null >= MNTD_obs) + 1) / (length(MNTD_null) + 1)
        MNTD_P_two <- min(1, 2 * min(MNTD_P_low, MNTD_P_high))
        
        interpret_result <- function(ses, p_low, p_high, alpha = 0.05){
          if(is.na(ses)){
            return(NA_character_)
          } else if(ses < 0 & p_low < alpha){
            return("Phylogenetic clustering")
          } else if(ses > 0 & p_high < alpha){
            return("Phylogenetic overdispersion")
          } else {
            return("Not significant")
          }
        }
        
        tibble(
          Group = group_name,
          N_ASV = n_asv,
          MPD_obs = MPD_obs,
          MPD_SES = MPD_SES,
          MPD_P_low = MPD_P_low,
          MPD_P_high = MPD_P_high,
          MPD_P_two_sided = MPD_P_two,
          MNTD_obs = MNTD_obs,
          MNTD_SES = MNTD_SES,
          MNTD_P_low = MNTD_P_low,
          MNTD_P_high = MNTD_P_high,
          MNTD_P_two_sided = MNTD_P_two,
          Interpretation_MPD = interpret_result(
            MPD_SES,
            MPD_P_low,
            MPD_P_high
          ),
          Interpretation_MNTD = interpret_result(
            MNTD_SES,
            MNTD_P_low,
            MNTD_P_high
          )
        )
      }
      
      set.seed(123)
      
      phylo_cluster_results <- purrr::imap_dfr(
        group_list,
        ~run_phylo_clustering_manual(
          asv_vec = .x,
          group_name = .y,
          phylo_dist = phylo_dist,
          background_asv = background_asv,
          runs = phylo_runs
        )
      )
      
      write_csv(phylo_cluster_results, out_phylo_csv)
      
      cat("\n", habitat_cn, " 系统发育聚集检验结果：\n", sep = "")
      print(phylo_cluster_results)
      cat("已输出系统发育聚集检验表：", out_phylo_csv, "\n")
    }
  }
  
  ########################################
  ## 7.9.3.1 生成右侧系统发育检验结果文字面板
  ########################################
  
  phylo_summary_text <- make_phylo_summary_text(
    phylo_cluster_results = phylo_cluster_results,
    habitat_cn = habitat_cn
  )
  
  phylo_summary_plot <- ggplot() +
    annotate(
      "text",
      x = 0,
      y = 1,
      label = phylo_summary_text,
      hjust = 0,
      vjust = 1,
      size = 2.7,
      lineheight = 0.95
    ) +
    xlim(0, 1) +
    ylim(0, 1) +
    theme_void() +
    theme(
      plot.margin = margin(10, 10, 10, 10)
    )
  
  ########################################
  ## 7.9.4 干旱热图数据
  ########################################
  
  heatmap_long <- abundance_long %>%
    group_by(ASV, Drought) %>%
    summarise(
      RelativeAbundance = mean(Abundance),
      .groups = "drop"
    ) %>%
    complete(
      ASV,
      Drought = factor(drought_levels, levels = drought_levels),
      fill = list(RelativeAbundance = 0)
    ) %>%
    mutate(
      Drought  = factor(Drought, levels = drought_levels),
      log2_abd = log2(RelativeAbundance + 1)
    ) %>%
    group_by(ASV) %>%
    mutate(
      z_abd = as.numeric(scale(log2_abd)),
      z_abd = ifelse(is.na(z_abd), 0, z_abd)
    ) %>%
    ungroup() %>%
    drop_na(Drought)
  
  ########################################
  ## 7.10 prevalence
  ########################################
  
  prevalence <- asv_sel %>%
    select(ASV, all_of(sample_ids)) %>%
    mutate(prevalence = rowMeans(across(-ASV) > 0)) %>%
    select(ASV, prevalence)
  
  ########################################
  ## 7.11 输出表格
  ########################################
  
  used_table <- titan_ring %>%
    left_join(asv_sel %>% select(ASV, phylum, family), by = "ASV") %>%
    left_join(anno_sel, by = "ASV") %>%
    left_join(
      drought_response %>%
        select(
          ASV,
          kw_p,
          spearman_r,
          spearman_p,
          mark_p,
          star,
          drought_response,
          drought_trend,
          drought_trend_label
        ),
      by = "ASV"
    ) %>%
    left_join(
      smf_response %>%
        select(
          ASV,
          smf_r,
          smf_p,
          smf_star,
          smf_response,
          smf_trend,
          smf_trend_label
        ),
      by = "ASV"
    ) %>%
    arrange(Titan, zenv_cp, cp_dist)
  
  out_csv <- paste0(habitat_cn, "_TITAN_threshold_nearby_by_Titan_ASVs_used_with_drought_and_SMF_response.csv")
  write_csv(used_table, out_csv)
  
  out_drought_csv <- paste0(habitat_cn, "_TITAN_threshold_drought_response_test.csv")
  write_csv(drought_response, out_drought_csv)
  
  out_smf_csv <- paste0(habitat_cn, "_TITAN_threshold_SMF_response_test.csv")
  write_csv(smf_response, out_smf_csv)
  
  ########################################
  ## 7.12 开始绘图
  ########################################
  
  p <- suppressWarnings(
    ggtree(
      tr_filt,
      layout = "circular",
      open.angle = 0,
      branch.length = "branch.length",
      size  = 0.6,
      color = "grey40"
    )
  ) +
    geom_aline(
      linetype  = "dashed",
      color     = "grey80",
      linewidth = 0.3
    ) +
    scale_x_continuous(
      expand = expansion(mult = c(0.02, 0.02))
    )
  
  p0 <- p +
    geom_fruit(
      data = titan_ring,
      geom = geom_tile,
      mapping = aes(y = ASV, x = "TITAN", fill = Titan),
      width  = 0.25,
      offset = 0.15
    ) +
    scale_fill_manual(
      values = titan_colors,
      name   = "TITAN",
      drop   = FALSE
    ) +
    new_scale_fill()
  
  p1 <- p0 +
    geom_fruit(
      data = asv_sel,
      geom = geom_tile,
      mapping = aes(y = ASV, x = "Phylum", fill = phylum),
      width  = 0.6,
      offset = 0.15
    ) +
    scale_fill_manual(
      values = phylum_colors,
      name   = "Phylum"
    ) +
    new_scale_fill()
  
  p2 <- p1 +
    geom_fruit(
      data = asv_label,
      geom = geom_text,
      mapping = aes(y = ASV, x = 0, label = ASV_label),
      size   = 3,
      color  = "black",
      offset = 0.05
    )
  
  p3 <- p2 +
    geom_fruit(
      data = heatmap_long,
      geom = geom_tile,
      mapping = aes(
        y    = ASV,
        x    = Drought,
        fill = z_abd
      ),
      pwidth = 0.2,
      offset = 0.2,
      color  = "grey90",
      size   = 0.1,
      axis.params = list(expand = c(0, 0))
    ) +
    scale_fill_gradient2(
      low  = "#8fb3d9",
      mid  = "white",
      high = "#f4a6a0",
      midpoint = 0,
      name = "Relative abundance\n(z-score)"
    ) +
    new_scale_fill()
  
  p3s <- p3 +
    geom_fruit(
      data = drought_star,
      geom = geom_text,
      mapping = aes(
        y = ASV,
        x = StarTrack,
        label = star,
        color = drought_trend
      ),
      size   = 4,
      offset = 0.05,
      na.rm  = TRUE
    ) +
    scale_color_manual(
      values = drought_star_colors,
      name   = "Drought response",
      breaks = c("increase_with_drought", "decrease_with_drought"),
      labels = c("Increase", "Decrease"),
      drop   = FALSE,
      na.translate = FALSE
    )
  
  p4 <- p3s +
    geom_fruit(
      data = anno_sel,
      geom = geom_tile,
      mapping = aes(y = ASV, x = "Primary", fill = primary_group),
      width  = 0.1,
      offset = 0.1
    ) +
    scale_fill_manual(
      values   = primary_colors,
      na.value = "white",
      name     = "Primary"
    ) +
    new_scale_fill()
  
  p_prevalence <- p4 +
    geom_fruit(
      data = prevalence,
      geom = geom_bar,
      stat = "identity",
      mapping = aes(y = ASV, x = prevalence),
      fill   = "#80B1D3",
      width  = 0.55,
      pwidth = 0.15,
      offset = 0.1
    )
  
  p_core <- p_prevalence +
    new_scale_color() +
    geom_fruit(
      data = smf_star,
      geom = geom_text,
      mapping = aes(
        y = ASV,
        x = SMFTrack,
        label = smf_star,
        color = smf_trend
      ),
      size   = 4,
      offset = 0.08,
      na.rm  = TRUE
    ) +
    scale_color_manual(
      values = smf_star_colors,
      name   = "SMF relationship",
      breaks = c("positive_with_SMF", "negative_with_SMF"),
      labels = c("Positive", "Negative"),
      drop   = FALSE,
      na.translate = FALSE
    ) +
    theme_void() +
    theme(
      legend.position  = "right",
      legend.box       = "vertical",
      legend.key.size  = unit(0.55, "cm"),
      legend.text      = element_text(size = 10),
      legend.title     = element_text(size = 11),
      legend.spacing.y = unit(0.35, "cm"),
      legend.spacing.x = unit(0.40, "cm"),
      legend.box.margin = margin(6, 6, 6, 6)
    )
  
  ########################################
  ## 7.12.1 把系统发育检验结果放在图例侧
  ########################################
  
  p_final <- cowplot::plot_grid(
    p_core,
    phylo_summary_plot,
    ncol = 2,
    rel_widths = c(1, 0.33),
    align = "h",
    axis = "tb"
  )
  
  print(p_final)
  
  ########################################
  ## 7.13 保存
  ########################################
  
  out_pdf <- paste0(habitat_cn, "_TITAN_threshold_nearby_by_Titan_phylogeny_with_drought_SMF_and_phylo_test.pdf")
  
  ggsave(
    out_pdf,
    p_final,
    width  = 27,
    height = 20,
    dpi    = 300
  )
  
  cat("已输出图形：", out_pdf, "\n")
  cat("已输出物种表：", out_csv, "\n")
  cat("已输出干旱响应检验表：", out_drought_csv, "\n")
  cat("已输出 SMF 相关性检验表：", out_smf_csv, "\n")
  cat("已输出系统发育聚集检验表：", out_phylo_csv, "\n")
  
  return(p_final)
}

########################################
## 8. 批量绘制三个生态位
########################################

plot_list <- list()

for(i in seq_len(nrow(habitat_files))){
  
  hf <- habitat_files[i, ]
  
  plot_list[[hf$Habitat]] <- plot_one_habitat(
    habitat_id = hf$Habitat,
    habitat_cn = hf$CN,
    asv_file   = hf$asv_file,
    anno_file  = hf$anno_file,
    grp_file   = hf$grp_file
  )
}

########################################
## 9. 输出本次阈值设定表
########################################

write_csv(
  threshold_plan,
  "TITAN_threshold_stage_plan_used.csv"
)

cat("\n全部完成！\n")
cat("已生成三个生态位的 TITAN 阈值附近 z+ / z- 物种系统发育图。\n")
cat("物种筛选逻辑：z- 按 z- 阈值 ±0.5；z+ 按 z+ 阈值 ±0.5；不合并 z- 和 z+ 阈值区间。\n")
cat("干旱星号含义：* P < 0.05, ** P < 0.01, *** P < 0.001，未进行 FDR 校正。\n")
cat("干旱红色星号：随干旱增强而增加。\n")
cat("干旱蓝色星号：随干旱增强而降低。\n")
cat("SMF 星号含义：* P < 0.05, ** P < 0.01, *** P < 0.001，未进行 FDR 校正。\n")
cat("SMF 红色星号：ASV 丰度与 SMF 显著正相关。\n")
cat("SMF 蓝色星号：ASV 丰度与 SMF 显著负相关。\n")
cat("系统发育检验结果已经展示在图例侧，并输出为 CSV 表。\n")
cat("阈值设定表：TITAN_threshold_stage_plan_used.csv\n")