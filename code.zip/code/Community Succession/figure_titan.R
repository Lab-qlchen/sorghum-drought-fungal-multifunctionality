###############################
## Figure 3C: TITAN 阈值密度分布图 (Density / Ridge style)
## 核心目的: 弱化物种细节，突出群落水平的演替突变阈值
###############################

rm(list = ls())
options(stringsAsFactors = FALSE)

###############################
## 1. 工作目录 (请根据实际情况修改)
###############################
wd <- "D:/IUE/山西数据/真菌/抽平/群落演替动态"
setwd(wd)

###############################
## 2. 加载包
###############################
pkg_needed <- c("ggplot2", "dplyr")
pkg_new <- pkg_needed[!pkg_needed %in% installed.packages()[, "Package"]]
if(length(pkg_new) > 0){
  install.packages(pkg_new, repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
}

library(ggplot2)
library(dplyr)

###############################
## 3. 读取已有的结果表
###############################
# 个体 OTU 的显著性结果 (用于绘制分布密度)
plot_all <- read.csv("Figure3C_TITAN_significant_OTUs.csv", 
                     header = TRUE, check.names = FALSE)

# 群落水平的突变点统计 (用于绘制阈值线)
titan_cp_all <- read.csv("Figure3C_TITAN_change_points_summary.csv", 
                         header = TRUE, check.names = FALSE)

###############################
## 4. 统一 Habitat 名称与顺序
###############################
format_habitat <- function(x) {
  x[x == "Leaf"] <- "Phyllosphere"
  x[x == "Root"] <- "Endosphere"
  return(x)
}

plot_all$Habitat <- format_habitat(as.character(plot_all$Habitat))
plot_all$Habitat <- factor(plot_all$Habitat, levels = c("Phyllosphere", "Endosphere", "Rhizosphere"))

titan_cp_all$Habitat <- format_habitat(as.character(titan_cp_all$Habitat))
titan_cp_all$Habitat <- factor(titan_cp_all$Habitat, levels = c("Phyllosphere", "Endosphere", "Rhizosphere"))

###############################
## 5. 整理 Titan 响应方向
###############################
plot_all$Titan <- as.character(plot_all$Titan)
plot_all$Titan[plot_all$Titan == "1"] <- "z-"
plot_all$Titan[plot_all$Titan == "2"] <- "z+"
plot_all$Titan <- factor(plot_all$Titan, levels = c("z-", "z+"))

plot_all$zenv.cp <- as.numeric(plot_all$zenv.cp)

###############################
## 6. 提取群落级阈值线 (sumz- 和 sumz+)
###############################
# TITAN 输出的 sumz- / sumz+ 代表了群落水平发生剧烈变化的节点
cp_lines <- titan_cp_all %>%
  filter(Metric %in% c("sumz-", "sumz+")) %>%
  mutate(
    Titan = ifelse(Metric == "sumz-", "z-", "z+"),
    Titan = factor(Titan, levels = c("z-", "z+")),
    cp = as.numeric(cp)
  )

###############################
## 7. 颜色设定
###############################
# z- (递减型，用深蓝); z+ (递增型，用红)
titan_colors <- c("z-" = "#65a2d2", "z+" = "#db6968")

###############################
## 8. 绘制密度分布图 (类似山脊图的视觉效果)
###############################
p_density <- ggplot() +
  # 1. 绘制底层密度面积图，展示 OTU 突变点的集中趋势
  geom_density(
    data = plot_all,
    aes(x = zenv.cp, fill = Titan, color = Titan),
    alpha = 0.5,       # 透明度，使重叠部分可见
    linewidth = 0.8,
    adjust = 1.2       # 平滑度调节，数值越大曲线越平滑
  ) +
  # 2. 在底部添加地毯线 (Rug)，保留一点个体 OTU 分布的数据感而不杂乱
  geom_rug(
    data = plot_all,
    aes(x = zenv.cp, color = Titan),
    sides = "b", alpha = 0.6, length = unit(0.04, "npc")
  ) +
  # 3. 添加群落级阈值垂直虚线
  geom_vline(
    data = cp_lines,
    aes(xintercept = cp, color = Titan),
    linetype = "dashed", 
    linewidth = 1.2
  ) +
  # 4. 在图内标注具体的群落阈值数值
  geom_text(
    data = cp_lines,
    aes(x = cp, y = Inf, label = sprintf("%.2f", cp), color = Titan),
    vjust = 1.5, hjust = -0.2, size = 4, fontface = "bold", show.legend = FALSE
  ) +
  # 5. 分面展示三个生态位
  facet_wrap(~Habitat, nrow = 1, strip.position = "top") +
  # 6. 坐标轴与主题设置
  scale_fill_manual(values = titan_colors, labels = c("z- (Decreasers)", "z+ (Increasers)")) +
  scale_color_manual(values = titan_colors, labels = c("z- (Decreasers)", "z+ (Increasers)")) +
  scale_x_continuous(
    breaks = c(1, 2, 3, 4),
    labels = c("JS", "HS", "FS", "MS"),
    limits = c(0.8, 4.2)
  ) +
  labs(
    x = "Succession Stage", 
    y = "Density of Change Points",
    fill = "TITAN Response",
    color = "TITAN Response"
  ) +
  theme_bw() +
  theme(
    strip.text = element_text(size = 14, face = "bold"),
    strip.background = element_rect(fill = "grey95", color = "black"),
    legend.position = "bottom",
    legend.title = element_text(size = 13, face = "bold"),
    legend.text = element_text(size = 12),
    axis.text.x = element_text(size = 12, face = "bold"),
    axis.text.y = element_text(size = 10),
    axis.title = element_text(size = 14, face = "bold"),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "grey90", linetype = "dotted")
  )

###############################
## 9. 显示与保存
###############################
print(p_density)

ggsave("Figure3C_TITAN_Density_Thresholds.pdf", p_density, width = 11, height = 5)

cat("\n已成功生成分布密度图：Figure3C_TITAN_Density_Thresholds.pdf\n")