###############################
## Figure 3: Succession under drought
## Phyllosphere + Endosphere + Rhizosphere
###############################

rm(list = ls())
options(stringsAsFactors = FALSE)

wd <- "D:/IUE/山西数据/真菌/抽平/群落演替动态"
setwd(wd)

###############################
## 加载包
###############################
pkg <- c("vegan", "ecodist", "dplyr", "tidyr")

for(p in pkg){
  if(!require(p, character.only = TRUE)){
    install.packages(p)
    library(p, character.only = TRUE)
  }
}

###############################
## 分析函数
###############################
analyze_habitat <- function(asv_file, group_file, habitat_name){
  
  asv <- read.csv(asv_file, check.names = FALSE)
  grp <- read.csv(group_file, check.names = FALSE)
  
  colnames(grp)[1:2] <- c("Sample", "Group")
  
  grp <- grp %>%
    separate(Group, c("Stage", "Water", "Level"), sep = "_", fill = "right")
  
  grp$Drought <- ifelse(grp$Water == "Control",
                        "Control",
                        paste0("Drought_", grp$Level))
  
  stage_map <- c(JS = 1, HS = 2, FS = 3, MS = 4)
  grp$Stage_num <- stage_map[grp$Stage]
  
  anno <- c("ASV", "Domain", "Phylum", "Class", "Order", "Family",
            "Genus", "Species", "Genus.join", "primary", "secondary")
  
  samples <- setdiff(colnames(asv), anno)
  samples <- intersect(samples, grp$Sample)
  
  grp <- grp[match(samples, grp$Sample), ]
  
  comm <- asv[, samples]
  comm[] <- lapply(comm, as.numeric)
  comm <- t(as.matrix(comm))
  
  comm[is.na(comm)] <- 0
  
  comm <- decostand(comm, "hellinger")
  
  res_list <- list()
  
  for(d in unique(grp$Drought)){
    
    idx <- grp$Drought == d
    
    comm_sub <- comm[idx, ]
    grp_sub <- grp[idx, ]
    
    if(nrow(comm_sub) < 4) next
    
    bc <- vegdist(comm_sub, "bray")
    td <- distance(grp_sub$Stage_num)
    
    ma <- mantel(bc ~ td, nperm = 999)
    
    df <- data.frame(
      temporal = as.vector(td),
      bc = as.vector(bc),
      habitat = habitat_name,
      drought = d,
      R = as.numeric(ma[1]),
      P = as.numeric(ma[2])
    )
    
    res_list[[d]] <- df
  }
  
  bind_rows(res_list)
}

###############################
## 运行三个生态位
###############################
leaf <- analyze_habitat(
  "叶际_ASV_FungalTraits_with_abundance.csv",
  "叶际分组.csv",
  "Phyllosphere"
)

endo <- analyze_habitat(
  "根内_ASV_FungalTraits_with_abundance.csv",
  "根内分组.csv",
  "Endosphere"
)

rhizo <- analyze_habitat(
  "根际_ASV_FungalTraits_with_abundance.csv",
  "根际分组.csv",
  "Rhizosphere"
)

all_data <- bind_rows(leaf, endo, rhizo)

###############################
###############################
## 在R中显示图
###############################
par(mfrow = c(3,4), mar = c(4,4,2,1))

for(h in unique(all_data$habitat)){
  
  for(d in c("Control", "Drought_L", "Drought_M", "Drought_H")){
    
    df <- all_data %>%
      filter(habitat == h, drought == d)
    
    if(nrow(df) == 0){
      plot.new()
      next
    }
    
    plot(jitter(df$temporal, 0.08),
         df$bc,
         pch = 16,
         cex = 0.5,
         col = rgb(0,0,0,0.2),
         xlab = "Temporal distance (stage)",
         ylab = "Bray-Curtis dissimilarity",
         xlim = c(-0.1,3.1),
         ylim = c(0,1))
    
    lines(lowess(df$temporal, df$bc),
          col = "red",
          lwd = 4)
    
    text(1.5,0.92,
         paste(h,d),
         col="#e64b35",
         cex=1.2,
         font=2)
    
    text(1.5,0.08,
         paste0("R = ",
                round(unique(df$R),3),
                ", P = ",
                round(unique(df$P),3)),
         col="#4dbbd5",
         cex=1.1,
         font=2)
  }
}
## 作图
###############################
pdf("Figure3_succession_drought.pdf",
    width = 14,
    height = 8)

par(mfrow = c(3, 4), mar = c(4, 4, 2, 1))

for(h in unique(all_data$habitat)){
  
  for(d in c("Control", "Drought_L", "Drought_M", "Drought_H")){
    
    df <- all_data %>%
      filter(habitat == h, drought == d)
    
    if(nrow(df) == 0){
      plot.new()
      next
    }
    
    plot(jitter(df$temporal, 0.08),
         df$bc,
         pch = 16,
         cex = 0.5,
         col = rgb(0, 0, 0, 0.2),
         xlab = "Temporal distance (stage)",
         ylab = "Bray-Curtis dissimilarity",
         xlim = c(-0.1, 3.1),
         ylim = c(0, 1))
    
    lines(lowess(df$temporal, df$bc),
          col = "red",
          lwd = 4)
    
    text(1.5, 0.92,
         paste(h, d),
         col = "#e64b35",
         cex = 1.2,
         font = 2)
    
    text(1.5, 0.08,
         paste0("R = ",
                round(unique(df$R), 3),
                ", P = ",
                round(unique(df$P), 3)),
         col = "#4dbbd5",
         cex = 1.1,
         font = 2)
    
  }
  
}

dev.off()

###############################
## 保存统计结果
###############################
mantel_table <- all_data %>%
  select(habitat, drought, R, P) %>%
  distinct()

write.csv(mantel_table,
          "Figure3_mantel_results.csv",
          row.names = FALSE)

print(mantel_table)