###############################
## DOC analysis - merged habitats
## 1) All fungi
## 2) Phyllosphere all
## 3) Endosphere all
## 4) Rhizosphere all
## 5) plant_pathogen
## 6) litter_saprotroph
## 7) animal_parasite
## 8) soil_saprotroph
###############################

rm(list = ls())
options(stringsAsFactors = FALSE)

###############################
## 1. 工作目录
###############################
wd <- "D:/IUE/山西数据/真菌/抽平/群落演替动态"
setwd(wd)

###############################
## 2. 加载包
###############################
if(!requireNamespace("DOC", quietly = TRUE)){
  if(!requireNamespace("remotes", quietly = TRUE)){
    install.packages("remotes", repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
  }
  remotes::install_github("Russel88/DOC", upgrade = "never")
}
library(DOC)

if(!requireNamespace("ggplot2", quietly = TRUE)){
  install.packages("ggplot2", repos = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/")
}
library(ggplot2)

###############################
## 3. 基本设置
###############################
anno_cols <- c(
  "ASV","Domain","Phylum","Class","Order","Family",
  "Genus","Species","Genus.join","primary","secondary"
)

target_primary <- c(
  "plant_pathogen",
  "litter_saprotroph",
  "animal_parasite",
  "soil_saprotroph"
)

###############################
## 4. 读取单个生态位数据
###############################
read_one_habitat <- function(asv_file, group_file, habitat_name){
  
  asv_tab <- read.csv(
    asv_file,
    header = TRUE,
    check.names = FALSE,
    stringsAsFactors = FALSE
  )
  
  group_tab <- read.csv(
    group_file,
    header = TRUE,
    check.names = FALSE,
    stringsAsFactors = FALSE
  )
  
  colnames(group_tab)[1:2] <- c("Sample", "Group")
  group_tab$Sample <- trimws(group_tab$Sample)
  
  sample_cols <- setdiff(colnames(asv_tab), anno_cols)
  sample_cols <- intersect(sample_cols, group_tab$Sample)
  
  if(length(sample_cols) == 0){
    stop(paste0(habitat_name, ": 样本名没有匹配上。"))
  }
  
  otu <- asv_tab[, sample_cols, drop = FALSE]
  otu[] <- lapply(otu, function(x) suppressWarnings(as.numeric(as.character(x))))
  otu <- as.data.frame(otu, check.names = FALSE)
  rownames(otu) <- asv_tab$ASV
  otu[is.na(otu)] <- 0
  
  keep_sample <- colSums(otu) > 0
  otu <- otu[, keep_sample, drop = FALSE]
  
  keep_taxa <- rowSums(otu) > 0
  otu <- otu[keep_taxa, , drop = FALSE]
  
  anno <- asv_tab[
    match(rownames(otu), asv_tab$ASV),
    intersect(c("ASV","primary","secondary","Genus"), colnames(asv_tab)),
    drop = FALSE
  ]
  rownames(anno) <- anno$ASV
  
  return(list(
    otu = otu,
    anno = anno
  ))
}

###############################
## 5. 读取三个生态位
###############################
leaf_dat <- read_one_habitat(
  "叶际_ASV_FungalTraits_with_abundance.csv",
  "叶际分组.csv",
  "Phyllosphere"
)

endo_dat <- read_one_habitat(
  "根内_ASV_FungalTraits_with_abundance.csv",
  "根内分组.csv",
  "Endosphere"
)

rhizo_dat <- read_one_habitat(
  "根际_ASV_FungalTraits_with_abundance.csv",
  "根际分组.csv",
  "Rhizosphere"
)

###############################
## 6. 合并三个生态位 OTU 表
###############################
all_asv <- unique(c(
  rownames(leaf_dat$otu),
  rownames(endo_dat$otu),
  rownames(rhizo_dat$otu)
))

pad_otu <- function(otu, all_asv){
  out <- matrix(
    0,
    nrow = length(all_asv),
    ncol = ncol(otu),
    dimnames = list(all_asv, colnames(otu))
  )
  out[rownames(otu), colnames(otu)] <- as.matrix(otu)
  as.data.frame(out, check.names = FALSE)
}

otu_leaf  <- pad_otu(leaf_dat$otu,  all_asv)
otu_endo  <- pad_otu(endo_dat$otu,  all_asv)
otu_rhizo <- pad_otu(rhizo_dat$otu, all_asv)

otu_all <- cbind(otu_leaf, otu_endo, otu_rhizo)

###############################
## 7. 合并注释
###############################
anno_all <- rbind(
  leaf_dat$anno,
  endo_dat$anno,
  rhizo_dat$anno
)

anno_all <- anno_all[!duplicated(anno_all$ASV), , drop = FALSE]
rownames(anno_all) <- anno_all$ASV
anno_all <- anno_all[match(rownames(otu_all), anno_all$ASV), , drop = FALSE]

clean_primary <- function(x){
  x <- as.character(x)
  x[is.na(x) | x == ""] <- "Unknown"
  x
}
anno_all$primary2 <- clean_primary(anno_all$primary)

###############################
## 8. 转相对丰度
###############################
to_relative_abundance <- function(otu){
  otu <- as.matrix(otu)
  sample_sums <- colSums(otu)
  sample_sums[sample_sums == 0] <- 1
  sweep(otu, 2, sample_sums, "/")
}

otu_leaf_rel  <- to_relative_abundance(otu_leaf)
otu_endo_rel  <- to_relative_abundance(otu_endo)
otu_rhizo_rel <- to_relative_abundance(otu_rhizo)
otu_all_rel   <- to_relative_abundance(otu_all)

###############################
## 9. 预过滤（提速）
###############################
filter_taxa_fast <- function(otu_rel, min_prevalence = 0.10, top_n = 500){
  otu_rel <- as.matrix(otu_rel)
  
  prev <- rowMeans(otu_rel > 0)
  keep <- prev >= min_prevalence
  otu_rel <- otu_rel[keep, , drop = FALSE]
  
  if(!is.null(top_n) && nrow(otu_rel) > top_n){
    ord <- order(rowSums(otu_rel), decreasing = TRUE)
    otu_rel <- otu_rel[ord[1:top_n], , drop = FALSE]
  }
  
  otu_rel
}

###############################
## 10. 安全运行 DOC
###############################
run_doc_safe <- function(otu_rel, label, min_prevalence = 0.10, top_n = 500){
  otu_rel <- as.matrix(otu_rel)
  mode(otu_rel) <- "numeric"
  
  ## 先处理非法值
  otu_rel[!is.finite(otu_rel)] <- 0
  otu_rel[is.na(otu_rel)] <- 0
  
  ## 原始样本数检查
  if(ncol(otu_rel) < 6){
    warning(paste0(label, ": 样本数少于6，跳过 DOC。"))
    return(NULL)
  }
  
  ## taxa 预过滤
  otu_rel <- filter_taxa_fast(
    otu_rel,
    min_prevalence = min_prevalence,
    top_n = top_n
  )
  
  ## 去掉全0 taxa
  keep_taxa <- rowSums(otu_rel, na.rm = TRUE) > 0
  otu_rel <- otu_rel[keep_taxa, , drop = FALSE]
  
  ## 再去掉全0样本：这一点非常关键
  keep_sample <- colSums(otu_rel, na.rm = TRUE) > 0
  otu_rel <- otu_rel[, keep_sample, drop = FALSE]
  
  ## 再次检查非法值
  otu_rel[!is.finite(otu_rel)] <- 0
  otu_rel[is.na(otu_rel)] <- 0
  
  if(ncol(otu_rel) < 6){
    warning(paste0(label, ": 过滤后非零样本少于6，跳过 DOC。"))
    return(NULL)
  }
  
  if(nrow(otu_rel) < 5){
    warning(paste0(label, ": 过滤后非零 taxa 少于5，跳过 DOC。"))
    return(NULL)
  }
  
  ## 如果太稀疏，也容易炸，给个保护
  prev_taxa <- rowMeans(otu_rel > 0)
  if(sum(prev_taxa > 0) < 5){
    warning(paste0(label, ": 有效 taxa 太少，跳过 DOC。"))
    return(NULL)
  }
  
  cat("\n============================\n")
  cat("Running DOC:", label, "\n")
  cat("Samples after filtering:", ncol(otu_rel), "\n")
  cat("Taxa after filtering:", nrow(otu_rel), "\n")
  cat("============================\n")
  
  out <- tryCatch(
    DOC(otu_rel),
    error = function(e){
      warning(paste0(label, ": DOC 运行失败 -> ", conditionMessage(e)))
      return(NULL)
    }
  )
  
  return(out)
}

###############################
## 11. 跑整体组 DOC
###############################
doc.all       <- run_doc_safe(otu_all_rel,   "All fungi",        min_prevalence = 0.10, top_n = 500)
doc.leaf_all  <- run_doc_safe(otu_leaf_rel,  "Phyllosphere all", min_prevalence = 0.10, top_n = 500)
doc.endo_all  <- run_doc_safe(otu_endo_rel,  "Endosphere all",   min_prevalence = 0.10, top_n = 500)
doc.rhizo_all <- run_doc_safe(otu_rhizo_rel, "Rhizosphere all",  min_prevalence = 0.10, top_n = 500)

###############################
## 12. 跑 4 个指定功能类群 DOC（合并生态位）
###############################
doc_primary_list <- list()

for(gd in target_primary){
  asv_use <- rownames(anno_all)[anno_all$primary2 == gd]
  
  if(length(asv_use) == 0){
    warning(paste0("未找到功能类群: ", gd))
    doc_primary_list[[gd]] <- NULL
  } else {
    otu_sub <- otu_all_rel[asv_use, , drop = FALSE]
    doc_primary_list[[gd]] <- run_doc_safe(
      otu_sub,
      paste0("Primary: ", gd),
      min_prevalence = 0.10,
      top_n = 500
    )
  }
}

###############################
## 13. 提取摘要指标
###############################
extract_doc_summary <- function(doc_obj, label){
  if(is.null(doc_obj)){
    return(data.frame(
      Dataset = label,
      Fns_median = NA_real_,
      P_non_negative_slope = NA_real_,
      NegSlope_median = NA_real_,
      stringsAsFactors = FALSE
    ))
  }
  
  data.frame(
    Dataset = label,
    Fns_median = median(doc_obj$FNS$Fns, na.rm = TRUE),
    P_non_negative_slope = (sum(doc_obj$LME$Slope >= 0, na.rm = TRUE) + 1) /
      (length(doc_obj$LME$Slope) + 1),
    NegSlope_median = median(doc_obj$NEG$Neg.Slope, na.rm = TRUE),
    stringsAsFactors = FALSE
  )
}

doc_summary_selected <- do.call(
  rbind,
  c(
    list(
      extract_doc_summary(doc.all,       "All_fungi"),
      extract_doc_summary(doc.leaf_all,  "Phyllosphere_all"),
      extract_doc_summary(doc.endo_all,  "Endosphere_all"),
      extract_doc_summary(doc.rhizo_all, "Rhizosphere_all")
    ),
    lapply(names(doc_primary_list), function(nm){
      extract_doc_summary(doc_primary_list[[nm]], paste0("Primary_", nm))
    })
  )
)

print(doc_summary_selected)

###############################
## 14. 画图函数
###############################
plot_one_doc <- function(da, title_txt){
  if(is.null(da)) return(NULL)
  
  Fns_med <- median(da$FNS$Fns, na.rm = TRUE)
  P_nonneg <- (sum(da$LME$Slope >= 0, na.rm = TRUE) + 1) / (length(da$LME$Slope) + 1)
  Neg_med <- median(da$NEG$Neg.Slope, na.rm = TRUE)
  
  lab_txt <- paste0(
    "median(Fns) = ", round(Fns_med, 3),
    "\nP = ", round(P_nonneg, 3)
  )
  
  p <- plot(da) +
    ggplot2::ggtitle(title_txt) +
    ggplot2::annotate(
      "text",
      x = -Inf, y = Inf,
      label = lab_txt,
      hjust = -0.05, vjust = 1.2,
      size = 3.5
    )
  
  cat("\n", title_txt, "\n", sep = "")
  cat("median(Fns) = ", Fns_med, "\n", sep = "")
  cat("P_non_negative_slope = ", P_nonneg, "\n", sep = "")
  cat("median(Neg.Slope) = ", Neg_med, "\n", sep = "")
  
  return(p)
}

###############################
## 15. 生成图对象
###############################
p_all       <- plot_one_doc(doc.all,       "All fungi")
p_leaf_all  <- plot_one_doc(doc.leaf_all,  "Phyllosphere all")
p_endo_all  <- plot_one_doc(doc.endo_all,  "Endosphere all")
p_rhizo_all <- plot_one_doc(doc.rhizo_all, "Rhizosphere all")

plot_list_primary <- list()
for(nm in names(doc_primary_list)){
  plot_list_primary[[nm]] <- plot_one_doc(
    doc_primary_list[[nm]],
    paste0("Primary: ", nm)
  )
}

###############################
## 16. 查看图
###############################
print(p_all)
print(p_leaf_all)
print(p_endo_all)
print(p_rhizo_all)

names(plot_list_primary)
print(plot_list_primary[["plant_pathogen"]])
print(plot_list_primary[["litter_saprotroph"]])
print(plot_list_primary[["animal_parasite"]])
print(plot_list_primary[["soil_saprotroph"]])

## 查看结果表
doc_summary_selected
###############################
###############################
## 17. 保存 PDF
###############################
outdir <- "DOC_selected_plots"
if(!dir.exists(outdir)) dir.create(outdir)

save_doc_pdf <- function(p, filename, width = 6, height = 5){
  if(is.null(p)) return(NULL)
  ggsave(
    filename = file.path(outdir, filename),
    plot = p,
    width = width,
    height = height
  )
}

## 4 个总体图
save_doc_pdf(p_all,       "DOC_All_fungi.pdf")
save_doc_pdf(p_leaf_all,  "DOC_Phyllosphere_all.pdf")
save_doc_pdf(p_endo_all,  "DOC_Endosphere_all.pdf")
save_doc_pdf(p_rhizo_all, "DOC_Rhizosphere_all.pdf")

## 4 个指定功能类群图
save_doc_pdf(plot_list_primary[["plant_pathogen"]],    "DOC_Primary_plant_pathogen.pdf")
save_doc_pdf(plot_list_primary[["litter_saprotroph"]], "DOC_Primary_litter_saprotroph.pdf")
save_doc_pdf(plot_list_primary[["animal_parasite"]],   "DOC_Primary_animal_parasite.pdf")
save_doc_pdf(plot_list_primary[["soil_saprotroph"]],   "DOC_Primary_soil_saprotroph.pdf")

## 结果表也保存
write.csv(
  doc_summary_selected,
  file = file.path(outdir, "DOC_summary_selected.csv"),
  row.names = FALSE
)