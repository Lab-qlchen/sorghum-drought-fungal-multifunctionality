############################################################
## Supplementary soil properties analysis
## 含品种(Variety)主效应控制
## 修复：singular fit + 特殊列名 + cld列名兼容问题
############################################################

rm(list = ls())

############################################################
# Packages
############################################################

library(tidyverse)
library(lme4)
library(lmerTest)
library(emmeans)
library(multcompView)
library(patchwork)
library(pheatmap)
library(RColorBrewer)
library(performance)

############################################################
# Read data
############################################################

setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/RWC")

soil <- read.csv("补充材料理化.csv", check.names = FALSE)
grp  <- read.csv("根际分组.csv",     check.names = FALSE)
colnames(grp)[1:2] <- c("Sample", "Group")

dat <- left_join(soil, grp, by = "Sample")

############################################################
# Extract Period / Drought / Variety
############################################################

dat <- dat %>%
  mutate(
    Period = case_when(
      str_detect(Group, "^JS_") ~ "Jointing",
      str_detect(Group, "^HS_") ~ "Heading",
      str_detect(Group, "^FS_") ~ "Filling",
      str_detect(Group, "^MS_") ~ "Maturity",
      TRUE ~ NA_character_
    ),
    Drought = case_when(
      str_detect(Group, "_Control$")   ~ "Control",
      str_detect(Group, "_Drought_L$") ~ "Drought_L",
      str_detect(Group, "_Drought_M$") ~ "Drought_M",
      str_detect(Group, "_Drought_H$") ~ "Drought_H",
      TRUE ~ NA_character_
    ),
    Variety = case_when(
      str_detect(Sample, "^Z") ~ "Variety_1",
      str_detect(Sample, "^N") ~ "Variety_2",
      TRUE ~ NA_character_
    )
  )

############################################################
# Factor levels
############################################################

dat$Period <- factor(
  dat$Period,
  levels = c("Jointing", "Heading", "Filling", "Maturity")
)

dat$Drought <- factor(
  dat$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

dat$Variety <- factor(
  dat$Variety,
  levels = c("Variety_1", "Variety_2")
)

dat$Block  <- factor(dat$Block)
dat$Sample <- factor(dat$Sample)

############################################################
# 颜色方案
############################################################

drought_colors <- c(
  "Control"   = "#F8766D",
  "Drought_L" = "#7CAE00",
  "Drought_M" = "#00BFC4",
  "Drought_H" = "#C77CFF"
)

############################################################
# Traits
############################################################

soil_traits   <- c("NH4+-N", "NO3--N", "AP", "DOC", "MBC", "TC", "RWC")
enzyme_traits <- c("ALP", "AG", "BG", "CBH", "NAG", "LAP")
all_traits    <- c(soil_traits, enzyme_traits)

############################################################
# 安全列名映射（解决 +/- 特殊字符问题）
############################################################

safe_name <- function(x) gsub("[^A-Za-z0-9]", "_", x)
name_map  <- setNames(safe_name(all_traits), all_traits)

for (orig in all_traits) {
  dat[[ name_map[orig] ]] <- dat[[ orig ]]
}

############################################################
# 安全获取 R2 / ICC（处理 singular fit）
############################################################

safe_r2_icc <- function(model, trait_label) {
  
  if (isSingular(model)) {
    warning(trait_label, ": singular fit，R2/ICC 返回 NA")
    vc <- as.data.frame(VarCorr(model))
    return(list(
      R2_marginal    = NA_real_,
      R2_conditional = NA_real_,
      ICC_adjusted   = NA_real_,
      block_var      = if ("Block"    %in% vc$grp) vc$vcov[vc$grp == "Block"]    else NA_real_,
      resid_var      = if ("Residual" %in% vc$grp) vc$vcov[vc$grp == "Residual"] else NA_real_
    ))
  }
  
  r2_res  <- tryCatch(performance::r2_nakagawa(model), error = function(e) NULL)
  icc_res <- tryCatch(performance::icc(model),          error = function(e) NULL)
  vc      <- as.data.frame(VarCorr(model))
  
  list(
    R2_marginal    = if (!is.null(r2_res))  unname(r2_res$R2_marginal)    else NA_real_,
    R2_conditional = if (!is.null(r2_res))  unname(r2_res$R2_conditional) else NA_real_,
    ICC_adjusted   = if (!is.null(icc_res)) unname(icc_res$ICC_adjusted)  else NA_real_,
    block_var      = if ("Block"    %in% vc$grp) vc$vcov[vc$grp == "Block"]    else NA_real_,
    resid_var      = if ("Residual" %in% vc$grp) vc$vcov[vc$grp == "Residual"] else NA_real_
  )
}

############################################################
# 字母分组：用 pairs + multcompLetters
# 完全避开 multcomp::cld 的版本兼容问题
############################################################

get_letters_df <- function(emm_obj) {
  
  pair_df <- pairs(emm_obj, adjust = "BH") %>%
    as.data.frame()
  
  pair_df %>%
    tidyr::separate(
      contrast,
      into = c("g1", "g2"),
      sep  = " - "
    ) %>%
    group_by(Period) %>%
    group_modify(~ {
      pvec        <- .x$p.value
      names(pvec) <- paste(.x$g1, .x$g2, sep = "-")
      lv          <- multcompView::multcompLetters(pvec)$Letters
      tibble(
        Drought = names(lv),
        Letter  = lv
      )
    }) %>%
    ungroup()
}

############################################################
# LMM statistics 循环
############################################################

anova_list <- list()
r2_list    <- list()

for (orig_trait in all_traits) {
  
  safe_trait <- name_map[orig_trait]
  cat("Running:", orig_trait, "\n")
  
  dat_sub <- dat %>%
    filter(
      !is.na(.data[[safe_trait]]),
      !is.na(Period),
      !is.na(Drought),
      !is.na(Variety),
      !is.na(Block)
    )
  
  formu <- as.formula(
    paste0(safe_trait, " ~ Drought * Period + Variety + (1|Block)")
  )
  
  model <- lmer(formu, data = dat_sub)
  
  # ANOVA
  aov_tab <- anova(model, ddf = "Satterthwaite")
  out     <- as.data.frame(aov_tab)
  out$Effect <- rownames(out)
  out$Trait  <- orig_trait
  rownames(out) <- NULL
  
  out <- out %>%
    mutate(
      partial_eta2 = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF),
      p_label = case_when(
        is.na(`Pr(>F)`)  ~ "",
        `Pr(>F)` < 0.001 ~ "<0.001",
        TRUE             ~ formatC(`Pr(>F)`, format = "f", digits = 3)
      )
    )
  
  anova_list[[orig_trait]] <- out
  
  # R2 / ICC
  ri <- safe_r2_icc(model, orig_trait)
  
  r2_list[[orig_trait]] <- data.frame(
    Trait          = orig_trait,
    R2_marginal    = ri$R2_marginal,
    R2_conditional = ri$R2_conditional,
    ICC_adjusted   = ri$ICC_adjusted,
    Block_variance = ri$block_var,
    Resid_variance = ri$resid_var,
    Singular_fit   = isSingular(model)
  )
}

anova_table <- bind_rows(anova_list)
r2_table    <- bind_rows(r2_list)

write.csv(
  anova_table,
  "Supplementary_Table_S1_LMM_statistics_with_Variety.csv",
  row.names = FALSE
)

write.csv(
  r2_table,
  "Supplementary_Table_S2_R2_ICC_with_Variety.csv",
  row.names = FALSE
)

############################################################
# Plot function
############################################################

make_trait_plot <- function(orig_trait) {
  
  safe_trait <- name_map[orig_trait]
  
  dat_sub <- dat %>%
    filter(
      !is.na(.data[[safe_trait]]),
      !is.na(Period),
      !is.na(Drought),
      !is.na(Variety),
      !is.na(Block)
    )
  
  formu <- as.formula(
    paste0(safe_trait, " ~ Drought * Period + Variety + (1|Block)")
  )
  
  model <- lmer(formu, data = dat_sub)
  
  # ANOVA
  aov_tab <- anova(model, ddf = "Satterthwaite")
  aov_df  <- as.data.frame(aov_tab)
  aov_df$Effect <- rownames(aov_df)
  rownames(aov_df) <- NULL
  
  aov_df <- aov_df %>%
    mutate(
      partial_eta2 = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF),
      p_label = case_when(
        is.na(`Pr(>F)`)  ~ "",
        `Pr(>F)` < 0.001 ~ "<0.001",
        TRUE             ~ formatC(`Pr(>F)`, format = "f", digits = 3)
      )
    )
  
  # R2 / ICC
  ri <- safe_r2_icc(model, orig_trait)
  
  # 提取效应行
  get_row  <- function(eff) aov_df %>% filter(Effect == eff)
  fmt_row  <- function(row, nm) {
    paste0(nm, ": F=", round(row$`F value`, 2),
           ", p=", row$p_label,
           ", eta_p2=", round(row$partial_eta2, 3))
  }
  
  r2_line <- if (!is.na(ri$R2_marginal)) {
    paste0(
      "R2m=",        round(ri$R2_marginal, 3),
      ", R2c=",      round(ri$R2_conditional, 3),
      ", ICC=",      round(ri$ICC_adjusted, 3), "\n",
      "Var(Block)=", round(ri$block_var, 3),
      ", Var(Res)=", round(ri$resid_var, 3)
    )
  } else {
    paste0(
      "R2=NA (singular)\n",
      "Var(Block)=", round(ri$block_var, 3),
      ", Var(Res)=", round(ri$resid_var, 3)
    )
  }
  
  label_text <- paste(
    fmt_row(get_row("Variety"),       "Variety"),
    fmt_row(get_row("Drought"),       "Drought"),
    fmt_row(get_row("Period"),        "Period"),
    fmt_row(get_row("Drought:Period"),"Drought x Period"),
    r2_line,
    sep = "\n"
  )
  
  # emmeans
  emm    <- emmeans(model, ~ Drought | Period)
  emm_df <- as.data.frame(emm)
  
  # 字母分组（pairs + multcompLetters，无版本依赖问题）
  cld_df <- get_letters_df(emm)
  
  plot_df <- left_join(emm_df, cld_df, by = c("Period", "Drought"))
  
  plot_df$Drought <- factor(
    plot_df$Drought,
    levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
  )
  plot_df$Period <- factor(
    plot_df$Period,
    levels = c("Jointing", "Heading", "Filling", "Maturity")
  )
  
  ymax   <- max(plot_df$upper.CL, na.rm = TRUE)
  ymin   <- min(plot_df$lower.CL, na.rm = TRUE)
  yrange <- ymax - ymin
  
  ggplot(
    plot_df,
    aes(x = Period, y = emmean,
        group = Drought, colour = Drought)
  ) +
    
    geom_ribbon(
      aes(ymin = lower.CL, ymax = upper.CL, fill = Drought),
      alpha = 0.15, colour = NA
    ) +
    
    geom_line(linewidth = 0.9) +
    
    geom_point(size = 2.8) +
    
    geom_text(
      aes(y = upper.CL + 0.05 * yrange, label = Letter),
      colour = "black", size = 3.5,
      show.legend = FALSE
    ) +
    
    annotate(
      "text",
      x = 1.05, y = ymax + 0.30 * yrange,
      label = label_text,
      hjust = 0, vjust = 1,
      size  = 2.5, color = "black"
    ) +
    
    coord_cartesian(
      ylim = c(ymin, ymax + 0.65 * yrange),
      clip = "off"
    ) +
    
    scale_colour_manual(
      values = drought_colors,
      breaks = c("Control", "Drought_L", "Drought_M", "Drought_H")
    ) +
    scale_fill_manual(
      values = drought_colors,
      breaks = c("Control", "Drought_L", "Drought_M", "Drought_H")
    ) +
    
    labs(title = orig_trait, x = NULL, y = NULL) +
    
    theme_bw() +
    
    theme(
      panel.grid   = element_blank(),
      plot.title   = element_text(hjust = 0.5, face = "bold", size = 11),
      axis.text.x  = element_text(angle = 20, hjust = 1),
      legend.title = element_text(size = 10),
      legend.text  = element_text(size = 9),
      plot.margin  = margin(10, 20, 10, 10)
    )
}

############################################################
# Fig S1 — Soil physicochemical properties
############################################################

soil_plot_list <- lapply(soil_traits, make_trait_plot)
fig_s1 <- wrap_plots(soil_plot_list, ncol = 3)

ggsave("Fig_S1_Soil_physicochemical_properties.pdf",
       fig_s1, width = 14, height = 10)
ggsave("Fig_S1_Soil_physicochemical_properties.png",
       fig_s1, width = 14, height = 10, dpi = 600)

############################################################
# Fig S2 — Soil enzyme activities
############################################################

enzyme_plot_list <- lapply(enzyme_traits, make_trait_plot)
fig_s2 <- wrap_plots(enzyme_plot_list, ncol = 3)

ggsave("Fig_S2_Soil_enzyme_activities.pdf",
       fig_s2, width = 14, height = 8)
ggsave("Fig_S2_Soil_enzyme_activities.png",
       fig_s2, width = 14, height = 8, dpi = 600)

############################################################
# Fig S3 — Heatmap
############################################################

heat_df <- dat %>%
  mutate(Treatment = paste(Period, Drought, sep = "_")) %>%
  group_by(Treatment) %>%
  summarise(
    across(all_of(all_traits), mean, na.rm = TRUE),
    .groups = "drop"
  )

heat_mat <- heat_df %>%
  column_to_rownames("Treatment") %>%
  t()

heat_mat <- t(scale(t(heat_mat)))

col_order <- expand.grid(
  Period  = c("Jointing", "Heading", "Filling", "Maturity"),
  Drought = c("Control", "Drought_L", "Drought_M", "Drought_H")
) %>%
  mutate(name = paste(Period, Drought, sep = "_")) %>%
  pull(name)

col_order <- col_order[col_order %in% colnames(heat_mat)]
heat_mat  <- heat_mat[, col_order, drop = FALSE]

pdf("Fig_S3_Heatmap.pdf", width = 10, height = 8)
pheatmap(
  heat_mat,
  cluster_rows = TRUE,
  cluster_cols = FALSE,
  border_color = NA,
  fontsize     = 10,
  color = colorRampPalette(rev(brewer.pal(11, "RdBu")))(100)
)
dev.off()

png("Fig_S3_Heatmap.png", width = 3000, height = 2400, res = 600)
pheatmap(
  heat_mat,
  cluster_rows = TRUE,
  cluster_cols = FALSE,
  border_color = NA,
  fontsize     = 10,
  color = colorRampPalette(rev(brewer.pal(11, "RdBu")))(100)
)
dev.off()

############################################################
# End
############################################################