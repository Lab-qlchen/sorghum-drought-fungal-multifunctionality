############################################################
## Ecoenzymatic vector analysis
## Moorhead proportional method
##
## C-acquiring enzyme: BG
## N-acquiring enzymes: NAG + LAP
## P-acquiring enzyme: ALP
############################################################

rm(list = ls())
options(stringsAsFactors = FALSE)

setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/酶获取能力差异")

############################################################
## 1. Read and organize data
############################################################

enz <- utils::read.csv(
  "酶获取.csv",
  check.names = FALSE
)

grp <- utils::read.csv(
  "根际分组.csv",
  check.names = FALSE
)

colnames(grp)[1:2] <- c("Sample", "Group")

dat <- dplyr::left_join(
  enz,
  grp,
  by = "Sample"
)

required_cols <- c(
  "Block", "Sample", "Group",
  "BG", "NAG", "LAP", "ALP"
)

missing_cols <- base::setdiff(
  required_cols,
  colnames(dat)
)

if (length(missing_cols) > 0) {
  base::stop(
    paste0(
      "数据缺少以下列：",
      paste(missing_cols, collapse = ", ")
    )
  )
}

############################################################
## 2. Parse group information
############################################################

stage_levels <- c("JS", "HS", "FS", "MS")

drought_levels <- c(
  "Control",
  "Drought_L",
  "Drought_M",
  "Drought_H"
)

variety_levels <- c("JZ22", "LN01")

dat <- dat |>
  dplyr::mutate(
    GrowthStage = dplyr::case_when(
      stringr::str_detect(Group, "^JS_") ~ "JS",
      stringr::str_detect(Group, "^HS_") ~ "HS",
      stringr::str_detect(Group, "^FS_") ~ "FS",
      stringr::str_detect(Group, "^MS_") ~ "MS",
      TRUE ~ NA_character_
    ),
    
    Drought = dplyr::case_when(
      stringr::str_detect(Group, "_Control$")   ~ "Control",
      stringr::str_detect(Group, "_Drought_L$") ~ "Drought_L",
      stringr::str_detect(Group, "_Drought_M$") ~ "Drought_M",
      stringr::str_detect(Group, "_Drought_H$") ~ "Drought_H",
      TRUE ~ NA_character_
    ),
    
    Variety = dplyr::case_when(
      stringr::str_detect(Sample, "^Z") ~ "JZ22",
      stringr::str_detect(Sample, "^N") ~ "LN01",
      TRUE ~ NA_character_
    ),
    
    GrowthStage = factor(
      GrowthStage,
      levels = stage_levels
    ),
    
    Drought = factor(
      Drought,
      levels = drought_levels
    ),
    
    Variety = factor(
      Variety,
      levels = variety_levels
    ),
    
    Block = factor(Block)
  ) |>
  dplyr::filter(
    !is.na(GrowthStage),
    !is.na(Drought),
    !is.na(Variety),
    !is.na(Block),
    !is.na(BG),
    !is.na(NAG),
    !is.na(LAP),
    !is.na(ALP)
  )

############################################################
## 3. Ecoenzymatic vector calculation
############################################################

dat <- dat |>
  dplyr::mutate(
    E_C = BG,
    E_N = NAG + LAP,
    E_P = ALP,
    
    ## Moorhead proportional coordinates
    x_CP = E_C / (E_C + E_P),
    y_CN = E_C / (E_C + E_N),
    
    ## Vector length and angle
    Vector_L = sqrt(x_CP^2 + y_CN^2),
    Vector_A = atan2(y_CN, x_CP) * 180 / pi,
    
    ## Ratios for limitation classification
    x_NP = E_N / E_P,
    y_CN_ratio = E_C / E_N,
    
    Limitation = dplyr::case_when(
      x_NP < 1 & y_CN_ratio > 1 ~ "C&P limited",
      x_NP > 1 & y_CN_ratio > 1 ~ "C&N limited",
      x_NP < 1 & y_CN_ratio < 1 ~ "P limited",
      x_NP > 1 & y_CN_ratio < 1 ~ "N limited",
      TRUE ~ "Boundary"
    )
  )

utils::write.csv(
  dat |>
    dplyr::select(
      Block,
      Sample,
      Group,
      GrowthStage,
      Drought,
      Variety,
      BG,
      NAG,
      LAP,
      ALP,
      x_CP,
      y_CN,
      Vector_L,
      Vector_A,
      x_NP,
      y_CN_ratio,
      Limitation
    ),
  "Ecoenzyme_vector_results.csv",
  row.names = FALSE
)

############################################################
## 4. Linear mixed-effects models
############################################################

fit_L <- base::suppressWarnings(
  lmerTest::lmer(
    Vector_L ~ Drought * GrowthStage +
      Variety +
      (1 | Block),
    data = dat
  )
)

fit_A <- base::suppressWarnings(
  lmerTest::lmer(
    Vector_A ~ Drought * GrowthStage +
      Variety +
      (1 | Block),
    data = dat
  )
)

anova_L <- base::as.data.frame(
  stats::anova(
    fit_L,
    type = 3,
    ddf = "Satterthwaite"
  )
)

anova_A <- base::as.data.frame(
  stats::anova(
    fit_A,
    type = 3,
    ddf = "Satterthwaite"
  )
)

anova_L$Effect <- rownames(anova_L)
anova_A$Effect <- rownames(anova_A)

rownames(anova_L) <- NULL
rownames(anova_A) <- NULL

anova_out <- dplyr::bind_rows(
  anova_L |>
    dplyr::mutate(
      Metric = "Vector_L",
      .before = 1
    ),
  
  anova_A |>
    dplyr::mutate(
      Metric = "Vector_A",
      .before = 1
    )
)

utils::write.csv(
  anova_out,
  "Ecoenzyme_vector_LMM_ANOVA.csv",
  row.names = FALSE
)

############################################################
## 5. Format LMM statistics for plots
############################################################

format_p <- function(p_value) {
  
  if (base::is.na(p_value)) {
    return("P = NA")
  }
  
  if (p_value < 0.001) {
    return("P < 0.001")
  }
  
  paste0(
    "P = ",
    base::formatC(
      p_value,
      format = "f",
      digits = 3
    )
  )
}

make_lmm_label <- function(anova_table) {
  
  effect_names <- rownames(anova_table)
  
  f_column <- base::grep(
    "F",
    colnames(anova_table),
    value = TRUE
  )
  
  f_column <- f_column[
    base::grepl(
      "value",
      f_column,
      ignore.case = TRUE
    )
  ][1]
  
  p_column <- base::grep(
    "Pr",
    colnames(anova_table),
    value = TRUE
  )[1]
  
  get_effect <- function(effect_name, display_name) {
    
    row_id <- base::which(
      effect_names == effect_name
    )
    
    if (length(row_id) == 0) {
      return(
        paste0(display_name, ": not available")
      )
    }
    
    f_value <- anova_table[
      row_id,
      f_column
    ]
    
    p_value <- anova_table[
      row_id,
      p_column
    ]
    
    paste0(
      display_name,
      ": F = ",
      base::formatC(
        f_value,
        format = "f",
        digits = 2
      ),
      ", ",
      format_p(p_value)
    )
  }
  
  paste(
    get_effect(
      "Drought",
      "Drought"
    ),
    get_effect(
      "GrowthStage",
      "GrowthStage"
    ),
    get_effect(
      "Drought:GrowthStage",
      "Drought × GrowthStage"
    ),
    sep = "   "
  )
}

lmm_label_L <- make_lmm_label(
  stats::anova(
    fit_L,
    type = 3,
    ddf = "Satterthwaite"
  )
)

lmm_label_A <- make_lmm_label(
  stats::anova(
    fit_A,
    type = 3,
    ddf = "Satterthwaite"
  )
)

############################################################
## 6. Pairwise drought comparisons within each stage
############################################################

emm_L <- emmeans::emmeans(
  fit_L,
  ~ Drought | GrowthStage
)

emm_A <- emmeans::emmeans(
  fit_A,
  ~ Drought | GrowthStage
)

pair_L <- base::as.data.frame(
  emmeans::contrast(
    emm_L,
    method = "pairwise",
    adjust = "BH"
  )
)

pair_A <- base::as.data.frame(
  emmeans::contrast(
    emm_A,
    method = "pairwise",
    adjust = "BH"
  )
)

pair_out <- dplyr::bind_rows(
  pair_L |>
    dplyr::mutate(
      Metric = "Vector_L",
      .before = 1
    ),
  
  pair_A |>
    dplyr::mutate(
      Metric = "Vector_A",
      .before = 1
    )
)

utils::write.csv(
  pair_out,
  "Ecoenzyme_vector_pairwise_BH.csv",
  row.names = FALSE
)

cld_L <- multcomp::cld(
  emm_L,
  adjust = "BH",
  Letters = letters
) |>
  base::as.data.frame() |>
  dplyr::transmute(
    GrowthStage,
    Drought,
    Letter = stringr::str_trim(.group)
  )

cld_A <- multcomp::cld(
  emm_A,
  adjust = "BH",
  Letters = letters
) |>
  base::as.data.frame() |>
  dplyr::transmute(
    GrowthStage,
    Drought,
    Letter = stringr::str_trim(.group)
  )

############################################################
## 7. Significance-letter positions
############################################################

pad_L <- base::max(
  base::diff(
    base::range(
      dat$Vector_L,
      na.rm = TRUE
    )
  ) * 0.08,
  0.01
)

pad_A <- base::max(
  base::diff(
    base::range(
      dat$Vector_A,
      na.rm = TRUE
    )
  ) * 0.08,
  0.50
)

anno_L <- dat |>
  dplyr::group_by(
    GrowthStage,
    Drought
  ) |>
  dplyr::summarise(
    y = base::max(
      Vector_L,
      na.rm = TRUE
    ) + pad_L,
    .groups = "drop"
  ) |>
  dplyr::left_join(
    cld_L,
    by = c(
      "GrowthStage",
      "Drought"
    )
  )

anno_A <- dat |>
  dplyr::group_by(
    GrowthStage,
    Drought
  ) |>
  dplyr::summarise(
    y = base::max(
      Vector_A,
      na.rm = TRUE
    ) + pad_A,
    .groups = "drop"
  ) |>
  dplyr::left_join(
    cld_A,
    by = c(
      "GrowthStage",
      "Drought"
    )
  )

############################################################
## 8. Plot settings
############################################################

drought_colors <- c(
  "Control"   = "#F8766D",
  "Drought_L" = "#7CAE00",
  "Drought_M" = "#00BFC4",
  "Drought_H" = "#C77CFF"
)

stage_shapes <- c(
  "JS" = 16,
  "HS" = 17,
  "FS" = 15,
  "MS" = 18
)

variety_shapes <- c(
  "JZ22" = 16,
  "LN01" = 17
)

base_theme <- ggplot2::theme_bw(
  base_size = 12
) +
  ggplot2::theme(
    panel.grid = ggplot2::element_blank(),
    axis.text = ggplot2::element_text(
      color = "black"
    ),
    axis.title = ggplot2::element_text(
      color = "black"
    ),
    strip.text = ggplot2::element_text(
      face = "bold"
    ),
    legend.position = "top"
  )

############################################################
## 9. Limitation-classification quadrant plot
############################################################

quadrant_x_max <- base::max(
  1.20,
  base::max(
    dat$x_NP,
    na.rm = TRUE
  ) * 1.05
)

quadrant_y_max <- base::max(
  1.20,
  base::max(
    dat$y_CN_ratio,
    na.rm = TRUE
  ) * 1.05
)

quadrant_x_right <- 1 +
  0.55 * (quadrant_x_max - 1)

quadrant_y_high <- 1 +
  0.55 * (quadrant_y_max - 1)

p_limit <- ggplot2::ggplot(
  dat,
  ggplot2::aes(
    x = x_NP,
    y = y_CN_ratio,
    color = Drought,
    shape = GrowthStage
  )
) +
  ggplot2::geom_vline(
    xintercept = 1,
    linetype = "dashed",
    linewidth = 0.6
  ) +
  ggplot2::geom_hline(
    yintercept = 1,
    linetype = "dashed",
    linewidth = 0.6
  ) +
  ggplot2::geom_point(
    size = 3,
    alpha = 0.80
  ) +
  ggplot2::annotate(
    "text",
    x = 0.50,
    y = quadrant_y_high,
    label = "C&P limited",
    size = 4
  ) +
  ggplot2::annotate(
    "text",
    x = quadrant_x_right,
    y = quadrant_y_high,
    label = "C&N limited",
    size = 4
  ) +
  ggplot2::annotate(
    "text",
    x = 0.50,
    y = 0.25,
    label = "P limited",
    size = 4
  ) +
  ggplot2::annotate(
    "text",
    x = quadrant_x_right,
    y = 0.25,
    label = "N limited",
    size = 4
  ) +
  ggplot2::coord_cartesian(
    xlim = c(
      0,
      quadrant_x_max
    ),
    ylim = c(
      0,
      quadrant_y_max
    )
  ) +
  ggplot2::scale_color_manual(
    values = drought_colors,
    drop = FALSE
  ) +
  ggplot2::scale_shape_manual(
    values = stage_shapes,
    drop = FALSE
  ) +
  ggplot2::labs(
    x = "(NAG + LAP) / ALP",
    y = "BG / (NAG + LAP)",
    color = "Drought",
    shape = "GrowthStage"
  ) +
  base_theme

base::print(p_limit)

ggplot2::ggsave(
  filename = "Fig_Ecoenzyme_limitation_quadrant.pdf",
  plot = p_limit,
  width = 7,
  height = 5.8,
  units = "in",
  device = grDevices::cairo_pdf
)

############################################################
## 10. Vector-coordinate scatter plot
## Raw points only
############################################################

xy_min <- base::max(
  0,
  base::floor(
    base::min(
      c(
        dat$x_CP,
        dat$y_CN
      ),
      na.rm = TRUE
    ) * 20
  ) / 20
)

xy_max <- base::min(
  1,
  base::ceiling(
    base::max(
      c(
        dat$x_CP,
        dat$y_CN
      ),
      na.rm = TRUE
    ) * 20
  ) / 20
)

p_scatter <- ggplot2::ggplot(
  dat,
  ggplot2::aes(
    x = x_CP,
    y = y_CN,
    color = Drought,
    shape = GrowthStage
  )
) +
  ggplot2::geom_abline(
    slope = 1,
    intercept = 0,
    linetype = "dashed",
    linewidth = 0.7
  ) +
  ggplot2::geom_point(
    size = 3,
    alpha = 0.80
  ) +
  ggplot2::coord_equal(
    xlim = c(
      xy_min,
      xy_max
    ),
    ylim = c(
      xy_min,
      xy_max
    )
  ) +
  ggplot2::scale_color_manual(
    values = drought_colors,
    drop = FALSE
  ) +
  ggplot2::scale_shape_manual(
    values = stage_shapes,
    drop = FALSE
  ) +
  ggplot2::labs(
    x = "BG / (BG + ALP)",
    y = "BG / (BG + NAG + LAP)",
    color = "Drought",
    shape = "GrowthStage"
  ) +
  base_theme

base::print(p_scatter)

ggplot2::ggsave(
  filename = "Fig_Ecoenzyme_vector_scatter.pdf",
  plot = p_scatter,
  width = 7,
  height = 5.8,
  units = "in",
  device = grDevices::cairo_pdf
)

############################################################
## 11. Vector-length boxplot
############################################################

p_length <- ggplot2::ggplot(
  dat,
  ggplot2::aes(
    x = Drought,
    y = Vector_L,
    fill = Drought
  )
) +
  ggplot2::geom_boxplot(
    width = 0.65,
    outlier.shape = NA,
    alpha = 0.75
  ) +
  ggplot2::geom_jitter(
    ggplot2::aes(
      color = Drought,
      shape = Variety
    ),
    width = 0.12,
    size = 2.2,
    alpha = 0.80
  ) +
  ggplot2::geom_text(
    data = anno_L,
    ggplot2::aes(
      x = Drought,
      y = y,
      label = Letter
    ),
    inherit.aes = FALSE,
    size = 5
  ) +
  ggplot2::facet_wrap(
    ~GrowthStage,
    nrow = 1
  ) +
  ggplot2::scale_fill_manual(
    values = drought_colors,
    drop = FALSE
  ) +
  ggplot2::scale_color_manual(
    values = drought_colors,
    drop = FALSE
  ) +
  ggplot2::scale_shape_manual(
    values = variety_shapes,
    drop = FALSE
  ) +
  ggplot2::scale_y_continuous(
    expand = ggplot2::expansion(
      mult = c(
        0.05,
        0.16
      )
    )
  ) +
  ggplot2::labs(
    x = NULL,
    y = "Vector length",
    subtitle = lmm_label_L
  ) +
  base_theme +
  ggplot2::theme(
    legend.position = "none",
    plot.subtitle = ggplot2::element_text(
      hjust = 0,
      size = 10,
      color = "black",
      margin = ggplot2::margin(
        b = 8
      )
    ),
    axis.text.x = ggplot2::element_text(
      angle = 45,
      hjust = 1
    )
  )

base::print(p_length)

############################################################
## 12. Vector-angle boxplot
############################################################

p_angle <- ggplot2::ggplot(
  dat,
  ggplot2::aes(
    x = Drought,
    y = Vector_A,
    fill = Drought
  )
) +
  ggplot2::geom_hline(
    yintercept = 45,
    linetype = "dashed",
    linewidth = 0.6
  ) +
  ggplot2::geom_boxplot(
    width = 0.65,
    outlier.shape = NA,
    alpha = 0.75
  ) +
  ggplot2::geom_jitter(
    ggplot2::aes(
      color = Drought,
      shape = Variety
    ),
    width = 0.12,
    size = 2.2,
    alpha = 0.80
  ) +
  ggplot2::geom_text(
    data = anno_A,
    ggplot2::aes(
      x = Drought,
      y = y,
      label = Letter
    ),
    inherit.aes = FALSE,
    size = 5
  ) +
  ggplot2::facet_wrap(
    ~GrowthStage,
    nrow = 1
  ) +
  ggplot2::scale_fill_manual(
    values = drought_colors,
    drop = FALSE
  ) +
  ggplot2::scale_color_manual(
    values = drought_colors,
    drop = FALSE
  ) +
  ggplot2::scale_shape_manual(
    values = variety_shapes,
    drop = FALSE
  ) +
  ggplot2::scale_y_continuous(
    expand = ggplot2::expansion(
      mult = c(
        0.05,
        0.16
      )
    )
  ) +
  ggplot2::labs(
    x = NULL,
    y = "Vector angle (°)",
    subtitle = lmm_label_A
  ) +
  base_theme +
  ggplot2::theme(
    legend.position = "none",
    plot.subtitle = ggplot2::element_text(
      hjust = 0,
      size = 10,
      color = "black",
      margin = ggplot2::margin(
        b = 8
      )
    ),
    axis.text.x = ggplot2::element_text(
      angle = 45,
      hjust = 1
    )
  )

base::print(p_angle)

############################################################
## 13. Combine vector-length and vector-angle plots
############################################################

p_box <- patchwork::wrap_plots(
  p_length,
  p_angle,
  ncol = 1,
  heights = c(
    1,
    1
  )
)

base::print(p_box)

ggplot2::ggsave(
  filename = "Fig_Ecoenzyme_vector_boxplots.pdf",
  plot = p_box,
  width = 12,
  height = 8.2,
  units = "in",
  device = grDevices::cairo_pdf
)

############################################################
## 14. Relationship between vector length and vector angle
############################################################

fit_relation <- stats::lm(
  Vector_A ~ Vector_L,
  data = dat
)

relation_summary <- base::summary(
  fit_relation
)

relation_r2 <- relation_summary$r.squared

relation_p <- relation_summary$coefficients[
  "Vector_L",
  "Pr(>|t|)"
]

relation_label <- paste0(
  "R² = ",
  base::formatC(
    relation_r2,
    format = "f",
    digits = 2
  ),
  ", ",
  format_p(relation_p)
)

p_relation <- ggplot2::ggplot(
  dat,
  ggplot2::aes(
    x = Vector_L,
    y = Vector_A,
    color = Drought,
    shape = GrowthStage
  )
) +
  ggplot2::geom_point(
    size = 3,
    alpha = 0.80
  ) +
  ggplot2::geom_smooth(
    method = "lm",
    formula = y ~ x,
    se = TRUE,
    color = "black",
    fill = "grey80",
    linetype = "dashed",
    linewidth = 0.8
  ) +
  ggplot2::annotate(
    "text",
    x = base::min(
      dat$Vector_L,
      na.rm = TRUE
    ),
    y = base::max(
      dat$Vector_A,
      na.rm = TRUE
    ),
    label = relation_label,
    hjust = 0,
    vjust = 1,
    size = 4.2
  ) +
  ggplot2::scale_color_manual(
    values = drought_colors,
    drop = FALSE
  ) +
  ggplot2::scale_shape_manual(
    values = stage_shapes,
    drop = FALSE
  ) +
  ggplot2::labs(
    x = "Vector length",
    y = "Vector angle (°)",
    color = "Drought",
    shape = "GrowthStage"
  ) +
  base_theme

base::print(p_relation)

ggplot2::ggsave(
  filename = "Fig_Ecoenzyme_VectorAngle_vs_VectorLength.pdf",
  plot = p_relation,
  width = 6.5,
  height = 5.2,
  units = "in",
  device = grDevices::cairo_pdf
)