## =========================================================
## Rhizosphere βNTI vs soil multifunctionality difference ΔSMF
## Show four stage-specific scatter plots
## Points use one unified color, no drought-specific colors
## =========================================================

rm(list = ls())
options(stringsAsFactors = FALSE)

setwd("D:/IUE/山西数据/真菌/抽平/群落组装/βNTI和SMF相关性")

library(tidyverse)

## =========================================================
## 1. File names
## =========================================================

bnti_file <- "根际pairwise_betaNTI_RCbray_process.csv"
smf_file  <- "测试数据SMF_MeanZ_results.csv"

smf_value_col <- "SMF_meanZ"
# If you want to use 0–1 normalized SMF, change to:
# smf_value_col <- "SMF_meanZ_01"

## =========================================================
## 2. Read data
## =========================================================

bnti <- read.csv(
  bnti_file,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

smf <- read.csv(
  smf_file,
  check.names = FALSE,
  stringsAsFactors = FALSE
)

## =========================================================
## 3. Check required columns
## =========================================================

bnti_need <- c(
  "Sample1",
  "Sample2",
  "betaNTI",
  "CompareType",
  "Group1",
  "Group2"
)

smf_need <- c("Sample", smf_value_col)

missing_bnti <- setdiff(bnti_need, colnames(bnti))
missing_smf  <- setdiff(smf_need, colnames(smf))

if(length(missing_bnti) > 0){
  stop("βNTI file is missing columns: ", paste(missing_bnti, collapse = ", "))
}

if(length(missing_smf) > 0){
  stop("SMF file is missing columns: ", paste(missing_smf, collapse = ", "))
}

## =========================================================
## 4. Prepare SMF table
## =========================================================

smf_use <- smf %>%
  transmute(
    Sample = as.character(Sample),
    SMF = as.numeric(.data[[smf_value_col]])
  )

if(any(is.na(smf_use$SMF))){
  warning("SMF contains NA values. Related sample pairs will be removed.")
}

## =========================================================
## 5. Merge βNTI with SMF and calculate ΔSMF
##    Here we use WithinGroup pairs:
##    same stage × same drought treatment
## =========================================================

rhizo_dat <- bnti %>%
  filter(CompareType == "WithinGroup") %>%
  filter(Group1 == Group2) %>%
  select(Sample1, Sample2, betaNTI, Group1) %>%
  left_join(smf_use, by = c("Sample1" = "Sample")) %>%
  rename(SMF1 = SMF) %>%
  left_join(smf_use, by = c("Sample2" = "Sample")) %>%
  rename(SMF2 = SMF) %>%
  mutate(
    dSMF = abs(SMF1 - SMF2),
    Stage = case_when(
      grepl("^JS_", Group1) ~ "Jointing stage",
      grepl("^HS_", Group1) ~ "Heading stage",
      grepl("^FS_", Group1) ~ "Filling stage",
      grepl("^MS_", Group1) ~ "Maturity stage",
      TRUE ~ NA_character_
    ),
    Drought = case_when(
      grepl("_Control$",   Group1) ~ "Control",
      grepl("_Drought_L$", Group1) ~ "Drought_L",
      grepl("_Drought_M$", Group1) ~ "Drought_M",
      grepl("_Drought_H$", Group1) ~ "Drought_H",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(
    !is.na(betaNTI),
    !is.na(dSMF),
    !is.na(Stage),
    !is.na(Drought)
  )

rhizo_dat$Stage <- factor(
  rhizo_dat$Stage,
  levels = c(
    "Jointing stage",
    "Heading stage",
    "Filling stage",
    "Maturity stage"
  )
)

rhizo_dat$Drought <- factor(
  rhizo_dat$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

write.csv(
  rhizo_dat,
  "Rhizosphere_betaNTI_vs_dSMF_pairwise_table_by_stage.csv",
  row.names = FALSE
)

## =========================================================
## 6. Stage-specific Spearman correlations
## =========================================================

cor_stage <- rhizo_dat %>%
  group_by(Stage) %>%
  summarise(
    n_pairs = n(),
    rho = ifelse(
      n_pairs >= 4 &&
        n_distinct(dSMF) > 1 &&
        n_distinct(betaNTI) > 1,
      suppressWarnings(cor(dSMF, betaNTI, method = "spearman")),
      NA_real_
    ),
    p_value = ifelse(
      n_pairs >= 4 &&
        n_distinct(dSMF) > 1 &&
        n_distinct(betaNTI) > 1,
      suppressWarnings(
        cor.test(
          dSMF,
          betaNTI,
          method = "spearman",
          exact = FALSE
        )$p.value
      ),
      NA_real_
    ),
    lm_r2 = ifelse(
      n_pairs >= 4 &&
        n_distinct(dSMF) > 1 &&
        n_distinct(betaNTI) > 1,
      summary(lm(betaNTI ~ dSMF))$r.squared,
      NA_real_
    ),
    .groups = "drop"
  ) %>%
  mutate(
    label = paste0(
      "Spearman rho = ",
      ifelse(is.na(rho), "NA", round(rho, 3)),
      "\nP = ",
      ifelse(is.na(p_value), "NA", format.pval(p_value, digits = 3))
    )
  )

write.csv(
  cor_stage,
  "Rhizosphere_betaNTI_vs_dSMF_correlation_by_stage.csv",
  row.names = FALSE
)

print(cor_stage)

## =========================================================
## 7. Combined four-panel plot
## =========================================================

p_stage <- ggplot(
  rhizo_dat,
  aes(x = dSMF, y = betaNTI)
) +
  geom_point(
    size = 3.5,
    color = "#2485bc",
    alpha = 0.7
  ) +
  geom_smooth(
    method = "lm",
    se = TRUE,
    color = "#1b4f72",
    fill  = "#b0c4de",
    linewidth = 1
  ) +
  geom_hline(
    yintercept = c(-2, 2),
    linetype = "dashed",
    color = "red",
    linewidth = 0.5
  ) +
  geom_text(
    data = cor_stage,
    aes(
      x = Inf,
      y = Inf,
      label = label
    ),
    inherit.aes = FALSE,
    hjust = 1.05,
    vjust = 1.15,
    size = 3.8
  ) +
  facet_wrap(
    ~ Stage,
    nrow = 1,
    scales = "free"
  ) +
  theme_bw(base_size = 12) +
  theme(
    strip.background = element_rect(fill = "grey90", color = "black"),
    strip.text = element_text(face = "bold", size = 12),
    axis.text = element_text(color = "black"),
    panel.grid.minor = element_blank(),
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      size = 15
    ),
    legend.position = "none"
  ) +
  labs(
    x = expression(Delta * "SMF"),
    y = expression(beta * NTI),
    title = "Rhizosphere βNTI and SMF difference across growth stages"
  )

print(p_stage)

ggsave(
  "Rhizosphere_betaNTI_vs_dSMF_by_stage_4panels.pdf",
  p_stage,
  width = 12,
  height = 4.8,
  dpi = 300
)

ggsave(
  "Rhizosphere_betaNTI_vs_dSMF_by_stage_4panels.png",
  p_stage,
  width = 12,
  height = 4.8,
  dpi = 300
)

## =========================================================
## 8. Optional: save four individual stage plots
## =========================================================

stage_levels <- levels(rhizo_dat$Stage)

for(st in stage_levels){
  
  dat_st <- rhizo_dat %>%
    filter(Stage == st)
  
  stat_st <- cor_stage %>%
    filter(Stage == st)
  
  p_single <- ggplot(
    dat_st,
    aes(x = dSMF, y = betaNTI)
  ) +
    geom_point(
      size = 3.5,
      color = "#2485bc",
      alpha = 0.7
    ) +
    geom_smooth(
      method = "lm",
      se = TRUE,
      color = "#1b4f72",
      fill  = "#b0c4de",
      linewidth = 1
    ) +
    geom_hline(
      yintercept = c(-2, 2),
      linetype = "dashed",
      color = "red",
      linewidth = 0.5
    ) +
    annotate(
      "text",
      x = Inf,
      y = Inf,
      hjust = 1.05,
      vjust = 1.15,
      label = stat_st$label,
      size = 4
    ) +
    theme_bw(base_size = 12) +
    theme(
      plot.title = element_text(
        hjust = 0.5,
        face = "bold",
        size = 15
      ),
      axis.text = element_text(color = "black"),
      panel.grid.minor = element_blank(),
      legend.position = "none"
    ) +
    labs(
      x = expression(Delta * "SMF"),
      y = expression(beta * NTI),
      title = paste0("Rhizosphere - ", st)
    )
  
  print(p_single)
  
  out_name <- gsub(" ", "_", st)
  
  ggsave(
    paste0("Rhizosphere_betaNTI_vs_dSMF_", out_name, ".pdf"),
    p_single,
    width = 5.5,
    height = 5,
    dpi = 300
  )
  
  ggsave(
    paste0("Rhizosphere_betaNTI_vs_dSMF_", out_name, ".png"),
    p_single,
    width = 5.5,
    height = 5,
    dpi = 300
  )
}

cat("\nDONE.\n")
cat("Outputs:\n")
cat("1. Rhizosphere_betaNTI_vs_dSMF_pairwise_table_by_stage.csv\n")
cat("2. Rhizosphere_betaNTI_vs_dSMF_correlation_by_stage.csv\n")
cat("3. Rhizosphere_betaNTI_vs_dSMF_by_stage_4panels.pdf / png\n")
cat("4. Four individual stage-specific scatter plots\n")