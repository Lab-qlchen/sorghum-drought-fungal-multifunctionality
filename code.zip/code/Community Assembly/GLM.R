############################################################
## Rhizosphere-only binomial GLM:
## Drought effect on homogeneous selection
## With significance markers on forest plot
############################################################

rm(list = ls())
options(stringsAsFactors = FALSE)

library(tidyverse)
library(ggplot2)

############################################################
## 1. Set working directory
############################################################

setwd("D:/IUE/山西数据/真菌/抽平/群落组装/βNTI和SMF相关性")

############################################################
## 2. Input pairwise process file
############################################################

process_file <- "根际pairwise_betaNTI_RCbray_process.csv"

############################################################
## 3. Read pairwise process table
############################################################

process_tab <- read.csv(
  process_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

need_cols <- c(
  "Sample1", "Sample2",
  "Group1", "Group2",
  "CompareType",
  "Process"
)

missing_cols <- setdiff(need_cols, colnames(process_tab))

if(length(missing_cols) > 0){
  stop(
    "Process table is missing columns: ",
    paste(missing_cols, collapse = ", ")
  )
}

############################################################
## 4. Keep within-group pairwise comparisons
############################################################

within_tab <- process_tab %>%
  filter(CompareType == "WithinGroup") %>%
  filter(Group1 == Group2) %>%
  mutate(
    Group = Group1,
    Stage = case_when(
      grepl("^JS_", Group) ~ "Jointing stage",
      grepl("^HS_", Group) ~ "Heading stage",
      grepl("^FS_", Group) ~ "Filling stage",
      grepl("^MS_", Group) ~ "Maturity stage",
      TRUE ~ NA_character_
    ),
    Drought = case_when(
      grepl("_Control$",   Group) ~ "Control",
      grepl("_Drought_L$", Group) ~ "Drought_L",
      grepl("_Drought_M$", Group) ~ "Drought_M",
      grepl("_Drought_H$", Group) ~ "Drought_H",
      TRUE ~ NA_character_
    ),
    Drought_num = case_when(
      Drought == "Control"   ~ 0,
      Drought == "Drought_L" ~ 1,
      Drought == "Drought_M" ~ 2,
      Drought == "Drought_H" ~ 3
    ),
    Homo = ifelse(Process == "Homogeneous_selection", 1, 0)
  ) %>%
  filter(!is.na(Stage), !is.na(Drought), !is.na(Drought_num))

within_tab$Stage <- factor(
  within_tab$Stage,
  levels = c(
    "Jointing stage",
    "Heading stage",
    "Filling stage",
    "Maturity stage"
  )
)

within_tab$Drought <- factor(
  within_tab$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

############################################################
## 5. Summarise Homogeneous selection pairs
##    per stage × drought treatment
############################################################

glm_data <- within_tab %>%
  group_by(Stage, Drought, Drought_num, Group) %>%
  summarise(
    Total_pairs = n(),
    Homo_pairs = sum(Homo),
    Other_pairs = Total_pairs - Homo_pairs,
    Homo_proportion = Homo_pairs / Total_pairs,
    .groups = "drop"
  )

write.csv(
  glm_data,
  "Rhizosphere_homogeneous_selection_binomial_GLM_input.csv",
  row.names = FALSE
)

print(glm_data)

############################################################
## 6. Fit binomial GLM for each stage
## Response = cbind(Homo_pairs, Other_pairs)
## Predictor = drought intensity
############################################################

fit_stage_glm <- function(df){
  
  if(nrow(df) < 4 || length(unique(df$Homo_proportion)) <= 1){
    return(tibble(
      estimate = NA_real_,
      se = NA_real_,
      z_value = NA_real_,
      p_value = NA_real_,
      OR = NA_real_,
      CI_low = NA_real_,
      CI_high = NA_real_
    ))
  }
  
  fit <- glm(
    cbind(Homo_pairs, Other_pairs) ~ Drought_num,
    data = df,
    family = binomial
  )
  
  sm <- summary(fit)$coefficients
  
  est <- sm["Drought_num", "Estimate"]
  se  <- sm["Drought_num", "Std. Error"]
  z   <- sm["Drought_num", "z value"]
  p   <- sm["Drought_num", "Pr(>|z|)"]
  
  tibble(
    estimate = est,
    se = se,
    z_value = z,
    p_value = p,
    OR = exp(est),
    CI_low = exp(est - 1.96 * se),
    CI_high = exp(est + 1.96 * se)
  )
}

glm_result <- glm_data %>%
  group_by(Stage) %>%
  group_modify(~ fit_stage_glm(.x)) %>%
  ungroup() %>%
  mutate(
    sig = case_when(
      is.na(p_value) ~ "",
      p_value < 0.001 ~ "***",
      p_value < 0.01  ~ "**",
      p_value < 0.05  ~ "*",
      TRUE ~ ""
    ),
    p_label = case_when(
      is.na(p_value) ~ "P = NA",
      p_value < 0.001 ~ "P < 0.001",
      TRUE ~ paste0("P = ", sprintf("%.3f", p_value))
    ),
    right_label = paste0(
      "OR = ", sprintf("%.2f", OR),
      " (", sprintf("%.2f", CI_low), "–", sprintf("%.2f", CI_high), ")",
      ", ", p_label
    )
  )

write.csv(
  glm_result,
  "Rhizosphere_drought_effect_on_homogeneous_selection_binomial_GLM.csv",
  row.names = FALSE
)

print(glm_result)

############################################################
## 7. Prepare plot data
############################################################

plot_df <- glm_result %>%
  mutate(
    Stage = factor(
      Stage,
      levels = rev(c(
        "Jointing stage",
        "Heading stage",
        "Filling stage",
        "Maturity stage"
      ))
    ),
    star_x = case_when(
      is.na(OR) ~ NA_real_,
      OR >= 1  ~ OR * 1.10,
      OR < 1   ~ OR * 0.90
    ),
    star_hjust = case_when(
      is.na(OR) ~ 0.5,
      OR >= 1  ~ 0,
      OR < 1   ~ 1
    )
  )

x_min <- min(plot_df$CI_low, na.rm = TRUE) * 0.75
x_max <- max(plot_df$CI_high, na.rm = TRUE) * 2.8
label_x <- max(plot_df$CI_high, na.rm = TRUE) * 1.20

############################################################
## 8. Forest-style plot with significance markers
############################################################

p_or <- ggplot(
  plot_df,
  aes(x = OR, y = Stage)
) +
  geom_vline(
    xintercept = 1,
    linetype = "dashed",
    color = "grey40",
    linewidth = 0.5
  ) +
  geom_errorbarh(
    aes(xmin = CI_low, xmax = CI_high),
    height = 0.18,
    color = "grey35",
    linewidth = 0.85,
    na.rm = TRUE
  ) +
  geom_point(
    size = 4.6,
    color = "#D7191C",
    na.rm = TRUE
  ) +
  geom_text(
    aes(
      x = star_x,
      label = sig,
      hjust = star_hjust
    ),
    size = 5.2,
    fontface = "bold",
    na.rm = TRUE
  ) +
  geom_text(
    aes(
      x = label_x,
      label = right_label
    ),
    hjust = 0,
    size = 4,
    na.rm = TRUE
  ) +
  scale_x_log10() +
  coord_cartesian(
    xlim = c(x_min, x_max),
    clip = "off"
  ) +
  theme_bw(base_size = 12) +
  labs(
    x = "Drought effect on homogeneous selection (odds ratio, log scale)",
    y = NULL,
    title = "Rhizosphere drought effect on homogeneous selection"
  ) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    axis.text = element_text(color = "black"),
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      size = 15
    ),
    plot.margin = margin(5.5, 155, 5.5, 5.5)
  )

print(p_or)

ggsave(
  "Rhizosphere_drought_effect_on_homogeneous_selection_OR_forest_with_significance.pdf",
  p_or,
  width = 9.5,
  height = 4.2,
  dpi = 300
)

ggsave(
  "Rhizosphere_drought_effect_on_homogeneous_selection_OR_forest_with_significance.png",
  p_or,
  width = 9.5,
  height = 4.2,
  dpi = 300
)

############################################################
## 9. Optional:
## Observed homogeneous selection proportions
############################################################

p_prop <- ggplot(
  glm_data,
  aes(x = Drought, y = Homo_proportion)
) +
  geom_point(
    size = 3.5,
    color = "#2485bc",
    alpha = 0.85
  ) +
  geom_line(
    aes(group = Stage),
    color = "grey40",
    linewidth = 0.7
  ) +
  facet_wrap(~ Stage, nrow = 1) +
  theme_bw(base_size = 12) +
  labs(
    x = "Drought treatment",
    y = "Proportion of homogeneous selection",
    title = "Observed homogeneous selection proportion in the rhizosphere"
  ) +
  theme(
    strip.background = element_rect(fill = "grey90", color = "black"),
    strip.text = element_text(face = "bold"),
    axis.text.x = element_text(angle = 35, hjust = 1, color = "black"),
    axis.text.y = element_text(color = "black"),
    panel.grid.minor = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold")
  )

print(p_prop)

ggsave(
  "Rhizosphere_observed_homogeneous_selection_proportion_by_stage.pdf",
  p_prop,
  width = 10,
  height = 4,
  dpi = 300
)

ggsave(
  "Rhizosphere_observed_homogeneous_selection_proportion_by_stage.png",
  p_prop,
  width = 10,
  height = 4,
  dpi = 300
)

cat("\nDONE.\n")
cat("Main outputs:\n")
cat("1. Rhizosphere_homogeneous_selection_binomial_GLM_input.csv\n")
cat("2. Rhizosphere_drought_effect_on_homogeneous_selection_binomial_GLM.csv\n")
cat("3. Rhizosphere_drought_effect_on_homogeneous_selection_OR_forest_with_significance.pdf / png\n")
cat("4. Rhizosphere_observed_homogeneous_selection_proportion_by_stage.pdf / png\n")