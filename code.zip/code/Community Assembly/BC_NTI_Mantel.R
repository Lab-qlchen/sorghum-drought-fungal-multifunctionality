rm(list = ls())
options(stringsAsFactors = FALSE)

setwd("D:/IUE/山西数据/真菌/抽平/群落组装/BC")

suppressPackageStartupMessages({
  library(tidyverse)
  library(vegan)
  library(ggplot2)
  library(patchwork)
})

# =========================================================
# 0. 文件信息
# =========================================================
file_info <- list(
  Phyllosphere = list(
    asv   = "叶际F_ASV.csv",
    pair  = "叶际pairwise_betaNTI_RCbray_process.csv",
    group = "叶际分组.csv",
    color = "#84B300"
  ),
  Endosphere = list(
    asv   = "根内F_ASV.csv",
    pair  = "根内pairwise_betaNTI_RCbray_process.csv",
    group = "根内分组.csv",
    color = "#F07167"
  ),
  Rhizosphere = list(
    asv   = "根际F_ASV.csv",
    pair  = "根际pairwise_betaNTI_RCbray_process.csv",
    group = "根际分组.csv",
    color = "#2DB7B5"
  )
)

# =========================================================
# 1. 工具函数
# =========================================================

# 读取 ASV：ASV ID 在第9列，样本从第10列开始
read_asv_comm <- function(asv_file) {
  asv <- read.csv(asv_file, check.names = FALSE)
  
  asv_id <- asv[[9]]
  otu <- asv[, 10:ncol(asv), drop = FALSE]
  rownames(otu) <- asv_id
  
  otu <- as.matrix(otu)
  mode(otu) <- "numeric"
  
  # 行=样本，列=ASV
  comm <- t(otu)
  comm <- comm[, colSums(comm) > 0, drop = FALSE]
  comm
}

# 距离矩阵转 pairwise 长表
dist_to_table <- function(dist_obj, value_name = "BrayCurtis") {
  mat <- as.matrix(dist_obj)
  s <- rownames(mat)
  idx <- which(upper.tri(mat), arr.ind = TRUE)
  
  out <- data.frame(
    Sample1 = s[idx[, 1]],
    Sample2 = s[idx[, 2]],
    value   = mat[idx],
    stringsAsFactors = FALSE
  )
  colnames(out)[3] <- value_name
  out
}

# 统一样本对顺序
normalize_pair_order <- function(df, s1 = "Sample1", s2 = "Sample2") {
  x1 <- df[[s1]]
  x2 <- df[[s2]]
  
  df[[s1]] <- ifelse(x1 <= x2, x1, x2)
  df[[s2]] <- ifelse(x1 <= x2, x2, x1)
  df
}

# 读取分组表
read_group_info <- function(group_file) {
  grp <- read.csv(group_file, check.names = FALSE)
  colnames(grp)[1:2] <- c("Sample", "Group")
  
  grp <- grp %>%
    mutate(
      Period = case_when(
        grepl("^JS_", Group) ~ "Jointing stage",
        grepl("^HS_", Group) ~ "Heading stage",
        grepl("^FS_", Group) ~ "Filling stage",
        grepl("^MS_", Group) ~ "Maturity stage",
        TRUE ~ NA_character_
      ),
      Drought = case_when(
        grepl("_Control$",   Group) ~ "Control",
        grepl("_Drought_L$", Group) ~ "Drought_L",
        grepl("_Drought_M$", Group) ~ "Drought_M",
        grepl("_Drought_H$", Group) ~ "Drought_H",
        TRUE ~ NA_character_
      )
    )
  
  grp$Period <- factor(
    grp$Period,
    levels = c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
  )
  grp$Drought <- factor(
    grp$Drought,
    levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
  )
  
  grp
}

# pairwise 长表转对称矩阵
pair_to_symmetric_matrix <- function(df, samples, value_col) {
  mat <- matrix(
    NA_real_,
    nrow = length(samples),
    ncol = length(samples),
    dimnames = list(samples, samples)
  )
  diag(mat) <- 0
  
  for (i in seq_len(nrow(df))) {
    s1 <- df$Sample1[i]
    s2 <- df$Sample2[i]
    val <- df[[value_col]][i]
    
    if (s1 %in% samples && s2 %in% samples) {
      mat[s1, s2] <- val
      mat[s2, s1] <- val
    }
  }
  
  mat
}

# 提取单个部位结果
process_one_habitat <- function(habitat_name, info) {
  cat("\n============================\n")
  cat("Processing:", habitat_name, "\n")
  cat("============================\n")
  
  # ---------- 读 ASV，算 Bray-Curtis ----------
  comm <- read_asv_comm(info$asv)
  
  bc_dist <- vegdist(comm, method = "bray")
  bc_df <- dist_to_table(bc_dist, value_name = "BrayCurtis")
  bc_df <- normalize_pair_order(bc_df, "Sample1", "Sample2")
  
  # ---------- 读 pairwise betaNTI 结果 ----------
  pair_df <- read.csv(info$pair, check.names = FALSE)
  pair_df <- normalize_pair_order(pair_df, "Sample1", "Sample2")
  
  # ---------- 合并 ----------
  merged <- left_join(pair_df, bc_df, by = c("Sample1", "Sample2"))
  
  # ---------- 读分组 ----------
  grp <- read_group_info(info$group)
  
  merged <- merged %>%
    left_join(
      grp %>% select(Sample, Group, Period, Drought),
      by = c("Sample1" = "Sample")
    ) %>%
    rename(
      Group_meta = Group,
      Period = Period,
      Drought = Drought
    ) %>%
    mutate(Habitat = habitat_name)
  
  # ---------- 仅保留组内比较 ----------
  merged_within <- merged %>%
    filter(CompareType == "WithinGroup") %>%
    filter(!is.na(BrayCurtis), !is.na(betaNTI), !is.na(Period), !is.na(Drought))
  
  cat("Total pairwise rows:", nrow(merged), "\n")
  cat("Within-group rows:", nrow(merged_within), "\n")
  
  # ---------- 线性模型：只用于R²和画趋势线 ----------
  fit <- lm(BrayCurtis ~ betaNTI, data = merged_within)
  fit_sum <- summary(fit)
  r2_val <- fit_sum$r.squared
  
  # ---------- Mantel test：P值 ----------
  # 使用组内比较中实际出现的样本
  # ---------- Mantel test：P值 ----------
  # Mantel 必须用完整矩阵，不能只用 WithinGroup 的残缺块矩阵
  samples_all <- sort(unique(c(pair_df$Sample1, pair_df$Sample2)))
  
  bc_mat_full <- pair_to_symmetric_matrix(
    df = bc_df,
    samples = samples_all,
    value_col = "BrayCurtis"
  )
  
  bnti_mat_full <- pair_to_symmetric_matrix(
    df = pair_df,
    samples = samples_all,
    value_col = "betaNTI"
  )
  
  # 只保留在两个矩阵中都完整存在的样本
  keep_samples <- samples_all[
    rowSums(is.na(bc_mat_full)) == 0 &
      rowSums(is.na(bnti_mat_full)) == 0
  ]
  
  bc_mat2 <- bc_mat_full[keep_samples, keep_samples, drop = FALSE]
  bnti_mat2 <- bnti_mat_full[keep_samples, keep_samples, drop = FALSE]
  
  mantel_res <- vegan::mantel(
    as.dist(bc_mat2),
    as.dist(bnti_mat2),
    method = "pearson",
    permutations = 999
  )
  
  stat_df <- data.frame(
    Habitat = habitat_name,
    R2 = r2_val,
    Mantel_r = unname(mantel_res$statistic),
    P = mantel_res$signif,
    N_samples = length(keep_samples),
    stringsAsFactors = FALSE
  )
  
  # ---------- 保存合并表 ----------
  write.csv(
    merged_within,
    paste0(habitat_name, "_pairwise_betaNTI_BrayCurtis_withingroup.csv"),
    row.names = FALSE
  )
  
  return(list(
    data = merged_within,
    stat = stat_df
  ))
}

# 绘图函数
make_scatter_plot <- function(df, habitat_name, point_color, stat_df) {
  x_pos <- quantile(df$betaNTI, 0.05, na.rm = TRUE)
  y_pos <- quantile(df$BrayCurtis, 0.95, na.rm = TRUE)
  
  p_txt <- if (is.na(stat_df$P)) {
    "NA"
  } else if (stat_df$P < 0.001) {
    "< 0.001"
  } else {
    sprintf("%.3f", stat_df$P)
  }
  
  lab_txt <- paste0(
    "R² = ", sprintf("%.3f", stat_df$R2),
    "\nMantel r = ", sprintf("%.3f", stat_df$Mantel_r),
    "\nP = ", p_txt
  )
  
  ggplot(df, aes(x = betaNTI, y = BrayCurtis)) +
    geom_point(
      color = point_color,
      size = 2,
      alpha = 0.35
    ) +
    geom_smooth(
      method = "lm",
      se = TRUE,
      color = point_color,
      linewidth = 1
    ) +
    annotate(
      "text",
      x = x_pos,
      y = y_pos,
      label = lab_txt,
      hjust = 0,
      vjust = 1,
      size = 4
    ) +
    theme_bw() +
    labs(
      title = habitat_name,
      x = expression(beta * "NTI"),
      y = "Bray-Curtis dissimilarity"
    ) +
    theme(
      panel.grid = element_blank(),
      plot.title = element_text(face = "bold", hjust = 0.5),
      axis.title = element_text(size = 12),
      axis.text = element_text(size = 10)
    )
}

# =========================================================
# 2. 依次处理三个部位
# =========================================================
res_list <- list()

for (nm in names(file_info)) {
  res_list[[nm]] <- process_one_habitat(nm, file_info[[nm]])
}

all_data <- bind_rows(lapply(res_list, function(x) x$data))
all_stat <- bind_rows(lapply(res_list, function(x) x$stat))

write.csv(
  all_data,
  "All_habitats_pairwise_betaNTI_BrayCurtis_withingroup.csv",
  row.names = FALSE
)

write.csv(
  all_stat,
  "All_habitats_betaNTI_BrayCurtis_stats_MantelP.csv",
  row.names = FALSE
)

# =========================================================
# 3. 分别作图
# =========================================================
plot_list <- list()

for (nm in names(file_info)) {
  plot_list[[nm]] <- make_scatter_plot(
    df = res_list[[nm]]$data,
    habitat_name = nm,
    point_color = file_info[[nm]]$color,
    stat_df = res_list[[nm]]$stat
  )
  
  ggsave(
    filename = paste0(nm, "_betaNTI_vs_BrayCurtis_scatter_MantelP.pdf"),
    plot = plot_list[[nm]],
    width = 5,
    height = 4
  )
  
  ggsave(
    filename = paste0(nm, "_betaNTI_vs_BrayCurtis_scatter_MantelP.png"),
    plot = plot_list[[nm]],
    width = 5,
    height = 4,
    dpi = 300
  )
  
  print(plot_list[[nm]])
}

# =========================================================
# 4. 拼成三联图
# =========================================================
p_combined <- plot_list$Phyllosphere + plot_list$Endosphere + plot_list$Rhizosphere +
  plot_layout(ncol = 3)

print(p_combined)

ggsave(
  filename = "Three_habitats_betaNTI_vs_BrayCurtis_scatter_combined_MantelP.pdf",
  plot = p_combined,
  width = 15,
  height = 4.5
)

ggsave(
  filename = "Three_habitats_betaNTI_vs_BrayCurtis_scatter_combined_MantelP.png",
  plot = p_combined,
  width = 15,
  height = 4.5,
  dpi = 300
)

cat("\n全部完成！\n")