############################################################
## ITS 群落构建：betaNTI + RCbray
## Stegen 原版理论 + 低内存流式实现
############################################################

## ===============================
## 0. 工作路径 & 参数
## ===============================
setwd("D:/IUE/山西数据/真菌/抽平/群落组装")

asv_file   <- "根际F_ASV.csv"
group_file <- "根际分组.csv"
tree_file  <- "phylo.tre"

nperm_bNTI <- 999
nperm_RC   <- 999
#nworker    <- max(1, parallel::detectCores() - 1)
nworker <- min(4, parallel::detectCores())

RNGkind("L'Ecuyer-CMRG")
set.seed(1)

## ===============================
## 1. 包
## ===============================
suppressPackageStartupMessages({
  library(data.table)
  library(ape)
  library(picante)
  library(vegan)
  library(parallel)
})

## ===============================
## 2. 数据读取
## ===============================
asv <- fread(asv_file, data.table = FALSE, check.names = FALSE)
grp <- fread(group_file, data.table = FALSE, check.names = FALSE)

asv_id <- asv[[9]]
otu <- asv[, 10:ncol(asv)]
rownames(otu) <- asv_id
otu <- as.matrix(otu)
mode(otu) <- "numeric"
comm <- t(otu)

colnames(grp)[1:2] <- c("SampleID","Group")
rownames(grp) <- grp$SampleID

common_samples <- intersect(rownames(comm), rownames(grp))
comm <- comm[common_samples, , drop = FALSE]
grp  <- grp[common_samples, , drop = FALSE]

comm <- comm[, colSums(comm) > 0, drop = FALSE]

## ===============================
## 3. 系统发育树
## ===============================
tree <- read.tree(tree_file)
if(is.null(tree$edge.length)) stop("phylo.tre 没有分支长度")

common_asv <- intersect(colnames(comm), tree$tip.label)
comm_bt <- comm[, common_asv, drop = FALSE]
tree <- keep.tip(tree, common_asv)

## ===============================
## 4. betaNTI（Stegen 原版，流式）
## ===============================
betaNTI_calc <- function(comm_mat, phy, nreps, nworker, seed){
  set.seed(seed)
  phydist <- cophenetic(phy)
  obs <- as.matrix(comdistnt(comm_mat, phydist, abundance.weighted = TRUE))
  
  n <- nrow(obs)
  mean_mat <- matrix(0, n, n)
  M2_mat   <- matrix(0, n, n)
  count <- 0L
  
  cl <- makeCluster(nworker)
  clusterSetRNGStream(cl, seed)
  on.exit(stopCluster(cl))
  clusterEvalQ(cl, library(picante))
  clusterExport(cl, c("comm_mat","phydist"), envir = environment())
  
  batch <- split(1:nreps, ceiling(seq_len(nreps)/10))
  
  for(b in batch){
    mats <- parLapply(cl, b, function(i){
      dist.rand <- phydist
      rn <- sample(colnames(dist.rand))
      colnames(dist.rand) <- rn
      rownames(dist.rand) <- rn
      as.matrix(comdistnt(comm_mat, dist.rand, abundance.weighted = TRUE))
    })
    
    for(m in mats){
      count <- count + 1L
      delta <- m - mean_mat
      mean_mat <- mean_mat + delta / count
      M2_mat <- M2_mat + delta * (m - mean_mat)
    }
    rm(mats); gc()
  }
  
  sd_mat <- sqrt(M2_mat / (count - 1))
  sd_mat[sd_mat == 0] <- NA_real_
  betaNTI <- (obs - mean_mat) / sd_mat
  diag(betaNTI) <- 0
  betaNTI
}

betaNTI_mat <- betaNTI_calc(comm_bt, tree, nperm_bNTI, nworker, 1)

## ===============================
## 5. RCbray（Stegen 原版，流式）
## ===============================
RCbray_calc <- function(comm_mat, nreps, nworker, seed){
  set.seed(seed)
  comm <- as.matrix(comm_mat)
  obs <- as.matrix(vegdist(comm, method = "bray"))
  
  n <- nrow(comm)
  prob.species <- colSums(comm > 0)
  prob.abund   <- colSums(comm)
  prob.abund   <- prob.abund / sum(prob.abund)
  
  species <- rowSums(comm > 0)
  samps   <- rowSums(comm)
  
  lt <- matrix(0L, n, n)
  eq <- matrix(0L, n, n)
  total <- 0L
  
  one_null <- function(){
    cr <- matrix(
      0,
      nrow = n,
      ncol = ncol(comm),
      dimnames = list(rownames(comm), colnames(comm))
    )
  
    for(j in 1:n){
      id <- sample(1:ncol(comm), species[j], replace = FALSE, prob = prob.species)
      cr[j,id] <- 1
      if(samps[j] > species[j]){
        cnt <- sample(id, samps[j]-species[j], replace = TRUE, prob = prob.abund[id])
        tb <- table(cnt)
        cr[j, as.numeric(names(tb))] <- cr[j, as.numeric(names(tb))] + as.vector(tb)
      }
    }
    cr
  }
  
  cl <- makeCluster(nworker)
  clusterSetRNGStream(cl, seed)
  on.exit(stopCluster(cl))
  clusterEvalQ(cl, library(vegan))
  clusterExport(cl, c("comm","prob.species","prob.abund","species","samps","one_null"),
                envir = environment())
  
  batch <- split(1:nreps, ceiling(seq_len(nreps)/5))
  
  for(b in batch){
    mats <- parLapply(cl, b, function(i){
      as.matrix(vegdist(one_null(), method = "bray"))
    })
    
    for(m in mats){
      total <- total + 1L
      lt <- lt + (m < obs)
      eq <- eq + (m == obs)
    }
    rm(mats); gc()
  }
  
  rc_p <- (lt + 0.5 * eq) / total
  rc <- (rc_p - 0.5) * 2
  diag(rc) <- 0
  rc
}

RCbray_mat <- RCbray_calc(comm, nperm_RC, nworker, 1)

## ===============================
## 6. 五过程划分（不变）
## ===============================
pair_table <- function(mat){
  s <- rownames(mat)
  idx <- which(upper.tri(mat), arr.ind = TRUE)
  data.frame(Sample1=s[idx[,1]], Sample2=s[idx[,2]], value=mat[idx])
}

df_bnti <- pair_table(betaNTI_mat); colnames(df_bnti)[3] <- "betaNTI"
df_rc   <- pair_table(RCbray_mat);  colnames(df_rc)[3]   <- "RCbray"
df <- merge(df_bnti, df_rc, by=c("Sample1","Sample2"))

df$Group1 <- grp[df$Sample1,"Group"]
df$Group2 <- grp[df$Sample2,"Group"]
df$CompareType <- ifelse(df$Group1==df$Group2,"WithinGroup","BetweenGroup")

df$Process <- "Drift_undominated"
df$Process[df$betaNTI >  2] <- "Variable_selection"
df$Process[df$betaNTI < -2] <- "Homogeneous_selection"

mid <- which(df$Process=="Drift_undominated")
df$Process[mid[df$RCbray[mid] >  0.95]] <- "Dispersal_limitation"
df$Process[mid[df$RCbray[mid] < -0.95]] <- "Homogenizing_dispersal"

## ===============================
#组内比例
df_within <- df[df$CompareType == "WithinGroup", ]
library(dplyr)

prop_within <- df_within %>%
  group_by(Group = Group1, Process) %>%
  summarise(Npairs = n(), .groups = "drop") %>%
  group_by(Group) %>%
  mutate(Proportion = Npairs / sum(Npairs))
write.csv(prop_within,
          "process_proportion_withingroup.csv",
          row.names = FALSE)

## 7. 输出
## ===============================
write.csv(betaNTI_mat,"betaNTI_matrix.csv")
write.csv(RCbray_mat,"RCbray_matrix.csv")
write.csv(df,"pairwise_betaNTI_RCbray_process.csv",row.names=FALSE)

prop_all <- as.data.frame(prop.table(table(df$Process)))
write.csv(prop_all,"process_proportion_allpairs.csv")

cat("DONE.\n")

## βNTI 小提琴图 + Dunn 检验 + BH 校正（最终版）
## 4 时期 × 4 干旱梯度（组内）
############################################################

## ===============================
## 0. 加载包
## 读取已计算好的 pairwise 表（关键）
## ===============================
setwd("D:/IUE/山西数据/真菌/抽平/群落组装")

library(dplyr)

df <- read.csv(
  "pairwise_betaNTI_RCbray_process.csv",
  stringsAsFactors = FALSE
)


library(dplyr)
library(ggplot2)
library(rstatix)
library(ggpubr)

## ===============================
## 1. 仅保留组内 pair，并拆分时期 & 干旱梯度
## ===============================
df_within <- df %>%
  filter(CompareType == "WithinGroup") %>%
  mutate(
    Period = case_when(
      grepl("^JS_", Group1) ~ "Jointing stage",
      grepl("^HS_", Group1) ~ "Heading stage",
      grepl("^FS_", Group1) ~ "Filling stage",
      grepl("^MS_", Group1) ~ "Maturity stage"
    ),
    Drought = case_when(
      grepl("_Control$",   Group1) ~ "Control",
      grepl("_Drought_L$", Group1) ~ "Drought_L",
      grepl("_Drought_M$", Group1) ~ "Drought_M",
      grepl("_Drought_H$", Group1) ~ "Drought_H"
    )
  ) %>%
  filter(!is.na(Period), !is.na(Drought))

## ===============================
## 2. 固定因子顺序（非常重要）
## ===============================
df_within$Period <- factor(
  df_within$Period,
  levels = c(
    "Jointing stage",
    "Heading stage",
    "Filling stage",
    "Maturity stage"
  )
)

df_within$Drought <- factor(
  df_within$Drought,
  levels = c("Control", "Drought_L", "Drought_M", "Drought_H")
)

## ===============================
## 3. 每个时期内做 Dunn 检验 + BH 校正
## ===============================
pairwise_results <- df_within %>%
  group_by(Period) %>%
  dunn_test(
    betaNTI ~ Drought,
    p.adjust.method = "BH"
  )

## 只保留显著结果，并在“每个时期内”生成 y.position
stat_plot <- pairwise_results %>%
  filter(p.adj < 0.05) %>%
  group_by(Period) %>%
  mutate(
    y.position =
      max(df_within$betaNTI[df_within$Period == unique(Period)],
          na.rm = TRUE) +
      seq(0.3, by = 0.3, length.out = n())
  ) %>%
  ungroup()

## ===============================
## 4. βNTI 小提琴图（四时期 × 四干旱梯度）
## ===============================
p_bnti <- ggplot(
  df_within,
  aes(x = Drought, y = betaNTI, fill = Drought)
) +
  geom_violin(
    color = "black",
    width = 0.9,
    trim = TRUE
  ) +
  geom_hline(
    yintercept = c(-2, 2),
    linetype = "dashed",
    color = "red"
  ) +
  facet_grid(
    . ~ Period,
    scales = "free_x",
    space  = "free_x"
  ) +
  scale_fill_manual(
    values = c(
      "Control"    = "#F8766D",
      "Drought_L"  = "#7CAE00",
      "Drought_M"  = "#00BFC4",
      "Drought_H"  = "#C77CFF"
    )
  ) +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.spacing.x = unit(1, "lines"),
    strip.background = element_rect(fill = "grey90"),
    strip.text = element_text(face = "bold"),
    plot.title = element_text(hjust = 0.5),
    legend.position = "bottom"
  ) +
  labs(
    x = "Drought gradient",
    y = expression(beta * NTI),
    fill = "Drought treatment",
    title = expression("Within-group " * beta * "NTI distribution")
  )

## ===============================
## 5. 加显著性标注（如果存在）
## ===============================
if (nrow(stat_plot) > 0) {
  p_bnti <- p_bnti +
    stat_pvalue_manual(
      stat_plot,
      label = "p.adj.signif",
      xmin = "group1",
      xmax = "group2",
      y.position = "y.position",
      tip.length = 0.01,
      hide.ns = TRUE
    )
}

## ===============================
## 6. 输出 PDF + RStudio 显示
## ===============================
ggsave(
  "betaNTI_violin_4stages_4droughts_with_significance.pdf",
  p_bnti,
  width = 16,
  height = 6
)

print(p_bnti)
#堆积柱状图
## ===============================
## 7.1 计算组内五过程比例
## ===============================
prop_process <- df_within %>%
  group_by(Period, Drought, Process) %>%
  summarise(Npairs = n(), .groups = "drop") %>%
  group_by(Period, Drought) %>%
  mutate(Proportion = Npairs / sum(Npairs)) %>%
  ungroup()

## 固定 Process 顺序（非常重要，保证颜色与逻辑一致）
prop_process$Process <- factor(
  prop_process$Process,
  levels = c(
    "Homogeneous_selection",
    "Variable_selection",
    "Dispersal_limitation",
    "Homogenizing_dispersal",
    "Drift_undominated"
  )
)
#绘图
p_process <- ggplot(
  prop_process,
  aes(x = Drought, y = Proportion, fill = Process)
) +
  geom_bar(
    stat = "identity",
    width = 0.8,
    color = "black"
  ) +
  facet_grid(
    . ~ Period,
    scales = "free_x",
    space  = "free_x"
  ) +
  scale_fill_manual(
    values = c(
      "Homogeneous_selection"  = "#4DBBD5",
      "Variable_selection"     = "#00A087",
      "Dispersal_limitation"   = "#3c5488",
      "Homogenizing_dispersal" = "#9E9E9E",
      "Drift_undominated"      = "#E64B35"
    )
  ) +
   theme_bw() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.spacing.x = unit(1, "lines"),
    strip.background = element_rect(fill = "grey90"),
    strip.text = element_text(face = "bold"),
    plot.title = element_text(hjust = 0.5),
    legend.position = "right"
  ) +
  labs(
    x = "Drought gradient",
    y = "Proportion of community assembly processes",
    fill = "Ecological process",
    title = "Relative importance of community assembly processes (Within-group)"
  )
#输出
ggsave(
  "process_stacked_bar_4stages_4droughts.pdf",
  p_process,
  width = 16,
  height = 6
)

print(p_process)


