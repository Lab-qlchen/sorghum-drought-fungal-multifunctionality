#==============================
# SMF 主线 + LMM差异分析 + Shannon关系 + 多阈值法（最终完整版本）
#==============================
library(tidyverse)
library(rstatix)
library(ggpubr)
library(lme4)
library(lmerTest)
library(emmeans)
library(multcomp)
library(multcompView)
library(performance)
library(car)
library(broom)

setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/表型理化")

#=====================================================
# 1. 读取数据
#=====================================================
ind <- read.csv("EMF测试数据.csv", check.names = FALSE)
grp <- read.csv("根际分组.csv", check.names = FALSE)
colnames(grp)[1:2] <- c("Sample", "Group")

if (!"Sample" %in% colnames(ind)) {
  stop("EMF测试数据.csv 缺少 Sample 列。")
}
if (!"Sample" %in% colnames(grp) || !"Group" %in% colnames(grp)) {
  stop("根际分组.csv 缺少 Sample 或 Group 列。")
}
if (!"Block" %in% colnames(ind)) {
  stop("EMF测试数据.csv 中未找到 Block 列，请把代码中的 Block 改成你的真实区组列名。")
}

dat <- ind %>%
  left_join(grp, by = "Sample")

#=====================================================
# 2. 识别功能指标列（只保留数值列）
#=====================================================
func_cols <- ind %>%
  select(-any_of(c("Sample", "Block"))) %>%
  select(where(is.numeric)) %>%
  colnames()

if (length(func_cols) == 0) {
  stop("没有识别到可用于计算 SMF 的数值型功能指标列，请检查 EMF测试数据.csv。")
}

#=====================================================
# 3. 提取 Period / Drought / Variety
#=====================================================
period_levels  <- c("Jointing stage", "Heading stage", "Filling stage", "Maturity stage")
drought_levels <- c("Control", "Drought_L", "Drought_M", "Drought_H")
variety_levels <- c("Variety_1", "Variety_2")

dat <- dat %>%
  mutate(
    Period = case_when(
      str_detect(Group, "^JS_") ~ "Jointing stage",
      str_detect(Group, "^HS_") ~ "Heading stage",
      str_detect(Group, "^FS_") ~ "Filling stage",
      str_detect(Group, "^MS_") ~ "Maturity stage",
      TRUE ~ NA_character_
    ),
    Drought = case_when(
      str_detect(Group, "_Control$")   ~ "Control",
      str_detect(Group, "_Drought_L$") ~ "Drought_L",
      str_detect(Group, "_Drought_M$") ~ "Drought_M",
      str_detect(Group, "_Drought_H$") ~ "Drought_H",
      TRUE ~ NA_character_
    ),
    Variety = case_when(
      str_detect(Sample, "^Z") ~ "Variety_1",
      str_detect(Sample, "^N") ~ "Variety_2",
      TRUE ~ NA_character_
    )
  )

dat$Drought <- factor(dat$Drought, levels = drought_levels)
dat$Period  <- factor(dat$Period,  levels = period_levels)
dat$Variety <- factor(dat$Variety, levels = variety_levels)
dat$Block   <- factor(dat$Block)

#=====================================================
# 4. Mean-based SMF
#=====================================================
Z <- scale(dat[, func_cols])
dat$SMF_meanZ <- rowMeans(Z, na.rm = TRUE)

range01 <- function(x){
  rng <- range(x, na.rm = TRUE)
  if (rng[1] == rng[2]) return(rep(0, length(x)))
  (x - rng[1]) / (rng[2] - rng[1])
}
dat$SMF_meanZ_01 <- range01(dat$SMF_meanZ)

SMF_MeanZ_results <- dat %>%
  select(Sample, Period, Drought, Variety, Block, SMF_meanZ, SMF_meanZ_01)

write.csv(
  SMF_MeanZ_results,
  "测试数据SMF_MeanZ_results.csv",
  row.names = FALSE
)

#=====================================================
# 5. 多阈值法（按原来一样保留）
#=====================================================
func_01 <- apply(dat[, func_cols], 2, function(x){
  rng <- range(x, na.rm = TRUE)
  if (rng[1] == rng[2]) {
    rep(0, length(x))
  } else {
    (x - rng[1]) / (rng[2] - rng[1])
  }
})
func_01 <- as.data.frame(func_01)

thresholds <- c(0.2, 0.4, 0.6, 0.8)

for(th in thresholds){
  dat[[paste0("SMF_T", th * 100)]] <- rowSums(func_01 >= th, na.rm = TRUE)
}

thresh_cols <- paste0("SMF_T", thresholds * 100)

SMF_Threshold_results <- dat %>%
  select(Sample, Period, Drought, all_of(thresh_cols))

write.csv(
  SMF_Threshold_results,
  "测试数据SMF_Threshold_results.csv",
  row.names = FALSE
)

#=====================================================
# 6. 方法一致性：mean-based vs threshold-based
#=====================================================
SMF_Method_consistency <- purrr::map_dfr(thresh_cols, function(tc){
  
  ct <- cor.test(
    dat$SMF_meanZ,
    dat[[tc]],
    method = "spearman",
    exact = FALSE
  )
  
  tibble(
    Threshold = as.numeric(gsub("SMF_T", "", tc)),
    Spearman_rho = unname(ct$estimate),
    P_value = ct$p.value
  )
})

write.csv(
  SMF_Method_consistency,
  "测试数据SMF_Method_consistency_rho_P.csv",
  row.names = FALSE
)

p_consistency <- ggplot(
  SMF_Method_consistency,
  aes(x = Threshold, y = Spearman_rho)
) +
  geom_point(size = 3) +
  geom_line(group = 1) +
  theme_bw() +
  scale_x_continuous(breaks = thresholds * 100) +
  labs(
    x = "Threshold (%)",
    y = expression("Spearman correlation (" * rho * ")"),
    title = "Consistency between mean-based and threshold-based SMF"
  )

ggsave(
  "测试数据SMF_Method_consistency_plot.pdf",
  p_consistency,
  width = 6,
  height = 4
)
print(p_consistency)

#=====================================================
# 7. SMF差异分析：LMM（唯一正式差异分析）
#=====================================================
dat2 <- dat %>%
  filter(
    !is.na(Drought),
    !is.na(Period),
    !is.na(Variety),
    !is.na(Block),
    !is.na(SMF_meanZ)
  ) %>%
  mutate(
    Period  = factor(str_trim(as.character(Period)), levels = period_levels),
    Drought = factor(str_trim(as.character(Drought)), levels = drought_levels),
    Variety = factor(Variety, levels = variety_levels),
    Block   = factor(Block)
  )

if (nrow(dat2) == 0) {
  stop("过滤后没有可用于 LMM 分析的数据，请检查 SMF、Period、Drought、Variety、Block 是否存在缺失。")
}

fit_lmm <- lmer(
  SMF_meanZ ~ Drought * Period + Variety + (1 | Block),
  data = dat2
)

sink("测试数据_SMF_LMM_summary_control_variety.txt")
print(summary(fit_lmm))
sink()

lmm_anova <- anova(fit_lmm, ddf = "Satterthwaite")
lmm_anova_df <- as.data.frame(lmm_anova)
lmm_anova_df$Effect <- rownames(lmm_anova_df)
rownames(lmm_anova_df) <- NULL

lmm_anova_df <- lmm_anova_df %>%
  mutate(
    partial_eta2 = (`F value` * NumDF) / ((`F value` * NumDF) + DenDF),
    p_label = case_when(
      is.na(`Pr(>F)`)  ~ "",
      `Pr(>F)` < 0.001 ~ "<0.001",
      TRUE             ~ formatC(`Pr(>F)`, format = "f", digits = 3)
    )
  )

write.csv(
  lmm_anova_df,
  "测试数据_SMF_LMM_ANOVA_with_eta2_control_variety.csv",
  row.names = FALSE
)

r2_res <- performance::r2_nakagawa(fit_lmm)
R2_marginal    <- unname(r2_res$R2_marginal)
R2_conditional <- unname(r2_res$R2_conditional)

icc_res <- performance::icc(fit_lmm)
ICC_adj <- unname(icc_res$ICC_adjusted)

vc <- as.data.frame(VarCorr(fit_lmm))
block_var <- vc$vcov[vc$grp == "Block"]
resid_var <- vc$vcov[vc$grp == "Residual"]

var_df <- data.frame(
  metric = c(
    "Block_variance",
    "Residual_variance",
    "ICC_adjusted",
    "R2_marginal",
    "R2_conditional"
  ),
  value = c(block_var, resid_var, ICC_adj, R2_marginal, R2_conditional)
)

write.csv(
  var_df,
  "测试数据_SMF_LMM_variance_R2_ICC_control_variety.csv",
  row.names = FALSE
)

fixed_df <- as.data.frame(summary(fit_lmm)$coefficients)
fixed_df$term <- rownames(fixed_df)
rownames(fixed_df) <- NULL
write.csv(
  fixed_df,
  "测试数据_SMF_LMM_fixed_effects_coefficients_control_variety.csv",
  row.names = FALSE
)

ranef_df <- as.data.frame(ranef(fit_lmm)$Block)
ranef_df$Block <- rownames(ranef(fit_lmm)$Block)
rownames(ranef_df) <- NULL
write.csv(
  ranef_df,
  "测试数据_SMF_LMM_random_effects_control_variety.csv",
  row.names = FALSE
)

emm_D_in_P <- emmeans(fit_lmm, ~ Drought | Period)
emm_df <- as.data.frame(emm_D_in_P)

pair_df <- as.data.frame(
  pairs(emm_D_in_P, adjust = "BH")
)

cld_df <- multcomp::cld(
  emm_D_in_P,
  adjust = "BH",
  Letters = letters
) %>%
  as.data.frame() %>%
  select(Period, Drought, .group) %>%
  mutate(
    .group = stringr::str_trim(.group),
    Period = factor(Period, levels = period_levels),
    Drought = factor(Drought, levels = drought_levels)
  )

write.csv(emm_df,  "测试数据_SMF_LMM_emmeans_control_variety.csv", row.names = FALSE)
write.csv(pair_df, "测试数据_SMF_LMM_pairwise_BH_control_variety.csv", row.names = FALSE)
write.csv(cld_df,  "测试数据_SMF_LMM_letters_control_variety.csv", row.names = FALSE)

sink("测试数据_SMF_LMM_diagnostics_control_variety.txt")
cat("Shapiro-Wilk test of residuals:\n")
print(shapiro.test(residuals(fit_lmm)))
cat("\n")
cat("Model summary:\n")
print(summary(fit_lmm))
sink()

pdf("测试数据_SMF_LMM_diagnostic_plots_control_variety.pdf", width = 8, height = 8)
par(mfrow = c(2, 2))
plot(fit_lmm)
par(mfrow = c(1, 1))
dev.off()

plot_df <- left_join(
  emm_df,
  cld_df,
  by = c("Period", "Drought")
) %>%
  mutate(
    Period  = factor(Period,  levels = period_levels),
    Drought = factor(Drought, levels = drought_levels)
  )

get_effect_row <- function(df, effect_name) {
  df %>% filter(Effect == effect_name)
}

variety_row <- get_effect_row(lmm_anova_df, "Variety")
drought_row <- get_effect_row(lmm_anova_df, "Drought")
period_row  <- get_effect_row(lmm_anova_df, "Period")
inter_row   <- get_effect_row(lmm_anova_df, "Drought:Period")

label_text <- paste0(
  "Variety: F = ", round(variety_row$`F value`, 2),
  ", p = ", variety_row$p_label,
  ", eta_p2 = ", round(variety_row$partial_eta2, 3), "\n",
  "Drought: F = ", round(drought_row$`F value`, 2),
  ", p = ", drought_row$p_label,
  ", eta_p2 = ", round(drought_row$partial_eta2, 3), "\n",
  "Period: F = ", round(period_row$`F value`, 2),
  ", p = ", period_row$p_label,
  ", eta_p2 = ", round(period_row$partial_eta2, 3), "\n",
  "Drought × Period: F = ", round(inter_row$`F value`, 2),
  ", p = ", inter_row$p_label,
  ", eta_p2 = ", round(inter_row$partial_eta2, 3), "\n",
  "R2m = ", round(R2_marginal, 3),
  ", R2c = ", round(R2_conditional, 3),
  ", ICC = ", round(ICC_adj, 3), "\n",
  "Var(Block) = ", round(block_var, 3),
  ", Var(Residual) = ", round(resid_var, 3)
)

y_max <- max(plot_df$upper.CL, na.rm = TRUE)
y_min <- min(plot_df$lower.CL, na.rm = TRUE)
y_range <- y_max - y_min

p_lmm_bar_FP <- ggplot(plot_df, aes(x = Drought, y = emmean, fill = Drought)) +
  geom_col(width = 0.75) +
  geom_errorbar(
    aes(ymin = lower.CL, ymax = upper.CL),
    width = 0.2
  ) +
  geom_text(
    aes(y = upper.CL + 0.04 * y_range, label = .group),
    size = 4,
    vjust = 0
  ) +
  facet_wrap(~Period, nrow = 1, scales = "free_y", drop = FALSE) +
  theme_bw() +
  labs(
    x = "Drought treatment",
    y = "Soil multifunctionality (Mean Z)",
    title = "Effects of drought, period and their interaction on SMF (LMM, controlling for Variety)"
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  ) +
  geom_text(
    data = data.frame(
      Period = factor("Maturity stage", levels = period_levels),
      x = Inf,
      y = Inf,
      label = label_text
    ),
    aes(x = x, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 1.05,
    vjust = 1.1,
    size = 3.5
  ) +
  coord_cartesian(
    ylim = c(y_min, y_max + 0.18 * y_range),
    clip = "off"
  )

print(p_lmm_bar_FP)

ggsave(
  "测试数据_SMF_LMM_barplot_with_FP_control_variety.pdf",
  p_lmm_bar_FP,
  width = 12,
  height = 4
)

#=====================================================
# 8. 真菌 Shannon × Mean-based SMF（整体普通 LM）
#=====================================================
#=====================================================
# 8. 真菌 Shannon × Mean-based SMF（整体普通 LM）
#    只显示 P 和 R²
#=====================================================
fungi <- read.csv("测试数据真菌shannon多阈值法.csv", check.names = FALSE)

if (!"Sample" %in% colnames(fungi)) {
  stop("测试数据真菌shannon多阈值法.csv 缺少 Sample 列。")
}
if (!"Fungi_Shannon" %in% colnames(fungi)) {
  stop("测试数据真菌shannon多阈值法.csv 中未找到 Fungi_Shannon 列，请把代码中的列名改成你的真实列名。")
}

dat_fungi <- dat %>%
  left_join(fungi, by = "Sample") %>%
  filter(
    !is.na(Fungi_Shannon),
    !is.na(SMF_meanZ)
  ) %>%
  mutate(
    Period  = factor(Period, levels = period_levels),
    Drought = factor(Drought, levels = drought_levels),
    Variety = factor(Variety, levels = variety_levels),
    Block   = factor(Block)
  )

if (nrow(dat_fungi) == 0) {
  stop("合并真菌 Shannon 后没有可用于分析的数据，请检查 Sample 是否一致，以及 Shannon 列名是否为 Fungi_Shannon。")
}

fit_fungi_mean_lm <- lm(
  SMF_meanZ ~ Fungi_Shannon,
  data = dat_fungi
)

sum_fit <- summary(fit_fungi_mean_lm)
R2 <- sum_fit$r.squared
P  <- coef(sum_fit)["Fungi_Shannon", "Pr(>|t|)"]

p_fungi_mean_lm <- ggplot(
  dat_fungi,
  aes(x = Fungi_Shannon, y = SMF_meanZ)
) +
  geom_point(
    size = 3.5,
    color = "#2485bc",
    alpha = 0.7
  ) +
  geom_smooth(
    method = "lm",
    formula = y ~ x,
    se = TRUE,
    color = "#1b4f72",
    fill  = "#b0c4de",
    linewidth = 1
  ) +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    axis.title = element_text(size = 12),
    axis.text  = element_text(size = 10),
    plot.title = element_text(size = 13, face = "bold")
  ) +
  labs(
    x = "Fungal Shannon diversity",
    y = "Soil multifunctionality (Mean Z)",
    title = "Fungal community"
  ) +
  annotate(
    "text",
    x = min(dat_fungi$Fungi_Shannon, na.rm = TRUE),
    y = max(dat_fungi$SMF_meanZ, na.rm = TRUE),
    hjust = 0,
    vjust = 1,
    size = 4,
    label = paste0(
      "R² = ", round(R2, 2), "\n",
      "P = ", signif(P, 3)
    )
  )

ggsave(
  "Fig_fungi_MeanZ_vs_Shannon_LM.pdf",
  p_fungi_mean_lm,
  width = 4.8,
  height = 4.2
)

print(p_fungi_mean_lm)
#=====================================================
# 9. 分时期：Shannon × Mean-based SMF（普通 LM）
#=====================================================
dat_fungi_period <- dat_fungi %>%
  filter(!is.na(Period)) %>%
  mutate(
    Period = factor(Period, levels = period_levels)
  )

lm_stats_period <- purrr::map_dfr(period_levels, function(pd){
  
  df_pd <- dat_fungi_period %>%
    filter(Period == pd)
  
  if (nrow(df_pd) < 4) {
    return(tibble(
      Period = pd,
      n = nrow(df_pd),
      slope = NA_real_,
      intercept = NA_real_,
      R2 = NA_real_,
      P = NA_real_
    ))
  }
  
  fit_pd <- lm(SMF_meanZ ~ Fungi_Shannon, data = df_pd)
  s <- summary(fit_pd)
  cf <- coef(fit_pd)
  
  tibble(
    Period = pd,
    n = nrow(df_pd),
    slope = cf["Fungi_Shannon"],
    intercept = cf["(Intercept)"],
    R2 = s$r.squared,
    P = s$coefficients["Fungi_Shannon", "Pr(>|t|)"]
  )
}) %>%
  ungroup() %>%
  mutate(
    Period = factor(Period, levels = period_levels),
    label = paste0(
      "R² = ", round(R2, 2), "\n",
      "P = ", signif(P, 3)
    )
  )

write.csv(
  lm_stats_period,
  "Fig_fungi_MeanZ_vs_Shannon_by_period_stats.csv",
  row.names = FALSE
)

anno_period <- dat_fungi_period %>%
  group_by(Period) %>%
  summarise(
    x = min(Fungi_Shannon, na.rm = TRUE),
    y = max(SMF_meanZ, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(lm_stats_period, by = "Period") %>%
  mutate(
    Period = factor(Period, levels = period_levels)
  )

p_fungi_mean_by_period <- ggplot(
  dat_fungi_period,
  aes(x = Fungi_Shannon, y = SMF_meanZ)
) +
  geom_point(
    size = 3,
    color = "#2485bc",
    alpha = 0.75
  ) +
  geom_smooth(
    method = "lm",
    formula = y ~ x,
    se = TRUE,
    color = "#1b4f72",
    fill  = "#b0c4de",
    linewidth = 0.9
  ) +
  facet_wrap(~Period, nrow = 1, scales = "free") +
  geom_text(
    data = anno_period,
    aes(x = x, y = y, label = label),
    inherit.aes = FALSE,
    hjust = 0,
    vjust = 1,
    size = 3.8
  ) +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    strip.text = element_text(size = 11, face = "bold"),
    plot.title = element_text(size = 13, face = "bold")
  ) +
  labs(
    x = "Fungal Shannon diversity",
    y = "Soil multifunctionality (Mean Z)",
    title = "Relationship between fungal diversity and SMF across growth periods"
  )

ggsave(
  "Fig_fungi_MeanZ_vs_Shannon_by_period.pdf",
  p_fungi_mean_by_period,
  width = 12,
  height = 4
)

print(p_fungi_mean_by_period)

#=====================================================
# 10. 多阈值法分析真菌多样性与 SMF 的关系（普通 LM）
#=====================================================

#------------------------------
# 10.1 功能指标 0–1 标准化
#------------------------------
func_01_fungi <- apply(dat_fungi[, func_cols], 2, function(x){
  rng <- range(x, na.rm = TRUE)
  if (rng[1] == rng[2]) {
    rep(0, length(x))
  } else {
    (x - rng[1]) / (rng[2] - rng[1])
  }
})
func_01_fungi <- as.data.frame(func_01_fungi)

#------------------------------
# 10.2 构建 1–99% 阈值 SMF
#------------------------------
thresholds_full <- seq(0.01, 0.99, by = 0.01)

SMF_long_fungi <- purrr::map_dfr(thresholds_full, function(th){
  
  tibble(
    Sample = dat_fungi$Sample,
    Fungi_Shannon = dat_fungi$Fungi_Shannon,
    Threshold = th * 100,
    SMF = rowSums(func_01_fungi >= th, na.rm = TRUE)
  )
})

#------------------------------
# 10.3 每个阈值一条回归线
#------------------------------
p_fungi_threshold_lines <- ggplot(
  SMF_long_fungi,
  aes(
    x = Fungi_Shannon,
    y = SMF,
    group = Threshold,
    color = Threshold
  )
) +
  geom_smooth(
    method = "lm",
    formula = y ~ x,
    se = FALSE,
    linewidth = 0.4,
    alpha = 0.7
  ) +
  scale_color_gradient(
    low = "blue",
    high = "red",
    name = "Percent of\nMaximum"
  ) +
  theme_bw() +
  labs(
    x = "Shannon diversity",
    y = expression("Number of functions " >= " threshold"),
    title = "Percent of maximum (fungi)"
  ) +
  theme(
    legend.position = "top"
  )

ggsave(
  "Fig_fungi_threshold_lines_all_thresholds.pdf",
  p_fungi_threshold_lines,
  width = 5,
  height = 4
)

print(p_fungi_threshold_lines)

#------------------------------
# 10.4 提取每个阈值下 Shannon -> SMF 的回归系数
#------------------------------
beta_fungi <- SMF_long_fungi %>%
  group_by(Threshold) %>%
  do({
    fit <- lm(SMF ~ Fungi_Shannon, data = .)
    s   <- summary(fit)
    tibble(
      estimate  = s$coefficients["Fungi_Shannon", "Estimate"],
      std.error = s$coefficients["Fungi_Shannon", "Std. Error"],
      p.value   = s$coefficients["Fungi_Shannon", "Pr(>|t|)"]
    )
  }) %>%
  ungroup()

write.csv(
  beta_fungi,
  "Fig_fungi_threshold_effect_stats.csv",
  row.names = FALSE
)

#------------------------------
# 10.5 阈值依赖效应图
# 注意：阴影为 estimate ± SE
#------------------------------
p_fungi_threshold_effect <- ggplot(
  beta_fungi,
  aes(x = Threshold, y = estimate)
) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey40",
    linewidth = 0.6
  ) +
  geom_ribbon(
    aes(
      ymin = estimate - std.error,
      ymax = estimate + std.error
    ),
    fill = "#B0C4DE",
    alpha = 0.6
  ) +
  geom_line(
    color = "#1B4F72",
    linewidth = 1.2
  ) +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    axis.title = element_text(size = 12),
    axis.text  = element_text(size = 10),
    plot.title = element_text(size = 13, face = "bold")
  ) +
  labs(
    x = "Threshold (%)",
    y = "Change in number of functions\nper unit increase in Shannon diversity",
    title = "Threshold-dependent effect of fungal diversity"
  )

ggsave(
  "Fig_fungi_threshold_effect.pdf",
  p_fungi_threshold_effect,
  width = 5,
  height = 4
)

print(p_fungi_threshold_effect)

#=====================================================
# 11. 分时期：多阈值 SMF × Shannon（普通 LM）
#=====================================================
func_01_period <- apply(dat_fungi_period[, func_cols], 2, function(x){
  rng <- range(x, na.rm = TRUE)
  if (rng[1] == rng[2]) {
    rep(0, length(x))
  } else {
    (x - rng[1]) / (rng[2] - rng[1])
  }
})
func_01_period <- as.data.frame(func_01_period)

SMF_long_fungi_period <- purrr::map_dfr(thresholds_full, function(th){
  tibble(
    Sample = dat_fungi_period$Sample,
    Period = dat_fungi_period$Period,
    Fungi_Shannon = dat_fungi_period$Fungi_Shannon,
    Threshold = th * 100,
    SMF = rowSums(func_01_period >= th, na.rm = TRUE)
  )
})

beta_fungi_period <- SMF_long_fungi_period %>%
  group_by(Period, Threshold) %>%
  do({
    fit <- lm(SMF ~ Fungi_Shannon, data = .)
    s <- summary(fit)
    tibble(
      estimate  = s$coefficients["Fungi_Shannon", "Estimate"],
      std.error = s$coefficients["Fungi_Shannon", "Std. Error"],
      p.value   = s$coefficients["Fungi_Shannon", "Pr(>|t|)"],
      R2        = s$r.squared
    )
  }) %>%
  ungroup() %>%
  mutate(
    Period = factor(Period, levels = period_levels)
  )

write.csv(
  beta_fungi_period,
  "Fig_fungi_threshold_effect_by_period_stats.csv",
  row.names = FALSE
)

p_fungi_threshold_effect_by_period <- ggplot(
  beta_fungi_period,
  aes(x = Threshold, y = estimate)
) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey40",
    linewidth = 0.6
  ) +
  geom_ribbon(
    aes(
      ymin = estimate - std.error,
      ymax = estimate + std.error
    ),
    fill = "#B0C4DE",
    alpha = 0.6
  ) +
  geom_line(
    color = "#1B4F72",
    linewidth = 1
  ) +
  facet_wrap(~Period, nrow = 1, scales = "free_y") +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    strip.text = element_text(size = 11, face = "bold"),
    plot.title = element_text(size = 13, face = "bold")
  ) +
  labs(
    x = "Threshold (%)",
    y = "Slope of Shannon diversity effect on SMF",
    title = "Threshold-dependent effect of fungal diversity across growth periods"
  )

ggsave(
  "Fig_fungi_threshold_effect_by_period.pdf",
  p_fungi_threshold_effect_by_period,
  width = 12,
  height = 4
)

print(p_fungi_threshold_effect_by_period)

beta_sig_period <- beta_fungi_period %>%
  filter(p.value < 0.05)

p_fungi_threshold_effect_by_period_sig <- ggplot(
  beta_fungi_period,
  aes(x = Threshold, y = estimate)
) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey40",
    linewidth = 0.6
  ) +
  geom_ribbon(
    aes(
      ymin = estimate - std.error,
      ymax = estimate + std.error
    ),
    fill = "#B0C4DE",
    alpha = 0.6
  ) +
  geom_line(
    color = "#1B4F72",
    linewidth = 1
  ) +
  geom_point(
    data = beta_sig_period,
    size = 1.6,
    color = "red"
  ) +
  facet_wrap(~Period, nrow = 1, scales = "free_y") +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    strip.text = element_text(size = 11, face = "bold"),
    plot.title = element_text(size = 13, face = "bold")
  ) +
  labs(
    x = "Threshold (%)",
    y = "Slope of Shannon diversity effect on SMF",
    title = "Significant threshold-dependent effects of fungal diversity across periods"
  )

ggsave(
  "Fig_fungi_threshold_effect_by_period_sig.pdf",
  p_fungi_threshold_effect_by_period_sig,
  width = 12,
  height = 4
)

print(p_fungi_threshold_effect_by_period_sig)