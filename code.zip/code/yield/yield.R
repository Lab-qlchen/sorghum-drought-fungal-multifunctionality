## ================= 环境 & 工作目录 =================
rm(list = ls()); options(stringsAsFactors = FALSE)
library(tidyverse); library(car); library(emmeans); library(multcomp)
setwd("D:/IUE/山西数据/真菌/抽平/测试数据文件/产量和生物量")

## ================= 读入产量数据 =================
dat_y <- read.csv("Yield.csv", fileEncoding = "GBK", check.names = FALSE)

dat_y$Genotype <- factor(dat_y$Genotype,
                         levels = c("Jinza","Liangnuo"),
                         labels = c("Jinza 22","Liangnuo 01"))
dat_y$Treatment <- factor(dat_y$Treatment,
                          levels = c("Control","Drought_L","Drought_M","Drought_H"))

## 产量变量（列名含特殊符号）
dat_y$Yield <- dat_y[[3]]   # 用列号，最稳妥

## ================= 双因素 ANOVA =================
m_y <- aov(Yield ~ Genotype * Treatment, data = dat_y)
anova_y <- as.data.frame(car::Anova(m_y, type = 2))
write.csv(anova_y, "ANOVA_Twoway_Yield.csv")

## 提取 F / P
fmt_p <- function(p) ifelse(p < 0.001, "< 0.001", paste0("= ", sprintf("%.3f", p)))
lab_y <- with(anova_y,
              paste0("Genotype: F = ", round(`F value`[1],2), ", P ", fmt_p(`Pr(>F)`[1]), "\n",
                     "Treatment: F = ", round(`F value`[2],2), ", P ", fmt_p(`Pr(>F)`[2]), "\n",
                     "Genotype × Treatment: F = ", round(`F value`[3],2), ", P ", fmt_p(`Pr(>F)`[3])))

## ================= 均值 ± SEM =================
sum_dat <- dat_y %>%
  group_by(Genotype, Treatment) %>%
  summarise(mean = mean(Yield),
            sem  = sd(Yield)/sqrt(n()),
            .groups="drop")
write.csv(sum_dat, "Yield_Mean_SEM.csv", row.names = FALSE)

## ================= 显著性字母（基因型内） =================
cld_dat <- multcomp::cld(
  emmeans(m_y, ~ Treatment | Genotype),
  Letters = letters, adjust = "tukey"
) %>% as.data.frame()
write.csv(cld_dat, "Yield_TreatmentLetters_withinGenotype.csv", row.names = FALSE)

## 字母位置
plot_letters <- left_join(
  cld_dat,
  dat_y %>% group_by(Genotype, Treatment) %>%
    summarise(y = max(Yield), .groups="drop") %>%
    mutate(y = y + 0.08 * diff(range(dat_y$Yield))),
  by = c("Genotype","Treatment")
)

## 只在 Liangnuo 01 分面标 F / P
fp_dat <- data.frame(
  Genotype = factor("Liangnuo 01", levels = levels(dat_y$Genotype)),
  x = Inf,
  y = max(sum_dat$mean + sum_dat$sem) * 1.15,
  label = lab_y
)

## ================= 作图（严格按你给的模板结构） =================
p2 <- ggplot(sum_dat, aes(Treatment, mean, fill = Treatment)) +
  geom_col(width = .65, color = "black", alpha = .85) +
  geom_errorbar(aes(ymin = mean - sem, ymax = mean + sem), width = .2) +
  geom_jitter(
    data = dat_y,
    aes(Treatment, Yield),
    width = .12,
    size = 1.5,
    alpha = .6,
    inherit.aes = FALSE
  ) +
  geom_text(
    data = plot_letters,
    aes(Treatment, y, label = .group),
    size = 5,
    inherit.aes = FALSE
  ) +
  geom_text(
    data = fp_dat,
    aes(x, y, label = label),
    hjust = 1.05,
    vjust = 1,
    size = 4,
    inherit.aes = FALSE
  ) +
  facet_wrap(~ Genotype, nrow = 1) +
  labs(x = NULL, y = expression(Yield~(10^2~kg~hm^-2))) +
  theme_bw() +
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 25, hjust = 1),
    strip.background = element_rect(fill = "grey90"),
    strip.text = element_text(face = "bold")
  )

print(p2)

ggsave("Yield_Bar_Scatter_SEM_Letters_ANOVA_FP_LiangnuoOnly.pdf",
       p2, width = 10, height = 4.5)
