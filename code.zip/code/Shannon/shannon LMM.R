## =========================
## 0. 环境
## =========================
rm(list = ls())
options(stringsAsFactors = FALSE)

library(tidyverse)
library(vegan)
library(rstatix)
library(multcompView)
library(ggplot2)

## =========================
## 1. 工作路径
## =========================
setwd("D:/IUE/山西数据/真菌/抽平/群落分类水平结构分析/群落结构分析")

## =========================
## 2. 读取数据
## =========================
asv_raw <- read.csv("叶际F_ASV.csv", check.names = FALSE)
group   <- read.csv("叶际分组.csv", check.names = FALSE)

## =========================
## 3. 分组信息
## =========================
colnames(group)[1] <- "Sample"
grp_col <- if ("Group" %in% colnames(group)) "Group" else colnames(group)[2]

meta <- group %>%
  mutate(
    Period = case_when(
      str_detect(.data[[grp_col]], "^JS_") ~ "Jointing stage",
      str_detect(.data[[grp_col]], "^HS_") ~ "Heading stage",
      str_detect(.data[[grp_col]], "^FS_") ~ "Filling stage",
      str_detect(.data[[grp_col]], "^MS_") ~ "Maturity stage"
    ),
    Drought = case_when(
      str_detect(.data[[grp_col]], "_Control$")   ~ "Control",
      str_detect(.data[[grp_col]], "_Drought_L$") ~ "Drought_L",
      str_detect(.data[[grp_col]], "_Drought_M$") ~ "Drought_M",
      str_detect(.data[[grp_col]], "_Drought_H$") ~ "Drought_H"
    )
  ) %>%
  filter(!is.na(Period), !is.na(Drought))

period_levels <- c(
  "Jointing stage",
  "Heading stage",
  "Filling stage",
  "Maturity stage"
)

meta$Period  <- factor(meta$Period,  levels = period_levels)
meta$Drought <- factor(
  meta$Drought,
  levels = c("Control","Drought_L","Drought_M","Drought_H")
)

## =========================
## 4. 计算 Shannon
## =========================
sample_cols <- intersect(meta$Sample, colnames(asv_raw))

asv_mat <- asv_raw %>%
  select(all_of(sample_cols)) %>%
  mutate(across(everything(), as.numeric)) %>%
  t()

df <- data.frame(
  Sample  = rownames(asv_mat),
  Shannon = vegan::diversity(asv_mat, index = "shannon")
) %>%
  left_join(meta, by = "Sample")

## —— 输出 Shannon（样本水平）——
write.csv(
  df,
  file = "叶际_Shannon_perSample.csv",
  row.names = FALSE
)

## =========================
## 5. Dunn 检验 + 显著性字母
## =========================
dunn_list    <- list()
letters_list <- list()

for(p in period_levels){
  
  sub <- df %>% filter(Period == p)
  
  dunn <- dunn_test(
    Shannon ~ Drought,
    data = sub,
    p.adjust.method = "BH"
  )
  dunn$Period <- p
  dunn_list[[p]] <- dunn
  
  letters <- multcompLetters(
    setNames(
      dunn$p.adj,
      paste(dunn$group1, dunn$group2, sep = "-")
    )
  )$Letters
  
  pos <- sub %>%
    group_by(Drought) %>%
    summarise(
      y = max(Shannon) + 0.08 * diff(range(df$Shannon)),
      .groups = "drop"
    )
  
  letters_list[[p]] <- data.frame(
    Period  = p,
    Drought = names(letters),
    Letter  = letters,
    y       = pos$y,
    stringsAsFactors = FALSE
  )
}

letters_df <- bind_rows(letters_list)
dunn_df    <- bind_rows(dunn_list)

letters_df$Period <- factor(letters_df$Period, levels = period_levels)

## —— 输出 Dunn 结果 ——
write.csv(
  dunn_df,
  file = "叶际_Shannon_Dunn_results.csv",
  row.names = FALSE
)

## =========================
## 6. 趋势检验（线性）
## =========================
trend_df <- df %>%
  mutate(Drought_num = as.numeric(Drought)) %>%
  group_by(Period) %>%
  do({
    m <- lm(Shannon ~ Drought_num, data = .)
    data.frame(p = summary(m)$coefficients[2, 4])
  }) %>%
  mutate(
    signif = case_when(
      p < 0.001 ~ "***",
      p < 0.01  ~ "**",
      p < 0.05  ~ "*",
      TRUE ~ "ns"
    )
  )

trend_df$Period <- factor(trend_df$Period, levels = period_levels)

## —— 输出趋势结果 ——
write.csv(
  trend_df,
  file = "叶际_Shannon_Trend_results.csv",
  row.names = FALSE
)

## =========================
## 7. 作图（最终版）
## =========================
p <- ggplot(df, aes(x = Drought, y = Shannon)) +
  
  geom_boxplot(
    aes(fill = Drought),
    width = 0.55,
    outlier.shape = NA
  ) +
  
  geom_jitter(
    width = 0.12,
    size = 1.8,
    shape = 21,
    fill = "white",
    color = "black",
    stroke = 0.2
  ) +
  
  geom_smooth(
    aes(x = as.numeric(Drought), group = Period),
    method = "lm",
    se = FALSE,
    color = "#6A8EC9",
    linewidth = 1.2
  ) +
  
  geom_text(
    data = letters_df,
    aes(x = Drought, y = y, label = Letter),
    size = 3,
    inherit.aes = FALSE
  ) +
  
  geom_text(
    data = trend_df,
    aes(x = 2.5, y = min(df$Shannon) - 0.10, label = signif),
    size = 5,
    inherit.aes = FALSE
  ) +
  
  facet_wrap(~ Period, nrow = 1) +
  
  scale_fill_manual(values = c(
    "Control"   = "#F8766D",
    "Drought_L" = "#7CAE00",
    "Drought_M" = "#00BFC4",
    "Drought_H" = "#C77CFF"
  )) +
  
  coord_cartesian(clip = "off") +
  
  theme_classic() +
  theme(
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.6),
    
    ## 去掉 X 轴
    axis.text.x  = element_blank(),
    axis.ticks.x = element_blank(),
    axis.title.x = element_blank(),
    
    ## 灰色分面标题
    strip.background = element_rect(
      fill = "grey85",
      colour = "black",
      linewidth = 0.6
    ),
    strip.text = element_text(face = "bold"),
    
    plot.margin = margin(10, 10, 25, 10)
  ) +
  
  labs(
    y = "Shannon diversity index",
    fill = "Drought treatment",
    title = "Phyllosphere fungal Shannon diversity"
  )

print(p)

## —— 输出最终图 ——
ggsave(
  filename = "叶际_Shannon_diversity.pdf",
  plot = p,
  width = 12,
  height = 4,
  dpi = 300
)
